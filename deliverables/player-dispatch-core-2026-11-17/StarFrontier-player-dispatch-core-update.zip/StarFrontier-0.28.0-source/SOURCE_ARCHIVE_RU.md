# Состав скачиваемого ZIP исходников

<!-- PLAYER_DISPATCH_CORE_CURRENT_BEGIN -->
Готовится кумулятивная контрольная точка **player-dispatch-core-2026-11-17**,
PREPUB. Для полного проекта нужны **два ZIP**: точная основа0.28 и новое
обновление player-dispatch. Оно содержит также предыдущее ядро reference-bank
со всеми необходимыми native-proof зависимостями; прежнее малое обновление
отдельно не требуется. Общий каталог — `StarFrontier-0.28.0-source/`.
Все игровые ресурсы остаются в основе. Новые модули, 149-модельный ресурс,
тесты, семь native-банков, инструменты и доказательства сохраняются полностью.
[Описание](docs/SOURCE_PLAYER_DISPATCH_RU.md).
<!-- PLAYER_DISPATCH_CORE_CURRENT_END -->

<!-- REFERENCE_BANK_CORE_CURRENT_BEGIN -->
Опубликована контрольная точка **reference-bank-core-2026-11-17**.
Для полного проекта нужны **два ZIP**:

1. [Основа 0.28](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/f6d802e5f34f735eef91fdc2670bc8850443511a/deliverables/0.28.0-native-station-alpha1/StarFrontier-0.28.0-native-station-source.zip) — **33 543 341 байт**,
   SHA256 `830e7219879f694a24e41f579417986f936902f6592926ff8e84dc99217b6c2d`.
2. [Обновление ядра](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/c7a0ec46371e3ac372aea6a2faaa997f38ff515e/deliverables/reference-bank-core-2026-11-17/StarFrontier-reference-bank-core-update.zip) — **1 312 879 байт**,
   SHA256 `c1d1567d77b4eb20f5d017444fc5c27721c7984cbb5af17ccb19c6db9deb816a`.

Оба меньше 32 МиБ. Сначала распакуйте основу, затем обновление в одну
родительскую папку. Общий префикс — `StarFrontier-0.28.0-source/`.
В обновлении **89 файлов**; после наложения — **1743 файла**. Сохранены все
ресурсы основы, текущие модули, тесты, три новых native-банка, инструменты,
документы и обязательные native-proof зависимости, включая linker-скрипт.

Точный source-коммит — `4380a069c569a1a094970d226f3204112c12d2c7`;
artifact-коммит — `c7a0ec46371e3ac372aea6a2faaa997f38ff515e`.
Чистая распаковка: запуск **10/0**, новые модули **20 721/0**,
побайтное воспроизведение **1921 DOS-контроля / 16 отдельных диагностик**,
все 1743 исходных файла неизменны. Проверены семь полных HTTPS-загрузок.
[Контракт](docs/SOURCE_REFERENCE_BANK_RU.md) ·
[Публикация](validation/reference-bank-publication-2026-11-17/verification.json).
Исходный ZIP обновления и манифест сохраняют состояние source-коммита;
документы внутри него содержат PREPUB-запись до проверки публикации.
Игровой APK остаётся 0.28; новые ядра ещё не подключены к Main.
<!-- REFERENCE_BANK_CORE_CURRENT_END -->

В состав исходников 0.13.1/0.13.2/0.14.0/0.15.0/0.16.0/0.17.0/0.18.0/0.19.0/0.20.0/0.21.0/0.22.0 входит `validation/parity-audit-2026-11-07/`:
машинная опись оригинальных ресурсов, функций и данных, матрица пропусков
и доказательные записи пяти новых аудитов. Это компактное исключение из
общего исключения `validation/`; скриншоты, кеши, APK и полные журналы
сборок по-прежнему находятся отдельно. Полнота исходной retail-игры и
наличие CD-медиа данным архивом не заявляются.

ZIP содержит текущий проект Godot, все рабочие изображения и игровые данные,
скрипты, сцены, тесты, инструменты сборки и генераторы текстур, документацию
и исторически восстановленные исходные фрагменты.

<!-- NATIVE_STATION_CURRENT_BEGIN -->
Опубликован **0.28.0-native-station-alpha1 / code 53**.
[Скачать точный ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/f6d802e5f34f735eef91fdc2670bc8850443511a/deliverables/0.28.0-native-station-alpha1/StarFrontier-0.28.0-native-station-source.zip).

Точный ZIP из исходного коммита `de8eb18a687d007781321436910187dff3785775`:
**33 543 341 байт / 1 660 файлов /
1 829 ZIP-записей**, меньше 32 МиБ. Свежие импорт и
запуск — **10/0**. Повтор в чистом ZIP: **490/0 — один Main
(114) и два pure-набора (157 + 219)**; это не три сценария Main. Все
**1 660 файлов** после проверок неизменны. Повторные
проверки переносимости остаются отдельно от функциональной суммы.

SHA256 исходного ZIP: `830e7219879f694a24e41f579417986f936902f6592926ff8e84dc99217b6c2d`.

В ZIP сохранены все текущие runtime, изображения, игровые данные,
тесты, инструменты, документация и `recovered-history/`. Добавлены
`native_station_frame.gd`, `native_station_trial.gd`, их UID и проверки.
Для ограничения 32 МиБ не дублируются прежние QA 0.27, кроме обязательного
`runtime-freeze.json`, и её прежняя проверка переносимости. Они остаются
в GitHub и точном архиве 0.27. Необходимые старые `native-proof/`, включая
зависимости прежних 0.26/0.25, сохранены. Технический APK-отчёт
`android-verification.json` поставляется отдельно с APK и не требуется
для сборки исходников. Четыре кадра и их capture-manifest/visual-review,
`capture-runtime-inputs.json`, `capture.log` и полный
`packaging-unit-tests.log` доступны отдельно в том же наборе сборки.
Сводка Python и все текущие функциональные отчёты включены в ZIP.
Файлы репозитория и история исходников этой политикой не удаляются.

Текущая функциональная сводка: **108 430 условий /
47 уникальных групп / 0 ошибок**. Новый блок содержит один сценарий
настоящего Main — **114/0**, два pure-набора Frame/Trial — **157/0 и 219/0**.
Отдельно: **431 Python-тест в 16 модулях**, **четыре осмотренных desktop-кадра /
1 512 проверок захвата**, прежний native-банк **402 случая /
6208 условий**. Повторы, захват, Python и прежний native-банк не прибавлены
к функциональной сумме; нового исходного native-эталона нет.

Проверен ARM64 TEST APK **code 53**, SDK 24/36,
16-КиБ выравнивание. Закреплены **475 runtime-входов**: из прежних 471
неизменны 468, изменены три, добавлены четыре. Проверены **58 основных
скомпилированных модулей**, включая два новых; **55 прежних модулей,
кроме Main, побайтно сохранены**.

Проверены **девять полных HTTPS-скачиваний**: манифест, APK,
исходники, протокол захвата, четыре PNG и настоящий ZIP-отчёт с сохранением.
Для всех получены HTTP 200 и совпадение размеров/SHA; CRC архивов и
Git-комментарий исходного ZIP совпали. Локально проверены все
**110 payload**; остальные **102 вспомогательных файлов
отдельно через HTTP не скачивались**. [Подтверждение публикации](validation/native-station-publication-2026-11-16/verification.json).
Artifact-коммит: `f6d802e5f34f735eef91fdc2670bc8850443511a`. Запечатанные манифест и исходный ZIP
не изменяются; документы внутри ZIP сохраняют PREPUB-состояние исходного
коммита. Итог публикации записан в текущем checkout.

[Контракт и границы](docs/SOURCE_NATIVE_STATION_RU.md).
<!-- NATIVE_STATION_CURRENT_END -->

<!-- NATIVE_RETURN_CURRENT_BEGIN -->
Опубликован **0.27.0-native-return-alpha1 / code 52**.
[Скачать точный ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/306095e9ea066639ee66e8a2104cd68a61fba342/deliverables/0.27.0-native-return-alpha1/StarFrontier-0.27.0-native-return-source.zip) из коммита
`1909e283fa6a9d4dfd2d57245ce3af82eebd7a45`: **33 420 254 байта / 1641 файл /
1810 ZIP-записей**, меньше 32 МиБ. SHA256:
`673ec87cdfb9434c778f11fb70fb0b443fb6811ca0e96f0eea534b02cbca391b`.

Добавлены `native_orbit_return.gd`, `dock_approach_guidance.gd`, их UID,
проверки обратного перехода, настоящего снижения/посадки и штатного дока,
а также переносимый code51 baseline. Все текущие runtime, изображения,
игровые данные, тесты, инструменты и `recovered-history/` сохранены.

Свежие импорт и обычный запуск — **10/0**, три отдельных сценария Main —
**308/0 (77 + 83 + 148)**. Прежний native-банк **402 случая / 6208 условий**
воспроизведён побайтно; все **1641 файл** после проверок неизменны.
Функциональная сводка **107 940 / 44 группы / 0 ошибок**; отдельно
393 Python-теста в 15 модулях. Проверки переносимости и старый банк
не прибавлены к функциональной сумме. Закреплён **471 runtime-вход**.

APK, ZIP, манифест, протокол захвата, четыре PNG и настоящий ZIP-отчёт
с сохранением проверены **девятью полными HTTPS-скачиваниями**:
HTTP 200, размеры/SHA, CRC и Git-комментарий совпали. Все **98 payload**
проверены локально; **90 вспомогательных файлов отдельно по HTTP
не скачивались**. [Подтверждение](validation/native-return-publication-2026-11-16/verification.json).
Artifact-коммит: `306095e9ea066639ee66e8a2104cd68a61fba342`.
Документы внутри точного ZIP сохраняют PREPUB-состояние исходного коммита;
итоговая запись о публикации находится в текущем checkout.

Чтобы ZIP оставался меньше 32 МиБ, в него не дублируются прежние QA-отчёты
и журналы 0.26 из `validation/native-autopilot-2026-11-16/`, кроме обязательного
`runtime-freeze.json`, и её историческая `native-autopilot-source-portability`.
Они остаются в GitHub и точном ZIP 0.26 ниже. Прежнее исключение двух
резервных recovery ZIP и дублирующих QA 0.25 сохраняется; весь необходимый
`native-proof/`, исходники и код проверок включены. Технический отчёт
`android-verification.json` поставляется отдельно с проверенным APK;
его большая копия не требуется для сборки исходников. Функциональные
отчёты текущих 44 групп и все исходники проверок включены в ZIP.
Ни один файл репозитория не удаляется; история исходников сохранена.
[Контракт и границы](docs/SOURCE_NATIVE_RETURN_RU.md).
<!-- NATIVE_RETURN_CURRENT_END -->

<!-- NATIVE_AUTOPILOT_CURRENT_BEGIN -->
Опубликован **0.26.0-native-autopilot-alpha1 / code 51**.
[Скачать точный ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/a5782a1d90804ff4b7cab9e1c07b9e71f046ad55/deliverables/0.26.0-native-autopilot-alpha1/StarFrontier-0.26.0-native-autopilot-source.zip) из коммита
`382723e75bc5030a44fa1dc640bc5229ea7481fa`: **33 472 195 байт**,
**1603 файла / 1771 ZIP-запись**, меньше 32 МиБ. SHA256:
`ceb3c64f6a6e59a1caf545e5261dedcad4faa791767cb1699eddba681b063d4c`.

Добавлены `native_surface_autopilot.gd`, `native_orbit_trial.gd`, их UID,
проверки трёх последовательных фаз настоящего Main и переносимый code50 baseline.
Свежие импорт/обычный запуск — **10/0**, три отдельных сценария Main —
**284/0**; прежний native-банк **402 случая / 6208 условий** воспроизведён
побайтно. Все **1603 файла**, **467 runtime-входов** и **724 закреплённых
входа исходных доказательств** проверены; файлы архива остались неизменными.
Функциональная сводка **51 420 / 32 группы / 0 ошибок**, отдельно 362 Python-теста.
Повторные проверки ZIP не добавлены к этим итогам.

APK, ZIP, манифест, четыре PNG, протокол захвата и настоящий отчёт с
сохранением проверены **девятью полными HTTPS-скачиваниями**: HTTP 200,
размеры/SHA, CRC и исходный Git-комментарий совпали.
[Подтверждение](validation/native-autopilot-publication-2026-11-16/verification.json).
Artifact-коммит: `a5782a1d90804ff4b7cab9e1c07b9e71f046ad55`.
Документы внутри точного ZIP сохраняют PREPUB-состояние исходного коммита;
итоговая запись о публикации находится в текущем checkout.

Для исторического аудита code50 используется компактный переносимый
source-baseline, связанный с предыдущими закреплёнными baseline-файлами;
исторический checkout и подмена compiled-байтов APK для этого не нужны.
Проверяемый архив включает весь текущий runtime, ресурсы, тесты,
инструменты, документацию, `recovered-history/` и зависимости native-контролей.

Чтобы исходники можно было снова прикрепить в чат, ZIP остаётся меньше
32 МиБ. Как и в 0.25, исключены два дублирующих резервных ZIP из `recovery/`.
Дополнительно не дублируются устаревшие QA-отчёты и журналы 0.25 из
`validation/contact-lifecycle-2026-11-15/`: они сохранены в GitHub и точном
архиве 0.25. Из этого каталога в новом ZIP остаются **весь `native-proof/`
и закреплённый `runtime-freeze.json`**, необходимые для воспроизведения
и проверки code50. Актуальные отчёты 0.26 включены.

Все рабочие исходники, assets, данные, тесты, инструменты, вся история
`recovered-history/` и зависимости native-проверок сохраняются. Файлы
репозитория не удаляются; исходный проект отделён от APK, кадров и кешей.
[Предыдущий точный ZIP 0.25](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/cd75c3df01bc8a72b4899307798ef454944706d0/deliverables/0.25.0-native-landing-alpha1/StarFrontier-0.25.0-native-landing-source.zip).

Формат отдельного космического trial-сеанса и сохранённые границы
host-наведения описаны в [контракте](docs/SOURCE_NATIVE_AUTOPILOT_RU.md).
<!-- NATIVE_AUTOPILOT_CURRENT_END -->

<!-- NATIVE_LANDING_CURRENT_BEGIN -->
Опубликован **0.25.0-native-landing-alpha1 / code 50**. Источники
нового блока — `source_natural_contact_session.gd`,
`source_natural_park.gd`, `source_native_surface_provider.gd`,
`source_native_surface_visual.gd`, `native_surface_model.gd`
и `native_landing_trial.gd`, их тесты и компактные независимые native-
доказательства. [Точный ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/cd75c3df01bc8a72b4899307798ef454944706d0/deliverables/0.25.0-native-landing-alpha1/StarFrontier-0.25.0-native-landing-source.zip) из `efef2cadaec58448b32c50a8d585a3c1d4902cc6`:
33 223 581 байт, 1579 файлов, 1748 ZIP-записей; SHA256
`c46bc666447d5e98350944fdf32b8a30bfacecd453ad937beacbd65a558fdeb4`.
Свежие импорт/запуск, 48 проверок Main и 402 native-сценария воспроизведены;
все файлы архива остались побайтно прежними. Полное HTTPS-скачивание проверено.
[Доказательства переносимости](validation/native-landing-source-portability-2026-11-15/verification.json).

Новый переносимый baseline `tests/fixtures/native_landing_v49_sources.json`
содержит только пять точных runtime-дельт и два файла метаданных 0.24.
Он раскрывается через закреплённые baseline 48 и 47 в 46 прежних runtime-
исходников. Для исторической проверки не нужны старый checkout, Git
или подмена compiled-байтов APK. SHA нового baseline:
`15b53e7150cc67624b73dc92dfe4c06100541b22f66e979246bd7f5cd8089b71`.

Чтобы сохранить скачиваемый исходный ZIP меньше 32 МиБ, в новый архив
**не дублируются только два старых ZIP внутри `recovery/`**:
`StarFrontier_recovered_sources_2026-11-04_checkpoint1.zip` и
`StarFrontier_recovered_sources_2026-11-04_expanded.zip`.
Их MANIFEST/SHA-файлы остаются в новом архиве. Сами исторические ZIP
остаются в GitHub и в
[полном исходном архиве 0.24](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/StarFrontier-0.24.0-contact-frame-source.zip).
Файлы репозитория не удаляются. **Все `recovered-history/`, текущие assets,
данные, тесты и зависимости native-генераторов сохраняются**, включая
`recovered-history/ground_harness/` и другие реально используемые проекты.
Исключение касается вложенных резервных ZIP, а не рабочих исходников.

В коде отдельно отмечены ограниченная область буквальных leaf-провайдеров,
ручной режим и host-адаптеры. Автопосадка, полный object bank/VM и полный
клон всех исходных механик этим блоком не объявляются готовыми.
[Подробный контракт](docs/SOURCE_NATIVE_LANDING_RU.md).
<!-- NATIVE_LANDING_CURRENT_END -->

<!-- CONTACT_FRAME_CURRENT_BEGIN -->
Предыдущая опубликованная версия исходников — **0.24.0-contact-frame-alpha1 /
code 49**. Добавлены `source_terrain_query_frame.gd`,
`source_native_contact_geometry.gd`, `source_contact_geometry_probe.gd`
и `native_contact_geometry_view.gd` с UID. Исходные кадры и integer-leaf
данные связаны с объявленной проекцией и выведенными интервалами
Q31/Float32. Каноническая проекция с нулевыми младшими SAR-битами
и полный диапазон младших битов F579 SAR хранятся раздельно.

Нативно проверен настоящий `qOrigin = C + T(−D)`; старый `C − T(D)`
сохранён отдельно, поскольку Q31-floor операции не нечётны. Набор
содержит **242 случая: 230 frame и 12 перехваченных caller**,
237 наблюдений F581, 236 кадров запроса и 187 проверенных solid-leaf
пакетов. Полное выполнение цепочки F575 этим не заявляется.

Функциональная сводка — **50 326 условий в 23 уникальных группах /
0 ошибок**. Отдельно прошли **328 Python-тестов упаковки в 12 модулях**,
native-валидатор **400/0** и **четыре осмотренных настоящих desktop-кадра
Main — 73 условия / 0 ошибок**. Заморожен **451 runtime-вход**:
440 из 443 прежних неизменны; изменены только Main/BuildInfo/preset,
добавлены четыре модуля и четыре UID. Исторические суммы, отдельные
проверки и повторы не прибавлены к 50 326.

Main получил команду **«Исходная геометрия контакта»**: отдельный
3D-предпросмотр и полный контекст ZIP-отчёта. Обычный рельеф, default v4
и живой F575 сохранены. Основа координат/проекции шага 1 готова;
публикуемый provider и жизненный цикл контакта относятся к шагу 2,
ручная/автоматическая посадка — к шагу 3.

Настоящий ARM64 TEST APK49 технически проверен: **50 304 669 байт**,
SHA256 `7624dd646e8685aad30e0e47131b4a631526b84337cca9196d90e08cbfb5795b`,
min SDK 24 / target SDK 36, `debuggable=false`, ZIP/ELF 16 КиБ.
Проверены четыре новых и 46 интеграционных compiled-модулей,
121 сохранённый метод Main и 51 карта материалов; TEST-подпись прежняя.

Точный source ZIP — **33 490 647 байт / 1644 записи / 1482 файла**,
меньше 32 МиБ. Исходный коммит `99167cc4f335936567d1185a69040420448dedc8`.
SHA256: `e43c4d469aa69e34dca8545f55a531abbac0d906ecc78f7ff5fa0b60abd3e307`.
Свежий импорт/обычный изолированный запуск — **10/0**, настоящий
Main из ZIP — **63/0**, включённый native-генератор и валидатор —
**400/0** с побайтным воспроизведением fixture. Все **1482 файла**
после проверок неизменны; все **451 runtime-вход** совпали с freeze.
Повторные проверки переносимости не прибавлены к функциональным группам.
[Импорт/запуск](validation/contact-frame-source-portability-2026-11-14/verification.json),
[Main из ZIP](validation/contact-frame-source-portability-2026-11-14/contact-frame-main-feature.json),
[воспроизводимость native](validation/contact-frame-source-portability-2026-11-14/source-native-reproduction.json).

[Скачать APK 0.24.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/StarFrontier-0.24.0-contact-frame-arm64.apk) · [Исходники 0.24.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/StarFrontier-0.24.0-contact-frame-source.zip)

[Предпросмотр исходной грани](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/screenshots/02-actual-native-contact-geometry.png) · [Поворот предпросмотра](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/screenshots/03-rotated-native-contact-geometry.png) · [Настоящий диагностический ZIP без сохранения](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/0d45eb7b27e16e73761c14dd262d8ec413819470/deliverables/0.24.0-contact-frame-alpha1/sample-diagnostic-report.zip)

Полным HTTPS-скачиванием проверены **девять файлов**: манифест,
APK, source ZIP, протокол захвата, четыре PNG и диагностический ZIP.
HTTP 200, размеры, SHA, CRC архивов и исходный Git-комментарий ZIP
совпали. Локально проверены все **75 payload-записей** манифеста;
остальные **67 вспомогательных файлов отдельно через HTTP не скачивались**.
[Проверка публикации](validation/contact-frame-publication-2026-11-14/verification.json). Artifact-коммит
`0d45eb7b27e16e73761c14dd262d8ec413819470`. Документы внутри точного source ZIP
сохраняют PREPUB-состояние исходного коммита.

[Заметка о сборке](docs/RELEASE_0_24_0_RU.md),
[контракт](docs/SOURCE_CONTACT_FRAME_RU.md). Прежние источники,
доказательства и опубликованные архивы 0.23 сохранены. Физический
телефон и полный клон этим блоком не подтверждаются.
<!-- CONTACT_FRAME_CURRENT_END -->

<!-- FOOTPRINT_CURRENT_BEGIN -->
Предыдущая опубликованная версия исходников — **0.23.0-footprint-alpha1 /
code 48**. Новые модули `source_terrain_query_trace.gd` и
`source_natural_footprint_probe.gd` сохраняют фактически посещённые
объёмы F576, исходные смещённые центры/пороги/масштабы, выбранные
целочисленные треугольники F1876 и происхождение высоты. Старые raw-ядра,
fixtures и доказательства 0.21/0.22 сохраняются.

Команда Main **«Проверить контакт всего корабля»** сохраняет полный
снимок в текущем и последнем периодическом контекстах ZIP-отчёта,
а в ограниченном журнале — компактную запись со ссылкой по SHA256.
Снимок временный: обычный save не получает новой секции; возврат
из графического просмотра восстанавливает снимок исходной сессии.

Функциональная сводка — **64 484 условия в 25 уникальных группах /
0 ошибок**. Отдельно прошли **312 Python-тестов упаковки в 11 модулях**
и native-валидатор **1833/0**. Сняты и осмотрены **три настоящих
desktop-кадра Main — 61 условие / 0 ошибок**. Заморожены **443
runtime-входа**: 436 из 439 прежних неизменны, изменены только
Main/BuildInfo/preset; добавлены два модуля и два UID. Отдельные
проверки, старые суммы и повторы не прибавлены к 64 484.

Новый fixture содержит **158 native-случаев: 65 actor и 93 groundpoint**,
202 посещённых объёма и 188 выбранных треугольников; 187 запросов
свежие и один ограниченный. SHA256 fixture:
`7fa98e4dd0b63ec9c0a608b9a11ec032aae2d55861c018212aeb50080d8bf726`.
Воспроизводимые наблюдения находятся в
`validation/footprint-2026-11-14/native-proof/`. Точный source ZIP
включает эти исходники/генератор и необходимые прежние native-proof
зависимости; старые доказательства не переписаны.

Настоящий ARM64 TEST APK48 технически проверен: **50 250 655 байт**,
SHA256 `3566e7e174ce2b162877a394bbdb88a145c570dfabf30926a1675aab43d4a793`,
min SDK 24 / target SDK 36, `debuggable=false`, ZIP/ELF 16 КиБ.
Проверены два новых и 42 интеграционных compiled-модуля, 119 прежних
методов Main и 51 карта материалов. Использована прежняя TEST-подпись.

Точный ZIP — **33 229 194 байта / 1596 записей / 1436 файлов**,
меньше 32 МиБ. Исходный коммит `a096346eb558c07f45b966f4e622ef7b1fff4e5b`.
SHA256: `eb01da63b1694bbbd4e16d12977bdc88be639004790b99c3fddc880a2b07fce2`.
Свежий импорт/обычный изолированный запуск — **10/0**, настоящий
Main из ZIP — **54/0**. Включённый оригинальный native-генератор
и валидатор — **1833/0**, fixture воспроизведён побайтно.
Все **1436 файлов** после проверок неизменны; все **443 runtime-входа**
совпали с freeze. Эти повторы не добавлены к функциональным группам.
[Свежий импорт/запуск](validation/footprint-source-portability-2026-11-14/verification.json),
[Main из точного ZIP](validation/footprint-source-portability-2026-11-14/footprint-main-feature.json),
[побайтная native-воспроизводимость](validation/footprint-source-portability-2026-11-14/source-native-reproduction.json).

[Скачать APK 0.23.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4453064042ab45123e9386807619ac874daab51a/deliverables/0.23.0-footprint-alpha1/StarFrontier-0.23.0-footprint-arm64.apk) · [Исходники 0.23.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4453064042ab45123e9386807619ac874daab51a/deliverables/0.23.0-footprint-alpha1/StarFrontier-0.23.0-footprint-source.zip)

[Проверка всего корабля](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4453064042ab45123e9386807619ac874daab51a/deliverables/0.23.0-footprint-alpha1/screenshots/02-actual-full-ship-contact-check.png) · [Настоящий диагностический ZIP без сохранения](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4453064042ab45123e9386807619ac874daab51a/deliverables/0.23.0-footprint-alpha1/sample-diagnostic-report.zip)

Полным HTTPS-скачиванием проверены **восемь файлов**: манифест,
APK, source ZIP, протокол захвата, три PNG и диагностический ZIP.
HTTP 200, размеры, SHA, CRC архивов и исходный Git-комментарий ZIP
совпали. Локально проверены все **61 payload-запись** манифеста;
остальные **54 вспомогательных файла отдельно через HTTP не скачивались**.
[Проверка публикации](validation/footprint-publication-2026-11-14/verification.json). Artifact-коммит
`4453064042ab45123e9386807619ac874daab51a`. Документы внутри точного source ZIP
сохраняют PREPUB-состояние исходного коммита.

Совпадение всей видимой сетки, работающий банк F569/F570 и новый
живой F576-response не заявляются; default v4 сохраняется.
[Заметка о сборке](docs/RELEASE_0_23_0_RU.md),
[точный контракт](docs/SOURCE_FOOTPRINT_RU.md). Физический S23 Ultra,
полный клон и магазинный релиз не подтверждены.
<!-- FOOTPRINT_CURRENT_END -->

<!-- ALIGNMENT_CURRENT_BEGIN -->
Последняя проверенная опубликованная версия исходников — **0.22.0-contact-alignment-alpha1 /
code 47**. В неё добавлены signed-root field
`source_terrain_contact_field.gd`, явная поверхность
`source_contact_surface_terrain.gd`, чистый
`source_natural_surface_bridge.gd` и read-only
`source_contact_alignment_probe.gd` вместе с native fixtures,
измерительной матрицей и проверками потребителей.

Прежний F879 sampler и raw collision kernels сохраняются. Новая
v5 имеет отдельную ревизию: подтверждение узлов не распространяется
на интерполированные точки и треугольники. Восстановление и фабрики
понимают явную v5, но предпочтительные новые входы и прежние v4-сохранения
остаются прежними. Main не включает новый default F576-response.

Матрица — **2403 классификации / 7401 условие / 0 ошибок**.
Независимый root-набор — **459 native-случаев**: 153 геометрических
и 306 настоящих player-классификаций; ядро — **3802/0**.
51 опора содержит 39 точных нулей и 12 adjacent boundaries шириной
параметра луча 1 raw. Старый seed — рассмотренный JJFFE F879 SAR3,
а DOS F879 SAR4 сохраняется отдельно в provenance.

Read-only команда **«Проверить высоту поверхности»** сохраняет последний
диагностический снимок для ZIP-отчёта, без новой схемы игрового save.
Selected child-hit и неподтверждённая видимая точка не разрешают ответ
чистого моста. [Подробный контракт](docs/SOURCE_CONTACT_ALIGNMENT_RU.md).

Финальная функциональная сводка — **22 599 условий в 39 уникальных
группах / 0 ошибок**: 11 601 в шести новых группах, 5382 в 28 прежних,
5534 в четырёх renderer-группах и Main 82. Отдельно прошли **298
Python-тестов** и восемь осмотренных desktop-кадров Main / **103 условия
захвата / 0 ошибок**. Совпали 19 source pins; заморожены 439 runtime-входов,
420 из 431 прежнего сохранены побайтно, 11 изменены; восемь новых —
четыре модуля и их UID.

APK47 проверен: **50 229 793 байта**, SHA256
`edb36a59ab8117b9f42b01723a1de9adc184e7d41595300bb6347d249ea5c845`,
ARM64 TEST, min SDK 24 / target SDK 36, ZIP/ELF-выравнивание 16 КиБ.

Точный source ZIP 0.22 дополнительно включает воспроизводимые
исходные native-контроли: каталоги
`validation/alignment-2026-11-13/native-root-proof/` и
`validation/alignment-2026-11-13/native-altitude-proof/`, а из
`validation/natural-2026-11-13/nativeproof/` — ровно три прежних файла
`natural-native.s`, `excluded-native.s`, `instruction-proofs.json`.
Они нужны генератору с закреплённым относительным путём к оригинальному
assembly/proof. Полные матрицы, GPU-кадры и журналы не включаются этим
исключением. Прежние три источника не переписываются.

Точный ZIP — **32 904 922 байта**, **1569 записей / 1411 файлов**,
меньше 32 МиБ. Исходный коммит `a61d64c348a88986206a5a0804cae8a01e7c93ca`.
SHA256:
`f8cf2ff60f9fe9ae7a58e0956aedef90aaefedc6dfcb6774e988ad5e1af5c984`.
Свежий импорт/обычный изолированный запуск — **10/0**, настоящий Main
из ZIP — **82/0**. Включённый native-генератор повторил 459 случаев
и воспроизвёл fixture побайтно, SHA256
`6cb84a1f6dff615a504c9cac7935f339291831b62a658971110a03c1cb7b6db6`.
Все 1411 исходных файлов после трёх проверок сохранили SHA;
все 439 runtime-входов совпали с freeze. Эти повторы не прибавлены
к функциональным группам и новым native-cases.
[Импорт/запуск](validation/alignment-source-portability-2026-11-13/verification.json),
[Main из ZIP](validation/alignment-source-portability-2026-11-13/alignment-main-feature.json),
[воспроизводимость native](validation/alignment-source-portability-2026-11-13/source-native-reproduction.json).

[Скачать APK 0.22.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/9d9ad1983c7bd96bcb267e5d0655b3672e37969f/deliverables/0.22.0-contact-alignment-alpha1/StarFrontier-0.22.0-contact-alignment-arm64.apk) · [Исходники 0.22.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/9d9ad1983c7bd96bcb267e5d0655b3672e37969f/deliverables/0.22.0-contact-alignment-alpha1/StarFrontier-0.22.0-contact-alignment-source.zip)

[Настоящий диагностический ZIP без сохранения](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/9d9ad1983c7bd96bcb267e5d0655b3672e37969f/deliverables/0.22.0-contact-alignment-alpha1/sample-diagnostic-report.zip)

Полным HTTPS-скачиванием проверены **13 файлов**: манифест, APK,
source ZIP, протокол захвата, восемь PNG и диагностический ZIP.
HTTP 200, размеры, SHA, CRC трёх архивов, число записей и Git-комментарий
ZIP совпали. Все **55 payload-записей** проверены локально; остальные
**43 вспомогательных файла отдельно через HTTP не скачивались**.
[Публикация](validation/alignment-publication-2026-11-13/verification.json).
Публикация завершена **13 ноября 2026 года**, artifact-коммит
`9d9ad1983c7bd96bcb267e5d0655b3672e37969f`. Документы внутри ZIP
сохраняют PREPUB-состояние исходного коммита.
[Состав 0.22](docs/RELEASE_0_22_0_RU.md).
<!-- ALIGNMENT_CURRENT_END -->

<!-- NATURAL_CURRENT_BEGIN -->
Предыдущая опубликованная версия исходников — **0.21.0-natural-contact-alpha1 /
code 46**. Добавлены `source_natural_contact.gd`,
`source_natural_contact_pipeline.gd`, `source_natural_contact_probe.gd`,
`data/ffe_natural_contact.json`, извлекатель, независимые DOS-контроли
и проверки ядра/композиции/настоящего Main.

Ядро использует положительные исходные радиусы Eagle/Cobra/Shuttle
и настоящие предшествующие списки их смещённых объёмов. Поддерживаемая
природная ветвь охватывает 32 модели 117..148. Старая геометрия и
данные остаются закреплены; модель 117 сохраняет исходную несферичность.
Полный VM F580/F583, F578 и F569/F570 этим переносом не закрываются.

Новый живой потребитель только пишет `source_natural_probe` в отчёты:
`diagnostic_only=true`, `response_applied=false`. Результат вычислен
для авторского центра корабля с изолированными начальными globals,
а не для готового банка исходной симуляции. Старая посадочная физика
сохраняется до [согласования поверхности](docs/F576_HEIGHT_ALIGNMENT_RU.md).

Финальная функциональная проверка — **47 045 условий в 28 уникальных
группах / 0 ошибок**: ядро 16 185, композиция 26 592, проба 136,
Main 163, 24 прежние группы 3969. Новый native набор — **993 случая**,
два VM-перехвата отдельно; вся композиция F576 → F575 независимо
в DOS не исполнялась. Байтовая опись — 67 областей / 29 143 байта /
10 055 инструкций — не означает исполнение всех ветвей VM.
Отдельно прошли **295 Python-тестов** (278 упаковки и 17 извлечения),
integration review **75/0** и восемь осмотренных desktop-кадров Main
с **129 условиями захвата / 0 ошибок**.

Настоящий APK46 проверен: **50 183 963 байта**, SHA256
`49f15c7435cf5db66a18e8d79385337be97b4876da911e642d626e1d4a826984`.
Заморожен **431 runtime-вход**; 421 из 424 прежних сохранён побайтно,
изменены только Main с диагностикой, BuildInfo и preset версии.
Добавлены три модуля, их три UID и один JSON. Прежние графика,
полётные/посадочные ядра и общий учёт HP сохранены.

Точный ZIP — **32 397 333 байта**, **1521 запись / 1368 файлов**, меньше
32 МиБ. Исходный коммит `abae633776275a88bf0706893a030e7497ae6ef0`.
SHA256:
`13d0309677062e8e2b8e6e10c5fc48b7bd7e75984adf6925de93df02a4fd6fa1`.
Свежий импорт и изолированный обычный запуск — **10/0**, настоящий
Main из точного ZIP — **163/0**. Все 1368 файлов сохранили SHA;
ZIP совпал со всеми 431 замороженными runtime-входами. Повторы
из ZIP не прибавлены к функциональному итогу.
[Свежий импорт/запуск](validation/natural-source-portability-2026-11-13/verification.json),
[Main из ZIP](validation/natural-source-portability-2026-11-13/natural-main-feature.json).

[Скачать APK 0.21.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/81ced88e551a7c64aaab1212892c50040fcff4f8/deliverables/0.21.0-natural-contact-alpha1/StarFrontier-0.21.0-natural-contact-arm64.apk) · [Исходники 0.21.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/81ced88e551a7c64aaab1212892c50040fcff4f8/deliverables/0.21.0-natural-contact-alpha1/StarFrontier-0.21.0-natural-contact-source.zip)

[Настоящий диагностический ZIP без сохранения](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/81ced88e551a7c64aaab1212892c50040fcff4f8/deliverables/0.21.0-natural-contact-alpha1/sample-diagnostic-report.zip)

Полным HTTPS-скачиванием проверены **13 файлов**: манифест, APK,
source ZIP, протокол захвата, восемь PNG и настоящий диагностический ZIP.
HTTP 200, размеры, SHA, CRC трёх архивов, число записей и исходный
Git-комментарий ZIP совпали. Локально проверены все **108 payload-записей**
манифеста; остальные **96 вспомогательных файлов отдельно через HTTP
не скачивались**. Документы внутри ZIP сохраняют PREPUB-состояние
исходного коммита; эта страница в ветке дополнена после публикации.
[Проверка скачивания](validation/natural-publication-2026-11-13/verification.json).
Публикация завершена **13 ноября 2026 года**, artifact-коммит
`81ced88e551a7c64aaab1212892c50040fcff4f8`.
[Состав блока](docs/RELEASE_0_21_0_RU.md).
Физический телефон и производственная подпись не проверены/не настроены.
<!-- NATURAL_CURRENT_END -->

Историческая опубликованная сборка — **0.20.0-spherical-contact-alpha1 / code 45**.
Добавлены `source_spherical_contact.gd`, чистая ограниченная композиция
`source_spherical_contact_pipeline.gd`, диагностическая проба и
`data/ffe_spherical_contact.json`. Ресурс содержит байтовые доказательства
F577 и 149 строк маршрутизации дескриптора/префикса коллизий F1533.
19 дескрипторов имеют нулевой поток, но инициализированных простых
моделей только 18: для модели 0 F1533 пропускает инициализацию,
фактические начальные флаги и пригодность в таблице остаются NULL.

F577: **363 байта / 128 инструкций**, с шестью вспомогательными областями —
**917 байт / 367 инструкций в семи областях**. Ядро прошло **17 224/0**
на **1141 новом DOS-случае**; изменённый вариант JJFFE — отдельный контроль.
Чистая композиция прошла **2400/0** на 207 поддерживаемых нативных случаях
и шести отдельных контролях перехвата/отката. Её 25 доказанных областей
не означают полного переноса F575, банков объектов, F569/F570/F576/F578.

Живой потребитель только записывает `source_spherical_probe` в диагностику:
`envelope_only=true`, `response_applied=false`, объектного банка нет.
Природный контакт и HP остаются прежними. Финальные проверки —
**23 593 условия в 26 уникальных группах, 0 ошибок**. Отдельно прошли
**260 Python-тестов**: 248 упаковки и 12 извлечения. Восемь настоящих
кадров Main сняты и осмотрены: **128 условий захвата, 0 ошибок**,
desktop GLES/Mesa с подготовленными позициями наблюдателя.
Настоящий ARM64 APK технически проверен: **50 150 546 байт**, SHA256
`db2c38100cb1d7c9a779e18a271f43fab664d30e29217e0dc433f6e20a8de7b7`.
Зафиксированы 424 runtime-файла; 11 исходных отметок захвата совпали.
Из 417 прежних runtime-входов 414 сохранены побайтно; изменены только
Main с диагностикой, BuildInfo и preset версии. Настоящий ZIP-отчёт
содержит новую пробу и исключает сохранение игрока.

Точный ZIP — **32 024 118 байт**, 1494 записи / **1341 файл**, меньше
32 МиБ. Исходный коммит `47903dae5b1688bac688a2568424ce3779489549`. SHA256:
`343bcfab4802dd2666825f382b89164838e30f20ccdfab42db1816d43398a3a3`.
Свежий импорт и обычный изолированный запуск — **10/0**; настоящий
Main с новой диагностикой из точного ZIP — **195/0**. Все 1341 исходный
файл сохранили SHA; ZIP также совпал со всеми 424 замороженными
runtime-входами. Повторы переносимости не прибавлены к 26 группам.
[Свежий импорт и запуск](validation/spherical-source-portability-2026-11-08/verification.json),
[настоящий Main из ZIP](validation/spherical-source-portability-2026-11-08/spherical-main-feature.json).

[Скачать APK 0.20.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/6e23511f96bfb8173f0390b21ebe5c19b79fb8cb/deliverables/0.20.0-spherical-contact-alpha1/StarFrontier-0.20.0-spherical-contact-arm64.apk) · [Исходники 0.20.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/6e23511f96bfb8173f0390b21ebe5c19b79fb8cb/deliverables/0.20.0-spherical-contact-alpha1/StarFrontier-0.20.0-spherical-contact-source.zip)

[Настоящий пример диагностического ZIP без сохранения](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/6e23511f96bfb8173f0390b21ebe5c19b79fb8cb/deliverables/0.20.0-spherical-contact-alpha1/sample-diagnostic-report.zip)

Полным скачиванием проверены **13 файлов**: манифест, APK, source ZIP,
протокол захвата, восемь PNG и настоящий диагностический ZIP через
`--include-file sample-diagnostic-report.zip`. HTTP 200, размеры, SHA,
CRC трёх архивов, число записей и Git-комментарий source ZIP совпали.
Остальные вспомогательные журналы и отчёты проверены по локальному
манифесту; каждый из них отдельно не скачивался. Документы внутри ZIP
сохраняют PREPUB-состояние исходного коммита.
[Проверка скачивания](validation/spherical-publication-2026-11-13/verification.json).

Публикация завершена **13 ноября 2026 года**. Протоколы разработки и
переносимости относятся к исходным запускам 8 ноября по московскому
времени; они не выдаются за повторный прогон всех условий в день публикации.
[Состав и границы блока](docs/RELEASE_0_20_0_RU.md).

Предыдущая опубликованная сборка — **0.19.0-surface-contact-alpha1 / code 44**.
Добавлены `source_surface_contact.gd`, отдельный мобильный мост,
`data/ffe_surface_contact.json`, извлекатель и независимые DOS-контроли.
Обработчик передаёт запросы урона существующему владельцу сырого
корпуса, щита и RNG. Новый постоянный блок состояния контакта не вводится.

Извлечённые исполняемые области содержат 3402 байта / 1259 инструкций
в 21 области, включая 518 инструкций основного продолжения F575.
Полная F575 на 2005 байт / 635 инструкций служит статической привязкой,
а не заявлением полного живого переноса. Источники DOS и изменённые
ветви JJFFE разделены; F577/F578 не подменяются вариантами порта.
Финальный функциональный итог — **22 137 условий в 32 уникальных
группах, 0 ошибок**; ядро — 10 498, мост — 234, общий потребитель HP —
70, Main — 220, прежний Main шасси — 112, регрессии — 11 003.
Отдельно прошли **227 Python-тестов**: 215 упаковки и 12 извлечения.
Восемь настоящих кадров Main сняты и осмотрены: **141 условие захвата,
0 ошибок**, desktop GLES/Mesa с явно подготовленными условиями.
Настоящий ARM64 APK технически проверен: **50 113 019 байт**, SHA256
`0b80d69711ce926314fb567add237f54bc4fad7dfdde983d13586527a525d92d`.
Зафиксированы 417 runtime-файлов; 12 исходных отметок захвата совпали.
Точный ZIP — **31 552 790 байт**, 1469 записей / **1316 файлов**, меньше
32 МиБ. Исходный коммит `5a8b7aa86fe94ac7662e37a7af69944b1f853ac3`. SHA256:
`ce00bb495943086f02a54fddd706755e8e8da92277ab66ae30dc74806d3fdf7a`.
Свежий импорт и обычный изолированный запуск — **10/0**; настоящий
контактный Main из точного ZIP — **220/0**. Все 1316 исходных файлов
сохранили SHA; повторные проверки ZIP не прибавлены к 32 группам.
[Свежий импорт и запуск](validation/contact-source-portability-2026-11-08/verification.json),
[настоящий контактный Main из ZIP](validation/contact-source-portability-2026-11-08/contact-main-feature.json).

[Скачать APK 0.19.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/ced44e68a261c2268f6d941c1dd0be037953dde1/deliverables/0.19.0-surface-contact-alpha1/StarFrontier-0.19.0-surface-contact-arm64.apk) · [Исходники 0.19.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/ced44e68a261c2268f6d941c1dd0be037953dde1/deliverables/0.19.0-surface-contact-alpha1/StarFrontier-0.19.0-surface-contact-source.zip)

Полным скачиванием проверены **12 файлов**: манифест, APK, source ZIP,
протокол захвата и восемь PNG. HTTP 200, размеры, SHA, CRC обоих архивов,
число записей и Git-комментарий source ZIP совпали. Вспомогательные
журналы и отчёты упакованы и хешированы, но каждый из них отдельно не
скачивался. Документы внутри ZIP сохраняют состояние исходного коммита
до удалённой публикации.
[Проверка скачивания](validation/contact-publication-2026-11-08/verification.json).
[Состав и границы блока](docs/RELEASE_0_19_0_RU.md).

Предыдущая опубликованная сборка — **0.18.0-landing-gear-alpha1 / code 43**.
В исходники входят отдельные ядро и сессия шасси, метаданные
`data/ffe_landing_gear.json`, нативные эталоны, извлекатель и проверки
консоли, визуального потребителя, Main и сохранений. Полная F1008
и ограниченная ветвь команды F1056 отделены от ещё не перенесённого
общего диспетчера ввода и событий.

Запрос и физическое положение сохраняются рядом с прежним состоянием
игры. Механизм использует явный мобильный шаг 60 Гц; прежние топливные,
тепловые и навигационные модули этим блоком не переписываются. Полярность
E9 и потребители F1014/посадочного контакта описаны в
[release](docs/RELEASE_0_18_0_RU.md). Ядро прошло 42 935 условий без ошибок
на 2812 DOS-контролях; извлечение — 10 Python-тестов без ошибок.
Финальный функциональный итог — **51 431 условие в 28 уникальных
группах, 0 ошибок**; отдельно **189 Python-тестов** (179 упаковки и десять
извлечения). Сняты и осмотрены восемь настоящих кадров Main: **196 условий
захвата, 0 ошибок**, desktop GLES/Mesa с подготовленными условиями.
Настоящий ARM64 APK технически проверен: **50 071 605 байт**, SHA256
`20f340f1d1c9e8917849d56246123a1f9519b89d730e3568f3ef5f95b671a735`.
Точный ZIP — **31 185 873 байта**, 1447 записей / **1294 файла**, меньше
32 МиБ. Исходный коммит `5c7be752af6cf3167452bb16a970b7a6f30d7cd9`. SHA256:
`89324041e68c1dfce09c7f9b5d5c20c7080396c8bfb3261a2e0c1148776d2b93`.
Свежий импорт и обычный изолированный запуск — **10/0**; фактический
сценарий Main с шасси из точного ZIP — **112/0**. Все 1294 исходных
файла сохранили SHA; повторные проверки ZIP не прибавлены к 28 группам.
[Свежий импорт и запуск](validation/gear-source-portability-2026-11-08/verification.json),
[фактический Main из ZIP](validation/gear-source-portability-2026-11-08/gear-main-feature.json).

[Скачать APK 0.18.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/38a6e59fef50b7d4f5e8c5a19e6a02a17a6c2477/deliverables/0.18.0-landing-gear-alpha1/StarFrontier-0.18.0-landing-gear-arm64.apk) · [Исходники 0.18.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/38a6e59fef50b7d4f5e8c5a19e6a02a17a6c2477/deliverables/0.18.0-landing-gear-alpha1/StarFrontier-0.18.0-landing-gear-source.zip)

Полным скачиванием проверены **12 файлов**: манифест, APK, source ZIP,
протокол захвата и восемь PNG. HTTP 200, размеры, SHA, CRC обоих архивов,
число записей и Git-комментарий source ZIP совпали. Вспомогательные
журналы и отчёты упакованы и хешированы, но каждый из них отдельно не
скачивался. Документы внутри ZIP сохраняют состояние исходного коммита
до удалённой публикации.
[Проверка скачивания](validation/gear-publication-2026-11-08/verification.json).

Предыдущая опубликованная сборка — **0.17.0-atmosphere-alpha1 / code 42**.
В исходники входят `source_atmospheric_dynamics.gd`, отдельный контакт
атмосферы, метаданные DOS-процедур `data/ffe_atmosphere.json`, нативные
эталоны и проверки тепловой сессии, Main и raw-motion. Перенесены нагрев
и сопротивление F1014, сырой учёт повреждений F953 и вспомогательные
процедуры. Вызовы внешних обработчиков остаются явно возвращаемыми
запросами; полная виртуальная машина событий и уничтожения не заявляется.

Прежние ресурсы топлива и гипердвигателя сохранены. Старые 17 полей
`fuel_system` принимаются без переинициализации; отдельное тепловое
состояние привязывается к фактическому корпусу. Порядок новых вызовов
обслуживает явный мобильный шаг 60 Гц. Происхождение DOS-эталона,
закреплённых JJFFE-проверок скорости и повторно использованных
геометрических контролей разделено в [описании блока](docs/RELEASE_0_17_0_RU.md).
Функциональные проверки завершены: **81 882 условия в 30 уникальных
группах, 0 ошибок**. Новый DOS-эталон содержит 1447 случаев, новые
проверки сырой скорости JJFFE — 239; повторно использованные записи
геометрии не прибавляются как новые исполнения. Отдельно прошли
**153 Python-теста**: 145 упаковки и восемь извлечения. Восемь настоящих
кадров Main сняты и осмотрены: **144 условия захвата, 0 ошибок**,
desktop GLES/Mesa с подготовленными контрольными условиями.
Настоящий ARM64 APK технически проверен: **50 038 396 байт**, SHA256
`8df3ed0fa1d790437bd536c16c7997ee18b263c39f462a6bad2716939e6fad63`.
Точный ZIP — **30 817 760 байт**, 1421 запись / **1268 файлов**, меньше
32 МиБ. Исходный коммит `714624bba30d6359921cced42be2c1adb8d4c5bd`. SHA256:
`bf87804585f3ba90a8be2459dd8c368e8c02f97797808d68b16386bece296d29`.
Свежий импорт и обычный изолированный запуск — **10/0**; фактический
тепловой сценарий Main из точного ZIP — **463/0**. Все 1268 исходных
файлов сохранили SHA; повторные проверки ZIP не прибавлены к 30 группам.

[Скачать APK 0.17.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/fd96b61d7f27d57a22c11269a4222d0de31f7054/deliverables/0.17.0-atmosphere-alpha1/StarFrontier-0.17.0-atmosphere-arm64.apk) · [Исходники 0.17.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/fd96b61d7f27d57a22c11269a4222d0de31f7054/deliverables/0.17.0-atmosphere-alpha1/StarFrontier-0.17.0-atmosphere-source.zip)

Полным скачиванием проверены **12 файлов**: манифест, APK, source ZIP,
протокол захвата и восемь PNG. HTTP 200, размеры, SHA, CRC обоих архивов,
число записей и Git-комментарий source ZIP совпали. Вспомогательные
журналы и отчёты упакованы и хешированы, но каждый из них отдельно не
скачивался. Документы внутри ZIP сохраняют состояние исходного коммита
до удалённой публикации.
[Подтверждение публикации](validation/atmosphere-publication-2026-11-07/verification.json).

Предыдущая опубликованная сборка — **0.16.0-fuel-alpha1 / code 41**.
В исходники входят отдельный ресурс `data/ffe_fuel.json`, перенесённые
DOS F929/F938/F289, ограниченные части F1007/F152, F1033/F1034 и исходное
поле контакта 15 звёздных/газовых моделей. Добавлены сохраняемое состояние
реактивного бака, связь с шестью пределами тяги, ручная заправка и
оборудование в существующем сенсорном интерфейсе. Нативные контрольные
примеры, извлекатели, проверки сессии и фактического Main также входят
в состав исходников. Код x86 служит эталоном при разработке; Android
исполняет перенесённые модули без DOS-эмулятора.

Старый ресурс гипердвигателя сохранён. Расширение Navigation v3 принимает
точное прежнее сохранение 0.15.0 и проверяет его незавершённый переход;
новые часы и оборудование сохраняются отдельно. Полные F569/FOR,
F575 и атмосферная тепловая/аэродинамическая цепь F1014 не заявляются
перенесёнными этим блоком. [Состав и ограничения](docs/RELEASE_0_16_0_RU.md).
Финальный функциональный агрегат — **74 687 условий в 26 уникальных
группах, 0 ошибок**; 4241 нативный случай уже входит в эти числа.
Отдельно прошли **126 Python-тестов** (117 упаковки и девять извлечения).
Восемь настоящих кадров Main сняты и осмотрены: **124 условия захвата,
0 ошибок**, desktop GLES/Mesa с подготовленными контрольными условиями.
Настоящий ARM64 APK технически проверен: **49 996 985 байт**, SHA256
`c7b12d9f869008bd5bce9bf3615b2d2d5f72fa7ffc0d799bda537111d5d4950d`.
Точный ZIP — **30 481 191 байт**, 1391 запись / **1238 файлов**, меньше
32 МиБ. Исходный коммит `217c1cbf1503cd44dbc386b66cbfff4a315be6f3`. SHA256:
`759b0ec67d958d2eaef6607b83a717e3c50387bb7c138f205f61c2e52297398c`.
Свежий импорт и обычный изолированный запуск — **10/0**; фактический Main
с новой топливной системой из точного ZIP — **397/0**. Все 1238 исходных
файлов сохранили SHA; повторные проверки ZIP не прибавлены к 26 группам.

[Скачать APK 0.16.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/e14007cba706c19e22de14c03dd59487884689f7/deliverables/0.16.0-fuel-alpha1/StarFrontier-0.16.0-fuel-arm64.apk) · [Исходники 0.16.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/e14007cba706c19e22de14c03dd59487884689f7/deliverables/0.16.0-fuel-alpha1/StarFrontier-0.16.0-fuel-source.zip)

Полным скачиванием проверены **12 файлов**: манифест, APK, source ZIP,
протокол захвата и восемь PNG. HTTP 200, размеры, SHA, CRC обоих архивов
и Git-комментарий source ZIP совпали. Вспомогательные журналы упакованы
и хешированы, но каждый из них отдельно не скачивался. Документы внутри
ZIP сохраняют состояние исходного коммита до удалённой публикации.
[Подтверждение публикации](validation/fuel-publication-2026-11-07/verification.json).

Нативные эталоны имеют смешанное происхождение: 3182 контроля Jet
сопоставлены с инструкциями DOS, а 729 Scoop и 330 Contact исполняют
закреплённый JJFFE ASM. [Уточнение подписей опубликованного счётчика](validation/fuel-publication-2026-11-07/native-reference-provenance.json).

Предыдущая опубликованная сборка — **0.15.0-hyperdrive-alpha1 / code 40**.
В исходники входят извлечённые таблицы оборудования/корпусов,
независимые нативные fixtures, ядро F833/F903, отдельный сохраняемый
инвентарь гипертоплива, Navigation v3, доковый экран и проверки
маршрута, вместимости, расхода и явной миграции с обязательной копией.
Старые v1/v2 сохраняют свои контракты; цены мастерской и активация
перехода остаются указанными адаптерами. Финальные проверки сборки
0.15.0 — 70 630 условий в 16 группах, 0 ошибок; отдельно 100 Python-тестов
и восемь осмотренных кадров Main с 120 условиями захвата. Размер APK — 49 934 782 байта, SHA256
`eed44e84639ae62f5c3afdf1bee8d666f83d1ca1b6e7144dcaf4fd8b2490246a`.

Точный ZIP — **30 094 130 байт**, 1 353 записи / **1 200 файлов**, меньше
32 МиБ. Исходный коммит `48d4b05161e8bcce1716e94d7f4845e0793f4714`. SHA256:
`9e03cfd4832a307754e019c37b631831178a72a5f5eb58fe82f9d7c0dc9887f7`.
Свежий импорт и обычный изолированный запуск — **10/0**; настоящий Main
с гипердвигателем из распакованного ZIP — **70/0**. Все 1 200 исходных
файлов сохранили SHA; повторные проверки ZIP не прибавлены к 16 группам.

[Скачать APK 0.15.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/2f33742937677df01e65d5e79f3cf1f6a01d2097/deliverables/0.15.0-hyperdrive-alpha1/StarFrontier-0.15.0-hyperdrive-arm64.apk) · [Исходники 0.15.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/2f33742937677df01e65d5e79f3cf1f6a01d2097/deliverables/0.15.0-hyperdrive-alpha1/StarFrontier-0.15.0-hyperdrive-source.zip)

Полным скачиванием проверены **12 файлов**: манифест, APK, source ZIP,
протокол захвата и восемь PNG. HTTP 200, размеры, SHA, CRC обоих архивов
и Git-комментарий source ZIP совпали. Вспомогательные журналы упакованы
и хешированы, но каждый из них отдельно не скачивался. Документы внутри
ZIP сохраняют состояние исходного коммита до удалённой публикации.
[Подтверждение публикации](validation/hyperdrive-publication-2026-11-07/verification.json).
[Состав блока и ограничения](docs/RELEASE_0_15_0_RU.md).

Предыдущая опубликованная сборка — **0.14.0-system-info-alpha1 / code 39**.
В исходники входят новые модели/экран сведений, исходный текстовый ресурс
и русский словарь 358 строк, независимые fixtures и проверки извлечения,
интерпретации и локализации. Длинные описания сохраняют 25 историй и 19
исходных пробелов; оригинальные IDs, source hex и переменные сохранены.
Настоящий ARM64 APK собран и технически проверен: 49 880 920 байт,
SHA256 `0570051ebfd302d2c46db2992e63b9ae64888bb0678b1d3e814e4660aa7c2b25`.
Точный ZIP — **29 818 080 байт**, 1 325 записей/1 172 файла, меньше 32 МиБ.
SHA256 `a58a357e7b7db7f8fe3b18d6f1071b19c78fea9ef28aba9a1fdeccc48aed0070`;
исходный коммит `860951235548fc58c859d7337b9a6909fd78ca62`. CRC исправен; свежий импорт
и обычный изолированный запуск — 10/0, новые страницы через Main — 44/0.
Все исходные файлы сохранили SHA.

[Скачать предыдущий APK 0.14.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4a2df6d8ad7739e9a622cf5a3c4e34c1d110a015/deliverables/0.14.0-system-info-alpha1/StarFrontier-0.14.0-system-info-arm64.apk) · [Предыдущие исходники 0.14.0 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/4a2df6d8ad7739e9a622cf5a3c4e34c1d110a015/deliverables/0.14.0-system-info-alpha1/StarFrontier-0.14.0-system-info-source.zip)

Двенадцать опубликованных файлов полностью скачаны: манифест, APK, ZIP,
протокол захвата и восемь PNG; размеры, SHA, CRC и Git-комментарий ZIP
совпали. [Подтверждение](validation/system-information-publication-2026-11-07/verification.json).
Документы внутри ZIP сохраняют состояние исходного коммита до публикации.
[Состав блока и ограничения](docs/RELEASE_0_14_0_RU.md).

Предыдущая опубликованная контрольная точка — **0.13.2-celestial-alpha1 / code 38**.
[Исправление видимости и проекции](docs/RELEASE_0_13_2_RU.md).
[Скачать предыдущий APK 0.13.2](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/bd6db12f798ed45e503c198dc6092940faed4096/deliverables/0.13.2-celestial-alpha1/StarFrontier-0.13.2-celestial-arm64.apk) · [Предыдущие исходники 0.13.2 ZIP](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/bd6db12f798ed45e503c198dc6092940faed4096/deliverables/0.13.2-celestial-alpha1/StarFrontier-0.13.2-celestial-source.zip)

ZIP: **29 528 548 байт**, 1 296 записей/1 143 файла, меньше 32 МиБ.
SHA256 `6fd180f08258a8d15e98df99277379b7cd984422a66442e56ee4e16507cb93c0`;
исходный коммит `606775527498662697ae9eedba152898adabfe40`. CRC исправен;
свежий импорт и изолированный обычный запуск — 10/0. Все исходные файлы
сохранили SHA. APK — 49 765 516 байт, SHA256
`c24b31c67dcf993dd44d837142e5bb69d8abfcec05722e5760b513f583529bdf`.

Пятнадцать опубликованных файлов скачаны полностью: манифест, APK, ZIP,
оба протокола захвата и десять PNG. Размеры/SHA/CRC/комментарий коммита ZIP
сверены. [Отчёт](validation/mercury-publication-2026-11-07/verification.json).
Документы внутри ZIP отражают состояние исходного коммита до публикации.

Предыдущая опубликованная сборка — **0.13.1-map-alpha1 / code 37**.
[Полный ZIP предыдущих исходников 0.13.1](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/fe920fceab88e02a0bfffdd9c7f185fd1df49368/deliverables/0.13.1-map-alpha1/StarFrontier-0.13.1-map-source.zip): 29 465 942 байт,
SHA256 `7588c52474ef115764d07b146e78decc195b32277c7ab7095b351f81a3e4ed3f`,
исходный коммит `c5d61229d579dc738aca6f5b45c570e5444fa836`. CRC исправен; свежий импорт
и обычный изолированный запуск — 10/0. Все 1137 исходных файлов неизменны.
Есть также [отдельный компактный ZIP аудита](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/fe920fceab88e02a0bfffdd9c7f185fd1df49368/deliverables/0.13.1-map-alpha1/FFE-parity-audit-2026-11-07.zip).

APK, оба ZIP, манифест и 8 PNG полностью скачаны с неизменяемых HTTPS-адресов.
[Проверка](validation/modern-map-publication-2026-11-07/verification.json) подтверждает размеры, SHA, CRC и source comments.
Это исходники частичной реконструкции; цель полного соответствия FFE
ещё требует реализации перечисленных в [аудите](docs/PARITY_AUDIT_RU.md)
страниц, механик и содержимого.

Для сохранённой **0.13.0** действует тот же состав: консоль, две графические
карты, исходный JSON плотности/палитры, ограниченный планировщик времени,
сенсорный крен, вращательный контакт, узкий исходный motion bridge,
отдельное ядро MB4, тесты, исследования и независимые контроли входят
в исходный ZIP. Готовые карты материалов также остаются в архиве.
Готовый [ZIP 0.13.0](https://raw.githubusercontent.com/brodyga0878-hub/Pyton/518438c23c0ff4a800d1749034a811f47b54a0ce/deliverables/0.13.0-navigation-alpha1/StarFrontier-0.13.0-navigation-source.zip) создан из точного коммита
`e4e8e7edccdb4422124f249365dfb8c99d135bb5`. Размер 28 766 521 байт, SHA-256
`24d5a592c920ce6785430577fef89126d11658ed5e168ae2dbe3cb8e88c9f57f`.
CRC исправен; свежий импорт и изолированный обычный запуск прошли
10 проверок без ошибок. Опубликованный ZIP скачан заново и сверён
по размеру, SHA, CRC и Git-комментарию.
[Отчёт публикации](validation/navigation-publication-2026-11-07/verification.json).

Исходные архивы 0.12.0/0.12.1 уже опубликованы и проверены независимым
скачиванием. Разрешение владельца на сохранение прогресса в его репозитории
действует; новый выпуск 0.13.0 также опубликован и проверен. Старые статусы внутри
архивов сохраняют состояние на момент их создания. Публикация 0.13.1
также подтверждена реальным скачиванием готовых файлов;
повторное разрешение на сохранение уже согласованного прогресса не требуется.

Каталог `deliverables/` и остальная `validation/` не включаются в ZIP: готовые APK,
прежние ZIP, снимки разных версий и журналы доступны отдельно в репозитории.
Это уменьшает размер резервной копии и не удаляет ресурсы, необходимые игре.
Кеш Godot, ключ подписи и установленный Android SDK также не являются
исходниками проекта. Скрипты подготовки инструментов находятся в `tools/`.

Архив создаётся командой `git archive` из точного исходного
коммита. Входят все 51 готовая карта материалов, исходные
игровые JSON, независимые нативные fixtures, текущие тесты и инструменты,
`recovered-history/` и сохранённые материалы восстановления. Это полный
комплект текущей реконструкции; найденным полным прежним проектом он
не объявляется. Проверки ZIP CRC, состава и загрузки опубликованных
файлов фиксируются в манифесте поставки. Размер исходного ZIP должен
оставаться меньше 32 МиБ для последующего переноса через чат; SDK,
подписывающий ключ, `.godot/`, `build/`, поставки и журналы исключаются.

После упаковки точный ZIP распаковывается в отдельный каталог. Свежий
импорт и обычный запуск/сохранение/загрузка проверяют переносимость
готового архива, а не повторно используют существующий кеш проекта.

Внутри исходников сохраняется `manifest.json` текстур, а в каталоге готовой
поставки рядом с ZIP — манифест сборки с точным Git-коммитом и SHA-256.
Для воспроизведения проверки импортируйте ресурсы в Godot 4.6.3, затем
запустите указанные в README инструменты. Генераторы текстур требуют
Python, NumPy и Pillow; сами готовые PNG уже входят в архив.

История, отчёты и настоящие кадры:
https://github.com/brodyga0878-hub/Pyton/tree/development/starfrontier-rebuild
