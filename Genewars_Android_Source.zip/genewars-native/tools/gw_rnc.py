# SPDX-License-Identifier: GPL-2.0-or-later
"""RNC method-1 reader for resource research, with packed/unpacked CRC checks.

Algorithm adapted from Jon Skeet / Tomasz Lis, KeeperFX bflib_dernc.c.
GPL-2.0-or-later. This file does not change game files.
Reference: https://github.com/dkfans/keeperfx/blob/master/src/bflib_dernc.c
"""
import struct


def crc16(data):
    value = 0
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0xA001 if value & 1 else 0)
    return value


class Stream:
    def __init__(self, data):
        self.data = data
        self.pos = 0
        self.value = self.word()
        self.count = 16

    def word(self):
        if self.pos > len(self.data):
            return 0
        return int.from_bytes(self.data[self.pos:self.pos+2].ljust(2, b'\0'), 'little')

    def advance(self, n):
        self.value >>= n
        self.count -= n
        if self.count < 16:
            self.pos += 2
            self.value |= self.word() << self.count
            self.count += 16

    def read(self, n):
        result = self.value & ((1 << n) - 1)
        self.advance(n)
        return result

    def literals(self, n):
        if self.pos + n > len(self.data):
            raise ValueError('RNC literals exceed payload')
        result = self.data[self.pos:self.pos+n]
        self.pos += n
        self.count -= 16
        self.value &= (1 << self.count) - 1
        self.value |= self.word() << self.count
        self.count += 16
        return result

    def table(self):
        lengths = [self.read(4) for _ in range(self.read(5))]
        table = []
        code = 0
        for n in range(1, max(lengths, default=0) + 1):
            for value, length in enumerate(lengths):
                if length == n:
                    mirrored = int(f'{code:0{n}b}'[::-1], 2)
                    table.append((mirrored, n, value))
                    code += 1
            code <<= 1
        return table

    def decode(self, table):
        for code, n, value in table:
            if self.value & ((1 << n) - 1) == code:
                self.advance(n)
                return (1 << (value - 1)) | self.read(value - 1) if value >= 2 else value
        raise ValueError('Invalid RNC Huffman code')


def unpack(data, max_output=64 * 1024 * 1024):
    if not data.startswith(b'RNC\x01'):
        return data
    if len(data) < 18:
        raise ValueError('Truncated RNC header')
    length, packed_length, expected_crc, packed_crc = struct.unpack_from('>IIHH', data, 4)
    if length > max_output or len(data) < packed_length + 18:
        raise ValueError('Invalid RNC lengths')
    payload = data[18:18+packed_length]
    if crc16(payload) != packed_crc:
        raise ValueError('RNC packed CRC mismatch')
    bs = Stream(payload)
    bs.advance(2)
    out = bytearray()
    while len(out) < length:
        start = len(out)
        raw, distance, run = bs.table(), bs.table(), bs.table()
        chunks = bs.read(16)
        if not chunks:
            raise ValueError('Empty RNC chunk')
        for i in range(chunks):
            n = bs.decode(raw)
            if n:
                out.extend(bs.literals(n))
            if i + 1 < chunks:
                d = bs.decode(distance) + 1
                n = bs.decode(run) + 2
                if d > len(out) or len(out) + n > length:
                    raise ValueError('RNC reference out of range')
                for _ in range(n):
                    out.append(out[-d])
            if len(out) > length:
                raise ValueError('RNC size exceeded')
        if len(out) == start:
            raise ValueError('RNC made no progress')
    if len(out) != length or crc16(out) != expected_crc:
        raise ValueError('RNC unpacked CRC/size mismatch')
    return bytes(out)
