#!/usr/bin/env python3
"""Check all 38 original native map/scenario exports against the Java core.

Uses the same JSON-to-core ownership/biomass policy as Android AssetRepository.
Only Python stdlib and a JDK are required. No original EXE is executed.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


class Writer:
    def __init__(self):
        self.buffer = io.BytesIO()

    def integer(self, *values):
        for value in values:
            self.buffer.write(struct.pack(">i", value))

    def double(self, *values):
        for value in values:
            self.buffer.write(struct.pack(">d", value))

    def ascii(self, value):
        data = value.encode("ascii")
        if len(data) > 65535:
            raise ValueError("Bridge string too long")
        self.buffer.write(struct.pack(">H", len(data)))
        self.buffer.write(data)


def asset_path(root: Path, name: str) -> Path:
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError(f"Invalid asset path: {name}")
    return path


def bridge(root: Path, metadata: dict, output: Path) -> dict:
    scenario_path = asset_path(root, metadata["scenarioFile"])
    source = scenario_path.read_bytes()
    if len(source) > 1024 * 1024:
        raise ValueError("Scenario exceeds Android reader limit")
    if hashlib.sha256(source).hexdigest() != metadata["scenarioSha256"]:
        raise ValueError("Scenario SHA-256 mismatch")
    scenario = json.loads(source)
    raw_map = asset_path(root, metadata["file"]).read_bytes()
    writer = Writer()
    writer.integer(0x47575343, 1)
    writer.ascii(metadata["name"])
    writer.integer(len(raw_map)); writer.buffer.write(raw_map)
    drops = metadata.get("dropSites", [])
    x = drops[0]["x"] if drops else float("nan")
    y = drops[0]["y"] if drops else float("nan")
    writer.double(x, y); writer.integer(scenario["payment"])
    writer.integer(len(scenario["trees"]))
    for tree in scenario["trees"]:
        biomass = tree.get("wood", 0)
        if biomass <= 0:
            biomass = tree["health"]
        writer.integer(tree["species"]); writer.double(tree["x"], tree["y"]); writer.integer(biomass)
    writer.integer(len(scenario["creatures"]))
    for creature in scenario["creatures"]:
        owner = creature["owner"]
        team = 0 if owner == 0 else 2 if owner == 4 else 1
        writer.integer(creature["species"]); writer.double(creature["x"], creature["y"]); writer.integer(team)
        writer.double(creature["health"], creature["energy"], creature["maxHealth"], creature["maxEnergy"], creature["lifespan"])
    writer.integer(len(scenario["buildings"]))
    for building in scenario["buildings"]:
        team = 0 if building["owner"] == 0 else 1
        writer.integer(building["type"], building["stage"], team)
        writer.double(building["x"], building["y"]); writer.integer(building["build"], building["flags"])
    output.write_bytes(writer.buffer.getvalue())
    return {"name": metadata["name"], "scenario_sha256": hashlib.sha256(source).hexdigest(),
            "trees": len(scenario["trees"]), "creatures": len(scenario["creatures"]),
            "buildings": len(scenario["buildings"])}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "android/app/src/main/assets")
    parser.add_argument("--jdk", type=Path)
    parser.add_argument("--report", type=Path, default=ROOT / "build/original-scenarios-report.json")
    args = parser.parse_args()
    javac = str(args.jdk / "bin/javac") if args.jdk else shutil.which("javac")
    java = str(args.jdk / "bin/java") if args.jdk else shutil.which("java")
    if not javac or not java:
        parser.error("A JDK is required; supply --jdk /path/to/jdk")
    manifest = json.loads(asset_path(args.assets, "native/manifest.json").read_text(encoding="utf-8"))
    maps = manifest["maps"]
    if manifest.get("format") != 2 or len(maps) != 38 or len({m["name"] for m in maps}) != 38:
        raise ValueError("Expected format-2 manifest with 38 unique original maps")
    if any(re.fullmatch(r"(?:CONQ|CUST)[0-9]{3}", m["name"]) is None for m in maps):
        raise ValueError("Invalid original map identifier")
    build = ROOT / "build"; build.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="original-scenario-tests-", dir=build) as temporary:
        work = Path(temporary); inputs = work / "inputs"; classes = work / "classes"
        inputs.mkdir(); classes.mkdir()
        source_records = []
        for metadata in maps:
            source_records.append(bridge(args.assets, metadata, inputs / (metadata["name"] + ".gwscenario")))
        sources = sorted((ROOT / "native-core/src").rglob("*.java"))
        harness = ROOT / "native-core/test/org/genewars/core/OriginalScenarioTests.java"
        subprocess.run([javac, "--release", "8", "-d", str(classes), *map(str, sources), str(harness)], check=True)
        run = subprocess.run([java, "-cp", str(classes), "org.genewars.core.OriginalScenarioTests", str(inputs)],
                             text=True, capture_output=True, check=False, timeout=180)
        print(run.stdout, end="")
        if run.stderr:
            print(run.stderr, end="")
        outcomes = []
        for line in run.stdout.splitlines():
            fields = line.split("\t")
            if fields[0] == "PASS":
                outcomes.append({"name": fields[1], "status": "passed", "trees": int(fields[2]),
                                 "creatures": int(fields[3]), "buildings": int(fields[4]), "save_bytes": int(fields[5])})
            elif fields[0] == "FAIL":
                outcomes.append({"name": fields[1].removesuffix(".gwscenario"), "status": "failed", "error": fields[2]})
        result = {"scope": "38 actual GWM imports, original entity import, 2 seconds deterministic runtime, save/load",
                  "full_campaign_verified": False, "exit_code": run.returncode,
                  "passed": sum(x["status"] == "passed" for x in outcomes),
                  "failed": sum(x["status"] == "failed" for x in outcomes),
                  "source_records": source_records, "outcomes": outcomes}
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if len(outcomes) != 38 or result["passed"] != 38 or run.returncode:
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
