#!/usr/bin/env python3
"""Build and verify the standalone native Android APK using official SDK tools.

No Gradle, downloads, emulator or external application is part of the APK.
Requires a JDK (17+) and Android SDK platform/build-tools 35.0.0.
The generated local debug signing key is for development, not publication.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def source_fingerprint() -> str:
    checksum = hashlib.sha256()
    inputs = []
    for directory in [ROOT / "native-core/src", ROOT / "android/app/src/main"]:
        inputs.extend(path for path in directory.rglob("*") if path.is_file())
    for path in sorted(inputs):
        checksum.update(path.relative_to(ROOT).as_posix().encode("utf-8") + b"\0")
        checksum.update(hashlib.sha256(path.read_bytes()).digest())
    return checksum.hexdigest()


def run(argv: list[str], env: dict[str, str], **kwargs) -> subprocess.CompletedProcess:
    result = subprocess.run(argv, env=env, text=True, check=True, **kwargs)
    return result


def build(sdk: Path, jdk: Path, output: Path) -> dict:
    sdk, jdk, output = sdk.resolve(), jdk.resolve(), output.resolve()
    platform = sdk / "platforms/android-35/android.jar"
    tools = sdk / "build-tools/35.0.0"
    source = ROOT / "android/app/src/main"
    required = [platform, tools / "aapt2", tools / "d8", tools / "zipalign",
                tools / "apksigner", jdk / "bin/javac", jdk / "bin/keytool",
                source / "AndroidManifest.xml"]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(f"Missing build prerequisite: {path}")
    if not output.is_relative_to((ROOT / "build").resolve()):
        raise ValueError("Write APKs below the repository build directory")
    java_sources = sorted((source / "java").rglob("*.java"))
    core_sources = sorted((ROOT / "native-core/src").rglob("*.java"))
    if not java_sources or not core_sources:
        raise ValueError("Native game source and Android UI must both be present")
    assets = source / "assets"
    if not assets.is_dir() or not any(assets.rglob("*.gwm")):
        raise ValueError("Original map assets must be generated before building")
    fingerprint = source_fingerprint()
    env = os.environ.copy()
    env["JAVA_HOME"] = str(jdk)
    env["PATH"] = str(jdk / "bin") + os.pathsep + env["PATH"]
    output.parent.mkdir(parents=True, exist_ok=True)
    signing = ROOT / "build/signing"
    signing.mkdir(exist_ok=True)
    keystore = signing / "android-debug.p12"
    if not keystore.exists():
        run([str(jdk / "bin/keytool"), "-genkeypair", "-keystore", str(keystore),
             "-storetype", "PKCS12", "-storepass", "android", "-keypass", "android",
             "-alias", "androiddebugkey", "-keyalg", "RSA", "-keysize", "2048",
             "-validity", "10000", "-dname", "CN=Android Debug,O=Local Development,C=US"], env)
        keystore.chmod(0o600)
    with tempfile.TemporaryDirectory(prefix="apk-work-", dir=ROOT / "build") as temporary:
        work = Path(temporary)
        generated, classes, dex = (work / name for name in ["generated", "classes", "dex"])
        for directory in [generated, classes, dex]:
            directory.mkdir()
        resources = work / "resources.zip"
        unsigned = work / "unsigned.apk"
        run([str(tools / "aapt2"), "compile", "--dir", str(source / "res"),
             "-o", str(resources)], env)
        run([str(tools / "aapt2"), "link", "-o", str(unsigned),
             "--manifest", str(source / "AndroidManifest.xml"), "-I", str(platform),
             "--debug-mode", "--java", str(generated), "-0", "wav", "-0", "ogg", "-0", "mid",
             "-A", str(assets), str(resources)], env)
        all_sources = java_sources + core_sources + sorted(generated.rglob("*.java"))
        arguments = work / "javac.args"
        arguments.write_text("\n".join('"' + str(p) + '"' for p in all_sources), encoding="utf-8")
        run([str(jdk / "bin/javac"), "-source", "8", "-target", "8", "-encoding", "UTF-8",
             "-bootclasspath", str(platform), "-d", str(classes), "@" + str(arguments)], env)
        class_jar = work / "classes.jar"
        with zipfile.ZipFile(class_jar, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(classes.rglob("*.class")):
                archive.write(path, path.relative_to(classes).as_posix())
        run([str(tools / "d8"), "--min-api", "26", "--lib", str(platform),
             "--output", str(dex), str(class_jar)], env)
        with zipfile.ZipFile(unsigned, "a", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(dex.glob("*.dex")):
                archive.write(path, path.name)
        aligned, signed = work / "aligned.apk", work / "signed.apk"
        run([str(tools / "zipalign"), "-f", "4", str(unsigned), str(aligned)], env)
        run([str(tools / "apksigner"), "sign", "--ks", str(keystore),
             "--ks-key-alias", "androiddebugkey", "--ks-pass", "pass:android",
             "--key-pass", "pass:android", "--out", str(signed), str(aligned)], env)
        verification = run([str(tools / "apksigner"), "verify", "--verbose", str(signed)],
                           env, capture_output=True).stdout
        run([str(tools / "zipalign"), "-c", "4", str(signed)], env)
        package = run([str(tools / "aapt2"), "dump", "badging", str(signed)],
                      env, capture_output=True).stdout
        with zipfile.ZipFile(signed) as archive:
            if archive.testzip() is not None or "classes.dex" not in archive.namelist():
                raise ValueError("Invalid APK contents")
            if any(name.lower().endswith((".exe", ".com")) for name in archive.namelist()):
                raise ValueError("DOS executables do not belong in the native APK")
            if any(name.startswith("lib/") for name in archive.namelist()):
                raise ValueError("Unexpected native dependency; this build uses only Android Java APIs")
        if source_fingerprint() != fingerprint:
            raise RuntimeError("Source/assets changed during build; rebuild a stable snapshot")
        shutil.copy2(signed, output)
    summary = {"apk": str(output), "bytes": output.stat().st_size,
               "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
               "min_sdk": 26, "compile_sdk": 35, "standalone": True,
               "dos_emulation": False, "java_classes": len(all_sources),
               "source_and_assets_sha256": fingerprint,
               "signing": "local development key", "signature_verification": verification.strip(),
               "package_information": package.strip(), "physical_device_tested": False,
               "status": "native reconstruction; see engine coverage report"}
    output.with_suffix(".json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
                                           encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in ["package_information", "signature_verification"]},
                     ensure_ascii=False, indent=2))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk", type=Path,
                        default=Path(os.environ.get("ANDROID_SDK_ROOT", "android-sdk")))
    parser.add_argument("--java-home", type=Path,
                        default=Path(os.environ.get("JAVA_HOME", "/usr/lib/jvm/default-java")))
    parser.add_argument("--output", type=Path,
                        default=ROOT / "build/genewars-native-0.1-debug.apk")
    args = parser.parse_args()
    build(args.sdk, args.java_home, args.output)


if __name__ == "__main__":
    main()
