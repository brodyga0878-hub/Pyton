#!/usr/bin/env python3
"""Install pinned official Android SDK tools into a chosen development directory.

Uses the current HTTPS proxy/CA configuration and verifies every archive by
SHA-256. Does not install a JDK, accept licenses on behalf of a distributor,
modify system directories, or include an emulator in the game.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile


def install(destination: Path) -> None:
    packages = json.loads(Path(__file__).with_name("android-toolchain.json").read_text())
    destination.mkdir(parents=True, exist_ok=True)
    for name, package in packages.items():
        target = destination / package["destination"]
        if target.exists():
            stamp = target / ".genewars-sdk-sha256"
            if stamp.exists() and stamp.read_text().strip() == package["sha256"]:
                print(f"Already installed: {name}")
                continue
            raise FileExistsError(f"Existing unverified SDK directory: {target}")
        with tempfile.TemporaryDirectory(prefix="sdk-download-", dir=destination) as temp:
            archive_path = Path(temp) / "package.zip"
            with urllib.request.urlopen(package["url"], timeout=60) as response, archive_path.open("wb") as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)
            with archive_path.open("rb") as handle:
                checksum = hashlib.sha256()
                while chunk := handle.read(1024 * 1024):
                    checksum.update(chunk)
                if checksum.hexdigest() != package["sha256"]:
                    raise ValueError(f"SDK checksum mismatch: {name}")
            extracted = Path(temp) / "extracted"
            extracted.mkdir()
            with zipfile.ZipFile(archive_path) as archive:
                roots = {i.filename.split("/", 1)[0] for i in archive.infolist()}
                if len(roots) != 1:
                    raise ValueError("Unexpected SDK archive layout")
                prefix = next(iter(roots)) + "/"
                for item in archive.infolist():
                    relative = item.filename[len(prefix):]
                    if not relative:
                        continue
                    path = Path(relative)
                    if path.is_absolute() or ".." in path.parts:
                        raise ValueError("Unsafe SDK archive path")
                    output = extracted / path
                    if item.is_dir():
                        output.mkdir(parents=True, exist_ok=True)
                    else:
                        output.parent.mkdir(parents=True, exist_ok=True)
                        output.write_bytes(archive.read(item))
                        mode = (item.external_attr >> 16) & 0o777
                        if mode:
                            output.chmod(mode)
            (extracted / ".genewars-sdk-sha256").write_text(package["sha256"] + "\n")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(extracted), str(target))
        print(f"Installed and verified: {name}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    install(parser.parse_args().destination)
