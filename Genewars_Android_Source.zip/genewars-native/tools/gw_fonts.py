#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Build experimental Cyrillic Bullfrog font resources without modifying a ZIP.

Run from the repository: python3 tools/gw_fonts.py ORIGINAL.zip --output build/fonts
Requires Pillow and a locally installed Cyrillic TrueType font. The preview is a
resource-rendering experiment, not a screenshot or proof that the game runs.
RNC decoding is in gw_rnc.py, adapted from KeeperFX under GPL-2.0-or-later.
"""
from __future__ import annotations
import argparse
import collections
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import statistics
import struct
import zipfile

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from gw_rnc import unpack

ALPHABET = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя'
ENCODING = {letter: 128 + i for i, letter in enumerate(ALPHABET)}
FONT_NAMES = ['FONT0', 'FONT1', 'FONT2', 'FONT4', 'FONT5', 'FONT7', 'QUITFONT']
TRANSPARENT = -1


@dataclass(frozen=True)
class Sprite:
    width: int
    height: int
    pixels: tuple[tuple[int, ...], ...]


def read_sprites(data: bytes, table: bytes) -> list[Sprite]:
    if len(table) % 6:
        raise ValueError('Sprite table length must be divisible by six')
    sprites = []
    for i in range(len(table) // 6):
        offset, width, height = struct.unpack_from('<IBB', table, i * 6)
        rows = []
        for _ in range(height):
            row = [TRANSPARENT] * width
            x = 0
            while True:
                if offset >= len(data):
                    raise ValueError('RLE sprite ended before its final row')
                n = struct.unpack_from('<b', data, offset)[0]
                offset += 1
                if not n:
                    break
                if n < 0:
                    x -= n
                else:
                    if offset + n > len(data) or x + n > width:
                        raise ValueError(f'Sprite {i} run exceeds data or width')
                    row[x:x+n] = data[offset:offset+n]
                    x += n
                    offset += n
            if x > width:
                raise ValueError('Sprite transparency run exceeds width')
            rows.append(tuple(row))
        sprites.append(Sprite(width, height, tuple(rows)))
    return sprites


def write_sprites(sprites: list[Sprite]) -> tuple[bytes, bytes]:
    """Write ordinary, uncompressed DAT/TAB accepted by the game's file loader."""
    data = bytearray(struct.pack('<H', len(sprites)))
    table = bytearray()
    for i, sprite in enumerate(sprites):
        if not sprite.width and not sprite.height:
            table.extend(struct.pack('<IBB', 0, 0, 0))
            continue
        table.extend(struct.pack('<IBB', len(data), sprite.width, sprite.height))
        for row in sprite.pixels:
            x = 0
            while x < len(row):
                transparent = row[x] == TRANSPARENT
                end = x + 1
                while end < len(row) and (row[end] == TRANSPARENT) == transparent and end-x < 126:
                    end += 1
                if transparent:
                    data.extend(struct.pack('<b', -(end-x)))
                else:
                    data.append(end-x)
                    data.extend(row[x:end])
                x = end
            data.append(0)
        data.append(0x7F)
    return bytes(data), bytes(table)


def mask_for(letter: str, font_path: Path, width: int, height: int) -> Image.Image:
    """Rasterize a PoC letter to the original resource's pixel-height envelope."""
    font = ImageFont.truetype(str(font_path), 64)
    bounds = font.getbbox(letter)
    mask = Image.new('L', (bounds[2]-bounds[0]+4, bounds[3]-bounds[1]+4))
    ImageDraw.Draw(mask).text((2-bounds[0], 2-bounds[1]), letter, font=font, fill=255)
    bounds = mask.getbbox()
    if bounds is None:
        raise ValueError(f'No glyph in selected TrueType font: {letter!r}')
    mask = mask.crop(bounds)
    return mask.resize((width, height), Image.Resampling.LANCZOS).point(lambda p: 255 if p >= 100 else 0)


def make_cyrillic(letter: str, original: list[Sprite], font_path: Path) -> Sprite:
    cap = original[ord('A') - 31]
    lower = original[ord('a') - 31]
    reference = cap if letter.isupper() else lower
    # The original FONT4 is an all-caps design even at lowercase code points.
    if reference.height < 5 or reference.width < 3:
        reference = cap
    height = reference.height
    colours = collections.Counter(p for row in cap.pixels for p in row if p >= 0)
    outlined = set(colours).issubset({1, 2})
    border = 1 if outlined else 0
    body_height = max(3, height - 2 * border)
    font = ImageFont.truetype(str(font_path), 64)
    glyph_bounds = font.getbbox(letter)
    cap_bounds = font.getbbox('А' if letter.isupper() else 'а')
    aspect = (glyph_bounds[2] - glyph_bounds[0]) / max(1, cap_bounds[2]-cap_bounds[0])
    typical = max(3, reference.width - 2 * border)
    body_width = max(2, min(round(typical * aspect), max(3, cap.width + 3 - 2*border)))
    mask = mask_for(letter, font_path, body_width, body_height)
    width = body_width + 2 * border
    canvas = Image.new('L', (width, height))
    canvas.paste(mask, (border, border))
    dilated = canvas.filter(ImageFilter.MaxFilter(3)) if outlined else canvas
    row_colours = []
    for row in cap.pixels:
        counts = collections.Counter(p for p in row if p >= 0)
        row_colours.append(counts.most_common(1)[0][0] if counts else colours.most_common(1)[0][0])
    rows = []
    for y in range(height):
        row = []
        for x in range(width):
            if canvas.getpixel((x, y)):
                row.append(1 if outlined else row_colours[min(y, len(row_colours)-1)])
            elif dilated.getpixel((x, y)):
                row.append(2)
            else:
                row.append(TRANSPARENT)
        rows.append(tuple(row))
    sprite = Sprite(width, height, tuple(rows))
    if not any(p >= 0 for row in sprite.pixels for p in row):
        raise ValueError(f'Empty Cyrillic glyph: {letter}')
    return sprite


def sprite_image(sprite: Sprite, palette: bytes) -> Image.Image:
    result = Image.new('RGB', (max(1, sprite.width), max(1, sprite.height)), '#151824')
    for y, row in enumerate(sprite.pixels):
        for x, value in enumerate(row):
            if value >= 0:
                start = value * 3
                result.putpixel((x, y), tuple(min(255, channel*4) for channel in palette[start:start+3]))
    return result


def render_sample(text: str, sprites: list[Sprite], palette: bytes, scale=3) -> Image.Image:
    letters = []
    for letter in text:
        value = ord(letter) if ord(letter) < 128 else ENCODING[letter]
        letters.append(sprites[value-31])
    result = Image.new('RGB', (max(1, sum(s.width-1 for s in letters)), max(s.height for s in letters)), '#151824')
    x = 0
    for sprite in letters:
        result.paste(sprite_image(sprite, palette), (x, 0))
        x += sprite.width-1
    return result.resize((result.width*scale, result.height*scale), Image.Resampling.NEAREST)


def run(archive: Path, output: Path, font_path: Path) -> dict:
    root = Path(__file__).resolve().parent.parent
    if not output.resolve().is_relative_to((root/'build').resolve()):
        raise ValueError('Write generated resources only below this repository\'s build directory')
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f'Refusing to overwrite nonempty output directory: {output}')
    if not font_path.is_file():
        raise FileNotFoundError(font_path)
    data_out = output/'DATA'
    data_out.mkdir(parents=True, exist_ok=True)
    manifest = {'status': 'experimental, runtime untested', 'encoding': ENCODING,
                'original_executable_changed': False, 'font3': 'unchanged; not emitted (numeric/special font)',
                'truetype_source': str(font_path), 'truetype_sha256': hashlib.sha256(font_path.read_bytes()).hexdigest(),
                'fonts': {}}
    proof = Image.new('RGB', (1800, 1210), '#151824')
    draw = ImageDraw.Draw(proof)
    label = ImageFont.truetype(str(font_path), 18)
    draw.text((20, 10), 'GENE WARS: resource preview, NOT a game screenshot', font=label, fill='white')
    with zipfile.ZipFile(archive) as z:
        prefix = 'Gene_Wars_RePack/DATA/'
        palette = unpack(z.read(prefix+'MAIN.PAL'))
        for row, name in enumerate(FONT_NAMES):
            source_data, source_table = (unpack(z.read(prefix+name+'.'+ext)) for ext in ['DAT', 'TAB'])
            original = read_sprites(source_data, source_table)
            # Prove the encoder preserves the decoded original resources before edits.
            round_data, round_table = write_sprites(original)
            if read_sprites(round_data, round_table) != original:
                raise AssertionError(f'{name}: original round trip failed')
            sprites = list(original)
            while len(sprites) <= max(ENCODING.values())-31:
                sprites.append(Sprite(0, 0, ()))
            metrics = []
            for letter, code in ENCODING.items():
                sprite = make_cyrillic(letter, original, font_path)
                sprites[code-31] = sprite
                metrics.append({'letter':letter, 'byte':code, 'width':sprite.width, 'height':sprite.height})
            for code in range(32, min(127, len(original)+31)):
                if sprites[code-31] != original[code-31]:
                    raise AssertionError('An ASCII glyph was changed')
            dat, tab = write_sprites(sprites)
            if read_sprites(dat, tab) != sprites:
                raise AssertionError(f'{name}: Cyrillic round trip failed')
            (data_out/(name+'.DAT')).write_bytes(dat)
            (data_out/(name+'.TAB')).write_bytes(tab)
            manifest['fonts'][name] = {'original_records':len(original),'output_records':len(sprites),
                'ascii_preserved':True,'cyrillic_glyphs':len(metrics),'metrics':metrics,
                'dat_sha256':hashlib.sha256(dat).hexdigest(),'tab_sha256':hashlib.sha256(tab).hexdigest()}
            y = 55 + row*160
            draw.text((20,y), name+' / experimental fitted lettering', font=label, fill='white')
            preview_palette = bytearray(palette)
            if name in ['FONT0', 'FONT1', 'FONT4', 'FONT7']:
                # These sprites use semantic foreground/outline indices. The game
                # renderer recolours them; show a diagnostic white/blue pair here.
                preview_palette[3:6] = bytes([63, 63, 63])
                preview_palette[6:9] = bytes([22, 33, 63])
            preview_scale = 1 if name in ['FONT2', 'QUITFONT'] else 2
            a = render_sample('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ',sprites,preview_palette,preview_scale)
            b = render_sample('Сохранить игру  Пауза',sprites,preview_palette,2)
            proof.paste(a,(20,y+25))
            proof.paste(b,(20,y+88))
            # A separate contact sheet shows every one of the 66 real RLE glyphs.
            cell_width = max(80, max(m['width'] for m in metrics)*3+16)
            cell_height = max(64, max(m['height'] for m in metrics)*3+32)
            contact = Image.new('RGB', (11*cell_width, 6*cell_height), '#151824')
            contact_draw = ImageDraw.Draw(contact)
            for i, (letter, code) in enumerate(ENCODING.items()):
                x, yy = (i % 11)*cell_width, (i // 11)*cell_height
                contact_draw.text((x+5, yy+3), f'{letter} / {code}', font=label, fill='white')
                glyph = sprite_image(sprites[code-31], preview_palette)
                contact.paste(glyph.resize((glyph.width*3, glyph.height*3), Image.Resampling.NEAREST), (x+5,yy+28))
            contact.save(output/(name.lower()+'-cyrillic.png'))
    proof.save(output/'cyrillic-preview.png')
    (output/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive',type=Path)
    parser.add_argument('--output',type=Path,default=Path('build/fonts'))
    parser.add_argument('--font',type=Path,default=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
    args=parser.parse_args()
    result=run(args.archive,args.output,args.font)
    print(json.dumps({'output':str(args.output),'fonts':len(result['fonts']),
                      'cyrillic_glyphs':len(ENCODING),'runtime_tested':False}))


if __name__ == '__main__':
    main()
