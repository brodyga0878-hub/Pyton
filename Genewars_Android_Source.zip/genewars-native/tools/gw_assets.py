#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Import this retail Gene Wars ZIP into native Android assets, without EXE code.

Layouts recovered from the supplied GW.EXE and cross-checked against the
mefistotelis/genewars format declarations. This is a resource converter, not an
implementation of the original simulation. See docs/assets-native.md.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import wave
import zipfile
import zlib

from PIL import Image, ImageOps
from gw_rnc import unpack
from gw_fonts import read_sprites
from gw_xmi import export_music

PREFIX = 'Gene_Wars_RePack/'
SOURCE_HASH = '504567d13e57299224a1c9dd3a02ba58b58e7293f2a0f7f5f867a66268f49f3c'
GRID_OFFSET, GRID_STRIDE, MAP_SIZE = 13662, 14, 128
LEVEL_SIZE, LEVEL_SIGNATURE = 343958, 348982
CREATURE_BASE, PLANT_BASE, SPECIALIST_BASE, BUILDING_BASE = 243038, 277838, 298830, 301630


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def terrain_types(blocks: list[int]) -> list[int]:
    """Actual GridTile.GetTerrain centre sample; includes eight-neighbour shore."""
    if len(blocks) != MAP_SIZE * MAP_SIZE:
        raise ValueError('Expected a 128 by 128 terrain layer')
    basic = [(block >> 8) & 7 for block in blocks]
    result = list(basic)
    for y in range(MAP_SIZE):
        for x in range(MAP_SIZE):
            i = y*MAP_SIZE+x
            if basic[i]:
                continue
            if any(basic[((y+dy)&127)*MAP_SIZE+((x+dx)&127)]
                   for dy in (-1,0,1) for dx in (-1,0,1)):
                result[i] = 1
    return result


def make_gwm(name: str, terrain: list[int], elevation: list[int]) -> bytes:
    """GWM1/DataInputStream, big endian, ASCII source name, trailing CRC32."""
    encoded = name.encode('ascii')
    if not 0 < len(encoded) <= 128:
        raise ValueError('Invalid source name')
    count = MAP_SIZE * MAP_SIZE
    if len(terrain) != count or len(elevation) != count:
        raise ValueError('Invalid map layer lengths')
    result = bytearray(struct.pack('>IHHHH',0x47574D31,1,MAP_SIZE,MAP_SIZE,len(encoded)))
    result.extend(encoded)
    result.extend(struct.pack('>I',count))
    for i, (kind, altitude) in enumerate(zip(terrain,elevation)):
        x,y = i%MAP_SIZE,i//MAP_SIZE
        # This flag is a native prototype policy, not recovered species-specific
        # DOS pathfinding: deep water and the outermost cells are not walkable.
        blocked = int(kind == 0 or x in (0,MAP_SIZE-1) or y in (0,MAP_SIZE-1))
        result.extend(struct.pack('>BhB',kind,altitude,blocked))
    result.extend(struct.pack('>I',zlib.crc32(result)))
    return bytes(result)


def cstring(data: bytes) -> str:
    return data.split(b'\0',1)[0].decode('ascii')


def read_planet(header: bytes) -> dict:
    if len(header) != 699:
        raise ValueError('Invalid retail level header length')
    p = header[32:671]
    u16 = lambda o: struct.unpack_from('<H',p,o)[0]
    s16 = lambda o: struct.unpack_from('<h',p,o)[0]
    drops = []
    for i in range(8):
        x,y = struct.unpack_from('<hh',p,54+4*i)
        if x or y:
            drops.append({'x':x/256.0,'y':y/256.0})
    stuff = []
    for i in range(64):
        x,y,kind,a,b,c = struct.unpack_from('<hhBBBB',p,86+8*i)
        if kind:
            stuff.append({'index':i,'x':x/256.0,'y':y/256.0,'type':kind,
                          'speciesByte':a,'playerOrStudy':b,'countOrSize':c})
    return {'title':cstring(p[:18]),'levelNumber':p[18],'planetClass':p[19],
            'gravity':s16(21),'solarEnergy':s16(23),'meanTemperature':s16(25),
            'seaLevel':s16(27),'planetFlags':u16(29),
            'payment':struct.unpack_from('<I',p,31)[0],
            'seed':u16(35),'biomass':u16(42),'initialBad':u16(44),
            'victoryCreatures':u16(46),'victoryGoop':u16(606),
            'victoryEnemyBuildings':u16(608),'victoryEPoints':struct.unpack_from('<i',p,610)[0],
            'victoryFlags':p[638],'specialistsAllowed':p[629],
            'specialistActions':list(p[630:634]),'dropSites':drops,'stuff':stuff}


def read_entities(data: bytes) -> dict:
    """Read on-disk records, not incompatible pointers/sizeof in the QA headers."""
    result = {'creatures':[],'trees':[],'buildings':[]}
    for key,base,stride,count,kind in [('creatures',CREATURE_BASE,116,300,1),
                                      ('trees',PLANT_BASE,41,512,2),
                                      ('buildings',BUILDING_BASE,59,256,4)]:
        for index in range(count):
            r = data[base+index*stride:base+(index+1)*stride]
            if len(r) != stride:
                raise ValueError('Truncated entity record')
            if r[6] != kind:
                continue
            x,y = struct.unpack_from('<hh',r,7)
            # Grid lookup masks the signed fixed-point tile coordinate with127
            # (actual EXE 0x7B557..55D). Forest/herd records can cross the seam.
            e = {'index':index,'x':(x & 0x7fff)/256.0,'y':(y & 0x7fff)/256.0,
                 'sourceX':x,'sourceY':y,'owner':r[24]}
            if kind == 1:
                e.update(species=r[114],state=r[86],mode=r[87],
                         maxEnergy=struct.unpack_from('<h',r,90)[0],
                         maxHealth=struct.unpack_from('<h',r,92)[0],
                         lifespan=struct.unpack_from('<h',r,94)[0],
                         energy=struct.unpack_from('<h',r,96)[0],
                         health=struct.unpack_from('<h',r,98)[0])
            elif kind == 2:
                e.update(species=r[35],health=struct.unpack_from('<h',r,36)[0],
                         flags=r[38],age=r[39],wood=r[40])
            else:
                e.update(build=struct.unpack_from('<h',r,35)[0],type=r[37],
                         stage=r[38],flags=struct.unpack_from('<H',r,41)[0],
                         power=struct.unpack_from('<h',r,53)[0])
            result[key].append(e)
    return result


def read_level(data: bytes, header: bytes, name: str) -> tuple[bytes,dict]:
    if len(data) != LEVEL_SIZE or struct.unpack_from('<I',data)[0] != LEVEL_SIGNATURE:
        raise ValueError('Unsupported level version; expected supplied retail layout')
    if data[7240:7879] != header[32:671]:
        raise ValueError('Level and header planet data differ')
    blocks = [struct.unpack_from('<H',data,GRID_OFFSET+GRID_STRIDE*i+4)[0]
              for i in range(MAP_SIZE*MAP_SIZE)]
    elevation = [struct.unpack_from('<h',data,GRID_OFFSET+GRID_STRIDE*i+2)[0]
                 for i in range(MAP_SIZE*MAP_SIZE)]
    terrain = terrain_types(blocks)
    meta = read_planet(header)
    meta.update(read_entities(data))
    expected_creatures, expected_plants = struct.unpack_from('<hh',data,13648)
    if len(meta['creatures']) != expected_creatures or len(meta['trees']) != expected_plants:
        raise ValueError('Entity counts disagree with the level header')
    meta.update(name=name,width=MAP_SIZE,height=MAP_SIZE,
                sourceSha256=sha(data),sourceHeaderSha256=sha(header),
                sourceGridOffset=GRID_OFFSET,sourceGridStride=GRID_STRIDE,
                nativeWalkabilityPolicy='deep-water-and-map-edge-blocked; species rules not fully recovered')
    return make_gwm(name,terrain,elevation),meta


def read_nibble_sprites(data: bytes, table: bytes):
    if len(table)%6:
        raise ValueError('Bad sprite table')
    sprites=[]
    for i in range(len(table)//6):
        offset,w,h=struct.unpack_from('<IBB',table,i*6)
        image=Image.new('P',(max(1,w),max(1,h)),255)
        pixels=image.load()
        for y in range(h):
            x=0
            while True:
                if offset>=len(data):raise ValueError('Truncated nibble sprite')
                n=struct.unpack_from('<b',data,offset)[0];offset+=1
                if n==0:break
                if n<0:x-=n
                else:
                    size=(n+1)//2
                    if offset+size>len(data) or x+n>w:raise ValueError('Nibble run out of bounds')
                    raw=data[offset:offset+size];offset+=size
                    for j in range(n):
                        v=raw[j//2]>>(4 if j%2==0 else 0)&15
                        pixels[x+j,y]=192+v
                    x+=n
                if x>w:raise ValueError('Nibble transparency out of bounds')
        sprites.append(image if w and h else None)
    return sprites


def read_anb(data: bytes, palette: bytes, nibble: bool = False) -> tuple[list[Image.Image],dict]:
    data=unpack(data)
    if len(data)<18:raise ValueError('Truncated ANB')
    count=struct.unpack_from('<H',data)[0]
    offsets=struct.unpack_from('<4I',data,2)
    a,b,c,d=offsets
    if not 18<=a<=b<=c<=d<=len(data) or (b-a)%6 or (c-b)%10 or (d-c)%14 or len(data)-d!=count*10:
        raise ValueError('Invalid ANB section bounds')
    source_sprites=read_nibble_sprites(data[18:a],data[a:b]) if nibble else read_sprites(data[18:a],data[a:b])
    sprites=[]
    rgb=[min(255,v*4) for v in palette]
    for s in source_sprites:
        if nibble:
            if s is None:sprites.append(None);continue
            s.putpalette(rgb);s.info['transparency']=255;sprites.append(s.convert('RGBA'))
        else:
            if not s.width or not s.height:sprites.append(None);continue
            out=Image.new('RGBA',(s.width,s.height))
            for y,row in enumerate(s.pixels):
                for x,v in enumerate(row):
                    if v>=0:out.putpixel((x,y),tuple(rgb[v*3:v*3+3])+(255,))
            sprites.append(out)
    # Render all frames of animation zero using the actual component offsets.
    first,last,frames,flags=struct.unpack_from('<IIBB',data,d)
    if first%14 or first+frames*14>d-c or not frames:raise ValueError('Bad ANB first animation')
    images=[]
    for f in range(frames):
        frame=c+first+f*14
        elems,w,h,fx,delay,nelems,fflags=struct.unpack_from('<IhhHBBH',data,frame)
        if elems%10 or elems+nelems*10>c-b:raise ValueError('Bad frame element range')
        pieces=[]
        for e in range(nelems):
            sprite,x,y,eflags,colour=struct.unpack_from('<IhhBB',data,b+elems+e*10)
            if sprite%6 or sprite//6>=len(sprites):raise ValueError('Bad element sprite reference')
            image=sprites[sprite//6]
            if image is None:continue
            if eflags&1:image=ImageOps.mirror(image)
            if eflags&2:image=ImageOps.flip(image)
            pieces.append((x,y,image))
        if not pieces:continue
        left=min(x for x,y,s in pieces);top=min(y for x,y,s in pieces)
        right=max(x+s.width for x,y,s in pieces);bottom=max(y+s.height for x,y,s in pieces)
        image=Image.new('RGBA',(max(1,right-left),max(1,bottom-top)))
        for x,y,s in pieces:image.alpha_composite(s,(x-left,y-top))
        images.append(image)
    if not images:raise ValueError('ANB animation zero contains no visible sprites')
    return images,{'animations':count,'firstAnimationFrames':len(images),'spriteRecords':len(sprites),
                   'nibblePalettePolicy':'player0 ramp192..207; team/light remapping not restored' if nibble else 'original MAIN.PAL',
                   'frameOriginPolicy':'component bounding box; original frame metadata retained in source'}


def read_waves(data: bytes) -> list[tuple[int,bytes,dict]]:
    waves=[];position=0
    while True:
        position=data.find(b'RIFF',position)
        if position<0:break
        if position+12>len(data):break
        length=struct.unpack_from('<I',data,position+4)[0]+8
        if length<44 or position+length>len(data) or data[position+8:position+12]!=b'WAVE':
            position+=4;continue
        raw=data[position:position+length]
        try:
            with wave.open(io.BytesIO(raw),'rb') as w:
                params={'channels':w.getnchannels(),'sampleRate':w.getframerate(),
                        'sampleWidth':w.getsampwidth(),'frames':w.getnframes()}
                if w.getcomptype()!='NONE':raise ValueError('Non-PCM wave')
                pcm=w.readframes(w.getnframes())
                if len(pcm)!=params['frames']*params['channels']*params['sampleWidth']:
                    raise ValueError('Truncated WAV PCM')
        except (wave.Error,EOFError):
            position+=4;continue
        waves.append((position,raw,params));position+=length
    return waves


def split_scenario(meta: dict, scenario_file: str) -> tuple[dict,bytes]:
    """Keep the start-up catalog small without discarding any scenario fields."""
    scenario=(json.dumps(meta,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    heavy={'creatures','trees','buildings','stuff'}
    entry={key:value for key,value in meta.items() if key not in heavy}
    # This is an ownership-based menu filter, not a reconstruction of alliances.
    count=sum(1 for key in ('creatures','buildings') for e in meta.get(key,[])
              if e.get('owner') in (1,2,3))
    entry.update(scenarioFile=scenario_file,scenarioSha256=sha(scenario),
                 hostileCount=count,hasHostiles=bool(count))
    return entry,scenario


def split_manifest(result: dict) -> tuple[dict,dict]:
    """Move audit-only metadata off the startup path; preserve it losslessly."""
    runtime=dict(result)
    audit={'format':1,'sourceSha256':result['sourceSha256'],
           'audio':result['audio'],'spriteSources':result['spriteSources']}
    del runtime['audio']
    runtime['audioCount']=len(audit['audio'])
    runtime['assetAuditFile']='native/asset-audit.json'
    runtime['spriteSources']={key:{'source':value['source']}
                              for key,value in result['spriteSources'].items()}
    runtime['format']=2
    return runtime,audit


def run(archive: Path, output: Path) -> dict:
    archive_bytes=archive.read_bytes()
    if sha(archive_bytes)!=SOURCE_HASH:
        raise ValueError('This importer is pinned to the supplied archive version')
    output.mkdir(parents=True,exist_ok=True)
    native=output/'native';native.mkdir(exist_ok=True)
    for folder in ['maps','sprites','sounds','terrain']:(native/folder).mkdir(exist_ok=True)
    result={'format':1,'status':'native reconstruction assets; simulation parity not established',
            'sourceSha256':SOURCE_HASH,'maps':[],'sprites':{},'spriteAnimations':{},'sounds':{},'audio':[],'limitations':[
                'Terrain centre samples and original initial entity positions recovered; species-specific pathfinding not restored.',
                'ANB animation zero extracted; full state/direction animation selection not yet restored.',
                'Creature nibble images use original player-zero palette ramp; dynamic team/light remapping is not restored.',
                'Audio samples are byte-identical original PCM; selected UI event mapping is provisional.',
                'RIP speech/video omissions cannot be recreated by resource conversion.']}
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failed')
        names=z.namelist()
        for n in sorted(names):
            match=re.fullmatch(PREFIX+r'LEVELS/(CONQ|CUST)(\d{3})\.DAT',n)
            if not match:continue
            family,num=match.groups();number=int(num);stem=f'{family}{num}'
            hname=f'LEVELS/HDR{"CO" if family=="CONQ" else "CU"}{number}.DAT'
            binary,meta=read_level(z.read(n),z.read(PREFIX+hname),stem)
            file=f'native/maps/{stem}.gwm';(output/file).write_bytes(binary)
            russian_names={'Exceland':'Экселанд','Krell':'Крелл','Madami':'Мадами','Roach':'Роуч','Brown':'Браун',
                'Lunacon':'Лунакон','Oid':'Оид','Fushon':'Фушон','Vergon':'Вергон','Pylon':'Пилон','Zed':'Зед',
                'Thyroid':'Тироид','Jenner':'Дженнер','Petri':'Петри','Mirkon':'Миркон','Kruush':'Крууш',
                'Ape':'Эйп','Forte':'Форте','Huth':'Хут','Voss':'Фосс','Shnorden':'Шнорден','Natismad':'Натисмад',
                'Kaminski':'Камински','Biosphere':'Биосфера','BIOCROSS':'Биокросс','STRONGHOLD':'Цитадель',
                'DINO RACE':'Гонка дино','BIRDWORLD':'Мир птиц','FRENZY':'Безумие','FOCUSPOINT':'Точка фокуса',
                'Boing':'Прыг-скок','WATER MARGIN':'У кромки воды','Icehaven':'Ледяная гавань',
                'Freeze Zone':'Зона замерзания','Land Fight':'Битва за сушу','Solarworld':'Солнечный мир'}
            meta.update(file=file,title_ru=russian_names.get(meta['title'],meta['title']),
                        family='campaign' if family=='CONQ' else 'custom')
            scenario_file=f'native/maps/{stem}.scenario.json'
            entry,scenario=split_scenario(meta,scenario_file)
            (output/scenario_file).write_bytes(scenario)
            # Remove only byte-verified old generated map metadata, preserving
            # any unknown/user-edited JSON from earlier work in this directory.
            legacy=native/'maps'/f'{stem}.json'
            if legacy.exists():
                try:
                    if json.loads(legacy.read_text())==meta:legacy.unlink()
                except (OSError,ValueError):
                    pass
            result['maps'].append(entry)
        palette=unpack(z.read(PREFIX+'DATA/MAIN.PAL'))
        sources={}
        species_names=['DINO','CRAB','FROG','BIRD','MULE','DINOCRAB','DINOFROG','DINOBIRD','DINOMULE',
                       'CRABFROG','CRABBIRD','CRABMULE','FROGBIRD','FROGMULE','BIRDMULE','CRABDINO',
                       'FROGDINO','FROGCRAB','BIRDDINO','BIRDCRAB','BIRDFROG','MULEDINO','MULECRAB','MULEFROG','MULEBIRD']
        for i,name in enumerate(species_names):sources[f'creature_{i}']=(f'DATA/CREATURE/{name}.ANB',True)
        sources['bones']=('DATA/CREATURE/BONES.ANB',True)
        for key,name in {'EXTRACTOR':'BMINE','DISTRIBUTOR':'BPOWE','SOLAR':'BSOLA','GENE_LAB':'BGENE',
                         'RECYCLER':'BFARM','PULPER':'BSAWM','TURRET':'BTURR','SHIELD':'BSHIE',
                         'WIND':'BWIND','LANDING_PAD':'BLAUN','TECH':'BOPER','OBSERVATORY':'BOBSE','VAT':'BVAT'}.items():
            sources['building_'+key]=(f'DATA/BUILDING/{name}.ANB',False)
        for i,name in enumerate(['GRASS1','GRASS2','GRASS3','DESERT1','DESERT2','DESERT3','SNOW1','SNOW2','SNOW3','ALL1','ALL2','ALL3']):
            sources[f'plant_{i}']=(f'DATA/PLANT/{name}.ANB',False)
        for key,name in {'ENGINEER':'HARCH','BOTANIST':'HFARM','GENETICIST':'HSCIE','RANGER':'HSHEP'}.items():
            sources['specialist_'+key]=(f'DATA/SPEC/{name}.ANB',False)
        for race in ['H','C','M','Y']:
            for key,suffix in {'ENGINEER':'ARCH','BOTANIST':'FARM','GENETICIST':'SCIE','RANGER':'SHEP'}.items():
                sources[f'specialist_{race}_{key}']=(f'DATA/SPEC/{race}{suffix}.ANB',False)
        result['spriteSources']={}
        for key,(name,nibble) in sources.items():
            try:
                images,metadata=read_anb(z.read(PREFIX+name),palette,nibble)
            except ValueError as error:
                raise ValueError(f'{name}: {error}') from error
            metadata.update(source=name,sourceSha256=sha(z.read(PREFIX+name)))
            paths=[]
            for i,image in enumerate(images):
                filename=f'native/sprites/{key}_{i:03d}.png';image.save(output/filename);paths.append(filename)
            alias=f'native/sprites/{key}.png';images[0].save(output/alias)
            result['sprites'][key]=alias;result['spriteAnimations'][key]=paths;result['spriteSources'][key]=metadata
        result['sprites']['building_DETECTOR']=result['sprites']['building_OBSERVATORY']
        result['spriteAnimations']['building_DETECTOR']=result['spriteAnimations']['building_OBSERVATORY']
        result['limitations'].append('Original fusion-generator bank DATA/BUILDING/BNUKE.ANB is absent; no invented replacement is emitted.')
        waves=read_waves(z.read(PREFIX+'SOUND/SOUND.DAT'))
        for i,(offset,raw,params) in enumerate(waves):
            name=f'native/sounds/{i:03d}.wav';(output/name).write_bytes(raw)
            result['audio'].append(dict(params,index=i,file=name,sourceOffset=offset,sha256=sha(raw)))
        if len(waves)>73:
            result['sounds']={'select':'native/sounds/019.wav','build':'native/sounds/073.wav','complete':'native/sounds/067.wav'}
        music=export_music(z.read(PREFIX+'SOUND/MUSIC.DAT'),native/'music')
        result['music']=[dict(track,file='native/music/'+track['file']) for track in music['tracks']]
        result['musicLimitations']=music['limitations']
        for name in ['B32A','B32B','B32C','B32D']:
            b=unpack(z.read(PREFIX+f'DATA/{name}.DAT'))
            if len(b)!=160*32*32:raise ValueError('Unexpected terrain texture length')
            atlas=Image.new('P',(32*16,32*10));atlas.putpalette([min(255,v*4) for v in palette])
            for i in range(160):atlas.paste(Image.frombytes('P',(32,32),b[i*1024:(i+1)*1024]),((i%16)*32,(i//16)*32))
            atlas.save(native/'terrain'/f'{name}.png')
    project=Path(__file__).resolve().parent.parent
    catalogue=json.loads((project/'localization/text.ru.json').read_text())
    (native/'strings.ru.json').write_text(json.dumps([e['ru'] for e in catalogue['entries']],ensure_ascii=False)+'\n')
    runtime,audit=split_manifest(result)
    (native/'asset-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    (native/'manifest.json').write_text(json.dumps(runtime,ensure_ascii=False,separators=(',',':'))+'\n')
    return runtime


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path)
    p.add_argument('--output',type=Path,default=Path('android/app/src/main/assets'))
    args=p.parse_args();result=run(args.archive,args.output)
    print(json.dumps({'maps':len(result['maps']),'sprites':len(result['sprites']),'waves':result['audioCount'],'output':str(args.output)}))


if __name__=='__main__':main()
