#!/usr/bin/env python3
"""Inspect and validate Gene Wars TEXT.DAT; never patches game binaries."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

RESOURCE = "Gene_Wars_RePack/DATA/TEXT.DAT"
FORMAT_TOKEN = re.compile(r"%(?:%|s|d)")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def make_catalogue(raw: bytes) -> dict:
    if not raw or not raw.endswith(b"\0"):
        raise ValueError("TEXT.DAT must end with NUL")
    tail = len(raw) - len(raw.rstrip(b"\0"))
    records = raw[:-tail].split(b"\0")
    entries = []
    offset = 0
    for index, record in enumerate(records):
        source = record.decode("ascii")
        entries.append({"id": index, "offset": offset,
                        "source_bytes": len(record), "en": source, "ru": None})
        offset += len(record) + 1
    return {"format_version": 1, "resource": RESOURCE,
            "source_sha256": digest(raw), "source_bytes": len(raw),
            "trailing_nul_bytes": tail, "translation_status": "draft",
            "runtime_verified": False, "entries": entries}


def rebuild_source(catalogue: dict) -> bytes:
    entries = catalogue["entries"]
    if [e["id"] for e in entries] != list(range(len(entries))):
        raise ValueError("IDs must be ordered, unique and contiguous")
    tail = catalogue["trailing_nul_bytes"]
    if not isinstance(tail, int) or tail < 1:
        raise ValueError("Invalid trailing NUL count")
    records = []
    for entry in entries:
        source = entry["en"]
        if "\0" in source:
            raise ValueError(f"Embedded NUL in source {entry['id']}")
        records.append(source.encode("ascii"))
    return b"\0".join(records) + b"\0" * tail


def validate(catalogue: dict, require_russian: bool = True) -> dict:
    raw = rebuild_source(catalogue)
    if digest(raw) != catalogue["source_sha256"]:
        raise ValueError("Source strings or metadata changed: SHA-256 mismatch")
    if len(raw) != catalogue["source_bytes"]:
        raise ValueError("Source size mismatch")
    errors, longer = [], []
    count = 0
    offset = 0
    for entry in catalogue["entries"]:
        index, source, target = entry["id"], entry["en"], entry.get("ru")
        source_size = len(source.encode("ascii"))
        if entry["offset"] != offset or entry["source_bytes"] != source_size:
            errors.append(f"{index}: invalid source offset/length")
        offset += source_size + 1
        if target is None:
            if require_russian:
                errors.append(f"{index}: missing Russian translation")
            continue
        if not isinstance(target, str):
            errors.append(f"{index}: translation must be a string")
            continue
        count += 1
        if "\0" in target:
            errors.append(f"{index}: embedded NUL in translation")
        if not target and source:
            errors.append(f"{index}: empty translation")
        if FORMAT_TOKEN.findall(source) != FORMAT_TOKEN.findall(target):
            errors.append(f"{index}: printf tokens changed or reordered")
        if source.count("%") != target.count("%"):
            errors.append(f"{index}: percent sign count changed")
        if source.count("\r\n") != target.count("\r\n"):
            errors.append(f"{index}: CRLF count changed")
        if "\n" in target.replace("\r\n", "") or "\r" in target.replace("\r\n", ""):
            errors.append(f"{index}: unsupported standalone newline")
        if source.startswith("{ ") and not target.startswith("{ "):
            errors.append(f"{index}: leading game control marker changed")
        if source.isspace() and source != target:
            errors.append(f"{index}: reserved whitespace slot changed")
        if len(target) > len(source):
            longer.append(index)
    return {"entries": len(catalogue["entries"]), "translated": count,
            "errors": errors, "longer_than_source_ids": longer,
            "warning": "Character counts do not establish pixel width or engine buffer safety.",
            "runtime_verified": catalogue.get("runtime_verified", False)}


def write_new(path: Path, value: str) -> None:
    # Prevent accidental replacement of a user's edited translation.
    with path.open("x", encoding="utf-8", newline="") as handle:
        handle.write(value)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    extract = sub.add_parser("extract", help="Extract the source catalogue from a ZIP")
    extract.add_argument("archive", type=Path)
    extract.add_argument("output", type=Path)
    check = sub.add_parser("validate", help="Check source integrity and translation structure")
    check.add_argument("catalogue", type=Path)
    check.add_argument("--allow-incomplete", action="store_true")
    export = sub.add_parser("review", help="Export a UTF-8 CSV for translation review")
    export.add_argument("catalogue", type=Path)
    export.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "extract":
            with zipfile.ZipFile(args.archive) as archive:
                matches = [i for i in archive.infolist() if i.filename == RESOURCE]
                if len(matches) != 1:
                    raise ValueError("Expected exactly one TEXT.DAT resource")
                if matches[0].file_size > 1024 * 1024:
                    raise ValueError("Unexpectedly large TEXT.DAT resource")
                catalogue = make_catalogue(archive.read(matches[0]))
            write_new(args.output, json.dumps(catalogue, ensure_ascii=False, indent=2) + "\n")
            print(f"Extracted {len(catalogue['entries'])} entries")
        else:
            catalogue = json.loads(args.catalogue.read_text(encoding="utf-8"))
            result = validate(catalogue, not getattr(args, "allow_incomplete", False))
            if args.command == "validate":
                print(json.dumps(result, ensure_ascii=False, indent=2))
            elif result["errors"]:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                with args.output.open("x", encoding="utf-8-sig", newline="") as handle:
                    writer = csv.writer(handle)
                    writer.writerow(["id", "source_offset", "source_bytes", "en", "ru"])
                    writer.writerows((e["id"], e["offset"], e["source_bytes"], e["en"], e["ru"])
                                     for e in catalogue["entries"])
                print(f"Exported {result['translated']} translated entries")
            if result["errors"]:
                return 1
    except (OSError, KeyError, ValueError, TypeError, zipfile.BadZipFile) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
