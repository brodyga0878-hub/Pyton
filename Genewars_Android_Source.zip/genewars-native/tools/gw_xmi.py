#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Convert Gene Wars MUSIC.DAT XMIDI event streams to standard MIDI files.

This is a data decoder; DOS code is never executed. XMIDI delay bytes are
additive, whereas note lengths use ordinary MIDI VLQs. Playback uses a fixed
120 Hz clock, not the original tempo meta events. The SMF uses 60 PPQN and
500000 microseconds/quarter to preserve that clock exactly. Original tempo
values, TIMB records, and Miles loop/callback controls remain in music.json.

Timing/event semantics were checked against ScummVM's
audio/midiparser_xmidi.cpp (readVLQ2, parseNextEvent, loadMusic). This independent
implementation does not embed ScummVM code. Miles FOR/NEXT loops are exported
as one pass, with their exact start/end positions in the manifest; a normal
SMF player does not implement them. Instrument synthesis is the MIDI player's
bank, not the original game's Miles timbres.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import struct
import zipfile

RESOURCE = 'Gene_Wars_RePack/SOUND/MUSIC.DAT'
TICKS_PER_SECOND = 120
PPQN = 60
TEMPO = 500000
REFERENCE = 'https://github.com/scummvm/scummvm/blob/master/audio/midiparser_xmidi.cpp'


def _vlq(data: bytes, pos: int) -> tuple[int, int]:
    value = 0
    for _ in range(4):
        if pos >= len(data):
            raise ValueError('Truncated MIDI variable-length quantity')
        byte = data[pos]
        pos += 1
        value = (value << 7) | (byte & 127)
        if byte < 128:
            return value, pos
    raise ValueError('MIDI variable-length quantity exceeds four bytes')


def _put_vlq(value: int) -> bytes:
    if not 0 <= value <= 0x0fffffff:
        raise ValueError('MIDI delta outside four-byte VLQ range')
    result = bytearray([value & 127])
    value >>= 7
    while value:
        result.insert(0, (value & 127) | 128)
        value >>= 7
    return bytes(result)


def _chunks(data: bytes, start: int, end: int):
    while start < end:
        if start + 8 > end:
            raise ValueError('Truncated IFF chunk header')
        name = data[start:start + 4]
        size = struct.unpack_from('>I', data, start + 4)[0]
        body = start + 8
        after = body + size
        padded = after + (size & 1)
        if padded > end:
            raise ValueError('IFF chunk extends outside its container')
        yield name, body, after
        start = padded


def read_sequences(data: bytes) -> list[dict]:
    """Read concatenated XDIR/CAT records inside the game's sound-bank file."""
    if len(data) > 16 * 1024 * 1024:
        raise ValueError('Unexpectedly large MUSIC.DAT')
    result = []
    search = 0
    while True:
        start = data.find(b'FORM', search)
        if start < 0:
            break
        search = start + 4
        if data[start + 8:start + 12] != b'XDIR':
            continue
        if start + 12 > len(data):
            raise ValueError('Truncated XDIR')
        size = struct.unpack_from('>I', data, start + 4)[0]
        end = start + 8 + size
        if size < 4 or end > len(data):
            raise ValueError('Invalid XDIR size')
        info = [data[p:q] for name, p, q in _chunks(data, start + 12, end)
                if name == b'INFO']
        if len(info) != 1 or len(info[0]) != 2:
            raise ValueError('Expected one two-byte XDIR INFO chunk')
        count = struct.unpack('<H', info[0])[0]
        cat = end + (size & 1)
        if data[cat:cat + 4] != b'CAT ' or data[cat + 8:cat + 12] != b'XMID':
            raise ValueError('XDIR is not followed by CAT XMID')
        cat_size = struct.unpack_from('>I', data, cat + 4)[0]
        cat_end = cat + 8 + cat_size
        if cat_size < 4 or cat_end > len(data):
            raise ValueError('Invalid CAT size')
        tracks = []
        for name, p, q in _chunks(data, cat + 12, cat_end):
            if name != b'FORM' or data[p:p + 4] != b'XMID':
                raise ValueError('Expected FORM XMID in CAT')
            events, timbres = [], []
            for kind, a, b in _chunks(data, p + 4, q):
                raw = data[a:b]
                if kind == b'EVNT':
                    events.append((a, raw))
                elif kind == b'TIMB':
                    if len(raw) < 2:
                        raise ValueError('Truncated TIMB list')
                    number = struct.unpack_from('<H', raw)[0]
                    if len(raw) != 2 + 2 * number:
                        raise ValueError('TIMB count/size mismatch')
                    timbres = [{'program': raw[i], 'bank': raw[i + 1]}
                               for i in range(2, len(raw), 2)]
                else:
                    raise ValueError(f'Unsupported XMIDI chunk {kind!r}')
            if len(events) != 1:
                raise ValueError('Expected exactly one EVNT per FORM XMID')
            offset, payload = events[0]
            tracks.append({'offset': offset, 'events': payload,
                           'timbres': timbres, 'xdir_offset': start})
        if count != len(tracks) or count == 0:
            raise ValueError('XDIR sequence count mismatch')
        result.extend(tracks)
        search = cat_end + (cat_size & 1)
    if not result:
        raise ValueError('No valid XDIR/CAT XMIDI sequences found')
    return result


@dataclass(frozen=True)
class Event:
    tick: int
    order: int
    data: bytes
    generated_note_off: bool = False


def parse_events(data: bytes) -> tuple[list[Event], dict]:
    """Decode one EVNT; synthesize explicit note-offs without changing timing."""
    pos = tick = notes = order = zero_duration = 0
    events = []
    tempos, controls, loops = [], [], []
    loop_stack = []
    ended = False
    while pos < len(data):
        # Unlike MIDI VLQ, XMI delta bytes are summed without bit shifting.
        while pos < len(data) and data[pos] < 128:
            tick += data[pos]
            pos += 1
        if pos >= len(data):
            raise ValueError('EVNT ends with a delay instead of an event')
        status = data[pos]
        pos += 1
        order += 1
        family = status >> 4
        if status == 0xff:
            if pos >= len(data):
                raise ValueError('Truncated MIDI meta type')
            kind = data[pos]
            pos += 1
            length, pos = _vlq(data, pos)
            if pos + length > len(data):
                raise ValueError('Truncated MIDI meta data')
            payload = data[pos:pos + length]
            pos += length
            if kind == 0x2f:
                if length != 0 or any(data[pos:]):
                    raise ValueError('Invalid end-of-track or nonzero trailing EVNT data')
                ended = True
                break
            if kind == 0x51:
                if length != 3 or int.from_bytes(payload, 'big') == 0:
                    raise ValueError('Invalid tempo meta event')
                tempos.append({'tick': tick,
                               'microseconds_per_quarter': int.from_bytes(payload, 'big')})
                payload = TEMPO.to_bytes(3, 'big')
            encoded = bytes([status, kind]) + _put_vlq(length) + payload
        elif status in (0xf0, 0xf7):
            length, pos = _vlq(data, pos)
            if pos + length > len(data):
                raise ValueError('Truncated MIDI SysEx')
            encoded = bytes([status]) + _put_vlq(length) + data[pos:pos + length]
            pos += length
        elif 8 <= family <= 14:
            size = 1 if family in (12, 13) else 2
            payload = data[pos:pos + size]
            if len(payload) != size or any(byte >= 128 for byte in payload):
                raise ValueError('Invalid MIDI channel data')
            pos += size
            encoded = bytes([status]) + payload
            if family == 9:
                duration, pos = _vlq(data, pos)
                if payload[1]:
                    notes += 1
                    zero_duration += int(duration == 0)
                    # Miles emits very short zero-length notes (ScummVM: 1 tick).
                    events.append(Event(tick + max(1, duration), order,
                                        bytes([0x80 | (status & 15), payload[0], 0]), True))
                else:
                    encoded = bytes([0x80 | (status & 15), payload[0], 0])
            elif family == 11 and payload[0] >= 110:
                control = {'tick': tick, 'channel': status & 15,
                           'controller': payload[0], 'value': payload[1]}
                controls.append(control)
                if payload[0] == 116:
                    loop_stack.append({'start_tick': tick,
                                       'count': payload[1], 'channel': status & 15})
                elif payload[0] == 117:
                    if not loop_stack:
                        raise ValueError('Unmatched XMIDI NEXT/BREAK controller')
                    loop = loop_stack.pop()
                    loop.update(end_tick=tick, infinite=loop['count'] == 0 and payload[1] >= 64,
                                next_value=payload[1])
                    loops.append(loop)
        else:
            raise ValueError(f'Unsupported MIDI status 0x{status:02x}')
        events.append(Event(tick, order, encoded))
    if not ended:
        raise ValueError('Missing MIDI end-of-track')
    if loop_stack:
        raise ValueError('Unterminated XMIDI FOR loop')
    end_tick = max([tick] + [e.tick for e in events])
    # Scheduled note-offs precede retriggers at the same tick; source order is
    # otherwise unchanged. End-of-track follows every scheduled note-off.
    events.sort(key=lambda e: (e.tick, not e.generated_note_off, e.order))
    events.append(Event(end_tick, order + 1, b'\xff\x2f\x00'))
    return events, {'source_events': order, 'notes': notes,
                    'generated_note_offs': notes, 'zero_duration_notes': zero_duration,
                    'end_tick': end_tick, 'duration_seconds': end_tick / TICKS_PER_SECOND,
                    'original_tempo_events': tempos, 'xmidi_controls': controls,
                    'loops': loops, 'evnt_trailing_zero_bytes': len(data) - pos}


def convert_evnt(data: bytes) -> tuple[bytes, dict]:
    events, metadata = parse_events(data)
    track = bytearray(b'\x00\xff\x51\x03' + TEMPO.to_bytes(3, 'big'))
    previous = 0
    for event in events:
        track.extend(_put_vlq(event.tick - previous))
        track.extend(event.data)
        previous = event.tick
    header = b'MThd' + struct.pack('>IHHH', 6, 0, 1, PPQN)
    return header + b'MTrk' + struct.pack('>I', len(track)) + track, metadata


def export_music(data: bytes, output: Path) -> dict:
    """Write native/music files plus a manifest, retaining source provenance."""
    sequences = read_sequences(data)
    output.mkdir(parents=True, exist_ok=True)
    tracks = []
    for index, sequence in enumerate(sequences, 1):
        midi, details = convert_evnt(sequence['events'])
        filename = f'track{index:02d}.mid'
        (output / filename).write_bytes(midi)
        tracks.append({'id': index, 'file': filename,
                       'evnt_offset': sequence['offset'],
                       'evnt_bytes': len(sequence['events']),
                       'xdir_offset': sequence['xdir_offset'],
                       'evnt_sha256': hashlib.sha256(sequence['events']).hexdigest(),
                       'midi_sha256': hashlib.sha256(midi).hexdigest(),
                       'timbres': sequence['timbres'], **details})
    manifest = {'schema': 1, 'source': RESOURCE,
                'source_sha256': hashlib.sha256(data).hexdigest(),
                'clock_ticks_per_second': TICKS_PER_SECOND,
                'smf_format': 0, 'smf_ppqn': PPQN,
                'smf_tempo_microseconds_per_quarter': TEMPO,
                'timing_reference': REFERENCE,
                'playback': 'one pass; Miles FOR/NEXT controls are retained but not expanded',
                'limitations': [
                    'MIDI instrument synthesis uses the platform bank, not Miles timbres.',
                    'Game callbacks and branches are not executed by a standard MIDI player.',
                    'Whole-file repeat differs from the original marked loop region.',
                    'Four stored sequences may be bank variants, not four unique compositions.',
                ],
                'tracks': tracks}
    (output / 'music.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('output', type=Path, help='native/music output directory')
    args = parser.parse_args()
    with zipfile.ZipFile(args.archive) as archive:
        members = [i for i in archive.infolist() if i.filename == RESOURCE]
        if len(members) != 1 or members[0].file_size > 16 * 1024 * 1024:
            raise ValueError('Expected exactly one bounded MUSIC.DAT resource')
        data = archive.read(members[0])
    manifest = export_music(data, args.output)
    print(json.dumps({'tracks': len(manifest['tracks']),
                      'notes': [t['notes'] for t in manifest['tracks']],
                      'durations_seconds': [t['duration_seconds'] for t in manifest['tracks']]}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
