#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Extract proven parameter tables from the supplied retail Gene Wars executable.

The layout names are informed by mefistotelis/genewars (Tomasz Lis, GPL-2.0+),
but values are read from this executable, not copied from that different build.
No gameplay code from the executable is run. Only the identified SHA-256 is
accepted: raw file offsets must never be reused silently for another version.
"""

import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile

EXE_NAME = 'Gene_Wars_RePack/GW.EXE'
EXE_SHA256 = '6a8c75b7de5f4e7f27c5378b712e04c24fd106778429f5765c49a641fac90e64'
BUILDINGS = ['GENELAB', 'TURRET', 'SAWMILL', 'POWERSTATION', 'FARM',
             'LAUNCHER', 'SOLAR', 'OBSERVATORY', 'WIND', 'NUCLEAR',
             'OPERATIONS', 'MINE', 'SHIELD', 'GOOPVAT']
SPECIES = ['DINO', 'CRAB', 'FROG', 'BIRD', 'MULE', 'DINOCRAB', 'DINOFROG',
           'DINOBIRD', 'DINOMULE', 'CRABBOFROG', 'CRABBOBIRD', 'CRABBOMULE',
           'FROGGOBIRD', 'FROGGOMULE', 'BIRDDOMULE', 'CRABBOSAUR', 'FROGGOSAUR',
           'FROGGOCRAB', 'BIRDDOSAUR', 'BIRDDOCRAB', 'BIRDDOFROG', 'MULEOSAUR',
           'MULEOCRAB', 'MULEOFROG', 'MULEOBIRD']
SPECIES_FIELDS = ['smarts_raw', 'strength', 'defense', 'speed_raw',
                  'life_span_raw', 'health', 'energy', 'rest_frequency_raw',
                  'births_per_life', 'mass_raw', 'food_0', 'food_1', 'food_2',
                  'cost_in_goop', 'wuss', 'half_life_stored', 'birth_span_stored']


def table(exe, offset, fmt, count):
    return list(struct.unpack_from('<' + fmt * count, exe, offset))


def chunks(values, width):
    return [values[i:i+width] for i in range(0, len(values), width)]


def extract(exe):
    actual = hashlib.sha256(exe).hexdigest()
    if actual != EXE_SHA256:
        raise ValueError('Unsupported GW.EXE SHA-256; offsets are version specific')
    costs = table(exe, 0x126C1C, 'i', 14)
    bmax = chunks(table(exe, 0x126B1E, 'h', 42), 3)
    power = table(exe, 0x126B10, 'B', 14)
    foundations = table(exe, 0x126BE0, 'B', 14)
    tech = chunks(table(exe, 0x126B88, 'B', 42), 3)
    species = []
    for index, name in enumerate(SPECIES):
        offset = 0x1263FC + index * 45
        values = struct.unpack_from('<iBBiiiiiBh3BiBii', exe, offset)
        record = dict(zip(SPECIES_FIELDS, values))
        record.update(id=index, name=name, file_offset=hex(offset))
        record['half_life_after_initialization'] = record['life_span_raw'] // 2
        record['birth_span_after_initialization'] = (record['life_span_raw'] // 2) // record['births_per_life']
        species.append(record)
    plants = []
    for index in range(12):
        offset = 0x126980 + index * 32
        name = exe[offset:offset+16].split(b'\0', 1)[0].decode('ascii')
        fields = table(exe, offset+24, 'B', 8)
        plants.append(dict(id=index, name=name, file_offset=hex(offset),
                           terrain=table(exe, offset+16, 'b', 8),
                           **dict(zip(['seed_time_raw', 'range_raw', 'max_neighbours',
                                       'life_span_raw', 'food', 'wood', 'seeds', 'density_raw'], fields))))
    genes = chunks(table(exe, 0x126864, 'B', 50), 2)
    lookup = chunks(table(exe, 0x126898, 'B', 25), 5)
    for index, pair in enumerate(genes):
        if lookup[pair[0]][pair[1]] != index:
            raise ValueError('Gene matrix does not agree with species order')
    if not all(record['health'] > 0 and record['births_per_life'] > 0 for record in species):
        raise ValueError('Invalid species table')
    return {
        'source_exe_sha256': actual,
        'source_layout_reference': 'mefistotelis/genewars commit 72ec4c4908d26304dd373132cb3187c855d4bf58',
        'status': 'extracted parameters; not a recovered complete simulation',
        'time_units': 'raw engine values; real-time conversion not established',
        'buildings': [dict(id=i, name=name, base_goop_cost=costs[i],
                           bmax_by_stage=bmax[i], power_table_value=power[i],
                           foundation_size=foundations[i], tech_by_stage=tech[i])
                      for i, name in enumerate(BUILDINGS)],
        'building_cost_formula': {
            'routine_object1': '0x20170',
            'expression': 'buildingGoopCost[type] - 2 * selected_specialist.ability',
            'scope_note': 'Confirmed primitive cost query; callers may impose additional conditions.'},
        'species': species, 'genes': genes, 'species_lookup': lookup, 'plants': plants,
        'specialist_races': [dict(id=i, **dict(zip(['speed_raw', 'discover_range_raw',
                                                   'max_ability', 'max_strength'],
                                                  table(exe, 0x1268E8+i*16, 'i', 4))))
                             for i in range(4)],
        'terrain_friction_raw': table(exe, 0x126320, 'h', 8),
        'terrain_bounce_raw': table(exe, 0x126330, 'h', 8),
        'terrain_sampling': {'routine_object1': '0x7B520', 'center_type': '(GridTile.Block >> 8) & 7',
                             'water_rule': 'A zero-type sampled tile with nonzero type in any of eight neighbours returns 1; otherwise 0.',
                             'coordinate_rule': 'Original sample also chooses the neighbour from the low-byte fractional position; importer exposes center type.'},
        'unrecovered': ['AI decision timings', 'movement tick duration', 'exact attack damage formulas',
                        'energy generation and consumption rates', 'full mission event interpreter',
                        'breeding eligibility and inheritance modifiers', 'original save-state compatibility']
    }


def java_array(values):
    if values and isinstance(values[0], list):
        return '{' + ', '.join(java_array(row) for row in values) + '}'
    return '{' + ', '.join(str(v) for v in values) + '}'


def java_source(rules):
    species = rules['species']
    arrays = {
        'SPECIES_HEALTH': [v['health'] for v in species],
        'SPECIES_ENERGY': [v['energy'] for v in species],
        'SPECIES_SPEED': [v['speed_raw'] for v in species],
        'SPECIES_STRENGTH': [v['strength'] for v in species],
        'SPECIES_DEFENSE': [v['defense'] for v in species],
        'SPECIES_COST': [v['cost_in_goop'] for v in species],
        'SPECIES_LIFESPAN': [v['life_span_raw'] for v in species],
        'SPECIES_GENES': rules['genes'], 'SPECIES_LOOKUP': rules['species_lookup'],
        'BUILDING_BASE_COST': [v['base_goop_cost'] for v in rules['buildings']],
        'BUILDING_BMAX': [v['bmax_by_stage'] for v in rules['buildings']],
        'PLANT_FOOD': [v['food'] for v in rules['plants']],
        'PLANT_WOOD': [v['wood'] for v in rules['plants']],
        'PLANT_SEEDS': [v['seeds'] for v in rules['plants']],
    }
    result = ['// SPDX-License-Identifier: GPL-2.0-or-later',
              '// Generated by tools/gw_rules.py from the exact uploaded GW.EXE, never executed.',
              '// Layout reference: Tomasz Lis / mefistotelis/genewars, GPL-2.0-or-later.',
              '// Binary SHA-256: ' + EXE_SHA256,
              '// Species: file 0x1263FC, 25 packed records x 45 bytes.',
              '// Genes: 0x126864; species lookup: 0x126898; building costs: 0x126C1C.',
              '// All speeds/lifespans remain raw values, not proven units per second.',
              'package org.genewars.core;', '', 'public final class RetailRules {',
              '    private RetailRules() {}']
    for name, values in arrays.items():
        dims = '[][]' if values and isinstance(values[0], list) else '[]'
        result.append('    public static final int' + dims + ' ' + name + ' = ' + java_array(values) + ';')
    result.extend(['}', ''])
    return '\n'.join(result)


def write_new(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as handle:
        handle.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--java-output', type=Path)
    args = parser.parse_args()
    with zipfile.ZipFile(args.archive) as archive:
        matches = [i for i in archive.infolist() if i.filename == EXE_NAME]
        if len(matches) != 1 or matches[0].file_size > 2 * 1024 * 1024:
            raise ValueError('Expected one supported GW.EXE')
        rules = extract(archive.read(matches[0]))
    write_new(args.output, json.dumps(rules, ensure_ascii=False, indent=2) + '\n')
    if args.java_output:
        write_new(args.java_output, java_source(rules))
    print('Extracted 14 building types, 25 species, 12 plants, 4 specialist races.')


if __name__ == '__main__':
    main()
