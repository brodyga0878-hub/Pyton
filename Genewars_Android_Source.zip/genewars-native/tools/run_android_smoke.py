#!/usr/bin/env python3
"""Run installed native smoke instrumentation and preserve its real result.

Use only on a development device: the test replaces the game's local save slot.
Both application APKs must already be installed and signed with the same key.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import threading
import time


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--adb", default="adb")
    parser.add_argument("--serial", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    name = "smoke-" + time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    log = args.output / (name + ".log")
    command = [args.adb, "-s", args.serial, "shell", "am", "instrument", "-w", "-r",
               "org.genewars.smoke/.NativeSmokeInstrumentation"]
    started = time.monotonic()
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, bufsize=1)
    timer = threading.Timer(600, process.kill)
    timer.start()
    lines = []
    try:
        with log.open("x", encoding="utf-8") as handle:
            for line in process.stdout:
                handle.write(line)
                handle.flush()
                lines.append(line)
                print(line, end="", flush=True)
        exit_code = process.wait()
    finally:
        timer.cancel()
    output = "".join(lines)
    # Android's am can return 0 for failed instrumentation. The Bundle and count
    # establish success; raw mode is required to expose them to this runner.
    passed = (exit_code == 0 and "INSTRUMENTATION_RESULT: status=passed" in output
              and "INSTRUMENTATION_RESULT: passed_checks=6" in output)
    result = {"adb_exit_code": exit_code, "passed": passed, "expected_checks": 6,
              "serial": args.serial, "seconds": round(time.monotonic() - started, 3),
              "log": str(log), "scope": "native UI/command/save/Activity restart"}
    log.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
