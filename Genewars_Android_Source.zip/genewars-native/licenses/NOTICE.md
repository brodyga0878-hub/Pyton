# Research tool and generated font notices

`tools/gw_rnc.py` adapts the RNC1 decoding algorithm from Jon Skeet / Tomasz Lis,
KeeperFX `src/bflib_dernc.c`; it and `tools/gw_fonts.py` are provided under
GPL-2.0-or-later. The licence text is in `GPL-2.0.txt`.

Reference used during implementation:
https://github.com/dkfans/keeperfx/blob/master/src/bflib_dernc.c

No error-ignore flags are used. The decoder verifies the RNC packed-data and
unpacked-data CRC16 checksums and expected unpacked lengths.

The optional experimental letter rasterizer uses the system-installed
DejaVuSans-Bold.ttf. Its font licence and attribution are preserved in
`DejaVu-copyright.txt`. The system font is not bundled by these tools; its path
and SHA-256 are written into each generated font manifest.

These notices concern the tools and font source. They do not grant rights to
Gene Wars, its original executable, original art, music, text or other game
assets. The game ZIP is not part of the repository. Output files retain some
original glyphs and should remain local development resources.
