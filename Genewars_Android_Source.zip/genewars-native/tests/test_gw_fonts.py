import struct
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from gw_fonts import ALPHABET, ENCODING, Sprite, read_sprites, write_sprites
from gw_rnc import crc16, unpack


class FontResourceTests(unittest.TestCase):
    def test_rle_roundtrip_handles_transparent_runs_and_zero_colour(self):
        sprites = [Sprite(0, 0, ()), Sprite(5, 3, (
            (-1, -1, 0, 1, -1), (255, 2, -1, 0, 7), (-1, -1, -1, -1, -1))) ]
        data, table = write_sprites(sprites)
        self.assertEqual(read_sprites(data, table), sprites)
        self.assertEqual(struct.unpack_from('<H', data)[0], len(sprites))
        self.assertEqual(len(table), 12)

    def test_long_runs_are_split_at_signed_byte_limit(self):
        sprites = [Sprite(0, 0, ()), Sprite(240, 2, (tuple([-1]*240), tuple([17]*240)))]
        data, table = write_sprites(sprites)
        self.assertEqual(read_sprites(data, table), sprites)

    def test_bad_table_and_run_are_rejected(self):
        with self.assertRaises(ValueError):
            read_sprites(b'', b'bad')
        with self.assertRaisesRegex(ValueError, 'width'):
            read_sprites(b'\x02\x01\x01\x00', struct.pack('<IBB', 0, 1, 1))

    def test_encoding_is_66_contiguous_single_byte_slots(self):
        self.assertEqual(len(ALPHABET), 66)
        self.assertEqual(list(ENCODING.values()), list(range(128, 194)))
        self.assertEqual(ENCODING['Ё'], 134)
        self.assertEqual(ENCODING['ё'], 167)

    def test_raw_bytes_unchanged_and_bad_rnc_crc_rejected(self):
        self.assertEqual(unpack(b'raw\0resource'), b'raw\0resource')
        # Header claims one byte with an intentionally wrong packed-data CRC.
        header = b'RNC\x01' + struct.pack('>IIHH', 1, 1, 0, 0) + b'\0\x01'
        with self.assertRaisesRegex(ValueError, 'packed CRC'):
            unpack(header+b'A')
        self.assertEqual(crc16(b'123456789'), 0xBB3D)


if __name__ == '__main__':
    unittest.main()
