import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from gw_xmi import convert_evnt, export_music, parse_events, read_sequences


def chunk(name, data):
    return name + struct.pack('>I', len(data)) + data + bytes(len(data) & 1)


def bank(events):
    timbres = chunk(b'TIMB', b'\x01\x00\x05\x00')
    directory = chunk(b'FORM', b'XDIR' + chunk(b'INFO', b'\x01\x00'))
    track = chunk(b'FORM', b'XMID' + timbres + chunk(b'EVNT', events))
    return directory + chunk(b'CAT ', b'XMID' + track)


def read_smf(data):
    # Deliberately independent test decoder for generated, non-running-status
    # SMF: validate byte boundaries, deltas, meta lengths, and event values.
    assert data[:4] == b'MThd'
    length, fmt, tracks, ppqn = struct.unpack_from('>IHHH', data, 4)
    assert (length, fmt, tracks) == (6, 0, 1)
    assert data[14:18] == b'MTrk'
    assert struct.unpack_from('>I', data, 18)[0] == len(data) - 22
    p, tick, result = 22, 0, []

    def quantity():
        nonlocal p
        value = 0
        while True:
            b = data[p]
            p += 1
            value = value * 128 + (b & 127)
            if b < 128:
                return value

    while p < len(data):
        tick += quantity()
        status = data[p]
        p += 1
        if status == 255:
            kind = data[p]
            p += 1
            n = quantity()
            payload = data[p:p + n]
            p += n
            result.append((tick, status, kind, payload))
        elif status in (240, 247):
            n = quantity()
            result.append((tick, status, data[p:p + n]))
            p += n
        else:
            n = 1 if status >> 4 in (12, 13) else 2
            payload = data[p:p + n]
            assert len(payload) == n and all(x < 128 for x in payload)
            p += n
            result.append((tick, status, *payload))
    assert p == len(data)
    assert result[-1][1:3] == (255, 47)
    return ppqn, result


class XmidiConversionTests(unittest.TestCase):
    def test_additive_delays_and_vlq_durations_become_real_note_offs(self):
        # Delay 127+73=200 (not a VLQ); duration 0x8100=128.
        source = b'\xc2\x05\x7f\x49\x92\x3c\x64\x81\x00\x01\xb2\x07\x70\xff\x2f\x00'
        midi, info = convert_evnt(source)
        ppqn, events = read_smf(midi)
        self.assertEqual(ppqn, 60)
        self.assertIn((200, 0x92, 60, 100), events)
        self.assertIn((328, 0x82, 60, 0), events)
        self.assertIn((201, 0xb2, 7, 112), events)
        self.assertEqual(events[-1][0], 328)
        self.assertEqual(info['notes'], 1)
        self.assertAlmostEqual(info['duration_seconds'], 328 / 120)

    def test_tempo_normalization_preserves_fixed_xmidi_time_and_provenance(self):
        source = b'\xff\x51\x03\x09\x70\x3d\x78\xff\x2f\x00'
        midi, info = convert_evnt(source)
        ppqn, events = read_smf(midi)
        tempos = [e for e in events if e[1:3] == (255, 81)]
        self.assertTrue(all(int.from_bytes(e[3], 'big') == 500000 for e in tempos))
        self.assertEqual(info['original_tempo_events'],
                         [{'tick': 0, 'microseconds_per_quarter': 618557}])
        self.assertEqual(events[-1][0] * 500000 / ppqn / 1000000, 1.0)

    def test_loop_markers_controls_and_pitch_are_retained_without_fake_expansion(self):
        source = b'\xc1\x08\x01\xb1\x74\x00\xe1\x00\x40\x05\xb1\x75\x7f\xff\x2f\x00'
        midi, info = convert_evnt(source)
        _, events = read_smf(midi)
        self.assertIn((0, 0xc1, 8), events)
        self.assertIn((1, 0xe1, 0, 64), events)
        self.assertIn((1, 0xb1, 116, 0), events)
        self.assertIn((6, 0xb1, 117, 127), events)
        self.assertEqual(info['loops'], [{'start_tick': 1, 'end_tick': 6,
                                         'channel': 1, 'count': 0,
                                         'infinite': True, 'next_value': 127}])

    def test_note_off_precedes_same_tick_retrigger_and_zero_duration_does_not_hang(self):
        source = b'\x90\x3c\x64\x01\x01\x90\x3c\x64\x00\xff\x2f\x00'
        midi, info = convert_evnt(source)
        _, events = read_smf(midi)
        at_one = [e for e in events if e[0] == 1]
        self.assertEqual(at_one, [(1, 0x80, 60, 0), (1, 0x90, 60, 100)])
        self.assertIn((2, 0x80, 60, 0), events)
        self.assertEqual(info['zero_duration_notes'], 1)

    def test_bank_parser_checks_containers_and_export_has_provenance(self):
        source = bank(b'\x90\x3c\x64\x03\x04\xff\x2f\x00')
        sequences = read_sequences(source + b'padding' + source)
        self.assertEqual(len(sequences), 2)
        self.assertEqual(sequences[0]['timbres'], [{'program': 5, 'bank': 0}])
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            manifest = export_music(source, output)
            self.assertEqual(manifest['tracks'][0]['notes'], 1)
            self.assertEqual(read_smf((output / 'track01.mid').read_bytes())[1][-1][0], 4)
            self.assertEqual(json.loads((output / 'music.json').read_text()), manifest)
        for candidate in [source[:-1], source.replace(b'\x00\x00\x00\x02\x01\x00',
                                                    b'\x00\x00\x00\x02\x02\x00', 1)]:
            with self.subTest(candidate=candidate.hex()):
                with self.assertRaises(ValueError):
                    read_sequences(candidate)

    def test_invalid_event_data_is_rejected(self):
        for candidate in [b'\x90\x3c\x64\x81', b'\x90\xff\x64\x01',
                          b'\xff\x51\x03\x00', b'\x90\x3c\x64\x01',
                          b'\xff\x2f\x00\x01', b'\x04', b'\xf4',
                          b'\xb0\x75\x7f\xff\x2f\x00']:
            with self.subTest(candidate=candidate.hex()):
                with self.assertRaises(ValueError):
                    parse_events(candidate)


if __name__ == '__main__':
    unittest.main()
