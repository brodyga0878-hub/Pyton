import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from gw_text import make_catalogue, rebuild_source, validate


class TextIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.raw = b"{ Select %s\0%d creatures\r\n%d specialists\0%d%% capacity\0 \0\0"
        self.catalogue = make_catalogue(self.raw)
        for entry, target in zip(self.catalogue["entries"], [
            "{ Выбрать %s", "%d существ\r\n%d специалистов", "%d%% объёма", " "
        ]):
            entry["ru"] = target

    def test_exact_roundtrip_preserves_offsets_and_double_terminator(self):
        self.assertEqual(rebuild_source(self.catalogue), self.raw)
        self.assertEqual(validate(self.catalogue)["errors"], [])

    def test_source_edit_cannot_pass_as_original(self):
        self.catalogue["entries"][0]["en"] = "Other %s"
        with self.assertRaisesRegex(ValueError, "SHA-256"):
            validate(self.catalogue)

    def test_format_damage_control_marker_and_nul_are_rejected(self):
        for index, value, message in [
            (0, "Выбрать %s", "marker"),
            (0, "{ Выбрать %d", "printf"),
            (0, "{ Выбрать %s\0", "NUL"),
            (1, "%d существ\n%d специалистов", "newline"),
            (2, "%d% объёма", "printf"),
            (3, "Перевод", "whitespace"),
        ]:
            with self.subTest(value=value):
                candidate = copy.deepcopy(self.catalogue)
                candidate["entries"][index]["ru"] = value
                self.assertTrue(any(message in e for e in validate(candidate)["errors"]))

    def test_missing_id_and_translation_are_rejected(self):
        candidate = copy.deepcopy(self.catalogue)
        candidate["entries"].pop(1)
        with self.assertRaisesRegex(ValueError, "IDs"):
            validate(candidate)
        self.catalogue["entries"][0]["ru"] = None
        self.assertTrue(validate(self.catalogue)["errors"])


if __name__ == "__main__":
    unittest.main()
