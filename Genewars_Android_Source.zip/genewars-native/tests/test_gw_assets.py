import io
import json
from pathlib import Path
import struct
import sys
import unittest
import wave
import zlib

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from gw_assets import (BUILDING_BASE, CREATURE_BASE, GRID_OFFSET, GRID_STRIDE,
                       LEVEL_SIGNATURE, LEVEL_SIZE, MAP_SIZE, PLANT_BASE,
                       make_gwm, read_anb, read_level, read_nibble_sprites,
                       read_waves, split_manifest, split_scenario, terrain_types)


class NativeAssetTests(unittest.TestCase):
    def test_gwm_header_signed_elevation_and_crc(self):
        count=MAP_SIZE*MAP_SIZE
        terrain=[3]*count;elevation=[-7]*count
        result=make_gwm('CONQ001',terrain,elevation)
        self.assertEqual(struct.unpack_from('>IHHHH',result),(0x47574d31,1,128,128,7))
        self.assertEqual(result[12:19],b'CONQ001')
        self.assertEqual(struct.unpack_from('>I',result,19)[0],count)
        self.assertEqual(struct.unpack_from('>BhB',result,23),(3,-7,1))
        self.assertEqual(struct.unpack_from('>BhB',result,23+4*129),(3,-7,0))
        self.assertEqual(struct.unpack_from('>I',result,len(result)-4)[0],zlib.crc32(result[:-4]))

    def test_retail_terrain_bitfield_and_eight_neighbour_shore(self):
        blocks=[0]*16384
        blocks[64*128+64]=0x7303
        kinds=terrain_types(blocks)
        self.assertEqual(kinds[64*128+64],3)
        self.assertEqual(kinds[63*128+63],1)
        self.assertEqual(kinds[62*128+62],0)
        blocks=[0]*16384;blocks[127]=0x0303
        self.assertEqual(terrain_types(blocks)[0],1)
        with self.assertRaises(ValueError):terrain_types([0])

    def make_level(self):
        data=bytearray(LEVEL_SIZE);header=bytearray(699)
        struct.pack_into('<I',data,0,LEVEL_SIGNATURE)
        header[32:39]=b'Fixture'
        data[7240:7879]=header[32:671]
        return data,header

    def test_retail_entities_and_wrapped_fixed_point_coordinates(self):
        data,header=self.make_level()
        struct.pack_into('<hh',data,13648,1,1)
        data[CREATURE_BASE+6]=1
        struct.pack_into('<hh',data,CREATURE_BASE+7,-256,62*256)
        data[CREATURE_BASE+24]=4;data[CREATURE_BASE+114]=4
        struct.pack_into('<h',data,CREATURE_BASE+98,77)
        data[PLANT_BASE+6]=2
        struct.pack_into('<hh',data,PLANT_BASE+7,95*256,66*256)
        data[PLANT_BASE+35]=3
        struct.pack_into('<h',data,PLANT_BASE+36,22)
        data[BUILDING_BASE+6]=4
        data[BUILDING_BASE+37]=3
        struct.pack_into('<H',data,BUILDING_BASE+41,1)
        _,meta=read_level(bytes(data),bytes(header),'CONQ001')
        self.assertEqual(meta['creatures'][0]['x'],127)
        self.assertEqual(meta['creatures'][0]['sourceX'],-256)
        self.assertEqual(meta['creatures'][0]['health'],77)
        self.assertEqual(meta['trees'][0]['species'],3)
        self.assertEqual(meta['buildings'][0]['flags'],1)
        data[0]=0
        with self.assertRaisesRegex(ValueError,'version'):read_level(bytes(data),bytes(header),'CONQ001')

    def test_mismatched_planet_and_counts_rejected(self):
        data,header=self.make_level();header[33]=90
        with self.assertRaisesRegex(ValueError,'planet'):read_level(bytes(data),bytes(header),'CONQ001')
        data,header=self.make_level();struct.pack_into('<h',data,13648,1)
        with self.assertRaisesRegex(ValueError,'counts'):read_level(bytes(data),bytes(header),'CONQ001')

    def test_anb_frame_component_and_palette_preserved(self):
        sprite=b'\1\0\1\x64\0'
        table=struct.pack('<IBB',2,1,1)
        element=struct.pack('<IhhBB',0,-2,-3,0,0)
        frame=struct.pack('<IhhHBBH',0,1,1,0,1,1,0)
        anim=struct.pack('<IIBB',0,0,1,0)
        a=18+len(sprite);b=a+len(table);c=b+len(element);d=c+len(frame)
        raw=struct.pack('<H4I',1,a,b,c,d)+sprite+table+element+frame+anim
        palette=bytes([10,20,30])*256
        images,meta=read_anb(raw,palette)
        self.assertEqual(images[0].getpixel((0,0)),(40,80,120,255))
        self.assertEqual(meta['firstAnimationFrames'],1)
        bad=bytearray(raw);struct.pack_into('<I',bad,b,1)
        with self.assertRaisesRegex(ValueError,'sprite reference'):read_anb(bytes(bad),palette)

    def test_nibble_odd_run_and_bounds(self):
        image=read_nibble_sprites(bytes([3,0x12,0x30,0]),struct.pack('<IBB',0,3,1))[0]
        self.assertEqual([image.getpixel((x,0)) for x in range(3)],[193,194,195])
        with self.assertRaisesRegex(ValueError,'bounds'):
            read_nibble_sprites(bytes([4,0x12,0x34,0]),struct.pack('<IBB',0,3,1))

    def test_wave_original_bytes_preserved_and_truncation_rejected(self):
        out=io.BytesIO()
        with wave.open(out,'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(22050);w.writeframes(b'\0\0'*20)
        raw=out.getvalue();found=read_waves(b'prefix'+raw+b'padding'+raw)
        self.assertEqual(len(found),2)
        self.assertEqual(found[0][0],6)
        self.assertEqual(found[0][1],raw)
        self.assertEqual(found[0][2]['frames'],20)
        self.assertEqual(read_waves(raw[:-1]),[])

    def test_scenario_split_preserves_full_world_without_startup_arrays(self):
        source={'file':'native/maps/CONQ001.gwm','title_ru':'Экселанд','payment':2000,
                'dropSites':[{'x':81,'y':53}],
                'creatures':[{'owner':4,'species':4,'x':64.0,'y':62.0}],
                'trees':[{'owner':4,'species':3,'x':95.453125,'y':66.421875}],
                'buildings':[{'owner':2,'type':3,'flags':1}],
                'stuff':[{'type':4,'x':77,'y':50}]}
        entry,raw=split_scenario(source,'native/maps/CONQ001.scenario.json')
        self.assertEqual(json.loads(raw),source)
        for key in ('creatures','trees','buildings','stuff'):self.assertNotIn(key,entry)
        self.assertEqual(entry['payment'],source['payment'])
        self.assertEqual(entry['dropSites'],source['dropSites'])
        self.assertEqual(entry['hostileCount'],1)
        self.assertTrue(entry['hasHostiles'])
        self.assertEqual(entry['scenarioFile'],'native/maps/CONQ001.scenario.json')
        self.assertIn('creatures',source)

    def test_runtime_manifest_split_preserves_audit_and_sprite_alias_source(self):
        source={'sourceSha256':'123','audio':[{'file':'native/sounds/000.wav','sha256':'456'}],
                'sprites':{'creature_0':'native/sprites/creature_0.png'},
                'spriteSources':{'creature_0':{'source':'DATA/CREATURE/DINO.ANB','sourceSha256':'789','spriteRecords':91}},
                'maps':[]}
        runtime,audit=split_manifest(source)
        self.assertNotIn('audio',runtime)
        self.assertEqual(runtime['audioCount'],1)
        self.assertEqual(runtime['assetAuditFile'],'native/asset-audit.json')
        self.assertEqual(audit['audio'],source['audio'])
        self.assertEqual(audit['spriteSources'],source['spriteSources'])
        self.assertEqual(runtime['spriteSources']['creature_0']['source'],'DATA/CREATURE/DINO.ANB')
        self.assertEqual(runtime['sprites'],source['sprites'])
        self.assertIn('audio',source)


if __name__=='__main__':unittest.main()
