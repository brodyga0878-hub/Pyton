package org.genewars.android;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.genewars.core.WorldMap;
import org.genewars.core.GameState;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;

/** Loads only resources bundled with this app. It never opens DOS executables. */
final class AssetRepository {
    static final class MapEntry {
        final String file;
        final String name;
        final String title;
        final int index;
        final double dropX;
        final double dropY;
        final JSONObject scenario;
        final boolean hasHostiles;
        MapEntry(String file, String name, String title, int index, double dropX, double dropY, JSONObject scenario) {
            this.file = file; this.name = name; this.title = title; this.index = index;
            this.dropX = dropX; this.dropY = dropY;
            this.scenario = scenario;
            boolean hostiles = scenario.optBoolean("hasHostiles", false);
            for (String key : new String[]{"creatures", "buildings"}) {
                JSONArray records = scenario.optJSONArray(key);
                if (records == null) continue;
                for (int i = 0; i < records.length(); i++) {
                    JSONObject record = records.optJSONObject(i);
                    int owner = record == null ? 0 : record.optInt("owner", 0);
                    if (owner >= 1 && owner <= 3) hostiles = true;
                }
            }
            hasHostiles = hostiles;
        }
        String displayTitle() {
            return title.length() > 0 ? title : "Карта " + (index + 1);
        }
    }

    final AssetManager assets;
    final List<MapEntry> maps = new ArrayList<MapEntry>();
    private final Map<String, String> spritePaths = new HashMap<String, String>();
    private final Map<String, Bitmap> imagesByPath = new ConcurrentHashMap<String, Bitmap>();
    private final Set<String> pendingImages = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final Set<String> failedImages = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final ExecutorService graphicsWorker = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "native-graphics"); thread.setDaemon(true); return thread;
        }
    });
    private volatile boolean closed;
    final Map<String, String> sounds = new HashMap<String, String>();
    final List<String> music = new ArrayList<String>();

    AssetRepository(Context context) throws Exception {
        long started = android.os.SystemClock.elapsedRealtime();
        assets = context.getAssets();
        JSONObject manifest = new JSONObject(readText("native/manifest.json", 4 * 1024 * 1024));
        JSONArray entries = manifest.getJSONArray("maps");
        if (entries.length() < 1 || entries.length() > 100) throw new IOException("Некорректный список карт");
        for (int i = 0; i < entries.length(); i++) {
            JSONObject item = entries.getJSONObject(i);
            String title = item.optString("title_ru", "");
            String name = item.optString("name", "");
            if (title.length() == 0) {
                title = name.startsWith("CUST") ? "Своя карта " + (i + 1) : "Планета " + (i + 1);
            }
            JSONArray dropSites = item.optJSONArray("dropSites");
            JSONObject drop = dropSites != null && dropSites.length() > 0 ? dropSites.optJSONObject(0) : null;
            maps.add(new MapEntry(safe(item.getString("file")), name, title, i,
                    drop == null ? Double.NaN : drop.optDouble("x", Double.NaN),
                    drop == null ? Double.NaN : drop.optDouble("y", Double.NaN), item));
        }
        JSONObject imageEntries = manifest.optJSONObject("sprites");
        if (imageEntries != null) {
            for (Iterator<String> iterator = imageEntries.keys(); iterator.hasNext();) {
                String key = iterator.next();
                Object value = imageEntries.get(key);
                String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
                spritePaths.put(key, safe(path));
            }
        }
        JSONObject sources = manifest.optJSONObject("spriteSources");
        if (sources != null) for (Iterator<String> iterator = sources.keys(); iterator.hasNext();) {
            String key = iterator.next();
            JSONObject info = sources.optJSONObject(key);
            String path = spritePaths.get(key);
            if (info == null || path == null) continue;
            String source = info.optString("source", "");
            int slash = source.lastIndexOf('/');
            String name = source.substring(slash + 1).replace(".ANB", "");
            if (source.contains("/CREATURE/")) spritePaths.put("creatures/" + name, path);
            else if (source.contains("/BUILDING/")) spritePaths.put("buildings/" + name, path);
            else if (source.contains("/SPEC/")) spritePaths.put("specialists/" + name, path);
        }
        JSONObject audioEntries = manifest.optJSONObject("sounds");
        if (audioEntries != null) {
            for (Iterator<String> iterator = audioEntries.keys(); iterator.hasNext();) {
                String key = iterator.next();
                Object value = audioEntries.get(key);
                String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
                sounds.put(key, safe(path));
            }
        }
        JSONArray musicEntries = manifest.optJSONArray("music");
        if (musicEntries != null) for (int i = 0; i < musicEntries.length(); i++) {
            Object value = musicEntries.get(i);
            String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
            music.add(safe(path));
        }
        android.util.Log.i("GeneWars", "Resource index ready: " + maps.size() + " maps in "
                + (android.os.SystemClock.elapsedRealtime() - started) + " ms; graphics deferred");
    }

    WorldMap loadMap(MapEntry entry) throws IOException {
        try (InputStream in = assets.open(entry.file)) { return WorldMap.read(in); }
    }

    GameState startGame(MapEntry entry, int mission, long seed) throws Exception {
        JSONObject scenario = entry.scenario;
        if (scenario.has("scenarioFile")) {
            scenario = new JSONObject(readText(safe(scenario.getString("scenarioFile")), 1024 * 1024));
        }
        WorldMap map = loadMap(entry);
        GameState game = Double.isNaN(entry.dropX) || Double.isNaN(entry.dropY)
                ? GameState.newImportedGame(map, mission, seed)
                : GameState.newImportedGame(map, mission, seed, entry.dropX, entry.dropY);
        // Initial ecology and buildings come from the supplied map, not a
        // decorative or randomly invented layout. New simulation rules remain
        // explicitly separate from the decoded original records.
        game.clearScenarioEntities();
        JSONArray trees = scenario.getJSONArray("trees");
        for (int i = 0; i < trees.length(); i++) {
            JSONObject tree = trees.getJSONObject(i);
            int biomass = tree.optInt("wood", 0);
            if (biomass <= 0) biomass = tree.getInt("health");
            game.importPlant(tree.getInt("species"), tree.getDouble("x"), tree.getDouble("y"), biomass);
        }
        JSONArray creatures = scenario.getJSONArray("creatures");
        for (int i = 0; i < creatures.length(); i++) {
            JSONObject creature = creatures.getJSONObject(i);
            int owner = creature.getInt("owner");
            int team = owner == 0 ? 0 : owner == 4 ? 2 : 1;
            game.importCreature(creature.getInt("species"), creature.getDouble("x"), creature.getDouble("y"),
                    team, creature.getDouble("health"), creature.getDouble("energy"),
                    creature.getDouble("maxHealth"), creature.getDouble("maxEnergy"), creature.getDouble("lifespan"));
        }
        JSONArray buildings = scenario.getJSONArray("buildings");
        for (int i = 0; i < buildings.length(); i++) {
            JSONObject building = buildings.getJSONObject(i);
            int team = building.getInt("owner") == 0 ? 0 : 1;
            if (!game.importBuilding(building.getInt("type"), building.getInt("stage"),
                    building.getDouble("x"), building.getDouble("y"), team,
                    building.getInt("build"), building.getInt("flags"))) {
                android.util.Log.w("GeneWars", "Unsupported source building in " + entry.name);
            }
        }
        game.finishScenarioImport(scenario.getInt("payment"));
        return game;
    }

    /** Called on the game-loading worker, before the new world is published. */
    void prepareGraphics(GameState state) throws IOException {
        Set<String> keys = new HashSet<String>();
        for (org.genewars.core.Unit unit : state.units) keys.add(unit.spriteKey());
        for (org.genewars.core.Building building : state.buildings) keys.add(building.spriteKey());
        for (org.genewars.core.Plant plant : state.plants) keys.add("plant_" + plant.species);
        for (String key : keys) {
            if (closed || Thread.currentThread().isInterrupted()) throw new IOException("Загрузка прервана");
            String path = spritePaths.get(key);
            if (path != null) cachedDecode(path);
        }
    }

    /** No disk IO on the drawing thread: unseen sprites are decoded once asynchronously. */
    Bitmap sprite(String key) {
        final String path = spritePaths.get(key);
        if (path == null) return null;
        Bitmap image = imagesByPath.get(path);
        if (image == null && !closed && !failedImages.contains(path) && pendingImages.add(path)) {
            try {
                graphicsWorker.execute(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!closed) cachedDecode(path);
                        } catch (IOException exception) {
                            failedImages.add(path);
                            android.util.Log.w("GeneWars", "Sprite could not be decoded: " + path, exception);
                        } finally { pendingImages.remove(path); }
                    }
                });
            } catch (RejectedExecutionException exception) { pendingImages.remove(path); }
        }
        return image;
    }

    void close() { closed = true; graphicsWorker.shutdownNow(); }

    private Bitmap cachedDecode(String path) throws IOException {
        synchronized (imagesByPath) {
            if (closed) throw new IOException("Загрузка прервана");
            Bitmap image = imagesByPath.get(path);
            if (image != null) return image;
            image = loadBitmap(path);
            if (closed) throw new IOException("Загрузка прервана");
            imagesByPath.put(path, image);
            return image;
        }
    }

    private Bitmap loadBitmap(String path) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try (InputStream in = assets.open(path)) { BitmapFactory.decodeStream(in, null, options); }
        if (options.outWidth <= 0 || options.outHeight <= 0 || options.outWidth > 2048 || options.outHeight > 2048)
            throw new IOException("Некорректный размер спрайта: " + path);
        options.inJustDecodeBounds = false;
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap image;
        try (InputStream in = assets.open(path)) { image = BitmapFactory.decodeStream(in, null, options); }
        if (image == null) throw new IOException("Не удалось прочитать спрайт: " + path);
        return image;
    }

    private String readText(String path, int limit) throws IOException {
        try (InputStream in = assets.open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) {
                if (out.size() + n > limit) throw new IOException("Слишком большой манифест ресурсов");
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), "UTF-8");
        }
    }

    private static String safe(String path) throws IOException {
        if (!path.startsWith("native/") || path.contains("..") || path.indexOf('\\') >= 0)
            throw new IOException("Некорректный путь ресурса");
        return path;
    }
}
