package org.genewars.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.genewars.core.Building;
import org.genewars.core.GameState;
import org.genewars.core.Plant;
import org.genewars.core.Unit;
import org.genewars.core.WorldMap;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;

/** Native Android game frontend. No WebView, DOS runtime, or external launcher. */
public final class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(16, 26, 32);
    private static final int FOREGROUND = Color.rgb(230, 241, 239);
    private static final int ACCENT = Color.rgb(82, 219, 197);
    private AssetRepository repository;
    private GameState game;
    private WorldView world;
    private LinearLayout page;
    private TextView hud;
    private TextView objective;
    private TextView message;
    private SharedPreferences preferences;
    private boolean smooth;
    private boolean muted;
    private boolean destroyed;
    private boolean resumed;
    private boolean showingOutcome;
    private boolean loadingGame;
    private int loadingGeneration;
    private GameState loadingPreviousGame;
    private LinearLayout loadingPreviousPage;
    private WorldView loadingPreviousWorld;
    private boolean audioPreparationStarted;
    private Future<?> activeWorldLoad;
    private final ExecutorService worldLoader = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "native-world-load"); thread.setDaemon(true); return thread;
        }
    });
    private float speed = 1f;
    private SoundPool soundPool;
    private MediaPlayer musicPlayer;
    private boolean musicReady;
    private boolean musicFinished;
    private int musicTrack;
    private int musicGeneration;
    private final Map<String, Integer> soundIds = new HashMap<String, Integer>();
    private final Map<Integer, Boolean> loadedSounds = new ConcurrentHashMap<Integer, Boolean>();
    private long nextHudUpdate;
    private Button pauseButton;
    private Button speedButton;
    private Button filterButton;
    private Button soundButton;
    private Button placementButton;
    private int modalDepth;

    @Override public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        preferences = getSharedPreferences("preferences", MODE_PRIVATE);
        smooth = preferences.getBoolean("smooth", false);
        muted = preferences.getBoolean("muted", false);
        musicTrack = preferences.getInt("musicTrack", 0);
        hideSystemBars();
        page = basePage();
        TextView loading = text("Подготовка планет…", 24);
        loading.setGravity(Gravity.CENTER);
        page.addView(loading, new LinearLayout.LayoutParams(-1, -1));
        setContentView(page);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final AssetRepository loaded = new AssetRepository(MainActivity.this);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed) { loaded.close(); return; }
                            repository = loaded;
                            if (savedInstanceState != null && savedInstanceState.getBoolean("playing", false)
                                    && saveFile().isFile()) {
                                continueGame();
                            } else showMainMenu();
                        }
                    });
                } catch (final Exception exception) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) showFatal("Не удалось прочитать игровые ресурсы", exception);
                        }
                    });
                }
            }
        }, "native-assets").start();
    }

    private LinearLayout basePage() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(BACKGROUND);
        layout.setPadding(dp(12), dp(6), dp(12), dp(6));
        layout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout());
                    view.setPadding(dp(12) + safe.left, dp(6) + safe.top,
                            dp(12) + safe.right, dp(6) + safe.bottom);
                } else {
                    view.setPadding(dp(12) + insets.getSystemWindowInsetLeft(),
                            dp(6) + insets.getSystemWindowInsetTop(),
                            dp(12) + insets.getSystemWindowInsetRight(),
                            dp(6) + insets.getSystemWindowInsetBottom());
                }
                return insets;
            }
        });
        return layout;
    }

    private void showMainMenu() {
        if (loadingGame) {
            ++loadingGeneration; loadingGame = false;
            if (activeWorldLoad != null) activeWorldLoad.cancel(true);
            activeWorldLoad = null;
            if (loadingPreviousWorld != null) loadingPreviousWorld.stop();
            clearPreviousLoad();
        }
        stopWorld();
        game = null;
        page = basePage();
        ScrollView scroll = new ScrollView(this);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setGravity(Gravity.CENTER_HORIZONTAL);
        menu.setPadding(dp(24), dp(12), dp(24), dp(18));
        TextView title = text("GENE WARS", 36);
        title.setTextColor(ACCENT);
        title.setGravity(Gravity.CENTER);
        menu.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = text("Нативная реконструкция 0.1", 17);
        subtitle.setGravity(Gravity.CENTER);
        menu.addView(subtitle);
        TextView status = text("Исследовательская версия: оригинальная кампания ещё восстанавливается.", 13);
        status.setGravity(Gravity.CENTER);
        menu.addView(status, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        Button start = button("Новая игра", new Runnable() { @Override public void run() { chooseMap(); } });
        Button resume = button("Продолжить", new Runnable() { @Override public void run() { continueGame(); } });
        resume.setEnabled(saveFile().isFile());
        row.addView(start, new LinearLayout.LayoutParams(dp(200), dp(54)));
        row.addView(resume, new LinearLayout.LayoutParams(dp(200), dp(54)));
        menu.addView(row);
        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        row2.addView(button("Как играть", new Runnable() { @Override public void run() { showHelp(); } }),
                new LinearLayout.LayoutParams(dp(200), dp(54)));
        row2.addView(button("Настройки", new Runnable() { @Override public void run() { showSettings(); } }),
                new LinearLayout.LayoutParams(dp(200), dp(54)));
        menu.addView(row2);
        scroll.addView(menu);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(page);
        hideSystemBars();
        scheduleAudioAfterFirstDraw(page);
    }

    private void chooseMap() {
        String[] names = new String[repository.maps.size()];
        for (int i = 0; i < names.length; i++) names[i] = repository.maps.get(i).displayTitle();
        showModal(new AlertDialog.Builder(this).setTitle("Выберите планету")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int index) {
                        chooseMission(repository.maps.get(index));
                    }
                }).setNegativeButton("Назад", null));
    }

    private void chooseMission(final AssetRepository.MapEntry map) {
        // A combat objective on a peaceful source map would instantly complete
        // without playing. Offer it only where original hostile records exist.
        final int count = map.hasHostiles ? GameState.MISSION_COUNT : Math.min(4, GameState.MISSION_COUNT);
        String[] names = new String[count];
        for (int i = 0; i < names.length; i++) names[i] = GameState.missionTitle(i);
        showModal(new AlertDialog.Builder(this).setTitle("Задание реконструкции")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int index) { startGame(map, index); }
                }).setNegativeButton("Назад", null));
    }

    private interface GameLoader { GameState load() throws Exception; }

    private void startGame(final AssetRepository.MapEntry entry, final int mission) {
        loadGameAsync("Открываем планету…", "Не удалось открыть планету", new GameLoader() {
            @Override public GameState load() throws Exception {
                long seed = 0x47454E45L + entry.index * 1009L + mission;
                return repository.startGame(entry, mission, seed);
            }
        });
    }

    private void continueGame() {
        loadGameAsync("Загрузка сохранения…", "Не удалось загрузить сохранение", new GameLoader() {
            @Override public GameState load() throws Exception { return GameState.load(saveFile()); }
        });
    }

    private void loadGameAsync(String progress, final String errorTitle, final GameLoader loader) {
        if (loadingGame || destroyed) return;
        loadingGame = true;
        final int generation = ++loadingGeneration;
        loadingPreviousGame = game;
        loadingPreviousPage = page;
        loadingPreviousWorld = world;
        if (world != null) world.stop();
        world = null;
        page = basePage();
        TextView label = text(progress, 22);
        label.setGravity(Gravity.CENTER);
        page.addView(label, new LinearLayout.LayoutParams(-1, 0, 1f));
        page.addView(button("Отмена", new Runnable() { @Override public void run() { cancelGameLoad(); } }),
                new LinearLayout.LayoutParams(-1, dp(50)));
        setContentView(page);
        activeWorldLoad = worldLoader.submit(new Runnable() {
            @Override public void run() {
                try {
                    long started = android.os.SystemClock.elapsedRealtime();
                    final GameState loaded = loader.load();
                    if (Thread.currentThread().isInterrupted()) return;
                    repository.prepareGraphics(loaded);
                    if (Thread.currentThread().isInterrupted()) return;
                    android.util.Log.i("GeneWars", "Selected world ready in "
                            + (android.os.SystemClock.elapsedRealtime() - started) + " ms");
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != loadingGeneration || !loadingGame) return;
                            loadingGame = false;
                            activeWorldLoad = null;
                            clearPreviousLoad();
                            game = loaded;
                            showGame();
                        }
                    });
                } catch (final Exception exception) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != loadingGeneration || !loadingGame) return;
                            restorePreviousLoad(true);
                            showError(errorTitle, exception);
                        }
                    });
                }
            }
        });
    }

    private void clearPreviousLoad() {
        loadingPreviousGame = null; loadingPreviousPage = null; loadingPreviousWorld = null;
    }

    private void restorePreviousLoad(boolean paused) {
        loadingGame = false;
        activeWorldLoad = null;
        game = loadingPreviousGame;
        page = loadingPreviousPage;
        world = loadingPreviousWorld;
        clearPreviousLoad();
        if (page == null || game == null) { showMainMenu(); return; }
        setContentView(page); hideSystemBars();
        if (game != null) {
            if (paused) game.paused = true;
            updateToolLabels(); updateHud();
            if (world != null && resumed && modalDepth == 0) world.start();
        }
    }

    private void cancelGameLoad() {
        if (!loadingGame) return;
        ++loadingGeneration;
        if (activeWorldLoad != null) activeWorldLoad.cancel(true);
        restorePreviousLoad(false);
    }

    private void showGame() {
        stopWorld();
        showingOutcome = false;
        nextHudUpdate = 0;
        page = basePage();
        hud = text("", 14);
        hud.setTextColor(ACCENT);
        objective = text("", 13);
        message = text("", 12);
        message.setSingleLine(true);
        page.addView(hud);
        page.addView(objective);
        page.addView(message);
        world = new WorldView(game);
        page.addView(world, new LinearLayout.LayoutParams(-1, 0, 1f));
        HorizontalScrollView barScroll = new HorizontalScrollView(this);
        barScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        addTool(bar, "Строить", new Runnable() { @Override public void run() { showBuildMenu(); } });
        placementButton = addTool(bar, "Отмена", new Runnable() { @Override public void run() { world.cancelPlacement(); } });
        placementButton.setVisibility(View.GONE);
        addTool(bar, "Существа", new Runnable() { @Override public void run() { showCreatureMenu(); } });
        addTool(bar, "Скрестить", new Runnable() { @Override public void run() { showBreedMenu(); } });
        addTool(bar, "Действия", new Runnable() { @Override public void run() { showActions(); } });
        addTool(bar, "К отряду", new Runnable() { @Override public void run() { if (world != null) world.centerOnTeam(); } });
        pauseButton = addTool(bar, "Пауза", new Runnable() { @Override public void run() {
            game.paused = !game.paused; updateToolLabels();
        } });
        speedButton = addTool(bar, "×1", new Runnable() { @Override public void run() {
            speed = speed == 1 ? 2 : 1; updateToolLabels();
        } });
        filterButton = addTool(bar, "Пиксели", new Runnable() { @Override public void run() {
            smooth = !smooth; savePreferences(); updateToolLabels(); world.invalidate();
        } });
        soundButton = addTool(bar, "Звук", new Runnable() { @Override public void run() {
            muted = !muted; savePreferences(); updateToolLabels();
        } });
        addTool(bar, "Меню", new Runnable() { @Override public void run() { showPauseMenu(); } });
        barScroll.addView(bar, new FrameLayout.LayoutParams(-2, dp(50)));
        page.addView(barScroll, new LinearLayout.LayoutParams(-1, dp(50)));
        setContentView(page);
        hideSystemBars();
        updateToolLabels();
        updateHud();
        if (resumed && modalDepth == 0) world.start();
        scheduleAudioAfterFirstDraw(page);
    }

    private void updateToolLabels() {
        if (game == null || pauseButton == null) return;
        pauseButton.setText(game.paused ? "Дальше" : "Пауза");
        speedButton.setText(speed == 1 ? "×1" : "×2");
        filterButton.setText(smooth ? "Сглаживание" : "Пиксели");
        soundButton.setText(muted ? "Без звука" : "Звук");
    }

    private void updateHud() {
        if (game == null || hud == null) return;
        hud.setText("Биогель: " + game.goop + "/" + game.goopCapacity + "    Древесина: " + game.wood
                + "    Целлюлоза: " + game.cellulose + "    Энергия: " + game.powerProduced + "/" + game.powerUsed);
        objective.setText(game.objectiveText() + "  •  " + game.objectiveProgress());
        String selected = "";
        for (Unit unit : game.units) {
            if (unit.id == game.selectedId && unit.hp > 0) {
                selected = unit.title() + "  " + (int) unit.hp + "/" + (int) unit.maxHp;
                if (unit.task != null && !unit.task.isEmpty()) selected += "  ·  " + unit.task;
                break;
            }
        }
        if (selected.length() == 0) {
            Building building = game.selectedBuilding();
            if (building != null && building.hp > 0) selected = building.title() + "  "
                    + (int) building.hp + "/" + (int) building.maxHp + "  ·  " + building.status();
        }
        String info = selected.length() > 0 ? selected : game.message == null ? "Выберите специалиста или существо" : game.message;
        if (game.etherealETA >= 0) info += "  ·  Эфириалы: " + (int) game.etherealETA + " с";
        else if (game.etherealPoints > 0) info += "  ·  Очки эфириалов: " + game.etherealPoints;
        message.setText(info);
    }

    private void frameUpdated() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now >= nextHudUpdate) { nextHudUpdate = now + 200; updateHud(); }
        for (String event : game.pollEvents()) playSound(event);
        if (!showingOutcome && (game.victory || game.defeat)) {
            showingOutcome = true;
            game.paused = true;
            updateToolLabels();
            String title = game.victory ? "Задание выполнено" : "Отряд потерян";
            showModal(new AlertDialog.Builder(this).setTitle(title).setMessage(game.objectiveProgress())
                    .setPositiveButton("Выбрать планету", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) { showMainMenu(); chooseMap(); }
                    }).setNegativeButton("Осмотреть карту", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) { showingOutcome = true; }
                    }).setCancelable(false));
        }
    }

    private void showBuildMenu() {
        world.cancelPlacement();
        final Building.Kind[] kinds = Building.Kind.values();
        String[] names = new String[kinds.length];
        for (int i = 0; i < kinds.length; i++) names[i] = kinds[i].title + " — " + kinds[i].cost + " биогеля";
        showModal(new AlertDialog.Builder(this).setTitle("Постройка: затем коснитесь земли")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        world.beginBuilding(kinds[which]);
                        Toast.makeText(MainActivity.this, "Выберите место для постройки", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Отмена", null));
    }

    private void showCreatureMenu() {
        world.cancelPlacement();
        final String[] names = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
        showModal(new AlertDialog.Builder(this).setTitle("Вырастить существо")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        boolean done = game.trainCreature(which);
                        showCommandResult(done);
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showBreedMenu() {
        world.cancelPlacement();
        final String[] names = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
        showModal(new AlertDialog.Builder(this).setTitle("Первый родитель")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, final int first) {
                        showModal(new AlertDialog.Builder(MainActivity.this).setTitle("Второй родитель")
                                .setItems(names, new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface dialog, int second) {
                                        showCommandResult(game.breed(first, second));
                                    }
                                }).setNegativeButton("Отмена", null));
                    }
                }).setNegativeButton("Отмена", null));
    }

    private void showActions() {
        world.cancelPlacement();
        final String[] items = {"Собирать древесину", "Переработать древесину", "Исследовать существо", "Посадить дерево",
                "Улучшить выбранную постройку", "Пригласить специалиста", "Вызвать эфириалов"};
        showModal(new AlertDialog.Builder(this).setTitle("Действия отряда")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) showCommandResult(game.orderHarvest());
                        else if (which == 1) showCommandResult(game.recycleWood());
                        else if (which == 2) showCommandResult(game.researchSelected());
                        else if (which == 3) {
                            world.beginPlanting();
                            Toast.makeText(MainActivity.this, "Коснитесь земли для посадки", Toast.LENGTH_SHORT).show();
                        } else if (which == 4) showCommandResult(game.upgradeSelectedBuilding());
                        else if (which == 5) showRecruitMenu();
                        else showCommandResult(game.callEthereals());
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showRecruitMenu() {
        final Unit.Kind[] kinds = {Unit.Kind.ENGINEER, Unit.Kind.BOTANIST, Unit.Kind.GENETICIST, Unit.Kind.RANGER};
        showModal(new AlertDialog.Builder(this).setTitle("Пригласить через посадочную площадку")
                .setItems(new String[]{"Инженер", "Ботаник", "Генетик", "Егерь"}, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        showCommandResult(game.recruitSpecialist(kinds[which]));
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showCommandResult(boolean accepted) {
        if (!accepted && game.message != null) Toast.makeText(this, game.message, Toast.LENGTH_LONG).show();
        updateHud();
    }

    private void showPauseMenu() {
        if (game == null) return;
        final boolean previous = game.paused;
        game.paused = true;
        updateToolLabels();
        showModal(new AlertDialog.Builder(this).setTitle("Игра приостановлена")
                .setItems(new String[]{"Сохранить", "Загрузить", "Как играть", "Настройки", "Главное меню"},
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) { saveGame(true); game.paused = previous; updateToolLabels(); }
                                else if (which == 1) continueGame();
                                else if (which == 2) { game.paused = previous; showHelp(); }
                                else if (which == 3) { game.paused = previous; showSettings(); }
                                else { saveGame(false); showMainMenu(); }
                            }
                        }).setNegativeButton("Продолжить", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                if (game != null) { game.paused = previous; updateToolLabels(); }
                            }
                        }).setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface dialog) {
                                if (game != null) { game.paused = previous; updateToolLabels(); }
                            }
                        }));
    }

    private void showHelp() {
        String instructions = "Коснитесь своего специалиста или существа, затем земли — отряд отправится туда. "
                + "Коснитесь врага, чтобы отдать приказ атаковать. Перетаскивайте карту одним пальцем; "
                + "сводите или разводите два пальца для масштаба. Долгое касание отдаёт приказ без смены выделения.\n\n"
                + "«Строить» → выберите здание и коснитесь места. «Отмена» или «Назад» отменяет размещение. Для существ нужна работающая генолаборатория. "
                + "«Действия» позволяют заготавливать и перерабатывать древесину, исследовать существ и сажать деревья. "
                + "Целлюлозатор перерабатывает древесину для улучшений. Выделите готовую постройку и улучшите её через «Действия». "
                + "Геномашина позволяет создавать гибридов. Посадочная площадка приглашает специалистов, а детектор вызывает эфириалов. "
                + "Следите за энергией и целью задания.\n\n"
                + "В меню доступны сохранение и загрузка. При сворачивании игра сохраняется автоматически. "
                + "«Пиксели/Сглаживание» меняет фильтрацию графики.\n\n"
                + "Это нативная реконструкция 0.1: используются карты и графика оригинала, "
                + "но игровая механика, задания и баланс пока восстановлены частично. "
                + "Сохранения этой версии не совместимы с DOS-игрой.";
        showModal(new AlertDialog.Builder(this).setTitle("Как играть").setMessage(instructions).setPositiveButton("Понятно", null));
    }

    private void showSettings() {
        final String[] items = {"Сглаживание изображения", "Отключить звук"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle("Настройки")
                .setMultiChoiceItems(items, new boolean[]{smooth, muted}, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which, boolean value) {
                        if (which == 0) smooth = value; else muted = value;
                        savePreferences();
                    }
                }).setPositiveButton("Готово", null);
        if (repository != null && !repository.music.isEmpty()) builder.setNeutralButton("Музыка", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) { showMusicMenu(); }
        });
        showModal(builder);
    }

    private void showMusicMenu() {
        String[] names = new String[repository.music.size()];
        for (int i = 0; i < names.length; i++) names[i] = "Дорожка " + (i + 1);
        showModal(new AlertDialog.Builder(this).setTitle("Оригинальная музыка")
                .setSingleChoiceItems(names, Math.min(musicTrack, names.length - 1), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        musicTrack = which;
                        preferences.edit().putInt("musicTrack", which).apply();
                        prepareMusic(); dialog.dismiss();
                    }
                }).setNegativeButton("Назад", null));
    }

    private void savePreferences() {
        preferences.edit().putBoolean("smooth", smooth).putBoolean("muted", muted).apply();
        updateAudioPlayback();
    }

    private File saveFile() { return new File(getFilesDir(), "game-v1.gws"); }

    private void saveGame(boolean notify) {
        if (game == null) return;
        try {
            game.saveAtomic(saveFile());
            if (notify) Toast.makeText(this, "Игра сохранена", Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            Toast.makeText(this, "Не удалось сохранить игру: " + errorText(exception), Toast.LENGTH_LONG).show();
        }
    }

    private void scheduleAudioAfterFirstDraw(final View content) {
        if (audioPreparationStarted) return;
        content.getViewTreeObserver().addOnDrawListener(new ViewTreeObserver.OnDrawListener() {
            private boolean posted;
            @Override public void onDraw() {
                if (posted) return;
                posted = true;
                final ViewTreeObserver.OnDrawListener listener = this;
                content.post(new Runnable() {
                    @Override public void run() {
                        if (content.getViewTreeObserver().isAlive()) content.getViewTreeObserver().removeOnDrawListener(listener);
                        if (destroyed || audioPreparationStarted) return;
                        audioPreparationStarted = true;
                        prepareAudio();
                        prepareMusic();
                    }
                });
            }
        });
    }

    private void prepareAudio() {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    AudioAttributes attributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                    final SoundPool preparedPool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attributes).build();
                    final Map<String, Integer> ids = new HashMap<String, Integer>();
                    preparedPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                        @Override public void onLoadComplete(SoundPool pool, int sampleId, int status) {
                            loadedSounds.put(sampleId, status == 0);
                        }
                    });
                    for (Map.Entry<String, String> entry : repository.sounds.entrySet()) {
                        try (AssetFileDescriptor descriptor = getAssets().openFd(entry.getValue())) {
                            ids.put(entry.getKey(), preparedPool.load(descriptor, 1));
                        } catch (Exception exception) {
                            android.util.Log.w("GeneWars", "Sound not loaded: " + entry.getKey(), exception);
                        }
                    }
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed) { preparedPool.release(); return; }
                            soundPool = preparedPool; soundIds.putAll(ids); updateAudioPlayback();
                        }
                    });
                } catch (Exception exception) { android.util.Log.w("GeneWars", "Sound initialization unavailable", exception); }
            }
        }, "native-sound-load").start();
    }

    private void playSound(String event) {
        if (muted || soundPool == null) return;
        String key = event;
        if ("win".equals(event)) key = "complete";
        else if ("birth".equals(event)) key = "build";
        Integer id = soundIds.get(key);
        if (id != null && Boolean.TRUE.equals(loadedSounds.get(id))) soundPool.play(id, .65f, .65f, 1, 0, 1f);
    }

    private void prepareMusic() {
        if (repository.music.isEmpty()) return;
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; }
        musicReady = false; musicFinished = false;
        musicTrack = Math.max(0, Math.min(repository.music.size() - 1, musicTrack));
        final String musicPath = repository.music.get(musicTrack);
        final int generation = ++musicGeneration;
        new Thread(new Runnable() {
            @Override public void run() {
                MediaPlayer pending = null;
                try {
                    final MediaPlayer player = new MediaPlayer(); pending = player;
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    try (AssetFileDescriptor descriptor = getAssets().openFd(musicPath)) {
                        player.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                    }
                    player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override public void onPrepared(final MediaPlayer prepared) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (destroyed || generation != musicGeneration) return;
                                    musicPlayer = prepared; musicReady = true;
                                    prepared.setLooping(false); prepared.setVolume(.28f, .28f);
                                    android.util.Log.i("GeneWars", "Original MIDI track prepared"); updateAudioPlayback();
                                }
                            });
                        }
                    });
                    player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override public void onCompletion(MediaPlayer completed) {
                            if (generation == musicGeneration && completed == musicPlayer) musicFinished = true;
                        }
                    });
                    player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                        @Override public boolean onError(MediaPlayer failed, int what, int extra) {
                            if (generation == musicGeneration && failed == musicPlayer) musicReady = false;
                            android.util.Log.w("GeneWars", "Music playback unavailable: " + what + "/" + extra); return true;
                        }
                    });
                    player.prepareAsync();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != musicGeneration) { player.release(); return; }
                            if (musicPlayer == null) musicPlayer = player;
                        }
                    });
                } catch (final Exception exception) {
                    if (pending != null) pending.release();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (generation == musicGeneration) { musicPlayer = null; musicReady = false; }
                            android.util.Log.w("GeneWars", "Music could not be prepared", exception);
                        }
                    });
                }
            }
        }, "native-music-load").start();
    }

    private void updateAudioPlayback() {
        if (soundPool != null) {
            if (resumed && !muted) soundPool.autoResume(); else soundPool.autoPause();
        }
        if (musicPlayer != null && musicReady) {
            try {
                if (resumed && !muted && !musicFinished) musicPlayer.start();
                else if (musicPlayer.isPlaying()) musicPlayer.pause();
            } catch (IllegalStateException exception) {
                musicReady = false;
                android.util.Log.w("GeneWars", "Music state changed", exception);
            }
        }
    }

    private void showError(String title, Exception exception) {
        showModal(new AlertDialog.Builder(this).setTitle(title).setMessage(errorText(exception)).setPositiveButton("Понятно", null));
    }

    /** Keep the game stationary under modal UI without changing manual pause. */
    private AlertDialog showModal(AlertDialog.Builder builder) {
        final boolean pausesWorld = game != null && world != null;
        final AlertDialog dialog = builder.create();
        if (pausesWorld) { modalDepth++; world.stop(); }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface ignored) {
                if (pausesWorld) modalDepth = Math.max(0, modalDepth - 1);
                if (!destroyed && resumed && !loadingGame && modalDepth == 0 && world != null) world.start();
            }
        });
        dialog.show();
        return dialog;
    }

    private void showFatal(String title, Exception exception) {
        page = basePage();
        TextView failure = text(title + "\n\n" + errorText(exception), 18);
        page.addView(failure, new LinearLayout.LayoutParams(-1, 0, 1f));
        page.addView(button("Закрыть", new Runnable() { @Override public void run() { finish(); } }));
        setContentView(page);
    }

    private String errorText(Exception exception) {
        android.util.Log.e("GeneWars", "Operation failed", exception);
        String detail = exception.getMessage();
        if (exception instanceof java.io.FileNotFoundException) return "Необходимый файл не найден.";
        if (detail != null) {
            String lower = detail.toLowerCase(Locale.ROOT);
            if (lower.contains("enospc") || lower.contains("no space")) return "Недостаточно свободного места на устройстве.";
            if (lower.contains("crc") || lower.contains("version") || lower.contains("invalid")
                    || lower.contains("truncated") || lower.contains("magic") || lower.contains("unsupported"))
                return "Файл повреждён или несовместим с этой версией.";
            if (detail.matches(".*[А-Яа-яЁё].*")) return detail;
        }
        return "Не удалось обработать игровые данные.";
    }

    private TextView text(String value, int size) {
        TextView label = new TextView(this);
        label.setText(value); label.setTextColor(FOREGROUND); label.setTextSize(size);
        label.setPadding(dp(4), dp(2), dp(4), dp(2));
        return label;
    }

    private Button button(String label, final Runnable action) {
        Button button = new Button(this);
        button.setText(label); button.setTextSize(13); button.setAllCaps(false);
        button.setMinimumHeight(dp(48)); button.setMinHeight(dp(48));
        button.setTextColor(FOREGROUND);
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { action.run(); }
        });
        return button;
    }

    private Button addTool(LinearLayout bar, String label, Runnable action) {
        Button button = button(label, action);
        bar.addView(button, new LinearLayout.LayoutParams(-2, dp(50)));
        return button;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private String unitName(Unit unit) {
        switch (unit.kind) {
            case ENGINEER: return "Инженер";
            case BOTANIST: return "Ботаник";
            case GENETICIST: return "Генетик";
            case RANGER: return "Егерь";
            default:
                String[] species = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
                return unit.species >= 0 && unit.species < 5 ? species[unit.species] : "Гибрид";
        }
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void stopWorld() { if (world != null) { world.stop(); world = null; } }
    @Override protected void onPause() {
        resumed = false;
        saveGame(false);
        if (world != null) world.stop();
        updateAudioPlayback();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume(); resumed = true; hideSystemBars();
        if (world != null && modalDepth == 0 && !loadingGame) world.start();
        updateAudioPlayback();
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        saveGame(false); state.putBoolean("playing", game != null); super.onSaveInstanceState(state);
    }
    @Override protected void onDestroy() {
        destroyed = true; resumed = false; stopWorld();
        ++loadingGeneration; ++musicGeneration;
        if (activeWorldLoad != null) activeWorldLoad.cancel(true);
        worldLoader.shutdownNow();
        if (loadingPreviousWorld != null) loadingPreviousWorld.stop();
        clearPreviousLoad();
        if (repository != null) repository.close();
        if (soundPool != null) { soundPool.release(); soundPool = null; }
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; musicReady = false; }
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (loadingGame) cancelGameLoad();
        else if (world != null && world.hasPlacement()) world.cancelPlacement();
        else if (game != null) showPauseMenu();
        else super.onBackPressed();
    }

    private final class WorldView extends View {
        final GameState state;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint spritePaint = new Paint();
        private final Path diamond = new Path();
        private final Paint terrainPaint = new Paint();
        private final Paint terrainBitmapPaint = new Paint();
        private Bitmap terrainCache;
        private float cachedCameraX = Float.NaN, cachedCameraY = Float.NaN, cachedZoom = Float.NaN;
        private int terrainVersion, cachedTerrainVersion = -1;
        private final RectF rectangle = new RectF();
        private final GestureDetector gestures;
        private final ScaleGestureDetector scales;
        private final ArrayList<Renderable> renderables = new ArrayList<Renderable>();
        private float cameraX, cameraY, zoom = 1f;
        private long previousFrame;
        private boolean running;
        private boolean secondaryGesture;
        private int minHeight;
        private Building.Kind buildMode;
        private boolean plantMode;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                if (!running || destroyed) return;
                long now = android.os.SystemClock.uptimeMillis();
                double dt = Math.min(.15, Math.max(0, (now - previousFrame) / 1000.0));
                previousFrame = now;
                state.update(dt * speed);
                frameUpdated();
                invalidate();
                if (running) postDelayed(this, 33);
            }
        };

        WorldView(GameState state) {
            super(MainActivity.this);
            this.state = state;
            setFocusable(true);
            setContentDescription("Карта планеты. Касание: выделить или отдать приказ. Перетаскивание: прокрутка. Два пальца: масштаб.");
            minHeight = Integer.MAX_VALUE;
            for (short height : state.map.elevation) minHeight = Math.min(minHeight, height);
            centerOnTeam();
            scales = new ScaleGestureDetector(MainActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float[] before = toWorld(detector.getFocusX(), detector.getFocusY());
                    zoom = Math.max(.35f, Math.min(3.5f, zoom * detector.getScaleFactor()));
                    float[] after = toWorld(detector.getFocusX(), detector.getFocusY());
                    cameraX += before[0] - after[0]; cameraY += before[1] - after[1]; clampCamera();
                    return true;
                }
            });
            gestures = new GestureDetector(MainActivity.this, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent event) { return true; }
                @Override public boolean onScroll(MotionEvent first, MotionEvent second, float dx, float dy) {
                    if (!scales.isInProgress() && second.getPointerCount() == 1) {
                        cameraX += (dx / halfWidth() + dy / halfHeight()) / 2;
                        cameraY += (dy / halfHeight() - dx / halfWidth()) / 2;
                        clampCamera(); invalidate();
                    }
                    return true;
                }
                @Override public boolean onSingleTapConfirmed(MotionEvent event) {
                    tap(event.getX(), event.getY(), false); performClick(); return true;
                }
                @Override public void onLongPress(MotionEvent event) { tap(event.getX(), event.getY(), true); }
                @Override public boolean onDoubleTap(MotionEvent event) {
                    zoom = zoom > 1.7f ? .8f : Math.min(3.5f, zoom * 1.4f); invalidate(); return true;
                }
            });
        }

        void start() { if (!running) { running = true; previousFrame = android.os.SystemClock.uptimeMillis(); post(frame); } }
        void stop() { running = false; removeCallbacks(frame); }

        boolean hasPlacement() { return buildMode != null || plantMode; }
        void cancelPlacement() {
            buildMode = null; plantMode = false;
            if (placementButton != null) placementButton.setVisibility(View.GONE);
            invalidate();
        }
        void beginBuilding(Building.Kind kind) {
            cancelPlacement(); buildMode = kind;
            if (placementButton != null) placementButton.setVisibility(View.VISIBLE);
        }
        void beginPlanting() {
            cancelPlacement(); plantMode = true;
            if (placementButton != null) placementButton.setVisibility(View.VISIBLE);
        }

        void centerOnTeam() {
            for (Unit unit : state.units) if (unit.team == 0 && unit.hp > 0) {
                cameraX = (float) unit.x; cameraY = (float) unit.y; invalidate(); return;
            }
            cameraX = state.map.width / 2f; cameraY = state.map.height / 2f;
        }

        private float halfWidth() { return dp(18) * zoom; }
        private float halfHeight() { return dp(9) * zoom; }
        private int elevation(double x, double y) {
            int ix = Math.max(0, Math.min(state.map.width - 1, (int) x));
            int iy = Math.max(0, Math.min(state.map.height - 1, (int) y));
            return state.map.elevation[iy * state.map.width + ix];
        }
        private float terrainLift(double x, double y) {
            return (elevation(x, y) - elevation(cameraX, cameraY)) / 256f * dp(1) * zoom;
        }
        private float sx(double x, double y) { return getWidth() / 2f + (float) ((x - cameraX - y + cameraY) * halfWidth()); }
        private float sy(double x, double y) { return getHeight() / 2f + (float) ((x - cameraX + y - cameraY) * halfHeight()) - terrainLift(x, y); }
        private float[] toWorld(float x, float y) {
            float dx = (x - getWidth() / 2f) / halfWidth();
            float dy = (y - getHeight() / 2f) / halfHeight();
            float wx = cameraX + (dx + dy) / 2;
            float wy = cameraY + (dy - dx) / 2;
            for (int i = 0; i < 2; i++) {
                dy = (y - getHeight() / 2f + terrainLift(wx, wy)) / halfHeight();
                wx = cameraX + (dx + dy) / 2; wy = cameraY + (dy - dx) / 2;
            }
            return new float[]{wx, wy};
        }
        private void clampCamera() {
            cameraX = Math.max(0, Math.min(state.map.width - 1, cameraX));
            cameraY = Math.max(0, Math.min(state.map.height - 1, cameraY));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            drawTerrainCache(canvas);
            drawZone(canvas);
            renderables.clear();
            for (Plant plant : state.plants) if (plant.biomass > 0) renderables.add(new Renderable(plant));
            for (Building building : state.buildings) if (building.hp > 0) renderables.add(new Renderable(building));
            for (Unit unit : state.units) if (unit.hp > 0) renderables.add(new Renderable(unit));
            Collections.sort(renderables, new Comparator<Renderable>() {
                @Override public int compare(Renderable a, Renderable b) { return Double.compare(a.x + a.y, b.x + b.y); }
            });
            spritePaint.setFilterBitmap(smooth);
            for (Renderable item : renderables) drawItem(canvas, item);
            paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(190, 12, 25, 31));
            rectangle.set(dp(8), dp(8), dp(164), dp(38)); canvas.drawRoundRect(rectangle, dp(7), dp(7), paint);
            paint.setColor(FOREGROUND); paint.setTextSize(dp(12));
            canvas.drawText("Масштаб " + String.format(Locale.ROOT, "%.1f", zoom) + "×", dp(17), dp(28), paint);
            if (buildMode != null || plantMode) {
                paint.setColor(Color.argb(225, 12, 25, 31)); rectangle.set(dp(8), getHeight() - dp(42), getWidth() - dp(8), getHeight() - dp(8));
                canvas.drawRoundRect(rectangle, dp(6), dp(6), paint);
                paint.setColor(ACCENT); paint.setTextSize(dp(13));
                canvas.drawText(buildMode != null ? "Коснитесь земли: " + buildMode.title : "Коснитесь земли: посадить дерево", dp(16), getHeight() - dp(20), paint);
            }
        }

        void invalidateTerrain() { terrainVersion++; invalidate(); }

        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            super.onSizeChanged(width, height, oldWidth, oldHeight);
            invalidateTerrain();
        }

        private void drawTerrainCache(Canvas canvas) {
            int width = getWidth(), height = getHeight();
            if (width <= 0 || height <= 0) return;
            if (terrainCache == null || terrainCache.getWidth() != width || terrainCache.getHeight() != height
                    || cachedCameraX != cameraX || cachedCameraY != cameraY || cachedZoom != zoom
                    || cachedTerrainVersion != terrainVersion) {
                long started = android.os.SystemClock.uptimeMillis();
                Bitmap replacement = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas buffer = new Canvas(replacement);
                renderTerrain(buffer);
                // Never recycle or overwrite a bitmap still referenced by a
                // hardware display list. The previous cache is released by GC.
                terrainCache = replacement;
                cachedCameraX = cameraX; cachedCameraY = cameraY; cachedZoom = zoom;
                cachedTerrainVersion = terrainVersion;
                android.util.Log.i("GeneWars", "Terrain viewport cached in "
                        + (android.os.SystemClock.uptimeMillis() - started) + " ms");
            }
            canvas.drawBitmap(terrainCache, 0, 0, terrainBitmapPaint);
        }

        private void renderTerrain(Canvas canvas) {
            canvas.drawColor(Color.rgb(15, 28, 33));
            float halfW = halfWidth(), halfH = halfHeight();
            float liftScale = dp(1) * zoom / 256f;
            float originX = getWidth() / 2f + (cameraY - cameraX) * halfW;
            float originY = getHeight() / 2f - (cameraX + cameraY) * halfH
                    + elevation(cameraX, cameraY) * liftScale;
            int span = Math.min(128, 6 + (int) (getWidth() / (2 * halfW) + getHeight() / (2 * halfH)));
            int minX = Math.max(0, (int) cameraX - span), maxX = Math.min(state.map.width - 1, (int) cameraX + span);
            int minY = Math.max(0, (int) cameraY - span), maxY = Math.min(state.map.height - 1, (int) cameraY + span);
            terrainPaint.setStyle(Paint.Style.FILL);
            terrainPaint.setAntiAlias(false);
            for (int sum = minX + minY; sum <= maxX + maxY; sum++) {
                for (int x = minX; x <= maxX; x++) {
                    int y = sum - x;
                    if (y < minY || y > maxY) continue;
                    int nextX = Math.min(state.map.width - 1, x + 1);
                    int row = y * state.map.width;
                    int nextRow = Math.min(state.map.height - 1, y + 1) * state.map.width;
                    float base = originY + (x + y) * halfH;
                    float x0 = originX + (x - y) * halfW;
                    float y0 = base - state.map.elevation[row + x] * liftScale;
                    float x1 = x0 + halfW, y1 = base + halfH - state.map.elevation[row + nextX] * liftScale;
                    float x2 = x0, y2 = base + 2 * halfH - state.map.elevation[nextRow + nextX] * liftScale;
                    float x3 = x0 - halfW, y3 = base + halfH - state.map.elevation[nextRow + x] * liftScale;
                    if (Math.max(Math.max(x0, x1), Math.max(x2, x3)) < 0
                            || Math.min(Math.min(x0, x1), Math.min(x2, x3)) > getWidth()
                            || Math.max(Math.max(y0, y1), Math.max(y2, y3)) < 0
                            || Math.min(Math.min(y0, y1), Math.min(y2, y3)) > getHeight()) continue;
                    int at = y * state.map.width + x;
                    int terrain = state.map.terrain[at] & 255;
                    int variation = ((x * 17 + y * 29) & 7) - 3;
                    if (terrain == 0) terrainPaint.setColor(Color.rgb(29 + variation, 72 + variation, 91 + variation));
                    else if (terrain == 1) terrainPaint.setColor(Color.rgb(57 + variation, 112 + variation, 119 + variation));
                    else {
                        int shade = Math.max(0, Math.min(30, (state.map.elevation[at] - minHeight) / 450));
                        if (terrain == 2) terrainPaint.setColor(Color.rgb(134 + variation, 119 + variation, 76 + variation));
                        else if (terrain == 4) terrainPaint.setColor(Color.rgb(101 + variation, 108 + variation, 96 + variation));
                        else if (terrain == 6) terrainPaint.setColor(Color.rgb(153 + variation, 165 + variation, 162 + variation));
                        else terrainPaint.setColor(Color.rgb(57 + shade + variation, 100 + shade + variation, 62 + variation));
                    }
                    // Four shared world vertices make adjacent cells meet even
                    // when their elevations differ; no independent tile lifts.
                    diamond.reset(); diamond.moveTo(x0, y0); diamond.lineTo(x1, y1);
                    diamond.lineTo(x2, y2); diamond.lineTo(x3, y3); diamond.close();
                    canvas.drawPath(diamond, terrainPaint);
                }
            }
        }

        private void drawZone(Canvas canvas) {
            if (state.zoneRadius <= 0) return;
            float cx = sx(state.zoneX, state.zoneY), cy = sy(state.zoneX, state.zoneY);
            paint.setColor(Color.argb(90, 238, 212, 92));
            rectangle.set(cx - (float) state.zoneRadius * halfWidth(), cy - (float) state.zoneRadius * halfHeight(),
                    cx + (float) state.zoneRadius * halfWidth(), cy + (float) state.zoneRadius * halfHeight());
            canvas.drawOval(rectangle, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(1, dp(1)));
            paint.setColor(Color.rgb(238, 212, 92)); canvas.drawOval(rectangle, paint); paint.setStyle(Paint.Style.FILL);
        }

        private void drawItem(Canvas canvas, Renderable item) {
            float x = sx(item.x, item.y), y = sy(item.x, item.y);
            float size = dp(item.building != null ? 43 : item.plant != null ? 27 : 24) * zoom;
            if (x < -size || y < -size || x > getWidth() + size || y > getHeight() + size * 2) return;
            Bitmap image = spriteFor(item);
            int teamColor = item.team == 0 ? ACCENT : item.team == 1 ? Color.rgb(240, 100, 104) : Color.rgb(195, 213, 134);
            if (item.unit != null || item.building != null) {
                paint.setColor(Color.argb(90, Color.red(teamColor), Color.green(teamColor), Color.blue(teamColor)));
                rectangle.set(x - size * .4f, y - size * .13f, x + size * .4f, y + size * .13f);
                canvas.drawOval(rectangle, paint);
                if (item.id == state.selectedId) {
                    paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setColor(ACCENT);
                    canvas.drawOval(rectangle, paint); paint.setStyle(Paint.Style.FILL);
                }
            }
            if (image != null) {
                float ratio = image.getWidth() / (float) image.getHeight();
                float height = size * (item.building != null ? 1.3f : 1f), width = height * ratio;
                if (width > size * 2) { width = size * 2; height = width / ratio; }
                rectangle.set(x - width / 2, y - height, x + width / 2, y);
                canvas.drawBitmap(image, null, rectangle, spritePaint);
            } else {
                paint.setColor(item.plant != null ? Color.rgb(68, 132, 72) : teamColor);
                if (item.building != null) {
                    rectangle.set(x - size * .35f, y - size, x + size * .35f, y);
                    canvas.drawRoundRect(rectangle, dp(3), dp(3), paint);
                } else canvas.drawCircle(x, y - size * .35f, size * .28f, paint);
            }
            if (item.building != null && item.building.progress < 1) {
                paint.setColor(Color.argb(160, 20, 20, 20)); rectangle.set(x - size * .45f, y + dp(3), x + size * .45f, y + dp(7)); canvas.drawRect(rectangle, paint);
                paint.setColor(Color.rgb(242, 204, 101)); rectangle.right = rectangle.left + size * .9f * (float) Math.max(0, item.building.progress); canvas.drawRect(rectangle, paint);
            }
            if (item.hp < item.maxHp && item.maxHp > 0) {
                float width = Math.max(dp(16), size * .7f);
                paint.setColor(Color.rgb(50, 35, 35)); rectangle.set(x - width / 2, y - size - dp(7), x + width / 2, y - size - dp(4)); canvas.drawRect(rectangle, paint);
                paint.setColor(teamColor); rectangle.right = rectangle.left + width * (float) Math.max(0, item.hp / item.maxHp); canvas.drawRect(rectangle, paint);
            }
        }

        private Bitmap spriteFor(Renderable item) {
            if (item.unit != null) {
                String key = item.unit.kind == Unit.Kind.CREATURE ? "creature_" + item.unit.species : "specialist_" + item.unit.kind.name();
                Bitmap sprite = repository.sprite(key);
                if (sprite == null) sprite = repository.sprite(item.unit.spriteKey());
                if (sprite == null && item.unit.kind == Unit.Kind.CREATURE) sprite = repository.sprite("creature_" + (item.unit.species % 5));
                return sprite;
            }
            if (item.building != null) {
                Bitmap sprite = repository.sprite("building_" + item.building.kind.name());
                return sprite == null ? repository.sprite(item.building.spriteKey()) : sprite;
            }
            Bitmap sprite = repository.sprite("plant_" + item.plant.species);
            if (sprite == null) sprite = repository.sprite("plant_0");
            return sprite;
        }

        private void tap(float x, float y, boolean commandOnly) {
            float[] position = toWorld(x, y);
            if (buildMode != null) {
                boolean accepted = state.build(buildMode, position[0], position[1]);
                showCommandResult(accepted); if (accepted) cancelPlacement(); return;
            }
            if (plantMode) {
                boolean accepted = state.plantTree(position[0], position[1]);
                showCommandResult(accepted); if (accepted) cancelPlacement(); return;
            }
            if (!commandOnly) {
                Unit best = null; float nearest = dp(24) * dp(24);
                for (Unit unit : state.units) if (unit.team == 0 && unit.hp > 0) {
                    float dx = sx(unit.x, unit.y) - x, dy = sy(unit.x, unit.y) - dp(8) * zoom - y;
                    float distance = dx * dx + dy * dy;
                    if (distance < nearest) { nearest = distance; best = unit; }
                }
                if (best != null) { state.select(best.id); updateHud(); invalidate(); return; }
                Building nearestBuilding = null;
                float buildingDistance = dp(28) * dp(28);
                for (Building building : state.buildings) if (building.team == 0 && building.hp > 0) {
                    float dx = sx(building.x, building.y) - x, dy = sy(building.x, building.y) - dp(17) * zoom - y;
                    float distance = dx * dx + dy * dy;
                    if (distance < buildingDistance) { buildingDistance = distance; nearestBuilding = building; }
                }
                if (nearestBuilding != null) {
                    Unit selected = state.selectedUnit();
                    if (selected != null && selected.kind == Unit.Kind.ENGINEER
                            && (nearestBuilding.progress < 1 || nearestBuilding.hp < nearestBuilding.maxHp)) {
                        showCommandResult(state.commandSelected(nearestBuilding.x, nearestBuilding.y));
                    } else {
                        state.select(nearestBuilding.id); updateHud();
                    }
                    invalidate(); return;
                }
            }
            // The artwork extends above its ground coordinate. Resolve taps in
            // screen space so a tap on a creature/tree actually targets it.
            float hitDistance = dp(23) * dp(23);
            double targetX = position[0], targetY = position[1];
            for (Unit unit : state.units) if (unit.team != 0 && unit.hp > 0) {
                float dx = sx(unit.x, unit.y) - x, dy = sy(unit.x, unit.y) - dp(8) * zoom - y;
                float distance = dx * dx + dy * dy;
                if (distance < hitDistance) { hitDistance = distance; targetX = unit.x; targetY = unit.y; }
            }
            for (Building building : state.buildings) if (building.team != 0 && building.hp > 0) {
                float dx = sx(building.x, building.y) - x, dy = sy(building.x, building.y) - dp(17) * zoom - y;
                float distance = dx * dx + dy * dy;
                if (distance < hitDistance) { hitDistance = distance; targetX = building.x; targetY = building.y; }
            }
            for (Plant plant : state.plants) if (plant.biomass > 0) {
                float dx = sx(plant.x, plant.y) - x, dy = sy(plant.x, plant.y) - dp(10) * zoom - y;
                float distance = dx * dx + dy * dy;
                if (distance < hitDistance) { hitDistance = distance; targetX = plant.x; targetY = plant.y; }
            }
            showCommandResult(state.commandSelected(targetX, targetY));
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            int secondary = MotionEvent.BUTTON_SECONDARY | MotionEvent.BUTTON_STYLUS_PRIMARY;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN && (event.getButtonState() & secondary) != 0) {
                if (!secondaryGesture) secondaryCommand(event);
                secondaryGesture = true;
                return true;
            }
            if (secondaryGesture) {
                if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL)
                    secondaryGesture = false;
                return true;
            }
            scales.onTouchEvent(event); gestures.onTouchEvent(event);
            return true;
        }
        @Override public boolean onGenericMotionEvent(MotionEvent event) {
            int secondary = MotionEvent.BUTTON_SECONDARY | MotionEvent.BUTTON_STYLUS_PRIMARY;
            if ((event.getActionButton() & secondary) != 0) {
                if (event.getActionMasked() == MotionEvent.ACTION_BUTTON_PRESS) {
                    if (!secondaryGesture) secondaryCommand(event);
                    secondaryGesture = true; return true;
                }
                if (event.getActionMasked() == MotionEvent.ACTION_BUTTON_RELEASE) {
                    secondaryGesture = false; return true;
                }
            }
            if (event.getAction() == MotionEvent.ACTION_SCROLL) {
                zoom = Math.max(.35f, Math.min(3.5f, zoom * (event.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0 ? 1.12f : .89f)));
                invalidate(); return true;
            }
            return super.onGenericMotionEvent(event);
        }
        private void secondaryCommand(MotionEvent event) {
            if (hasPlacement()) cancelPlacement();
            else tap(event.getX(), event.getY(), true);
        }
        @Override public boolean performClick() { return super.performClick(); }

        private final class Renderable {
            final Unit unit; final Building building; final Plant plant;
            final double x, y, hp, maxHp; final int team, id;
            Renderable(Unit value) { unit = value; building = null; plant = null; x = value.x; y = value.y; hp = value.hp; maxHp = value.maxHp; team = value.team; id = value.id; }
            Renderable(Building value) { unit = null; building = value; plant = null; x = value.x; y = value.y; hp = value.hp; maxHp = value.maxHp; team = value.team; id = value.id; }
            Renderable(Plant value) { unit = null; building = null; plant = value; x = value.x; y = value.y; hp = maxHp = 1; team = 2; id = value.id; }
        }
    }
}
