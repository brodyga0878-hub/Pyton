#!/usr/bin/env python3
"""Build a standalone instrumentation APK using the main app's local debug key.

This script does not download, install or run Android software. The development
keystore must already exist; it never creates a different signing identity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
SOURCE = Path(__file__).resolve().parent


def run(command: list[str], env: dict[str, str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, env=env, check=True, text=True, **kwargs)


def build(sdk: Path, jdk: Path, keystore: Path, alias: str, output: Path) -> dict:
    sdk, jdk, keystore, output = (path.resolve() for path in (sdk, jdk, keystore, output))
    platform = sdk / "platforms/android-35/android.jar"
    tools = sdk / "build-tools/35.0.0"
    required = [platform, tools / "aapt2", tools / "d8", tools / "zipalign",
                tools / "apksigner", jdk / "bin/javac", keystore]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(f"Missing prerequisite: {path}")
    if not output.is_relative_to((ROOT / "build").resolve()):
        raise ValueError("Write the test APK below the repository build directory")
    sources = sorted((SOURCE / "src").rglob("*.java"))
    if not sources:
        raise ValueError("Instrumentation sources are missing")
    env = os.environ.copy()
    env["JAVA_HOME"] = str(jdk)
    env["PATH"] = str(jdk / "bin") + os.pathsep + env["PATH"]
    # The default is the public development-key password used by build_android.py.
    # For any other local key, callers can provide the value without logging it.
    env.setdefault("GW_SMOKE_KEYSTORE_PASSWORD", "android")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="smoke-apk-", dir=ROOT / "build") as temporary:
        work = Path(temporary)
        classes, dex = work / "classes", work / "dex"
        classes.mkdir(); dex.mkdir()
        unsigned = work / "unsigned.apk"
        run([str(tools / "aapt2"), "link", "-o", str(unsigned), "--manifest",
             str(SOURCE / "AndroidManifest.xml"), "-I", str(platform), "--debug-mode"], env)
        arguments = work / "javac.args"
        arguments.write_text("\n".join('"' + str(path) + '"' for path in sources), encoding="utf-8")
        run([str(jdk / "bin/javac"), "-source", "8", "-target", "8", "-encoding", "UTF-8",
             "-bootclasspath", str(platform), "-d", str(classes), "@" + str(arguments)], env)
        class_jar = work / "classes.jar"
        with zipfile.ZipFile(class_jar, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(classes.rglob("*.class")):
                archive.write(path, path.relative_to(classes).as_posix())
        run([str(tools / "d8"), "--min-api", "26", "--lib", str(platform),
             "--output", str(dex), str(class_jar)], env)
        with zipfile.ZipFile(unsigned, "a", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(dex.glob("*.dex")):
                archive.write(path, path.name)
        aligned, signed = work / "aligned.apk", work / "signed.apk"
        run([str(tools / "zipalign"), "-f", "4", str(unsigned), str(aligned)], env)
        run([str(tools / "apksigner"), "sign", "--ks", str(keystore), "--ks-key-alias", alias,
             "--ks-pass", "env:GW_SMOKE_KEYSTORE_PASSWORD", "--key-pass", "env:GW_SMOKE_KEYSTORE_PASSWORD",
             "--out", str(signed), str(aligned)], env)
        verification = run([str(tools / "apksigner"), "verify", "--verbose", str(signed)],
                           env, capture_output=True).stdout
        run([str(tools / "zipalign"), "-c", "4", str(signed)], env)
        with zipfile.ZipFile(signed) as archive:
            if archive.testzip() is not None or "classes.dex" not in archive.namelist():
                raise ValueError("Invalid instrumentation APK")
        shutil.copy2(signed, output)
    result = {"apk": str(output), "bytes": output.stat().st_size,
              "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
              "target_package": "org.genewars.android",
              "runner": "org.genewars.smoke/.NativeSmokeInstrumentation",
              "signature_verification": verification.strip(),
              "runtime_tested": False}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "signature_verification"}, indent=2))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk", type=Path, default=Path(os.environ.get("ANDROID_SDK_ROOT", "android-sdk")))
    parser.add_argument("--java-home", type=Path, default=Path(os.environ.get("JAVA_HOME", "/usr/lib/jvm/default-java")))
    parser.add_argument("--keystore", type=Path, default=ROOT / "build/signing/android-debug.p12")
    parser.add_argument("--alias", default="androiddebugkey")
    parser.add_argument("--output", type=Path, default=ROOT / "build/genewars-native-smoke.apk")
    args = parser.parse_args()
    build(args.sdk, args.java_home, args.keystore, args.alias, args.output)


if __name__ == "__main__":
    main()
