package org.genewars.smoke;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Black-box native UI, command and persisted-save smoke test. No AndroidX. */
public final class NativeSmokeInstrumentation extends Instrumentation {
    private final List<String> checks = new ArrayList<String>();
    private Activity activity;
    private UiAutomation automation;
    private String stage = "launch";
    private String lastAccessibilitySnapshot = "No accessibility root was sampled";

    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        start();
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            automation = getUiAutomation();
            activity = launch();
            awaitExact("Новая игра", 30000).recycle();
            pass("native_main_menu");

            stage = "choose original map and mission";
            clickExact("Новая игра");
            awaitExact("Выберите планету", 10000).recycle();
            clickFirstListItem();
            awaitExact("Задание реконструкции", 10000).recycle();
            clickFirstListItem();
            awaitHud(30000);
            awaitExact("Строить", 10000).recycle();
            SystemClock.sleep(2200);
            pass("original_map_loaded_and_native_frames_running");

            stage = "select engineer and start construction";
            int before = goop(hudOnMainThread());
            Rect world = worldBounds();
            float density = getTargetContext().getResources().getDisplayMetrics().density;
            injectTap(world.exactCenterX(), world.exactCenterY() - 9 * density);
            SystemClock.sleep(500);
            clickExact("Строить");
            awaitPrefix("Постройка:", 10000).recycle();
            clickFirstListItem();
            awaitHud(10000);
            int[][] offsets = {{3,0}, {0,3}, {-3,0}, {0,-3}, {3,3}, {-3,-3}, {5,0}, {0,5}, {-5,0}, {0,-5}};
            boolean spent = false;
            int after = before;
            for (int[] offset : offsets) {
                float x = world.exactCenterX() + (offset[0] - offset[1]) * 18 * density;
                float y = world.exactCenterY() + (offset[0] + offset[1]) * 9 * density;
                if (x <= world.left + 8 || x >= world.right - 8 || y <= world.top + 8 || y >= world.bottom - 8) continue;
                injectTap(x, y);
                long deadline = SystemClock.uptimeMillis() + 1800;
                while (SystemClock.uptimeMillis() < deadline) {
                    after = goop(hudOnMainThread());
                    if (after < before) { spent = true; break; }
                    SystemClock.sleep(100);
                }
                if (spent) break;
            }
            require(spent, "Construction command did not debit GOOP; before=" + before + ", after=" + after);
            pass("native_construction_command_debits_resources");

            stage = "save game through native menu";
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            String savedHud = hudOnMainThread();
            require(goop(savedHud) < before, "Changed resource state was not retained before saving");
            clickExact("Сохранить");
            File save = new File(getTargetContext().getFilesDir(), "game-v1.gws");
            long saveDeadline = SystemClock.uptimeMillis() + 10000;
            while ((!save.isFile() || save.length() < 32) && SystemClock.uptimeMillis() < saveDeadline) SystemClock.sleep(100);
            require(save.isFile() && save.length() >= 32, "No durable private save file");
            pass("private_game_save_created");

            stage = "leave game and restart Activity";
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            savedHud = hudOnMainThread();
            clickExact("Главное меню");
            awaitExact("Новая игра", 10000).recycle();
            runOnMainSync(new Runnable() { @Override public void run() { activity.finish(); } });
            waitForIdleSync();
            activity = launch();
            awaitExact("Продолжить", 30000).recycle();
            pass("native_activity_restarted_with_persisted_slot");
            clickExact("Продолжить");
            awaitHud(30000);
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            String restoredHud = hudOnMainThread();
            require(savedHud.equals(restoredHud), "Restored counters differ: saved=" + savedHud + ", loaded=" + restoredHud);
            pass("changed_resource_state_restored_after_activity_restart");

            result.putString("status", "passed");
            result.putInt("passed_checks", checks.size());
            result.putStringArrayList("checks", new ArrayList<String>(checks));
            result.putString("saved_hud", savedHud);
            result.putString("restored_hud", restoredHud);
            result.putString("scope", "native UI, real command, private save and Activity restart; not process-kill or physical-device performance");
            result.putString("stream", "\nPASS: " + checks.size() + " native smoke checks\n");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable failure) {
            android.util.Log.e("GeneWarsSmoke", "Failure at " + stage, failure);
            String diagnostic = "Accessibility: " + accessibilitySnapshot() + " | Activity: " + activitySnapshot();
            android.util.Log.e("GeneWarsSmoke", diagnostic);
            String detail = failure.getMessage();
            if (detail == null) detail = failure.getClass().getSimpleName();
            if (detail.length() > 600) detail = detail.substring(0, 600);
            result.putString("status", "failed");
            result.putString("stage", stage);
            result.putString("reason", detail);
            result.putString("ui_snapshot", diagnostic);
            result.putInt("passed_checks", checks.size());
            result.putStringArrayList("checks", new ArrayList<String>(checks));
            result.putString("stream", "\nFAIL at " + stage + ": " + detail + "\n" + diagnostic + "\n");
            finish(Activity.RESULT_CANCELED, result);
        }
    }

    private Activity launch() {
        Intent launch = new Intent(Intent.ACTION_MAIN);
        launch.setClassName("org.genewars.android", "org.genewars.android.MainActivity");
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return startActivitySync(launch);
    }

    private void pass(String check) {
        checks.add(check);
        Bundle progress = new Bundle();
        progress.putString("stream", "PASS " + check + "\n");
        progress.putString("check", check);
        sendStatus(1, progress);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private interface Match { boolean accepts(AccessibilityNodeInfo node); }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, Match match) {
        if (node == null) return null;
        if (match.accepts(node)) return AccessibilityNodeInfo.obtain(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo found;
            try { found = find(child, match); } finally { child.recycle(); }
            if (found != null) return found;
        }
        return null;
    }

    private AccessibilityNodeInfo await(Match match, long timeout) {
        long deadline = SystemClock.uptimeMillis() + timeout;
        while (SystemClock.uptimeMillis() < deadline) {
            AccessibilityNodeInfo root = automation.getRootInActiveWindow();
            if (root != null) {
                AccessibilityNodeInfo found;
                try {
                    lastAccessibilitySnapshot = "root=" + root.getPackageName() + '/' + root.getClassName();
                    found = find(root, match);
                } finally { root.recycle(); }
                if (found != null) return found;
            } else lastAccessibilitySnapshot = "root=null";
            SystemClock.sleep(100);
        }
        throw new AssertionError("UI condition timed out after " + timeout + " ms");
    }

    private AccessibilityNodeInfo awaitExact(final String text, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && text.contentEquals(node.getText() == null ? "" : node.getText());
        } }, timeout);
    }

    private AccessibilityNodeInfo awaitPrefix(final String text, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && node.getText() != null && node.getText().toString().startsWith(text);
        } }, timeout);
    }

    private void awaitHud(long timeout) { AccessibilityNodeInfo node = awaitPrefix("Биогель:", timeout); node.recycle(); }

    private void clickExact(String text) {
        AccessibilityNodeInfo node = awaitExact(text, 10000);
        try { click(node); } finally { node.recycle(); }
        SystemClock.sleep(150);
    }

    private void clickFirstListItem() {
        AccessibilityNodeInfo list = await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && "android.widget.ListView".contentEquals(node.getClassName() == null ? "" : node.getClassName()) && node.getChildCount() > 0;
        } }, 10000);
        try {
            AccessibilityNodeInfo first = list.getChild(0);
            require(first != null, "Dialog list has no first item");
            try { click(first); } finally { first.recycle(); }
        } finally { list.recycle(); }
        SystemClock.sleep(200);
    }

    private void click(AccessibilityNodeInfo node) {
        require(node.isEnabled(), "Control is disabled: " + node.getText());
        if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
            require(!bounds.isEmpty(), "Control has empty bounds");
            injectTap(bounds.exactCenterX(), bounds.exactCenterY());
        }
    }

    private void injectTap(float x, float y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
        MotionEvent up = MotionEvent.obtain(now, now + 100, MotionEvent.ACTION_UP, x, y, 0);
        down.setSource(InputDevice.SOURCE_TOUCHSCREEN); up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        try {
            require(automation.injectInputEvent(down, true), "Touch down injection failed");
            require(automation.injectInputEvent(up, true), "Touch up injection failed");
        } finally { down.recycle(); up.recycle(); }
    }

    private void pressBack() {
        sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
        SystemClock.sleep(150);
    }

    private Rect worldBounds() {
        AccessibilityNodeInfo node = await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            CharSequence description = node.getContentDescription();
            return node.isVisibleToUser() && description != null && description.toString().startsWith("Карта планеты.");
        } }, 10000);
        try { Rect bounds = new Rect(); node.getBoundsInScreen(bounds); return bounds; }
        finally { node.recycle(); }
    }

    private String hudOnMainThread() {
        final String[] value = {null};
        runOnMainSync(new Runnable() { @Override public void run() { value[0] = hudText(activity.getWindow().getDecorView()); } });
        require(value[0] != null, "Native HUD view disappeared");
        return value[0];
    }

    private String hudText(View view) {
        if (view instanceof TextView) {
            String value = ((TextView) view).getText().toString();
            if (value.startsWith("Биогель:")) return value;
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                String found = hudText(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private int goop(String hud) {
        Matcher matcher = Pattern.compile("Биогель:\\s*(\\d+)").matcher(hud);
        require(matcher.find(), "Cannot parse GOOP counter: " + hud);
        return Integer.parseInt(matcher.group(1));
    }

    private void describeAccessibility(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || out.length() >= 1800 || depth > 12) return;
        CharSequence value = node.getText();
        if (depth == 0 || value != null && value.length() > 0) {
            if (out.length() > 0) out.append("; ");
            out.append(node.getPackageName()).append('/').append(node.getClassName());
            out.append(" visible=").append(node.isVisibleToUser());
            if (value != null) out.append(" text=").append(limit(value.toString(), 100));
        }
        for (int i = 0; i < node.getChildCount() && out.length() < 1800; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            try { describeAccessibility(child, out, depth + 1); } finally { child.recycle(); }
        }
    }

    private String accessibilitySnapshot() {
        try {
            AccessibilityNodeInfo root = automation == null ? null : automation.getRootInActiveWindow();
            if (root == null) return "root=null; last=" + lastAccessibilitySnapshot;
            try {
                StringBuilder out = new StringBuilder();
                describeAccessibility(root, out, 0);
                return out.toString();
            } finally { root.recycle(); }
        } catch (Throwable diagnosticError) {
            return "snapshot failed: " + diagnosticError.getClass().getSimpleName()
                    + "; last=" + lastAccessibilitySnapshot;
        }
    }

    private String activitySnapshot() {
        final Activity current = activity;
        if (current == null) return "Activity=null";
        final String[] value = {"main thread did not answer within 1500 ms"};
        final CountDownLatch completed = new CountDownLatch(1);
        current.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    View decor = current.getWindow().getDecorView();
                    StringBuilder text = new StringBuilder();
                    describeViews(decor, text, 0);
                    value[0] = "finishing=" + current.isFinishing() + ", destroyed=" + current.isDestroyed()
                            + ", windowFocus=" + current.hasWindowFocus() + ", shown=" + decor.isShown()
                            + ", attached=" + decor.isAttachedToWindow() + ", views=" + text;
                } catch (Throwable diagnosticError) {
                    value[0] = "snapshot failed: " + diagnosticError.getClass().getSimpleName();
                } finally { completed.countDown(); }
            }
        });
        try { completed.await(1500, TimeUnit.MILLISECONDS); }
        catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
        return limit(value[0], 2000);
    }

    private void describeViews(View view, StringBuilder out, int depth) {
        if (view == null || out.length() >= 1500 || depth > 12) return;
        if (view instanceof TextView) {
            String value = ((TextView) view).getText().toString();
            if (!value.isEmpty()) {
                if (out.length() > 0) out.append("; ");
                out.append(view.getClass().getSimpleName()).append(" shown=").append(view.isShown())
                        .append(" text=").append(limit(value, 100));
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount() && out.length() < 1500; i++)
                describeViews(group.getChildAt(i), out, depth + 1);
        }
    }

    private static String limit(String text, int max) {
        return text.length() > max ? text.substring(0, max) : text;
    }
}
