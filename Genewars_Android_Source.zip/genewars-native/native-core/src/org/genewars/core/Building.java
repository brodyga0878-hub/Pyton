package org.genewars.core;

public final class Building {
    /** Base costs and first-stage HP recovered from the supplied retail EXE. */
    public enum Kind {
        EXTRACTOR(650, 280, 6, 0, "Экстрактор", "BMINE"),
        DISTRIBUTOR(400, 240, 0, 2, "Распределитель", "BPOWE"),
        SOLAR(250, 80, 0, 15, "Фотонный процессор", "BSOLA"),
        GENE_LAB(600, 280, 10, 0, "Генокапсула", "BGENE"),
        RECYCLER(300, 240, 5, 0, "Перерабатывающий завод", "BFARM"),
        TURRET(750, 120, 9, 0, "Оглушающая турель", "BTURR"),
        PULPER(400, 160, 4, 0, "Целлюлозатор", "BSAWM"),
        LANDING_PAD(600, 160, 3, 0, "Посадочная площадка", "BLAUN"),
        DETECTOR(1000, 240, 4, 0, "Эфириальный детектор", "BOBSE"),
        WIND(300, 150, 0, 20, "Ветряк", "BWIND"),
        FUSION(500, 240, 0, 60, "Термоядерная батарея", "BNUKE"),
        TECH(900, 400, 8, 0, "Технический центр", "BOPER"),
        SHIELD(600, 140, 12, 0, "Генератор щита", "BSHIE"),
        VAT(300, 80, 1, 0, "Бак биогеля", "BVAT");
        public final int cost, maxHp, powerUse, powerOutput;
        public final String title, sprite;
        Kind(int cost, int maxHp, int use, int output, String title, String sprite) {
            this.cost = cost; this.maxHp = maxHp; this.powerUse = use; this.powerOutput = output;
            this.title = title; this.sprite = sprite;
        }
    }
    public int id, team, stage;
    public Kind kind;
    public double x, y, hp, maxHp, progress;
    public boolean powered;
    double production, cooldown;
    int queuedSpecies = -1;
    int queuedSpecialist = -1;
    double training;
    Building(int id, int team, Kind kind, double x, double y, boolean complete) {
        this.id = id; this.team = team; this.kind = kind; this.x = x; this.y = y;
        maxHp = kind.maxHp; hp = complete ? maxHp : maxHp * .15; progress = complete ? 1 : 0;
    }
    public boolean alive() { return hp > 0; }
    public String spriteKey() { return "buildings/" + kind.sprite; }
    public String title() {
        switch (kind) {
            case GENE_LAB: return new String[]{"Генокапсула", "Геномашина", "Генолаборатория"}[stage];
            case DISTRIBUTOR: return new String[]{"Распределитель I", "Распределитель II", "Распределитель III"}[stage];
            case SOLAR: return new String[]{"Фотонный процессор", "Спектральная губка", "ЭМ-ловушка"}[stage];
            case RECYCLER: return new String[]{"Перерабатывающий завод", "Рециклотрон", "Фабрика биогеля"}[stage];
            case TURRET: return new String[]{"Оглушающая турель", "Разрядная турель", "Бластерная турель"}[stage];
            case PULPER: return new String[]{"Целлюлозатор", "Измельчитель", "Массовый измельчитель"}[stage];
            case WIND: return new String[]{"Ветряк", "Ветропроцессор", "Атмосферный генератор"}[stage];
            case FUSION: return stage == 0 ? "Термоядерная батарея" : "Термоядерный генератор";
            case DETECTOR: return new String[]{"Эфириальный детектор", "Эфириальный телескоп", "Эфириальная обсерватория"}[stage];
            case SHIELD: return new String[]{"Генератор щита", "Генератор убежища", "Защитный купол"}[stage];
            default: return kind.title;
        }
    }
    public int retailType() {
        switch (kind) {
            case GENE_LAB: return 0; case TURRET: return 1; case PULPER: return 2; case DISTRIBUTOR: return 3;
            case RECYCLER: return 4; case LANDING_PAD: return 5; case SOLAR: return 6; case DETECTOR: return 7;
            case WIND: return 8; case FUSION: return 9; case TECH: return 10; case EXTRACTOR: return 11;
            case SHIELD: return 12; default: return 13;
        }
    }
    public int maxStage() {
        switch (kind) {
            case LANDING_PAD: case TECH: case EXTRACTOR: case VAT: return 0;
            case FUSION: return 1;
            default: return 2;
        }
    }
    public boolean complete() { return progress >= 1; }
    public String status() {
        if (!complete()) return "Строительство " + (int) (progress * 100) + "%";
        if (!powered && kind.powerUse > 0) return "Нет энергии";
        if (queuedSpecies >= 0 || queuedSpecialist >= 0) return "Создание " + (int) (training * 100) + "%";
        return "Работает";
    }
}
