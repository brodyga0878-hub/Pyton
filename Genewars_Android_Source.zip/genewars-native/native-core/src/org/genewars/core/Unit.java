package org.genewars.core;

/** A live specialist or creature. Mutate only through GameState on the game thread. */
public final class Unit {
    public enum Kind { ENGINEER, BOTANIST, GENETICIST, RANGER, CREATURE }
    public int id, team, species, ability;
    public Kind kind;
    public double x, y, hp, maxHp, energy, age, energyCapacity, lifespan;
    public boolean selected;
    public String task = "Ожидание";
    int action, targetId, pathCursor;
    int[] path = new int[0];
    double targetX, targetY, cooldown, workTimer;
    boolean repeatHarvest;

    Unit(int id, int team, Kind kind, int species, double x, double y) {
        this.id = id; this.team = team; this.kind = kind; this.species = species;
        this.x = this.targetX = x; this.y = this.targetY = y;
        maxHp = kind == Kind.CREATURE ? RetailRules.SPECIES_HEALTH[species] : 100;
        energyCapacity = kind == Kind.CREATURE ? RetailRules.SPECIES_ENERGY[species] : 120;
        lifespan = kind == Kind.CREATURE ? RetailRules.SPECIES_LIFESPAN[species] : 1000000;
        hp = maxHp; energy = maxEnergy();
    }
    public double maxEnergy() { return energyCapacity; }
    public boolean alive() { return hp > 0; }
    public String title() {
        switch (kind) {
            case ENGINEER: return "Инженер";
            case BOTANIST: return "Ботаник";
            case GENETICIST: return "Генетик";
            case RANGER: return "Егерь";
            default: return GameState.SPECIES_NAMES[species];
        }
    }
    public String spriteKey() {
        if (kind != Kind.CREATURE) {
            switch (kind) {
                case ENGINEER: return "specialists/HARCH";
                case BOTANIST: return "specialists/HFARM";
                case GENETICIST: return "specialists/HSCIE";
                default: return "specialists/HSHEP";
            }
        }
        return "creatures/" + GameState.SPECIES_SPRITES[species];
    }
}
