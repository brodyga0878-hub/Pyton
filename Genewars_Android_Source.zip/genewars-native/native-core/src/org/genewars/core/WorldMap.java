package org.genewars.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.CRC32;

/** Imported original terrain. Values 0..7 follow the recovered GetTerrain rule. */
public final class WorldMap {
    public final int width, height;
    public final byte[] terrain;
    public final short[] elevation;
    public final boolean[] blocked;
    public final String sourceName;

    public WorldMap(int width, int height, byte[] terrain, short[] elevation,
                    boolean[] blocked, String sourceName) {
        if (width < 8 || height < 8 || width > 256 || height > 256
                || terrain == null || elevation == null || blocked == null
                || terrain.length != width * height || elevation.length != terrain.length
                || blocked.length != terrain.length || sourceName == null || sourceName.length() > 128) {
            throw new IllegalArgumentException("Invalid map dimensions or arrays");
        }
        this.width = width; this.height = height;
        this.terrain = terrain.clone(); this.elevation = elevation.clone();
        this.blocked = blocked.clone(); this.sourceName = sourceName;
    }

    public boolean contains(int x, int y) { return x >= 0 && y >= 0 && x < width && y < height; }
    public int index(int x, int y) { return y * width + x; }
    public boolean walkable(int x, int y) { return contains(x, y) && !blocked[index(x, y)]; }

    public byte[] toBytes() throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(buffer);
        out.writeInt(0x47574d31); out.writeShort(1); out.writeShort(width); out.writeShort(height);
        byte[] name = sourceName.getBytes(StandardCharsets.UTF_8);
        out.writeShort(name.length); out.write(name); out.writeInt(width * height);
        for (int i = 0; i < terrain.length; i++) {
            out.writeByte(terrain[i]); out.writeShort(elevation[i]); out.writeByte(blocked[i] ? 1 : 0);
        }
        out.flush(); CRC32 crc = new CRC32(); crc.update(buffer.toByteArray());
        out.writeInt((int) crc.getValue()); out.flush(); return buffer.toByteArray();
    }

    public static WorldMap read(InputStream input) throws IOException {
        byte[] bytes = readLimited(input, 1024 * 1024);
        if (bytes.length < 24) throw new IOException("Truncated map");
        CRC32 crc = new CRC32(); crc.update(bytes, 0, bytes.length - 4);
        DataInputStream tail = new DataInputStream(new ByteArrayInputStream(bytes, bytes.length - 4, 4));
        if ((int) crc.getValue() != tail.readInt()) throw new IOException("Map CRC mismatch");
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes, 0, bytes.length - 4));
        if (in.readInt() != 0x47574d31 || in.readUnsignedShort() != 1) throw new IOException("Unsupported map format");
        int width = in.readUnsignedShort(), height = in.readUnsignedShort(), nameLength = in.readUnsignedShort();
        if (width < 8 || height < 8 || width > 256 || height > 256 || nameLength > 128) throw new IOException("Invalid map header");
        byte[] name = new byte[nameLength]; in.readFully(name);
        int count = in.readInt(); if (count != width * height || in.available() != count * 4) throw new IOException("Invalid map size");
        byte[] terrain = new byte[count]; short[] elevation = new short[count]; boolean[] blocked = new boolean[count];
        for (int i = 0; i < count; i++) {
            terrain[i] = in.readByte(); elevation[i] = in.readShort(); int flags = in.readUnsignedByte();
            if ((flags & ~1) != 0) throw new IOException("Unknown map flags");
            blocked[i] = (flags & 1) != 0;
        }
        return new WorldMap(width, height, terrain, elevation, blocked, new String(name, StandardCharsets.UTF_8));
    }

    static byte[] readLimited(InputStream input, int limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int count;
        while ((count = input.read(buffer)) != -1) {
            if (out.size() > limit - count) throw new IOException("File exceeds allowed size");
            out.write(buffer, 0, count);
        }
        return out.toByteArray();
    }
}
