package org.genewars.core;

public final class Plant {
    public int id, species, biomass;
    public double x, y;
    double growth;
    Plant(int id, int species, double x, double y, int biomass) {
        this.id = id; this.species = species; this.x = x; this.y = y; this.biomass = biomass;
    }
    public String spriteKey() {
        String[] names = {"GRASS1", "GRASS2", "GRASS3", "DESERT1", "DESERT2", "DESERT3",
                "SNOW1", "SNOW2", "SNOW3", "ALL1", "ALL2", "ALL3"};
        return "plants/" + names[species % names.length];
    }
}
