# Gene Wars resource format findings

These findings describe the uploaded `GW.EXE` with SHA-256
`6a8c75b7de5f4e7f27c5378b712e04c24fd106778429f5765c49a641fac90e64`.
They were obtained statically; instructions shown below were disassembled, not
executed. Addresses are offsets within LE code object 1, whose first data page
starts at file offset `0x41E00`. For these addresses, add `0x41E00` to obtain the
file offset. Do not reuse the addresses for a different executable.

## TEXT.DAT and string count

The file is 36,610 bytes, plain ASCII/NUL-separated text, with 604 nonempty
records, including nine space-only placeholders. Its last record is `Y / N` and
it ends in two NUL bytes. Splitting on NUL yields 606 elements because of those
two final terminators. There is no leading index table in this resource.

The actual executable initialises **604**, not 602, string pointers:

```text
DA48: BB 5C 02 00 00       mov ebx,0x25c        ; 604 records
DA58: A1 88 5E 01 00       mov eax,[0x15e88]   ; loaded text data
DA60: 4B                   dec ebx
DA61: 83 FB FF             cmp ebx,-1
DA64: 74 17                je 0xDA7D
DA66: 89 F2                mov edx,esi
DA68: 81 C2 90 5E 01 00    add edx,0x15e90
DA6E: 83 C6 04             add esi,4
DA71: 89 02                mov [edx],eax       ; pointer to this string
DA73: 0F BE 10             movsx edx,byte [eax]
DA76: 40                   inc eax
DA77: 85 D2                test edx,edx
DA79: 75 F8                jne 0xDA73         ; scan through next NUL
DA7B: EB E3                jmp 0xDA60
```

The early-stage public reverse-engineering repository
https://github.com/mefistotelis/genewars declares `strings[602]`. It is not the
same build and is mostly function stubs. Its array declaration must not override
the evidence from the uploaded binary.

String order and count must remain unchanged. Preserve printf tokens in order
(27 `%d`, 19 `%s`, one `%%` across this file), `{` control markers, three CRLF
strings, and the placeholder records. Variable-length strings are compatible
with this pointer-building routine, but this alone does not prove that every
consumer's temporary buffer and every text box has sufficient capacity. Longer
translations still require runtime checks of menus, help, mission briefings,
results and formatted messages.

## RNC1 and uncompressed resources

112 files in the archive start with the RNC method-1 signature. All 112 were
decoded using the research Python decoder, with both the packed-data and the
unpacked-data CRC16 and unpacked size verified. No checksum checks were disabled.

The **uploaded executable itself accepts raw, uncompressed replacements**:

- `0x894A0` constructs the `RNC\x01` signature, reads the first eight bytes and
  compares the first four at `0x8950B`.
- On a signature match, `0x89514–0x89539` reads the big-endian unpacked length.
  Otherwise `0x8953B` calls the ordinary file-length routine.
- `0x8954C` reads the resource and calls `UnpackM1` at `0xA95DC`.
- `UnpackM1` compares the words `0x4E52` (`RN`) and `0x0143` (`C` + method 1).
  A non-RNC resource reaches `0xA975C`, which returns zero.
- The caller at `0x89598–0x895B5` treats a negative result as an error, a positive
  result as the unpacked length, and zero as success using the original length.
- Descriptor loader `0x8A109` allocates the reported length plus 512 bytes.
  At `0x8A154–0x8A15E`, it sets `End = Start + reported_length`.

Consequently an experimental font builder can emit ordinary DAT/TAB pairs,
without implementing an RNC compressor. Variable-size TAB tables are supported
by these loader and end-pointer paths. This is static evidence, not proof that
all later game routines accept arbitrary dimensions or every possible font.

## Bitmap font data

`FONT0`, `FONT1`, `FONT2`, `FONT4`, `FONT5`, `FONT7` normally have 195 records.
`QUITFONT` has 136. `FONT3` has 27 and covers only the numeric/punctuation range;
it is left unchanged by the experimental Cyrillic tool.

A TAB record is packed `<IBB>`: 32-bit little-endian DAT offset, one-byte width,
one-byte height. The DAT starts with a two-byte little-endian record count, also
represented by an empty first table record pointing to offset zero. Each glyph
uses signed-byte row runs: positive n = n palette bytes follow, negative n = skip
-n transparent pixels, zero = end of scanline. There are `height` rows, followed
by a `0x7F` marker. The parser respects the table's dimensions rather than
searching blindly for that marker.

Character-to-table mapping is `table_index = byte_value - 31`:

```text
F566: mov eax,[edi]             ; table start
F568: add eax,6
F56B: mov [esi],eax             ; FontInfo.SpaceSprite = table + one record
F5C2: movzx esi,byte [edx]      ; unsigned character
F5CE: lea ecx,[esi-0x20]
F5D1: imul ecx,ecx,6           ; relative to SpaceSprite
F978: mov dl,byte [edi]         ; EDX was zeroed immediately before
F97A: lea ebp,[edx-0x20]
F97D: imul ebp,ebp,6           ; draw path uses the same map
```

These tables contain Latin and Western European glyphs, not Cyrillic. CP1251 and
CP866 are not safe drop-in choices for the unmodified tables: some encoded
letters exceed the available range. UTF-8 would render as several unrelated
byte glyphs.

The prototype instead uses one byte per Russian letter, contiguous 128–193:
uppercase `АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ`, then the corresponding lowercase.
ASCII remains unchanged. Ordinary 195-record tables already cover these slots;
QUITFONT is expanded from 136 to 163 records. This replaces some Western
European glyphs in that particular Russian build. Existing English ASCII
pixels and metrics remain intact. Text authoring remains Unicode; it must be
encoded through this explicit map only at build time.

The text width and drawing paths above read these character bytes as unsigned.
The game's C-character classification table has zero flags for the proposed
128–193 range, so they are not accidentally classified as whitespace by the
observed word-breaking path. Other code paths, input, case conversion and all
screen layouts still require testing.

## FADE.DAT is generated when absent

The old included `GW.ERR` mentions `data/fade.dat`, but this is **not evidence
that the distribution needs an original FADE.DAT supplied externally**. At
`0xD3B0–0xD49A`, the game first attempts to read the file. If that returns -1,
it builds tables from the active palette, then saves them:

```text
D3C1: mov edx,0xD3AC           ; "data/fade.dat"
D3CB: call 0x54F0             ; file read wrapper
D3D0: cmp eax,-1
D3D3: jne 0xD49A              ; existing file: use it
       ...                    ; palette table generation loops
D486: mov ebx,0x4000           ; 16,384 bytes
D48B: mov edx,0x88F48          ; generated table buffer
D490: mov eax,0xD3BA           ; second "data/fade.dat" literal
D495: call 0x895C8            ; save wrapper
```

The development copy must be writable for this cache generation. The static
analysis does not prove why the previous owner produced the old error log.

## Work beyond text + font replacement

- `LEVELS/HDRCO*.DAT` / `HDRCU*.DAT` contain English map names in binary records.
  Their length limits and record schema require a separate safe editor.
- Some strings, diagnostics and network messages are embedded in GW.EXE.
- Some headings are painted into images. `FILEEN.DAT` decodes to a 640×480 indexed
  image using `FILESCR.PAL`, and its `OPTIONS` heading is part of the image.
  `CUSTOMEN.DAT` likewise has a baked `NETWORK` heading. `TITLESCR.DAT` is another
  640×480 image. A translated TEXT.DAT cannot change those pixels.
- `QUITFONT` and large original fonts use textured palette colours. The prototype
  applies a simple row-colour approximation, not hand-finished art.
- Tiny original font heights of 7–8 pixels make Cyrillic fitting difficult.
  In particular Ё/ё and narrow lowercase letters need manual visual review.
- The RIP archive's voice resources are zero-length audio placeholders. Original
  missing narration cannot be restored from this upload. New synchronized
  subtitles for absent narration cannot be inferred from the empty WAVs.

## Prototype usage

From the repository directory:

```sh
python3 tools/gw_fonts.py /path/to/original.zip --output build/fonts
```

This requires Pillow and a local Cyrillic TrueType font. The default is the
system DejaVu Sans Bold; `--font` selects another installed font. The tool writes
only below the repository's ignored `build/` directory and refuses a nonempty
output folder. It does not modify the original ZIP or the game executable.

For each of seven font families it validates original RNC CRCs, decodes the
original sprites, checks a lossless pixel/metric encoder round trip, replaces
66 Cyrillic slots, preserves all ASCII glyphs, and validates the new resources
with another encoder/decoder round trip. It saves 14 raw DAT/TAB files, exact
metrics and hashes in `manifest.json`, a combined preview and one contact sheet
per font. The resource previews are labelled as such; they are not screenshots
of a running game. New glyphs are an experimental raster fit, not a finished
artistic localisation or a claim of full compatibility.
