// SPDX-License-Identifier: GPL-2.0-or-later
package org.genewars.android.gl3d;

/**
 * Native, fully volumetric building meshes. Every family has a distinct silhouette
 * and functioning mechanical rig; no sprite, camera-facing quad or imported DOS
 * executable is used. Colours store emissiveness in their fourth component.
 */
public final class BuildingModels3D {
    private static final float PI = (float) Math.PI;
    private static final float[] IVORY = {.83f, .86f, .79f, 0};
    private static final float[] WHITE = {.95f, .94f, .83f, 0};
    private static final float[] DARK = {.075f, .12f, .15f, 0};
    private static final float[] METAL = {.22f, .29f, .31f, 0};
    private static final float[] COPPER = {.68f, .35f, .13f, 0};
    private static final float[] CYAN = {.045f, .72f, .86f, .80f};
    private static final float[] BLUE = {.045f, .26f, .43f, .22f};
    private static final float[] GREEN = {.19f, .67f, .27f, .25f};
    private static final float[] LIME = {.49f, .91f, .22f, .65f};
    private static final float[] AMBER = {.98f, .53f, .07f, .75f};
    private static final float[] WOOD = {.39f, .20f, .08f, 0};

    private BuildingModels3D() {}

    /** Ordinals are the native Building.Kind order, not the old retail type ID. */
    public static MeshData3D build(int ordinal) {
        if (ordinal < 0 || ordinal >= 14) throw new IllegalArgumentException("Building ordinal");
        MeshBuilder3D b = new MeshBuilder3D("building_" + ordinal);
        switch (ordinal) {
            case 0: extractor(b); break;
            case 1: distributor(b); break;
            case 2: solar(b); break;
            case 3: geneLab(b); break;
            case 4: recycler(b); break;
            case 5: turret(b); break;
            case 6: pulper(b); break;
            case 7: landingPad(b); break;
            case 8: detector(b); break;
            case 9: wind(b); break;
            case 10: fusion(b); break;
            case 11: technicalCenter(b); break;
            case 12: shield(b); break;
            default: vat(b);
        }
        return b.finish();
    }

    private static void foundation(MeshBuilder3D b, float radius) {
        b.cylinder(0, .09f, 0, 0, .24f, 0, radius, radius * .96f, 12, METAL, 0);
        b.cylinder(0, .24f, 0, 0, .29f, 0, radius * .84f, radius * .84f, 12, DARK, 0);
        for (int i = 0; i < 4; i++) {
            float a = PI * .25f + i * PI * .5f;
            float x = cos(a) * radius, z = sin(a) * radius;
            b.ellipsoid(x, .09f, z, .18f, .09f, .19f, 8, 4, IVORY, 0);
            b.cylinder(x * .66f, .25f, z * .66f, x, .13f, z, .07f, .07f, 7, COPPER, 0);
            b.ellipsoid(x * .92f, .18f, z * .92f, .045f, .025f, .045f, 6, 3, CYAN, 0);
        }
        ringY(b, 0, .255f, 0, radius * .84f, .025f, 12, COPPER, 0);
    }

    private static void extractor(MeshBuilder3D b) {
        foundation(b, .73f);
        int drill = b.bone("auger", 0, 0, .65f, .05f, Bone3D.ROTOR_Y, 0, 1.65f);
        for (int side = -1; side <= 1; side += 2) {
            b.cylinder(side * .45f, .28f, -.10f, side * .40f, 1.65f, -.06f,
                    .12f, .085f, 8, IVORY, 0);
            b.cylinder(side * .47f, .4f, .03f, side * .42f, 1.5f, .03f,
                    .034f, .034f, 6, COPPER, 0);
        }
        b.cylinder(-.44f, 1.64f, -.06f, .44f, 1.64f, -.06f, .15f, .15f, 8, METAL, 0);
        b.ellipsoid(0, 1.48f, .02f, .28f, .28f, .25f, 12, 7, IVORY, 0);
        b.cylinder(0, .28f, .05f, 0, 1.35f, .05f, .10f, .10f, 10, DARK, drill);
        for (int i = 0; i < 7; i++) {
            float y = .34f + i * .13f;
            b.cylinder(0, y, .05f, 0, y + .09f, .05f, .23f, .13f, 10, COPPER, drill);
        }
        b.cylinder(0, .17f, .05f, 0, .37f, .05f, .025f, .20f, 10, METAL, drill);
        b.box(.49f, .37f, .46f, .40f, .22f, .37f, DARK, 0);
        for (int i = 0; i < 5; i++)
            b.ellipsoid(.35f + .065f * i, .54f + .025f * (i % 2), .44f,
                    .09f, .075f, .08f, 6, 3, COPPER, 0);
        b.cylinder(-.48f, .32f, -.37f, -.48f, 1.91f, -.37f, .09f, .075f, 8, DARK, 0);
        ringY(b, -.48f, 1.80f, -.37f, .095f, .028f, 8, AMBER, 0);
        frontGauge(b, .27f, .78f, .29f, 0);
    }

    private static void distributor(MeshBuilder3D b) {
        foundation(b, .77f);
        int pulse = b.bone("plasma_node", 0, 0, 1.35f, 0, Bone3D.PULSE, 0, .045f);
        b.cylinder(0, .30f, 0, 0, 1.28f, 0, .31f, .18f, 12, IVORY, 0);
        b.ellipsoid(0, 1.42f, 0, .24f, .30f, .24f, 12, 8, CYAN, pulse);
        b.cylinder(0, 1.65f, 0, 0, 2.28f, 0, .07f, .025f, 8, DARK, 0);
        b.ellipsoid(0, 2.28f, 0, .06f, .065f, .06f, 8, 4, CYAN, pulse);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3 + PI / 2;
            float x = cos(a) * .53f, z = sin(a) * .53f;
            b.cylinder(x, .27f, z, x, 1.72f, z, .15f, .10f, 10, DARK, 0);
            for (int j = 0; j < 6; j++) ringY(b, x, .58f + j * .15f, z, .14f, .033f, 9, COPPER, 0);
            b.ellipsoid(x, 1.78f, z, .13f, .10f, .13f, 10, 5, IVORY, 0);
            b.cylinder(x, .42f, z, x * .35f, .58f, z * .35f, .065f, .065f, 7, METAL, 0);
        }
        frontGauge(b, 0, .8f, .27f, 0);
    }

    private static void solar(MeshBuilder3D b) {
        foundation(b, .66f);
        b.cylinder(0, .3f, 0, 0, 1.12f, 0, .18f, .11f, 10, IVORY, 0);
        int core = b.bone("collector_core", 0, 0, 1.17f, 0, Bone3D.PULSE, 0, .035f);
        int tracking = b.bone("solar_tracking", 0, 0, 1.12f, 0, Bone3D.ROTOR_Y, 0, .035f);
        b.ellipsoid(0, 1.15f, 0, .20f, .24f, .20f, 12, 6, CYAN, core);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3 + .15f;
            float ux = cos(a), uz = sin(a), vx = -uz, vz = ux;
            float x0 = ux * .12f, z0 = uz * .12f;
            float x1 = ux * .95f, z1 = uz * .95f;
            panel(b, x0, 1.12f, z0, x1, 1.70f, z1, vx * .28f, vz * .28f, BLUE, tracking);
            b.cylinder(x0, 1.1f, z0, x1, 1.72f, z1, .025f, .025f, 5, IVORY, tracking);
            for (int j = 1; j <= 4; j++) {
                float t = j / 5f, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
                float y = 1.12f + .58f * t + .027f;
                b.cylinder(x - vx * .26f, y, z - vz * .26f, x + vx * .26f, y, z + vz * .26f,
                        .009f, .009f, 4, CYAN, tracking);
            }
            b.cylinder(ux * .2f, .43f, uz * .2f, ux * .68f, 1.48f, uz * .68f,
                    .04f, .03f, 6, COPPER, tracking);
        }
    }

    private static void geneLab(MeshBuilder3D b) {
        foundation(b, .79f);
        int pulse = b.bone("nutrient_vessel", 0, 0, 1.05f, 0, Bone3D.PULSE, .3f, .025f);
        b.ellipsoid(0, 1.04f, 0, .48f, .75f, .48f, 14, 9, GREEN, pulse);
        b.cylinder(0, .30f, 0, 0, .47f, 0, .56f, .52f, 12, IVORY, 0);
        b.cylinder(0, 1.68f, 0, 0, 1.84f, 0, .46f, .29f, 12, IVORY, 0);
        b.ellipsoid(0, 1.92f, 0, .21f, .25f, .21f, 10, 6, AMBER, pulse);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2 + PI / 4;
            float x = cos(a), z = sin(a);
            b.cylinder(x * .56f, .37f, z * .56f, x * .44f, 1.62f, z * .44f, .055f, .045f, 7, IVORY, 0);
            b.cylinder(x * .62f, .35f, z * .62f, x * .60f, 1.18f, z * .60f, .035f, .035f, 6, COPPER, 0);
        }
        // An embossed double helix sits in front of the opaque nutrient surface.
        for (int i = 0; i < 12; i++) {
            float a = i * .62f, aa = (i + 1) * .62f;
            float y = .58f + i * .077f, yy = y + .077f;
            for (int strand = 0; strand < 2; strand++) {
                float phase = strand * PI;
                b.cylinder(sin(a + phase) * .20f, y, .46f, sin(aa + phase) * .20f, yy, .46f,
                        .018f, .018f, 5, strand == 0 ? CYAN : AMBER, pulse);
            }
            if ((i & 1) == 0) b.cylinder(-.16f, y, .463f, .16f, y, .463f, .009f, .009f, 4, IVORY, pulse);
        }
        sideVial(b, -.65f, .8f, .17f, .12f, AMBER);
        sideVial(b, .65f, .8f, .17f, .12f, LIME);
    }

    private static void recycler(MeshBuilder3D b) {
        foundation(b, .80f);
        int pulse = b.bone("digestor", 0, -.22f, .98f, -.12f, Bone3D.PULSE, 1.2f, .02f);
        b.ellipsoid(-.22f, .95f, -.12f, .43f, .65f, .43f, 12, 8, GREEN, pulse);
        ringY(b, -.22f, .49f, -.12f, .44f, .04f, 12, IVORY, 0);
        ringY(b, -.22f, 1.39f, -.12f, .37f, .05f, 12, IVORY, 0);
        b.ellipsoid(-.22f, 1.58f, -.12f, .24f, .14f, .24f, 10, 5, IVORY, 0);
        for (int i = 0; i < 3; i++) sideVial(b, .47f, .64f, -.4f + i * .35f, .15f, LIME);
        b.cylinder(-.25f, .39f, .28f, -.25f, .70f, .44f, .12f, .12f, 8, METAL, 0);
        panel(b, -.25f, .40f, .85f, -.25f, .66f, .27f, .30f, 0, DARK, 0);
        for (int i = 0; i < 5; i++) {
            float z = .35f + i * .12f, y = .64f - i * .05f;
            b.cylinder(-.53f, y, z, .03f, y, z, .027f, .027f, 6, COPPER, 0);
        }
        b.cylinder(.35f, .44f, -.48f, .35f, 1.62f, -.48f, .065f, .065f, 8, METAL, 0);
        b.cylinder(.35f, 1.62f, -.48f, -.17f, 1.62f, -.48f, .065f, .065f, 8, COPPER, 0);
        frontGauge(b, .44f, .92f, .3f, 0);
    }

    private static void turret(MeshBuilder3D b) {
        foundation(b, .70f);
        b.cylinder(0, .3f, 0, 0, 1.09f, 0, .30f, .22f, 12, IVORY, 0);
        int head = b.bone("turret_tracking", 0, 0, 1.12f, 0, Bone3D.TAIL_Y, .2f, .35f);
        int recoil = b.bone("weapon_pitch", head, 0, 1.28f, .04f, Bone3D.WORK_ARM_X, 0, .08f);
        b.ellipsoid(0, 1.26f, .07f, .43f, .25f, .37f, 12, 7, IVORY, head);
        b.ellipsoid(0, 1.20f, -.27f, .29f, .15f, .18f, 10, 5, DARK, head);
        for (int side = -1; side <= 1; side += 2) {
            float x = side * .17f;
            b.cylinder(x, 1.27f, .15f, x, 1.27f, .95f, .105f, .075f, 10, DARK, recoil);
            b.cylinder(x, 1.27f, .83f, x, 1.27f, 1.0f, .13f, .12f, 10, IVORY, recoil);
            ringZ(b, x, 1.27f, .95f, .12f, .021f, 10, CYAN, recoil);
            b.cylinder(x, 1.27f, .988f, x, 1.27f, 1.01f, .052f, .052f, 8, CYAN, recoil);
        }
        b.ellipsoid(-.29f, 1.42f, .25f, .075f, .075f, .07f, 8, 5, CYAN, head);
        b.cylinder(.30f, 1.37f, -.12f, .30f, 1.80f, -.12f, .023f, .015f, 6, DARK, head);
        b.ellipsoid(.30f, 1.81f, -.12f, .04f, .04f, .04f, 6, 3, AMBER, head);
    }

    private static void pulper(MeshBuilder3D b) {
        foundation(b, .80f);
        b.box(0, .62f, -.15f, 1.04f, .70f, .72f, IVORY, 0);
        b.box(0, .69f, .23f, .76f, .45f, .10f, DARK, 0);
        int wheel = b.bone("sawwheel", 0, 0, .91f, .30f, Bone3D.ROTOR_Z, 0, 2.8f);
        b.cylinder(0, .91f, .29f, 0, .91f, .38f, .43f, .43f, 16, METAL, wheel);
        b.cylinder(0, .91f, .38f, 0, .91f, .41f, .12f, .12f, 10, COPPER, wheel);
        for (int i = 0; i < 18; i++) {
            float a = i * PI * 2 / 18;
            b.ellipsoid(cos(a) * .45f, .91f + sin(a) * .45f, .36f,
                    .052f, .073f, .055f, 5, 3, WHITE, wheel);
        }
        for (int i = 0; i < 4; i++) {
            float y = .34f + (i % 2) * .18f, z = .52f + (i / 2) * .19f;
            b.cylinder(-.72f, y, z, .21f, y, z, .095f, .085f, 8, WOOD, 0);
            b.cylinder(.20f, y, z, .23f, y, z, .07f, .07f, 8, COPPER, 0);
        }
        b.cylinder(-.39f, .95f, -.30f, -.39f, 1.85f, -.30f, .075f, .07f, 8, DARK, 0);
        for (int i = 0; i < 3; i++) ringY(b, -.39f, 1.34f + .16f * i, -.30f, .079f, .025f, 8, COPPER, 0);
        frontGauge(b, .43f, .78f, .27f, 0);
    }

    private static void landingPad(MeshBuilder3D b) {
        b.cylinder(0, .05f, 0, 0, .18f, 0, .97f, .97f, 12, DARK, 0);
        b.cylinder(0, .18f, 0, 0, .23f, 0, .83f, .83f, 12, METAL, 0);
        ringY(b, 0, .245f, 0, .76f, .025f, 18, AMBER, 0);
        int pulse = b.bone("landing_beacon", 0, 0, .3f, 0, Bone3D.PULSE, 1, .04f);
        for (int i = 0; i < 8; i++) {
            float a = i * PI / 4;
            b.ellipsoid(cos(a) * .87f, .24f, sin(a) * .87f, .045f, .045f, .045f, 6, 4, CYAN, pulse);
        }
        b.cylinder(0, .36f, 0, 0, 1.50f, 0, .18f, .18f, 12, IVORY, 0);
        b.cylinder(0, 1.5f, 0, 0, 2.11f, 0, .18f, .018f, 12, WHITE, 0);
        b.cylinder(0, .28f, 0, 0, .53f, 0, .17f, .11f, 10, DARK, 0);
        b.ellipsoid(0, .30f, 0, .105f, .08f, .105f, 8, 4, CYAN, pulse);
        ringY(b, 0, .65f, 0, .185f, .022f, 12, COPPER, 0);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2, x = cos(a), z = sin(a);
            b.cylinder(x * .09f, .56f, z * .09f, x * .40f, .25f, z * .40f, .055f, .07f, 6, IVORY, 0);
            blade(b, x * .16f, .52f, z * .16f, x * .42f, .26f, z * .42f, .12f, DARK, 0);
        }
        frontGauge(b, 0, 1.2f, .182f, 0);
    }

    private static void detector(MeshBuilder3D b) {
        foundation(b, .73f);
        b.cylinder(0, .3f, 0, 0, 1.38f, 0, .28f, .14f, 12, IVORY, 0);
        int dish = b.bone("observatory_scan", 0, 0, 1.38f, 0, Bone3D.ROTOR_Y, 0, .18f);
        dish(b, 0, 1.43f, 0, .65f, .39f, IVORY, dish);
        ringY(b, 0, 1.82f, 0, .65f, .035f, 16, COPPER, dish);
        b.cylinder(-.49f, 1.71f, -.13f, .04f, 2.13f, .04f, .035f, .025f, 7, DARK, dish);
        b.ellipsoid(.04f, 2.14f, .04f, .10f, .08f, .10f, 10, 5, CYAN, dish);
        b.cylinder(.53f, .3f, -.33f, .53f, 1.67f, -.33f, .10f, .07f, 8, METAL, 0);
        b.cylinder(.53f, 1.67f, -.33f, .53f, 2.28f, -.33f, .025f, .013f, 6, COPPER, 0);
        b.ellipsoid(.53f, 2.29f, -.33f, .05f, .055f, .05f, 6, 4, AMBER, 0);
        frontGauge(b, 0, .8f, .24f, 0);
    }

    private static void wind(MeshBuilder3D b) {
        foundation(b, .60f);
        b.cylinder(0, .3f, 0, 0, 1.66f, 0, .13f, .095f, 10, IVORY, 0);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3;
            b.cylinder(cos(a) * .45f, .24f, sin(a) * .45f, 0, 1.28f, 0,
                    .055f, .035f, 6, COPPER, 0);
        }
        int rotor = b.bone("wind_rotor", 0, 0, 1.65f, .18f, Bone3D.ROTOR_Z, 0, 1.6f);
        b.cylinder(0, 1.65f, .05f, 0, 1.65f, .32f, .13f, .13f, 10, METAL, rotor);
        b.ellipsoid(0, 1.65f, .34f, .14f, .14f, .12f, 10, 6, CYAN, rotor);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3;
            float ux = cos(a), uy = sin(a), vx = -uy, vy = ux;
            // A thick closed aerodynamic blade in the XY rotor plane.
            float[] p = {ux*.12f + vx*.10f,1.65f+uy*.12f+vy*.10f,.22f,
                         ux*.76f + vx*.055f,1.65f+uy*.76f+vy*.055f,.27f,
                         ux*.76f - vx*.055f,1.65f+uy*.76f-vy*.055f,.27f,
                         ux*.12f - vx*.10f,1.65f+uy*.12f-vy*.10f,.22f};
            prismZ(b, p, .055f, IVORY, rotor);
            b.cylinder(ux*.17f,1.65f+uy*.17f,.283f, ux*.70f,1.65f+uy*.70f,.316f,
                    .012f,.008f,5,CYAN,rotor);
        }
    }

    private static void fusion(MeshBuilder3D b) {
        foundation(b, .82f);
        int pulse = b.bone("fusion_plasma", 0, 0, 1.02f, 0, Bone3D.PULSE, 0, .08f);
        int ring = b.bone("containment_ring", 0, 0, 1.04f, 0, Bone3D.ROTOR_Y, 0, .55f);
        b.ellipsoid(0, 1.02f, 0, .46f, .55f, .46f, 16, 10, CYAN, pulse);
        ringY(b, 0, .68f, 0, .53f, .075f, 16, COPPER, 0);
        ringY(b, 0, 1.37f, 0, .53f, .075f, 16, COPPER, 0);
        ringY(b, 0, 1.03f, 0, .65f, .045f, 18, METAL, ring);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2 + PI / 4, x = cos(a), z = sin(a);
            b.cylinder(x*.67f,.31f,z*.67f,x*.62f,1.34f,z*.62f,.11f,.08f,8,IVORY,0);
            b.cylinder(x*.62f,1.34f,z*.62f,x*.33f,1.66f,z*.33f,.08f,.07f,8,IVORY,0);
            b.ellipsoid(x*.66f,1.03f,z*.66f,.09f,.13f,.09f,8,5,AMBER,ring);
        }
        b.cylinder(0,1.56f,0,0,1.74f,0,.28f,.20f,12,DARK,0);
        b.cylinder(0,1.74f,0,0,2.03f,0,.09f,.07f,10,IVORY,0);
        ringY(b,0,1.88f,0,.11f,.024f,10,CYAN,0);
    }

    private static void technicalCenter(MeshBuilder3D b) {
        foundation(b, .86f);
        taperedTower(b, .52f, .43f, .33f, .32f, .29f, 1.76f, IVORY, 0);
        b.cylinder(0,1.76f,0,0,1.90f,0,.38f,.32f,12,DARK,0);
        for(int row=0;row<3;row++) {
            float y=.66f+row*.31f, z=.43f-(y-.29f)/1.47f*.11f+.012f;
            for(int col=-1;col<=1;col++) {
                float x=col*.22f;
                b.quad(x-.075f,y-.06f,z,x+.075f,y-.06f,z,
                        x+.075f,y+.06f,z-.01f,x-.075f,y+.06f,z-.01f,BLUE,0);
            }
        }
        for(int side=-1;side<=1;side+=2) {
            b.ellipsoid(side*.62f,.60f,-.13f,.22f,.35f,.30f,10,6,METAL,0);
            b.cylinder(side*.63f,.45f,.15f,side*.63f,1.16f,.15f,.035f,.03f,6,COPPER,0);
        }
        b.cylinder(-.16f,1.84f,0,-.16f,2.36f,0,.025f,.012f,6,DARK,0);
        b.ellipsoid(-.16f,2.37f,0,.05f,.045f,.05f,6,4,CYAN,0);
        b.cylinder(.18f,1.84f,0,.18f,2.15f,0,.03f,.02f,6,COPPER,0);
        int pulse=b.bone("operations_beacon",0,.18f,2.15f,0,Bone3D.PULSE,2,.05f);
        b.ellipsoid(.18f,2.18f,0,.075f,.07f,.075f,8,4,AMBER,pulse);
    }

    private static void shield(MeshBuilder3D b) {
        foundation(b, .79f);
        int pulse=b.bone("shield_focus",0,0,1.45f,0,Bone3D.PULSE,0,.065f);
        b.ellipsoid(0,1.45f,0,.25f,.35f,.25f,12,8,CYAN,pulse);
        b.cylinder(0,.29f,0,0,.75f,0,.26f,.17f,10,DARK,0);
        ringY(b,0,.65f,0,.29f,.055f,12,COPPER,0);
        for(int i=0;i<4;i++) {
            float a=i*PI/2,ux=cos(a),uz=sin(a);
            float px=ux*.63f,py=.31f,pz=uz*.63f;
            for(int j=1;j<=5;j++) {
                float t=j/5f, r=.63f*(1-t*.72f),y=.31f+1.75f*t;
                float x=ux*r,z=uz*r;
                b.cylinder(px,py,pz,x,y,z,.085f,.065f,7,IVORY,0);
                if(j==3) b.ellipsoid(x,y,z,.085f,.10f,.085f,7,4,CYAN,pulse);
                px=x;py=y;pz=z;
            }
        }
        ringY(b,0,2.07f,0,.19f,.045f,12,COPPER,0);
        b.ellipsoid(0,2.12f,0,.15f,.13f,.15f,10,6,CYAN,pulse);
    }

    private static void vat(MeshBuilder3D b) {
        foundation(b,.80f);
        int pulse=b.bone("storage_biogel",0,0,.99f,0,Bone3D.PULSE,1,.018f);
        b.cylinder(0,.34f,0,0,1.44f,0,.58f,.58f,16,GREEN,pulse);
        b.cylinder(0,.31f,0,0,.43f,0,.65f,.63f,16,IVORY,0);
        b.cylinder(0,1.38f,0,0,1.52f,0,.63f,.60f,16,IVORY,0);
        b.ellipsoid(0,1.53f,0,.59f,.23f,.59f,14,7,IVORY,0);
        for(int i=0;i<6;i++) {
            float a=i*PI/3,x=cos(a)*.60f,z=sin(a)*.60f;
            b.cylinder(x,.40f,z,x,1.43f,z,.035f,.035f,6,COPPER,0);
        }
        for(int i=0;i<4;i++) {
            float y=.55f+i*.20f;
            b.ellipsoid(.14f*sin(i*1.6f),y,.575f,.075f,.055f,.025f,8,4,LIME,pulse);
        }
        b.cylinder(0,1.70f,0,0,1.90f,0,.065f,.065f,8,METAL,0);
        int valve=b.bone("pressure_valve",0,0,1.91f,0,Bone3D.ROTOR_Y,0,.27f);
        ringY(b,0,1.91f,0,.19f,.027f,12,COPPER,valve);
        for(int i=0;i<3;i++) {
            float a=i*PI*2/3;
            b.cylinder(0,1.91f,0,cos(a)*.18f,1.91f,sin(a)*.18f,.02f,.02f,5,IVORY,valve);
        }
        b.cylinder(.57f,.57f,-.12f,.81f,.57f,-.12f,.07f,.07f,8,DARK,0);
        b.cylinder(.81f,.57f,-.12f,.81f,1.20f,-.12f,.07f,.07f,8,COPPER,0);
        b.cylinder(.81f,1.20f,-.12f,.57f,1.20f,-.12f,.07f,.07f,8,DARK,0);
        b.ellipsoid(.81f,.57f,-.12f,.078f,.078f,.078f,8,5,METAL,0);
        b.ellipsoid(.81f,1.20f,-.12f,.078f,.078f,.078f,8,5,METAL,0);
    }

    private static void sideVial(MeshBuilder3D b,float x,float y,float z,float r,float[] colour) {
        b.cylinder(x,y-.34f,z,x,y+.25f,z,r,r,9,colour,0);
        b.cylinder(x,y-.39f,z,x,y-.30f,z,r*1.16f,r*1.16f,9,METAL,0);
        b.cylinder(x,y+.24f,z,x,y+.32f,z,r*1.16f,r*.8f,9,IVORY,0);
        b.ellipsoid(x,y+.34f,z,r*.52f,.05f,r*.52f,8,4,CYAN,0);
    }

    private static void frontGauge(MeshBuilder3D b,float x,float y,float z,int bone) {
        b.box(x,y,z,.20f,.16f,.045f,DARK,bone);
        b.box(x,y,z+.027f,.14f,.095f,.015f,BLUE,bone);
        b.box(x-.045f,y-.06f,z+.032f,.035f,.018f,.014f,AMBER,bone);
        b.box(x+.045f,y-.06f,z+.032f,.035f,.018f,.014f,CYAN,bone);
    }

    private static void ringY(MeshBuilder3D b,float cx,float cy,float cz,float r,float tube,int segments,float[] c,int bone) {
        for(int i=0;i<segments;i++) {
            float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
            b.cylinder(cx+cos(a)*r,cy,cz+sin(a)*r,cx+cos(aa)*r,cy,cz+sin(aa)*r,tube,tube,5,c,bone);
        }
    }

    private static void ringZ(MeshBuilder3D b,float cx,float cy,float cz,float r,float tube,int segments,float[] c,int bone) {
        for(int i=0;i<segments;i++) {
            float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
            b.cylinder(cx+cos(a)*r,cy+sin(a)*r,cz,cx+cos(aa)*r,cy+sin(aa)*r,cz,tube,tube,5,c,bone);
        }
    }

    /** A closed thin panel with eight independent 3D corners. */
    private static void panel(MeshBuilder3D b,float ax,float ay,float az,float bx,float by,float bz,
                              float wx,float wz,float[] colour,int bone) {
        float[] p={ax-wx,ay,az-wz,bx-wx,by,bz-wz,bx+wx,by,bz+wz,ax+wx,ay,az+wz};
        prismY(b,p,.035f,colour,bone);
    }

    private static void blade(MeshBuilder3D b,float ax,float ay,float az,float bx,float by,float bz,
                              float width,float[] colour,int bone) {
        float dx=bx-ax,dz=bz-az,length=(float)Math.sqrt(dx*dx+dz*dz);
        float wx=length>0?-dz/length*width:width,wz=length>0?dx/length*width:0;
        panel(b,ax,ay,az,bx,by,bz,wx,wz,colour,bone);
    }

    private static void prismY(MeshBuilder3D b,float[] p,float thickness,float[] colour,int bone) {
        float[] q=p.clone();for(int i=1;i<q.length;i+=3)q[i]-=thickness;
        closedPrism(b,p,q,colour,bone);
    }
    private static void prismZ(MeshBuilder3D b,float[] p,float thickness,float[] colour,int bone) {
        float[] q=p.clone();for(int i=2;i<q.length;i+=3)q[i]-=thickness;
        closedPrism(b,p,q,colour,bone);
    }
    private static void closedPrism(MeshBuilder3D b,float[] p,float[] q,float[] colour,int bone) {
        closedPrism(b,p,q,colour,COPPER,bone);
    }
    private static void closedPrism(MeshBuilder3D b,float[] p,float[] q,float[] colour,float[] sideColour,int bone) {
        float cx=0,cy=0,cz=0;
        for(int i=0;i<12;i+=3) {
            cx+=(p[i]+q[i])/8;cy+=(p[i+1]+q[i+1])/8;cz+=(p[i+2]+q[i+2])/8;
        }
        outwardFace(b,p,cx,cy,cz,colour,bone);outwardFace(b,q,cx,cy,cz,METAL,bone);
        for(int i=0;i<4;i++) {
            int j=(i+1)%4;
            float[] side={p[i*3],p[i*3+1],p[i*3+2],q[i*3],q[i*3+1],q[i*3+2],
                          q[j*3],q[j*3+1],q[j*3+2],p[j*3],p[j*3+1],p[j*3+2]};
            outwardFace(b,side,cx,cy,cz,sideColour,bone);
        }
    }
    /** Winding is outward for any convex four-sided prism orientation. */
    private static void outwardFace(MeshBuilder3D b,float[] p,float cx,float cy,float cz,float[] colour,int bone) {
        float ux=p[3]-p[0],uy=p[4]-p[1],uz=p[5]-p[2];
        float vx=p[6]-p[0],vy=p[7]-p[1],vz=p[8]-p[2];
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        float fx=(p[0]+p[3]+p[6]+p[9])/4-cx,fy=(p[1]+p[4]+p[7]+p[10])/4-cy;
        float fz=(p[2]+p[5]+p[8]+p[11])/4-cz;
        if(nx*fx+ny*fy+nz*fz>=0)face(b,p,0,1,2,3,colour,bone);
        else face(b,p,3,2,1,0,colour,bone);
    }
    private static void face(MeshBuilder3D b,float[] p,int a,int c,int d,int e,float[] colour,int bone) {
        b.quad(p[a*3],p[a*3+1],p[a*3+2],p[c*3],p[c*3+1],p[c*3+2],
                p[d*3],p[d*3+1],p[d*3+2],p[e*3],p[e*3+1],p[e*3+2],colour,bone);
    }

    private static void taperedTower(MeshBuilder3D b,float rx0,float rz0,float rx1,float rz1,float y0,float y1,float[] colour,int bone) {
        float[] low={-rx0,y0,-rz0,rx0,y0,-rz0,rx0,y0,rz0,-rx0,y0,rz0};
        float[] high={-rx1,y1,-rz1,rx1,y1,-rz1,rx1,y1,rz1,-rx1,y1,rz1};
        closedPrism(b,high,low,colour,colour,bone);
    }

    private static void dish(MeshBuilder3D b,float cx,float cy,float cz,float radius,float depth,float[] colour,int bone) {
        final int rings=4,segments=16;
        b.ellipsoid(cx,cy+.015f,cz,.10f,.035f,.10f,8,4,METAL,bone);
        for(int row=0;row<rings;row++) {
            float r0=.075f+(radius-.075f)*row/rings,r1=.075f+(radius-.075f)*(row+1)/rings;
            float y0=cy+depth*(r0/radius)*(r0/radius),y1=cy+depth*(r1/radius)*(r1/radius);
            for(int i=0;i<segments;i++) {
                float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
                float[] p={cx+cos(a)*r0,y0,cz+sin(a)*r0,cx+cos(a)*r1,y1,cz+sin(a)*r1,
                           cx+cos(aa)*r1,y1,cz+sin(aa)*r1,cx+cos(aa)*r0,y0,cz+sin(aa)*r0};
                face(b,p,3,2,1,0,colour,bone);
                // Back face is also physical, with a small normal-direction separation.
                float[] front=p.clone();
                for(int j=1;j<p.length;j+=3)p[j]-=.018f;
                face(b,p,0,1,2,3,METAL,bone);
                if(row==rings-1) b.quad(front[3],front[4],front[5],p[3],p[4],p[5],
                        p[6],p[7],p[8],front[6],front[7],front[8],COPPER,bone);
                if(row==0) b.quad(front[9],front[10],front[11],p[9],p[10],p[11],
                        p[0],p[1],p[2],front[0],front[1],front[2],METAL,bone);
            }
        }
    }

    private static float cos(float value) { return (float)Math.cos(value); }
    private static float sin(float value) { return (float)Math.sin(value); }
}
