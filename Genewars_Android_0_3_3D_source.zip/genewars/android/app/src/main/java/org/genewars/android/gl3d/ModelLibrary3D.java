package org.genewars.android.gl3d;

/** Shared immutable model assets, generated once and reused by all actors. */
public final class ModelLibrary3D {
    private static final MeshData3D[] CREATURES=new MeshData3D[25],SPECIALISTS=new MeshData3D[4],
            BUILDINGS=new MeshData3D[14],PLANTS=new MeshData3D[12];
    private ModelLibrary3D(){}
    public static synchronized MeshData3D getCreature(int species){
        range(species,25);if(CREATURES[species]==null)CREATURES[species]=CreatureModels3D.build(species);return CREATURES[species];
    }
    public static synchronized MeshData3D getSpecialist(int kind){
        range(kind,4);if(SPECIALISTS[kind]==null)SPECIALISTS[kind]=SpecialistModels3D.build(kind);return SPECIALISTS[kind];
    }
    public static synchronized MeshData3D getBuilding(int ordinal){
        range(ordinal,14);if(BUILDINGS[ordinal]==null)BUILDINGS[ordinal]=BuildingModels3D.build(ordinal);return BUILDINGS[ordinal];
    }
    public static synchronized MeshData3D getPlant(int species){
        range(species,12);if(PLANTS[species]==null)PLANTS[species]=PlantModels3D.build(species);return PLANTS[species];
    }
    private static void range(int value,int size){if(value<0||value>=size)throw new IllegalArgumentException("Unknown 3D model index");}
}
