package org.genewars.android.gl3d;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Genuine GLES3 mesh renderer. All GLES calls remain on the GLSurfaceView thread. */
public final class Scene3DRenderer implements GLSurfaceView.Renderer {
    private static final String TAG="GeneWars3D";
    private static final int STRIDE=13,MAX_BONES=24,SHADOW_SIZE=1024;
    private static final float[] LIGHT={-.436f,.873f,.218f};
    private final AssetManager assets;
    private final Camera3D camera;
    private final AtomicReference<Scene3DFrame> submitted=new AtomicReference<Scene3DFrame>();
    private volatile boolean closed,ready,highQuality=true;
    private final Map<String,GpuMesh> meshes=new HashMap<String,GpuMesh>();
    private final Map<Integer,Motion> motion=new HashMap<Integer,Motion>();
    private Scene3DFrame previousFrame;
    private Scene3DFrame.Terrain loadedTerrain;
    private GpuMesh ground,disk;
    private int mainProgram,depthProgram,flatProgram,materialTexture,shadowTexture,shadowFbo;
    private boolean shadowReady,loggedFirstFrame;
    private long frameNumber;
    private float completedYaw=Float.NaN;
    private float[] lightViewProjection=Matrix3D.identity();
    private final float[] model=new float[16],normal=new float[9],bones=new float[MAX_BONES*16];
    private Uniforms uniforms,depthUniforms;
    private int flatMvp,flatColor;

    public Scene3DRenderer(AssetManager assets,Camera3D camera){this.assets=assets;this.camera=camera;}
    public void submitFrame(Scene3DFrame frame){if(!closed)submitted.set(frame);}
    public void setHighQuality(boolean enabled){highQuality=enabled;}
    public boolean isReady(){return ready&&!closed;}
    /** No GL calls here: context-owned resources disappear when the View detaches. */
    public void close(){closed=true;ready=false;submitted.set(null);}

    @Override public void onSurfaceCreated(GL10 unused,EGLConfig config){
        if(closed)return;
        ready=false;
        meshes.clear();motion.clear();loadedTerrain=null;ground=null;disk=null;previousFrame=null;loggedFirstFrame=false;frameNumber=0;completedYaw=Float.NaN;
        int[] limit=new int[1];GLES30.glGetIntegerv(GLES30.GL_MAX_VERTEX_UNIFORM_VECTORS,limit,0);
        Log.i(TAG,"GL_VERSION="+GLES30.glGetString(GLES30.GL_VERSION)+"; max vertex uniform vectors="+limit[0]);
        if(limit[0]<128)throw new IllegalStateException("Insufficient vertex uniforms for 24-bone models");
        mainProgram=program(VERTEX_SHADER,FRAGMENT_SHADER);uniforms=new Uniforms(mainProgram,false);
        depthProgram=program(DEPTH_VERTEX,DEPTH_FRAGMENT);depthUniforms=new Uniforms(depthProgram,true);
        flatProgram=program(FLAT_VERTEX,FLAT_FRAGMENT);flatMvp=GLES30.glGetUniformLocation(flatProgram,"uMVP");flatColor=GLES30.glGetUniformLocation(flatProgram,"uColor");
        materialTexture=loadMaterialAtlas();createShadowMap();disk=createDisk();
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);GLES30.glDepthFunc(GLES30.GL_LEQUAL);
        GLES30.glEnable(GLES30.GL_CULL_FACE);GLES30.glCullFace(GLES30.GL_BACK);
        GLES30.glClearColor(.085f,.14f,.19f,1);
        Log.i(TAG,"GLES3 shader programs linked; initialization GL error count="+checkError("surface initialization"));
    }
    @Override public void onSurfaceChanged(GL10 unused,int width,int height){camera.setViewport(width,height);GLES30.glViewport(0,0,Math.max(1,width),Math.max(1,height));}

    @Override public void onDrawFrame(GL10 unused){
        if(closed)return;
        long drawStarted=System.nanoTime();
        Scene3DFrame frame=submitted.get();Camera3D.Snapshot view=camera.snapshot();
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);GLES30.glViewport(0,0,view.width,view.height);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
        if(frame==null)return;
        if(loadedTerrain!=frame.terrain){if(ground!=null)ground.delete();ground=buildTerrain(frame.terrain);loadedTerrain=frame.terrain;motion.clear();previousFrame=null;}
        updateMotion(frame);
        boolean detailed=highQuality&&frame.highQuality;
        lightViewProjection=Matrix3D.multiply(Matrix3D.ortho(-34,34,-34,34,1,125),
                Matrix3D.lookAt(view.targetX+LIGHT[0]*65,view.targetY+LIGHT[1]*65,view.targetZ+LIGHT[2]*65,
                        view.targetX,view.targetY,view.targetZ));
        if(detailed&&shadowReady)renderShadowMap(frame,view);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);GLES30.glViewport(0,0,view.width,view.height);
        GLES30.glUseProgram(mainProgram);
        GLES30.glUniformMatrix4fv(uniforms.vp,1,false,view.viewProjection,0);
        GLES30.glUniformMatrix4fv(uniforms.lightVp,1,false,lightViewProjection,0);
        GLES30.glUniform3f(uniforms.eye,view.eyeX,view.eyeY,view.eyeZ);
        GLES30.glUniform3f(uniforms.light,LIGHT[0],LIGHT[1],LIGHT[2]);
        GLES30.glUniform1f(uniforms.time,frame.seconds);
        GLES30.glUniform1i(uniforms.highQuality,detailed?1:0);GLES30.glUniform1i(uniforms.shadowEnabled,detailed&&shadowReady?1:0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,materialTexture);GLES30.glUniform1i(uniforms.materials,0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,shadowTexture);GLES30.glUniform1i(uniforms.shadowMap,1);
        Matrix3D.identity(model);normalIdentity();GLES30.glUniformMatrix4fv(uniforms.model,1,false,model,0);GLES30.glUniformMatrix3fv(uniforms.normal,1,false,normal,0);
        GLES30.glUniform1i(uniforms.skinned,0);GLES30.glUniform1i(uniforms.terrain,1);GLES30.glUniform3f(uniforms.tint,1,1,1);ground.draw();
        renderGroundMarkers(frame,view);
        GLES30.glUseProgram(mainProgram);GLES30.glUniform1i(uniforms.terrain,0);GLES30.glUniform1i(uniforms.skinned,1);
        int drawnActors=0;
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;
            MeshData3D data=modelFor(actor);GpuMesh mesh=gpuModel(actor,data);Motion moving=motion.get(actor.id);
            applyModel(actor,frame.terrain,data,moving);
            data.pose(frame.seconds,moving!=null&&moving.speed>.05f?1:actor.action,moving==null?0:moving.speed,bones);
            GLES30.glUniformMatrix4fv(uniforms.model,1,false,model,0);GLES30.glUniformMatrix3fv(uniforms.normal,1,false,normal,0);
            GLES30.glUniformMatrix4fv(uniforms.bones,MAX_BONES,false,bones,0);
            teamTint(uniforms.tint,actor.team);mesh.draw();drawnActors++;
        }
        // A bounded diagnostic fence makes the logged camera safe to capture in device tests.
        // Ordinary animation frames keep their asynchronous GPU pipeline.
        boolean reportCompletion=!loggedFirstFrame||Float.compare(completedYaw,view.yaw)!=0;
        if(reportCompletion)GLES30.glFinish();
        int errors=checkError("frame");
        if(errors==0&&drawnActors>0&&!closed)ready=true;
        if(!loggedFirstFrame){loggedFirstFrame=true;Log.i(TAG,"Rendered genuine 3D scene: terrain="+frame.terrain.width+"x"+frame.terrain.height+", mesh actors="+frame.actors.size()+", shadowMap="+(detailed&&shadowReady)+", GL_NO_ERROR="+(errors==0));}
        frameNumber++;
        if(reportCompletion){
            completedYaw=view.yaw;
            Log.i(TAG,"Frame complete: frame="+frameNumber+", yaw="+view.yaw+", pitch="+view.pitch+", meshActors="+frame.actors.size()+", renderMs="+((System.nanoTime()-drawStarted)/1000000L)+", GL_NO_ERROR="+(errors==0));
        }
    }

    private void renderShadowMap(Scene3DFrame frame,Camera3D.Snapshot view){
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,shadowFbo);GLES30.glViewport(0,0,SHADOW_SIZE,SHADOW_SIZE);
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);GLES30.glUseProgram(depthProgram);
        GLES30.glUniformMatrix4fv(depthUniforms.vp,1,false,lightViewProjection,0);
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL);GLES30.glPolygonOffset(1.5f,3);
        Matrix3D.identity(model);GLES30.glUniformMatrix4fv(depthUniforms.model,1,false,model,0);GLES30.glUniform1i(depthUniforms.skinned,0);ground.draw();
        GLES30.glUniform1i(depthUniforms.skinned,1);
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;
            MeshData3D data=modelFor(actor);Motion moving=motion.get(actor.id);applyModel(actor,frame.terrain,data,moving);
            data.pose(frame.seconds,moving!=null&&moving.speed>.05f?1:actor.action,moving==null?0:moving.speed,bones);
            GLES30.glUniformMatrix4fv(depthUniforms.model,1,false,model,0);GLES30.glUniformMatrix4fv(depthUniforms.bones,MAX_BONES,false,bones,0);gpuModel(actor,data).draw();
        }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL);
    }

    private void renderGroundMarkers(Scene3DFrame frame,Camera3D.Snapshot view){
        GLES30.glUseProgram(flatProgram);GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glDepthMask(false);GLES30.glDisable(GLES30.GL_CULL_FACE);
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;MeshData3D data=modelFor(actor);
            float radius=Math.max(.22f,Math.min(1.4f,data.radius*.72f)),y=frame.terrain.height(actor.x,actor.z)+.012f;
            Matrix3D.model(model,actor.x,y,actor.z,0,radius,1,radius*.65f);
            GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);
            GLES30.glUniform4f(flatColor,.025f,.045f,.05f,actor.type==3?.14f:.25f);disk.draw();
            if(actor.id==frame.selectedId){
                Matrix3D.model(model,actor.x,y+.006f,actor.z,0,radius*1.18f,1,radius*.87f);
                GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);GLES30.glUniform4f(flatColor,.15f,.95f,.78f,.32f);disk.draw();
            }
        }
        if(frame.zoneRadius>0){
            Matrix3D.model(model,frame.zoneX,frame.terrain.height(frame.zoneX,frame.zoneZ)+.018f,frame.zoneZ,0,frame.zoneRadius,1,frame.zoneRadius);
            GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);GLES30.glUniform4f(flatColor,.95f,.82f,.25f,.12f);disk.draw();
        }
        GLES30.glEnable(GLES30.GL_CULL_FACE);GLES30.glDepthMask(true);GLES30.glDisable(GLES30.GL_BLEND);
    }

    private void applyModel(Scene3DFrame.Actor actor,Scene3DFrame.Terrain terrain,MeshData3D data,Motion moving){
        float yaw=actor.type>=2?0:moving==null?0:moving.yaw;
        float scale=actor.type==1?1:actor.type==2?1+(actor.stage*.08f):1;
        float vertical=actor.type==2?Math.max(.08f,actor.progress):1;
        Matrix3D.model(model,actor.x,terrain.height(actor.x,actor.z),actor.z,yaw,scale,scale*vertical,scale);
        float c=(float)Math.cos(yaw),s=(float)Math.sin(yaw);
        normal[0]=c/scale;normal[1]=0;normal[2]=-s/scale;normal[3]=0;normal[4]=1/(scale*vertical);normal[5]=0;normal[6]=s/scale;normal[7]=0;normal[8]=c/scale;
    }
    private void normalIdentity(){for(int i=0;i<9;i++)normal[i]=0;normal[0]=normal[4]=normal[8]=1;}
    private static void teamTint(int uniform,int team){
        if(team==0)GLES30.glUniform3f(uniform,.64f,1,.91f);
        else if(team==1)GLES30.glUniform3f(uniform,1,.65f,.60f);
        else GLES30.glUniform3f(uniform,1,1,1);
    }
    private boolean visible(Scene3DFrame.Actor actor,Camera3D.Snapshot view){
        float dx=actor.x-view.targetX,dz=actor.z-view.targetZ;float limit=Math.min(86,view.distance*2.6f+8);return dx*dx+dz*dz<limit*limit;
    }
    private void updateMotion(Scene3DFrame frame){
        if(frame==previousFrame)return;
        float dt=previousFrame==null?0:frame.seconds-previousFrame.seconds;
        for(Scene3DFrame.Actor actor:frame.actors){
            Motion m=motion.get(actor.id);if(m==null){m=new Motion();m.x=actor.x;m.z=actor.z;motion.put(actor.id,m);}
            else if(dt>0&&dt<2){float dx=actor.x-m.x,dz=actor.z-m.z;float distance=(float)Math.sqrt(dx*dx+dz*dz);m.speed=distance/dt;if(distance>.0001f)m.yaw=(float)Math.atan2(dx,dz);}
            else if(dt>0)m.speed=0;
            m.x=actor.x;m.z=actor.z;m.seen=frameNumber;
        }
        Iterator<Motion> iterator=motion.values().iterator();while(iterator.hasNext())if(iterator.next().seen!=frameNumber)iterator.remove();previousFrame=frame;
    }
    private static MeshData3D modelFor(Scene3DFrame.Actor actor){
        if(actor.type==0)return ModelLibrary3D.getCreature(actor.kind);
        if(actor.type==1)return ModelLibrary3D.getSpecialist(actor.kind);
        if(actor.type==2)return ModelLibrary3D.getBuilding(actor.kind);
        return ModelLibrary3D.getPlant(actor.kind);
    }
    private GpuMesh gpuModel(Scene3DFrame.Actor actor,MeshData3D data){
        String key=actor.type+":"+actor.kind;GpuMesh mesh=meshes.get(key);if(mesh==null){mesh=new GpuMesh(data.vertices,data.indices);meshes.put(key,mesh);}return mesh;
    }
    private GpuMesh buildTerrain(Scene3DFrame.Terrain map){
        long started=System.nanoTime();TerrainMesh3D mesh=TerrainMesh3D.build(map);
        Log.i(TAG,"Terrain mesh: "+(mesh.vertices.length/STRIDE)+" genuine vertices, "+(mesh.indices.length/3)+" triangles; prepareMs="+((System.nanoTime()-started)/1000000L));
        return new GpuMesh(mesh.vertices,mesh.indices);
    }
    private GpuMesh createDisk(){
        int segments=32;float[] v=new float[(segments+2)*STRIDE];int[] index=new int[segments*3];
        v[4]=1;v[6]=v[7]=v[8]=1;v[9]=1;
        for(int i=0;i<=segments;i++){double a=i*Math.PI*2/segments;int at=(i+1)*STRIDE;v[at]=(float)Math.cos(a);v[at+2]=(float)Math.sin(a);v[at+4]=1;v[at+6]=v[at+7]=v[at+8]=1;v[at+9]=0;if(i<segments){index[i*3]=0;index[i*3+1]=i+2;index[i*3+2]=i+1;}}
        return new GpuMesh(v,index);
    }

    private int loadMaterialAtlas(){
        String[] names={"water","shore","sand","grass","rock","alien","snow","moss","biotech"};
        int[] colors={0xFF1C566B,0xFF519FA6,0xFFB8A775,0xFF578A53,0xFF808A87,0xFF65728B,0xFFD2DEDD,0xFF4A7E5A,0xFF6A9A95};
        int cell=256;Bitmap atlas=Bitmap.createBitmap(cell*3,cell*3,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(atlas);Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
        JSONObject entries=null;try{entries=new JSONObject(readText("native/hd/manifest.json")).optJSONObject("textures");}catch(Exception e){Log.w(TAG,"HD material metadata missing; using base palette");}
        int decoded=0;
        for(int i=0;i<names.length;i++){
            int x=(i%3)*cell,y=(i/3)*cell;paint.setColor(colors[i]);canvas.drawRect(x,y,x+cell,y+cell,paint);
            JSONObject entry=entries==null?null:entries.optJSONObject(names[i]);
            if(entry!=null)try{
                String path=entry.getString("file");if(!path.startsWith("native/")||path.contains(".."))throw new IOException("Unsafe material path");
                BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;Bitmap bitmap;
                try(InputStream input=assets.open(path)){bitmap=BitmapFactory.decodeStream(input,null,options);}
                if(bitmap==null||bitmap.getWidth()>4096||bitmap.getHeight()>4096)throw new IOException("Invalid texture bitmap");
                canvas.drawBitmap(bitmap,null,new android.graphics.Rect(x,y,x+cell,y+cell),paint);bitmap.recycle();decoded++;
            }catch(Exception e){Log.w(TAG,"Material fallback: "+names[i],e);}
        }
        int[] id=new int[1];GLES30.glGenTextures(1,id,0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,id[0]);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR_MIPMAP_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,atlas,0);GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);atlas.recycle();
        Log.i(TAG,"Uploaded "+decoded+" HD materials to real GLES texture atlas");return id[0];
    }
    private String readText(String path)throws IOException{
        try(InputStream in=assets.open(path);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException("Manifest too big");out.write(buffer,0,n);}return out.toString("UTF-8");}
    }
    private void createShadowMap(){
        int[] id=new int[1];GLES30.glGenTextures(1,id,0);shadowTexture=id[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,shadowTexture);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D,0,GLES30.GL_DEPTH_COMPONENT24,SHADOW_SIZE,SHADOW_SIZE,0,GLES30.GL_DEPTH_COMPONENT,GLES30.GL_UNSIGNED_INT,null);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_NEAREST);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glGenFramebuffers(1,id,0);shadowFbo=id[0];GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,shadowFbo);GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER,GLES30.GL_DEPTH_ATTACHMENT,GLES30.GL_TEXTURE_2D,shadowTexture,0);
        GLES30.glDrawBuffers(1,new int[]{GLES30.GL_NONE},0);GLES30.glReadBuffer(GLES30.GL_NONE);
        shadowReady=GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)==GLES30.GL_FRAMEBUFFER_COMPLETE;
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);Log.i(TAG,"Shadow framebuffer complete="+shadowReady);
    }
    private static int program(String vertex,String fragment){
        int vs=shader(GLES30.GL_VERTEX_SHADER,vertex),fs=shader(GLES30.GL_FRAGMENT_SHADER,fragment),program=GLES30.glCreateProgram();
        GLES30.glAttachShader(program,vs);GLES30.glAttachShader(program,fs);GLES30.glLinkProgram(program);int[] status=new int[1];GLES30.glGetProgramiv(program,GLES30.GL_LINK_STATUS,status,0);
        String log=GLES30.glGetProgramInfoLog(program);if(!log.isEmpty())Log.i(TAG,"Program log: "+log);
        GLES30.glDeleteShader(vs);GLES30.glDeleteShader(fs);if(status[0]!=GLES30.GL_TRUE)throw new IllegalStateException("GLES link failed: "+log);return program;
    }
    private static int shader(int type,String source){
        int shader=GLES30.glCreateShader(type);GLES30.glShaderSource(shader,source);GLES30.glCompileShader(shader);int[] status=new int[1];GLES30.glGetShaderiv(shader,GLES30.GL_COMPILE_STATUS,status,0);
        String log=GLES30.glGetShaderInfoLog(shader);if(!log.isEmpty())Log.i(TAG,"Shader log: "+log);if(status[0]!=GLES30.GL_TRUE)throw new IllegalStateException("GLES shader failed: "+log);return shader;
    }
    private static int checkError(String operation){int error,count=0;while((error=GLES30.glGetError())!=GLES30.GL_NO_ERROR){count++;Log.e(TAG,"GL_ERROR "+operation+": 0x"+Integer.toHexString(error));}return count;}
    private static final class Motion {float x,z,yaw,speed;long seen;}
    private static final class GpuMesh {
        final int vao,vbo,ibo,count;
        GpuMesh(float[] vertices,int[] indices){
            if(vertices.length%STRIDE!=0||indices.length%3!=0)throw new IllegalArgumentException("Invalid mesh stride");int verticesCount=vertices.length/STRIDE;
            for(int index:indices)if(index<0||index>=verticesCount)throw new IllegalArgumentException("Mesh index out of range");
            count=indices.length;int[] id=new int[1],buffers=new int[2];GLES30.glGenVertexArrays(1,id,0);vao=id[0];GLES30.glBindVertexArray(vao);GLES30.glGenBuffers(2,buffers,0);vbo=buffers[0];ibo=buffers[1];
            FloatBuffer data=ByteBuffer.allocateDirect(vertices.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();data.put(vertices).position(0);
            IntBuffer elements=ByteBuffer.allocateDirect(indices.length*4).order(ByteOrder.nativeOrder()).asIntBuffer();elements.put(indices).position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,vbo);GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER,vertices.length*4,data,GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,ibo);GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER,indices.length*4,elements,GLES30.GL_STATIC_DRAW);
            int[] sizes={3,3,4,2,1},offsets={0,12,24,40,48};for(int i=0;i<5;i++){GLES30.glEnableVertexAttribArray(i);GLES30.glVertexAttribPointer(i,sizes[i],GLES30.GL_FLOAT,false,STRIDE*4,offsets[i]);}GLES30.glBindVertexArray(0);
        }
        void draw(){GLES30.glBindVertexArray(vao);GLES30.glDrawElements(GLES30.GL_TRIANGLES,count,GLES30.GL_UNSIGNED_INT,0);GLES30.glBindVertexArray(0);}
        void delete(){GLES30.glDeleteVertexArrays(1,new int[]{vao},0);GLES30.glDeleteBuffers(2,new int[]{vbo,ibo},0);}
    }
    private static final class Uniforms {
        final int vp,model,bones,skinned,normal,lightVp,eye,light,time,highQuality,shadowEnabled,materials,shadowMap,tint,terrain;
        Uniforms(int program,boolean depth){
            vp=loc(program,"uVP");model=loc(program,"uModel");bones=loc(program,"uBones[0]");skinned=loc(program,"uSkinned");normal=loc(program,"uNormal");lightVp=loc(program,"uLightVP");eye=loc(program,"uEye");light=loc(program,"uLight");time=loc(program,"uTime");highQuality=loc(program,"uHighQuality");shadowEnabled=loc(program,"uShadowEnabled");materials=loc(program,"uMaterials");shadowMap=loc(program,"uShadowMap");tint=loc(program,"uTint");terrain=loc(program,"uTerrain");
        }
        private static int loc(int p,String n){return GLES30.glGetUniformLocation(p,n);}
    }

    private static final String VERTEX_SHADER="#version 300 es\nprecision highp float;\n"
        +"layout(location=0) in vec3 aPosition;layout(location=1) in vec3 aNormal;layout(location=2) in vec4 aColor;layout(location=3) in vec2 aUV;layout(location=4) in float aBone;"
        +"uniform mat4 uVP,uModel,uLightVP,uBones[24];uniform mat3 uNormal;uniform bool uSkinned,uTerrain;uniform float uTime;uniform bool uHighQuality;"
        +"out vec3 vWorld,vNormal;out vec4 vColor,vShadow;out vec2 vUV;flat out int vMaterial;"
        +"void main(){mat4 skin=uSkinned?uBones[clamp(int(aBone+.5),0,23)]:mat4(1.0);vec4 p=skin*vec4(aPosition,1.0);"
        +"vMaterial=uTerrain?clamp(int(aBone+.5),0,8):-1;if(uTerrain&&vMaterial<2&&uHighQuality)p.y+=sin(p.x*2.2+p.z*1.5+uTime*1.7)*.012;"
        +"vec4 world=uModel*p;vWorld=world.xyz;vNormal=normalize(uNormal*mat3(skin)*aNormal);vColor=aColor;vUV=aUV;vShadow=uLightVP*world;gl_Position=uVP*world;}";
    private static final String FRAGMENT_SHADER="#version 300 es\nprecision highp float;\n"
        +"in vec3 vWorld,vNormal;in vec4 vColor,vShadow;in vec2 vUV;flat in int vMaterial;uniform sampler2D uMaterials,uShadowMap;uniform vec3 uEye,uLight,uTint;uniform float uTime;uniform bool uTerrain,uHighQuality,uShadowEnabled;out vec4 fragColor;"
        +"float visibility(vec3 n){if(!uShadowEnabled)return 1.0;vec3 q=vShadow.xyz/vShadow.w*.5+.5;if(q.x<0.0||q.x>1.0||q.y<0.0||q.y>1.0||q.z>1.0)return 1.0;float bias=max(.0007*(1.0-dot(n,uLight)),.00025);float sum=0.0;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){float d=texture(uShadowMap,q.xy+vec2(float(x),float(y))/1024.0).r;sum+=q.z-bias<=d?1.0:.22;}return sum/9.0;}"
        +"void main(){vec3 n=normalize(vNormal);vec3 base=pow(max(vColor.rgb,vec3(.001)),vec3(2.2));float metal=.05;"
        +"if(uTerrain){vec2 uv=abs(fract(vUV*.5)*2.0-1.0);vec2 tile=vec2(float(vMaterial%3),float(vMaterial/3));base=pow(texture(uMaterials,(tile+vec2(.012)+uv*.976)/3.0).rgb,vec3(2.2));"
        +"if(vMaterial<2){metal=.8;if(uHighQuality)n=normalize(n+vec3(sin(vWorld.x*4.0+uTime*1.2)*.09,0.0,cos(vWorld.z*3.7+uTime)*.09));}}"
        +"else base=mix(base,base*uTint,.32);float ndl=max(dot(n,uLight),0.0),shadow=visibility(n);vec3 view=normalize(uEye-vWorld);vec3 halfway=normalize(view+uLight);"
        +"float spec=uHighQuality?pow(max(dot(n,halfway),0.0),48.0)*metal:0.0;float rim=pow(1.0-max(dot(n,view),0.0),3.0)*.075;"
        +"vec3 color=base*(vec3(.25,.30,.34)+vec3(1.08,1.02,.88)*ndl*shadow)+vec3(.8,.93,1.0)*spec*shadow+base*rim;"
        +"if(!uTerrain)color+=base*vColor.a*.95;float fog=smoothstep(36.0,108.0,length(uEye-vWorld));color=mix(color,vec3(.12,.19,.24),fog*.86);fragColor=vec4(pow(max(color,vec3(0.0)),vec3(1.0/2.2)),1.0);}";
    private static final String DEPTH_VERTEX="#version 300 es\nprecision highp float;layout(location=0) in vec3 aPosition;layout(location=4) in float aBone;uniform mat4 uVP,uModel,uBones[24];uniform bool uSkinned;void main(){vec4 p=vec4(aPosition,1.0);if(uSkinned)p=uBones[clamp(int(aBone+.5),0,23)]*p;gl_Position=uVP*uModel*p;}";
    private static final String DEPTH_FRAGMENT="#version 300 es\nprecision mediump float;void main(){}";
    private static final String FLAT_VERTEX="#version 300 es\nprecision highp float;layout(location=0) in vec3 aPosition;layout(location=2) in vec4 aColor;uniform mat4 uMVP;out float vAlpha;void main(){gl_Position=uMVP*vec4(aPosition,1.0);vAlpha=aColor.a;}";
    private static final String FLAT_FRAGMENT="#version 300 es\nprecision mediump float;in float vAlpha;uniform vec4 uColor;out vec4 fragColor;void main(){fragColor=vec4(uColor.rgb,uColor.a*vAlpha);}";
}
