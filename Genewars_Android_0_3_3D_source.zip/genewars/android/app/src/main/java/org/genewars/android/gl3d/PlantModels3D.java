package org.genewars.android.gl3d;

/** Twelve distinct, closed-volume plants generated from the same native mesh primitives. */
public final class PlantModels3D {
    private PlantModels3D() {}
    private static final float TAU=(float)(Math.PI*2);
    private static float[] colour(float r,float g,float b,float emission){return new float[]{r,g,b,emission};}
    private static final float[] BARK=colour(.23f,.14f,.07f,0),WOOD=colour(.35f,.22f,.10f,0),
            GREEN=colour(.14f,.42f,.20f,0),TEAL=colour(.08f,.44f,.43f,.04f),
            GOLD=colour(.94f,.55f,.10f,.18f),SNOW=colour(.79f,.91f,.94f,.02f),
            BLUE=colour(.13f,.36f,.51f,.05f),PURPLE=colour(.40f,.13f,.57f,.15f),
            CYAN=colour(.10f,.79f,.93f,.42f);

    public static MeshData3D build(int species){
        if(species<0||species>=12)throw new IllegalArgumentException("Unknown plant species");
        MeshBuilder3D m=new MeshBuilder3D("plant_"+species);
        int stem=m.bone("stem",0,0,.06f,0,Bone3D.PLANT_SWAY_Z,species*.71f,species==7?.012f:.045f);
        if(species==0)broadleaf(m,stem);
        else if(species==1)fruit(m,stem);
        else if(species==2)fern(m,stem);
        else if(species==3)bloom(m,stem);
        else if(species==4)desertCanopy(m,stem);
        else if(species==5)palm(m,stem);
        else if(species==6)snowTree(m,stem);
        else if(species==7)crystals(m,stem);
        else if(species==8)pine(m,stem);
        else if(species==9)fungus(m,stem);
        else if(species==10)spiral(m,stem);
        else cone(m,stem);
        return m.finish();
    }

    private static void root(MeshBuilder3D m,int b,float height,float radius,float[]c){
        m.cylinder(0,.03f,0,.04f,height,0,radius,radius*.55f,8,c,b);
        for(int i=0;i<5;i++){
            float a=i*TAU/5,dx=(float)Math.cos(a),dz=(float)Math.sin(a);
            m.cylinder(dx*.30f,.025f,dz*.30f,0,.25f,0,.055f,.07f,6,c,b);
        }
    }
    private static void leaf(MeshBuilder3D m,int b,float x,float y,float z,float rx,float ry,float rz,float[]c){
        m.ellipsoid(x,y,z,rx,ry,rz,8,5,c,b);
    }
    private static void broadleaf(MeshBuilder3D m,int b){
        root(m,b,.82f,.10f,BARK);
        for(int i=0;i<9;i++){
            float a=i*TAU/9,x=(float)Math.cos(a)*.37f,z=(float)Math.sin(a)*.37f,y=.85f+(i%3)*.13f;
            m.cylinder(0,.65f,0,x,y,z,.035f,.014f,6,WOOD,b);
            leaf(m,b,x,y,z,.25f,.13f,.21f,i%2==0?GREEN:TEAL);
        }
        leaf(m,b,0,1.20f,0,.24f,.19f,.25f,GREEN);
    }
    private static void fruit(MeshBuilder3D m,int b){
        root(m,b,1.12f,.10f,BARK);
        for(int i=0;i<7;i++){
            float a=i*TAU/7,x=(float)Math.cos(a)*.35f,z=(float)Math.sin(a)*.35f,y=1.08f+(i%2)*.15f;
            m.cylinder(.02f,.92f,0,x,y,z,.035f,.018f,6,WOOD,b);
            leaf(m,b,x,y+.14f,z,.30f,.13f,.23f,i%2==0?GREEN:TEAL);
            leaf(m,b,x,y-.12f,z,.075f,.13f,.075f,GOLD);
        }
        leaf(m,b,0,1.43f,0,.28f,.20f,.27f,GREEN);
    }
    private static void fern(MeshBuilder3D m,int b){
        root(m,b,.65f,.075f,WOOD);
        for(int i=0;i<10;i++){
            float a=i*TAU/10,c=(float)Math.cos(a),s=(float)Math.sin(a),y=.72f+(i%3)*.13f;
            m.cylinder(0,.48f,0,c*.62f,y-.13f,s*.62f,.025f,.008f,6,TEAL,b);
            for(int j=1;j<=3;j++){
                float d=j*.16f;
                leaf(m,b,c*d,y-j*.035f,s*d,.18f,.075f,.13f,TEAL);
            }
        }
        leaf(m,b,0,1.05f,0,.18f,.15f,.18f,GREEN);
    }
    private static void bloom(MeshBuilder3D m,int b){
        root(m,b,.72f,.07f,WOOD);
        float[]petal=colour(.95f,.29f,.055f,.10f);
        for(int i=0;i<4;i++){
            float a=i*TAU/4+.3f,x=(float)Math.cos(a)*.26f,z=(float)Math.sin(a)*.26f,y=1.05f+(i%2)*.22f;
            m.cylinder(0,.50f,0,x,y,z,.045f,.025f,8,WOOD,b);
            int flower=m.bone("bloom_"+i,b,x,y,z,Bone3D.PULSE,i*.8f,.03f);
            for(int j=0;j<6;j++){
                float f=j*TAU/6;
                leaf(m,flower,x+(float)Math.cos(f)*.13f,y+.04f,z+(float)Math.sin(f)*.13f,.12f,.09f,.10f,petal);
            }
            leaf(m,flower,x,y+.10f,z,.09f,.10f,.09f,GOLD);
        }
    }
    private static void desertCanopy(MeshBuilder3D m,int b){
        root(m,b,.80f,.13f,WOOD);
        float[]rust=colour(.59f,.25f,.08f,0),amber=colour(.74f,.33f,.09f,.01f);
        for(int i=0;i<6;i++){
            float a=i*TAU/6,x=(float)Math.cos(a)*.40f,z=(float)Math.sin(a)*.40f,y=1.03f+(i%2)*.20f;
            m.cylinder(0,.52f,0,x,y,z,.07f,.035f,8,WOOD,b);
            leaf(m,b,x,y+.08f,z,.29f,.15f,.25f,i%2==0?rust:amber);
        }
        leaf(m,b,.03f,1.32f,0,.30f,.16f,.29f,rust);
    }
    private static void palm(MeshBuilder3D m,int b){
        root(m,b,1.25f,.09f,BARK);
        float[]olive=colour(.40f,.49f,.13f,0);
        for(int i=0;i<8;i++){
            float a=i*TAU/8,x=(float)Math.cos(a),z=(float)Math.sin(a);
            m.cylinder(.04f,1.20f,0,x*.60f,1.43f,z*.60f,.027f,.009f,6,olive,b);
            leaf(m,b,x*.30f,1.48f,z*.30f,.25f,.10f,.20f,olive);
            leaf(m,b,x*.56f,1.38f,z*.56f,.22f,.075f,.17f,olive);
            if(i%2==0)leaf(m,b,x*.12f,1.13f,z*.12f,.07f,.09f,.07f,GOLD);
        }
    }
    private static void snowTree(MeshBuilder3D m,int b){
        root(m,b,1.40f,.085f,colour(.62f,.71f,.75f,0));
        for(int i=0;i<7;i++){
            float a=i*TAU/7,x=(float)Math.cos(a)*.34f,z=(float)Math.sin(a)*.34f,y=1.30f+(i%3)*.17f;
            m.cylinder(0,.90f,0,x,y,z,.045f,.015f,8,SNOW,b);
            leaf(m,b,x,y+.12f,z,.29f,.19f,.26f,SNOW);
        }
        leaf(m,b,0,1.84f,0,.25f,.22f,.25f,SNOW);
    }
    private static void crystals(MeshBuilder3D m,int b){
        leaf(m,b,0,.12f,0,.36f,.12f,.35f,BLUE);
        for(int i=0;i<9;i++){
            float a=i*TAU/9,x=(float)Math.cos(a)*.24f,z=(float)Math.sin(a)*.24f,h=.8f+(i%3)*.24f;
            float[]c=i%2==0?CYAN:colour(.43f,.32f,.84f,.28f);
            m.cylinder(x,.10f,z,x*1.45f,h,z*1.45f,.10f,.075f,6,c,b);
            m.cylinder(x*1.45f,h,z*1.45f,x*1.55f,h+.28f,z*1.55f,.075f,0,6,c,b);
        }
    }
    private static void pine(MeshBuilder3D m,int b){
        root(m,b,1.70f,.065f,BARK);
        for(int i=0;i<5;i++){
            float y=.40f+i*.27f,r=.52f-i*.085f;
            m.cylinder(0,y,0,0,y+.55f,0,r,0,10,BLUE,b);
            m.cylinder(0,y+.12f,0,0,y+.56f,0,r*.77f,0,10,SNOW,b);
        }
    }
    private static void fungus(MeshBuilder3D m,int b){
        for(int i=0;i<5;i++){
            float a=i*TAU/5,x=i==0?0:(float)Math.cos(a)*.32f,z=i==0?0:(float)Math.sin(a)*.32f,h=i==0?1.30f:.60f+(i%3)*.18f,r=i==0?.37f:.23f;
            m.cylinder(x,.02f,z,x,h,z,.05f,.035f,8,colour(.46f,.27f,.12f,0),b);
            leaf(m,b,x,h,z,r,.05f,r,CYAN);
            leaf(m,b,x,h+.10f,z,r*1.02f,.14f,r,TEAL);
            for(int j=0;j<5;j++){
                float f=j*TAU/5;
                leaf(m,b,x+(float)Math.cos(f)*r*.6f,h+.20f,z+(float)Math.sin(f)*r*.6f,.025f,.02f,.025f,CYAN);
            }
        }
    }
    private static void spiral(MeshBuilder3D m,int b){
        root(m,b,.75f,.08f,colour(.18f,.13f,.25f,0));
        for(int side=0;side<2;side++){
            float lastX=0,lastY=.42f,lastZ=0;
            for(int i=1;i<=16;i++){
                float a=i*.48f+side*(float)Math.PI,r=.10f+i*.014f;
                float x=(float)Math.cos(a)*r,z=(float)Math.sin(a)*r,y=.42f+i*.073f;
                m.cylinder(lastX,lastY,lastZ,x,y,z,.035f,.030f,6,PURPLE,b);
                if(i%3==0)leaf(m,b,x,y,z,.10f,.07f,.09f,colour(.65f,.19f,.79f,.15f));
                lastX=x;lastY=y;lastZ=z;
            }
            leaf(m,b,lastX,lastY,lastZ,.10f,.10f,.10f,CYAN);
        }
    }
    private static void cone(MeshBuilder3D m,int b){
        root(m,b,.48f,.11f,BARK);
        leaf(m,b,0,.91f,0,.35f,.72f,.35f,colour(.14f,.35f,.29f,0));
        for(int row=0;row<5;row++){
            float y=.42f+row*.24f,r=.33f*(float)Math.sin((row+1)*Math.PI/6);
            for(int j=0;j<7;j++){
                float a=j*TAU/7+row*.31f,x=(float)Math.cos(a)*r,z=(float)Math.sin(a)*r;
                leaf(m,b,x,y,z,.11f,.17f,.10f,j%3==0?GOLD:TEAL);
            }
        }
    }
}
