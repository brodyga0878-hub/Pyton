package org.genewars.android.gl3d;

/** Four volumetric humanoid specialists with hierarchical arm and leg rigs. */
final class SpecialistModels3D {
    private static final float[] IVORY={.78f,.81f,.73f,0},DARK={.08f,.13f,.16f,0},SKIN={.61f,.40f,.27f,0},
            COPPER={.63f,.35f,.12f,0},GLOW={.05f,.85f,.82f,.8f};
    private static final float[][] JOB={{.86f,.43f,.10f,0},{.18f,.46f,.30f,0},{.86f,.75f,.48f,0},{.10f,.25f,.34f,0}};
    static MeshData3D build(int kind){
        if(kind<0||kind>3)throw new IllegalArgumentException("Specialist kind");
        MeshBuilder3D b=new MeshBuilder3D("specialist_"+kind);float[]suit=JOB[kind];
        int body=b.bone("torso",0,0,.72f,0,Bone3D.ROOT,.3f*kind,.02f);
        b.ellipsoid(0,.77f,0,.19f,.23f,.13f,12,8,suit,body);
        b.ellipsoid(0,.86f,.02f,.19f,.13f,.13f,12,6,kind==3?DARK:IVORY,body);
        b.cylinder(0,.53f,0,0,.67f,0,.15f,.15f,12,DARK,body);
        b.cylinder(0,.94f,0,0,1.02f,0,.06f,.065f,10,SKIN,body);
        int head=b.bone("head",body,0,1.02f,0,Bone3D.HEAD_Y,kind*.6f,.08f);
        b.ellipsoid(0,1.10f,.014f,.115f,.14f,.11f,14,9,SKIN,head);
        b.ellipsoid(0,1.165f,-.004f,.12f,.085f,.113f,12,6,kind==0?IVORY:DARK,head);
        b.box(0,1.116f,.108f,.19f,.055f,.025f,DARK,head);
        b.box(0,1.119f,.124f,.153f,.025f,.008f,kind==2?new float[]{.98f,.65f,.16f,.5f}:GLOW,head);
        b.ellipsoid(0,1.062f,.116f,.023f,.033f,.022f,8,5,SKIN,head);
        b.cylinder(-.037f,1.017f,.10f,.037f,1.017f,.10f,.007f,.007f,6,DARK,head);
        int[]hands=new int[2];
        for(int side=-1;side<=1;side+=2){
            float phase=side<0?0:(float)Math.PI;
            int thigh=b.bone("leg_hip_"+side,body,side*.09f,.56f,0,Bone3D.SWING_X,phase,.52f);
            int shin=b.bone("leg_knee_"+side,thigh,side*.10f,.29f,.015f,Bone3D.KNEE_X,phase+1.1f,.66f);
            b.cylinder(side*.09f,.56f,0,side*.10f,.29f,.015f,.074f,.055f,10,suit,thigh);
            b.ellipsoid(side*.10f,.29f,.028f,.065f,.068f,.066f,9,6,IVORY,shin);
            b.cylinder(side*.10f,.29f,.015f,side*.105f,.075f,.01f,.05f,.04f,9,DARK,shin);
            b.ellipsoid(side*.105f,.055f,.045f,.065f,.052f,.115f,10,5,DARK,shin);
            int arm=b.bone("arm_shoulder_"+side,body,side*.21f,.91f,0,Bone3D.WORK_ARM_X,phase+(float)Math.PI,.70f);
            int fore=b.bone("arm_elbow_"+side,arm,side*.25f,.70f,.01f,Bone3D.SWING_X,phase+.4f,.16f);
            b.ellipsoid(side*.205f,.91f,0,.085f,.09f,.08f,10,6,kind==3?DARK:IVORY,arm);
            b.cylinder(side*.21f,.91f,0,side*.25f,.70f,.01f,.052f,.043f,9,suit,arm);
            b.ellipsoid(side*.25f,.70f,.01f,.05f,.05f,.05f,8,5,COPPER,fore);
            b.cylinder(side*.25f,.70f,.01f,side*.255f,.52f,.075f,.05f,.041f,9,suit,fore);
            b.ellipsoid(side*.255f,.51f,.075f,.047f,.055f,.055f,9,5,DARK,fore);
            hands[side<0?0:1]=fore;
        }
        // Belt, shoulder seams, boots and backpack are solid, separate surfaces.
        for(int i=-2;i<=2;i++)b.box(i*.056f,.575f,.137f,.039f,.045f,.035f,COPPER,body);
        b.box(0,.78f,-.16f,.23f,.26f,.10f,DARK,body);
        b.cylinder(-.075f,.69f,-.21f,-.075f,.94f,-.21f,.041f,.041f,10,kind==1?suit:COPPER,body);
        b.cylinder(.075f,.69f,-.21f,.075f,.94f,-.21f,.041f,.041f,10,COPPER,body);
        b.cylinder(-.07f,.95f,-.21f,.07f,.95f,-.21f,.014f,.014f,8,GLOW,body);
        if(kind==0){
            int arm=hands[1];
            b.box(.20f,.815f,-.21f,.22f,.045f,.095f,DARK,body);
            b.cylinder(.255f,.52f,.075f,.255f,.52f,.28f,.055f,.035f,10,COPPER,arm);
            b.cylinder(.255f,.52f,.27f,.255f,.52f,.34f,.04f,.025f,9,new float[]{.98f,.55f,.08f,.9f},arm);
            for(int i=0;i<3;i++)b.cylinder(.215f+i*.04f,.79f,-.21f,.215f+i*.04f,.96f,-.21f,.012f,.012f,6,IVORY,body);
        }else if(kind==1){
            for(int side=-1;side<=1;side+=2){
                int arm=hands[side<0?0:1];
                b.cylinder(side*.255f,.48f,.14f,side*.255f,.63f,.14f,.04f,.04f,10,IVORY,arm);
                b.cylinder(side*.255f,.505f,.14f,side*.255f,.605f,.14f,.043f,.043f,10,new float[]{.24f,.78f,.25f,.35f},arm);
            }
            b.ellipsoid(0,.74f,-.24f,.10f,.13f,.06f,10,6,suit,body);
        }else if(kind==2){
            b.cylinder(0,.51f,0,0,.75f,0,.19f,.15f,12,IVORY,body);
            b.box(-.255f,.535f,.15f,.16f,.12f,.035f,DARK,hands[0]);
            b.box(-.255f,.54f,.174f,.13f,.085f,.008f,new float[]{.96f,.64f,.10f,.65f},hands[0]);
            b.cylinder(.255f,.54f,.11f,.255f,.54f,.23f,.032f,.015f,8,GLOW,hands[1]);
        }else{
            b.box(.255f,.56f,.16f,.085f,.10f,.25f,DARK,hands[1]);
            b.cylinder(.255f,.575f,.18f,.255f,.575f,.48f,.025f,.022f,10,COPPER,hands[1]);
            b.cylinder(.255f,.575f,.45f,.255f,.575f,.50f,.027f,.027f,9,GLOW,hands[1]);
            b.cylinder(-.14f,.93f,-.13f,-.14f,1.16f,-.13f,.009f,.006f,6,DARK,body);
        }
        return b.finish();
    }
}
