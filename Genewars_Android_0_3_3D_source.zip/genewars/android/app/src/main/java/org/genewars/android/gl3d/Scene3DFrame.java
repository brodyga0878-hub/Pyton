package org.genewars.android.gl3d;

import org.genewars.core.Building;
import org.genewars.core.GameState;
import org.genewars.core.Plant;
import org.genewars.core.Unit;
import org.genewars.core.WorldMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;

/** An immutable UI-to-GL message. No mutable GameState objects reach GL. */
public final class Scene3DFrame {
    private static final WeakHashMap<WorldMap,Terrain> TERRAIN_CACHE=new WeakHashMap<WorldMap,Terrain>();
    public final Terrain terrain;
    public final List<Actor> actors;
    public final float seconds,zoneX,zoneZ,zoneRadius;
    public final int selectedId;
    public final boolean highQuality;
    private Scene3DFrame(Terrain terrain,List<Actor> actors,float seconds,int selected,boolean quality,float zx,float zz,float zr){
        this.terrain=terrain;this.actors=Collections.unmodifiableList(actors);this.seconds=seconds;selectedId=selected;highQuality=quality;zoneX=zx;zoneZ=zz;zoneRadius=zr;
    }
    /** Capture on the simulation/UI thread only. */
    public static Scene3DFrame capture(GameState state,float seconds,boolean highQuality){
        if(state==null)throw new IllegalArgumentException("Game state required");
        Terrain terrain;
        synchronized(TERRAIN_CACHE){terrain=TERRAIN_CACHE.get(state.map);if(terrain==null){terrain=new Terrain(state.map);TERRAIN_CACHE.put(state.map,terrain);}}
        ArrayList<Actor> actors=new ArrayList<Actor>(state.units.size()+state.buildings.size()+state.plants.size());
        for(Plant p:state.plants)if(p.biomass>0)actors.add(new Actor(p.id,3,p.species,2,(float)p.x,(float)p.y,1,1,1,0,0));
        for(Building b:state.buildings)if(b.hp>0)actors.add(new Actor(b.id,2,b.kind.ordinal(),b.team,(float)b.x,(float)b.y,(float)b.hp,(float)b.maxHp,(float)b.progress,0,b.stage));
        for(Unit u:state.units)if(u.hp>0){
            String task=u.task==null?"":u.task;int action=task.contains("Атак")||task.contains("Бой")?2:task.contains("Стро")||task.contains("Исслед")||task.contains("Сбор")||task.contains("Посад")||task.contains("Ремонт")?3:task.contains("Движ")||task.contains("Идёт")?1:0;
            int type=u.kind==Unit.Kind.CREATURE?0:1,kind=type==0?u.species:u.kind.ordinal();
            actors.add(new Actor(u.id,type,kind,u.team,(float)u.x,(float)u.y,(float)u.hp,(float)u.maxHp,1,action,0));
        }
        return new Scene3DFrame(terrain,actors,Float.isNaN(seconds)||Float.isInfinite(seconds)?0:seconds,state.selectedId,highQuality,(float)state.zoneX,(float)state.zoneY,(float)state.zoneRadius);
    }
    public static final class Actor {
        public final int id,type,kind,team,action,stage;
        public final float x,z,hp,maxHp,progress;
        Actor(int id,int type,int kind,int team,float x,float z,float hp,float maxHp,float progress,int action,int stage){this.id=id;this.type=type;this.kind=kind;this.team=team;this.x=x;this.z=z;this.hp=hp;this.maxHp=maxHp;this.progress=progress;this.action=action;this.stage=stage;}
    }
    public static final class Terrain {
        public final int width,height;
        private final byte[] types;
        private final short[] elevations;
        Terrain(WorldMap source){width=source.width;height=source.height;types=source.terrain.clone();elevations=source.elevation.clone();}
        public int type(int x,int z){return types[Math.max(0,Math.min(height-1,z))*width+Math.max(0,Math.min(width-1,x))]&7;}
        public float height(float x,float z){return Camera3D.heightAt(width,height,elevations,x,z);}
        /** Integer grid sample for mesh preparation; matches height(x,z) at a corner. */
        float vertexHeight(int x,int z){
            int ix=Math.max(0,Math.min(width-1,x)),iz=Math.max(0,Math.min(height-1,z));
            return elevations[iz*width+ix]/256f*Camera3D.HEIGHT_FACTOR;
        }
    }
}
