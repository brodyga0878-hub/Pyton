package org.genewars.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import org.genewars.android.gl3d.Camera3D;
import org.genewars.android.gl3d.Scene3DFrame;
import org.genewars.android.gl3d.Scene3DRenderer;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import org.genewars.core.Building;
import org.genewars.core.GameState;
import org.genewars.core.Plant;
import org.genewars.core.Unit;
import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;

/** Native Android game frontend. No WebView, DOS runtime, or external launcher. */
public final class MainActivity extends Activity {
    private static final int BACKGROUND = ModernUiSkin.INK;
    private static final int FOREGROUND = ModernUiSkin.WHITE;
    private static final int ACCENT = ModernUiSkin.AQUA;
    private AssetRepository repository;
    private GameState game;
    private WorldView world;
    private LinearLayout page;
    private TextView hud;
    private TextView objective;
    private TextView message;
    private SharedPreferences preferences;
    private boolean smooth;
    private boolean muted;
    private boolean destroyed;
    private boolean resumed;
    private boolean showingOutcome;
    private boolean loadingGame;
    private int loadingGeneration;
    private GameState loadingPreviousGame;
    private LinearLayout loadingPreviousPage;
    private WorldView loadingPreviousWorld;
    private boolean audioPreparationStarted;
    private Future<?> activeWorldLoad;
    private final ExecutorService worldLoader = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "native-world-load"); thread.setDaemon(true); return thread;
        }
    });
    private float speed = 1f;
    private SoundPool soundPool;
    private MediaPlayer musicPlayer;
    private boolean musicReady;
    private boolean musicFinished;
    private int musicTrack;
    private int musicGeneration;
    private final Map<String, Integer> soundIds = new HashMap<String, Integer>();
    private final Map<Integer, Boolean> loadedSounds = new ConcurrentHashMap<Integer, Boolean>();
    private long nextHudUpdate;
    private Button pauseButton;
    private Button speedButton;
    private Button filterButton;
    private Button soundButton;
    private Button placementButton;
    private int modalDepth;

    @Override public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        preferences = getSharedPreferences("preferences", MODE_PRIVATE);
        // The 3D renderer starts in HD even when a 0.1 pixel-filter setting was off.
        smooth = preferences.getBoolean("graphics3dHigh", true);
        muted = preferences.getBoolean("muted", false);
        musicTrack = preferences.getInt("musicTrack", 0);
        hideSystemBars();
        page = basePage();
        TextView loading = text("Подготовка планет…", 24);
        loading.setGravity(Gravity.CENTER);
        page.addView(loading, new LinearLayout.LayoutParams(-1, -1));
        setContentView(page);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final AssetRepository loaded = new AssetRepository(MainActivity.this);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed) { loaded.close(); return; }
                            repository = loaded;
                            if (savedInstanceState != null && savedInstanceState.getBoolean("playing", false)
                                    && saveFile().isFile()) {
                                continueGame();
                            } else showMainMenu();
                        }
                    });
                } catch (final Exception exception) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (!destroyed) showFatal("Не удалось прочитать игровые ресурсы", exception);
                        }
                    });
                }
            }
        }, "native-assets").start();
    }

    private LinearLayout basePage() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7, 20, 29), Color.rgb(14, 31, 42), Color.rgb(6, 16, 25)}));
        layout.setPadding(dp(12), dp(6), dp(12), dp(6));
        layout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout());
                    view.setPadding(dp(12) + safe.left, dp(6) + safe.top,
                            dp(12) + safe.right, dp(6) + safe.bottom);
                } else {
                    view.setPadding(dp(12) + insets.getSystemWindowInsetLeft(),
                            dp(6) + insets.getSystemWindowInsetTop(),
                            dp(12) + insets.getSystemWindowInsetRight(),
                            dp(6) + insets.getSystemWindowInsetBottom());
                }
                return insets;
            }
        });
        return layout;
    }

    private void showMainMenu() {
        if (loadingGame) {
            ++loadingGeneration; loadingGame = false;
            if (activeWorldLoad != null) activeWorldLoad.cancel(true);
            activeWorldLoad = null;
            if (loadingPreviousWorld != null) loadingPreviousWorld.stop();
            clearPreviousLoad();
        }
        stopWorld();
        game = null;
        page = basePage();
        FrameLayout scene = new FrameLayout(this);
        scene.addView(ModernUiSkin.menuBackdrop(this, repository), new FrameLayout.LayoutParams(-1, -1));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setGravity(Gravity.CENTER_VERTICAL);
        menu.setPadding(dp(26), dp(18), dp(20), dp(18));
        TextView eyebrow = text("БИОИНЖЕНЕРИЯ  /  НОВЫЕ МИРЫ", 11);
        eyebrow.setTextColor(ACCENT); eyebrow.setLetterSpacing(.17f);
        menu.addView(eyebrow);
        TextView title = text("GENE WARS", 43);
        title.setTextColor(FOREGROUND); title.setLetterSpacing(.06f);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        menu.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = text("Возродите жизнь среди звёзд.", 18);
        subtitle.setTextColor(Color.rgb(173, 205, 208));
        menu.addView(subtitle);
        LinearLayout badges = new LinearLayout(this);
        badges.setPadding(0, dp(10), 0, dp(16));
        for (String value : new String[]{"38 КАРТ", "25 ВИДОВ", "3D-МОДЕЛИ"}) {
            TextView badge = text(value, 10); badge.setTextColor(ACCENT); badge.setLetterSpacing(.08f);
            badge.setPadding(dp(10), dp(6), dp(10), dp(6));
            badge.setBackground(ModernUiSkin.panel(this, Color.argb(180, 17, 46, 53), Color.argb(180, 8, 28, 37), 9));
            LinearLayout.LayoutParams parameters = new LinearLayout.LayoutParams(-2, -2); parameters.rightMargin = dp(8);
            badges.addView(badge, parameters);
        }
        menu.addView(badges);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.LEFT);
        Button start = button("Новая игра", new Runnable() { @Override public void run() { chooseMap(); } });
        ModernUiSkin.styleButton(start, true);
        Button resume = button("Продолжить", new Runnable() { @Override public void run() { continueGame(); } });
        resume.setEnabled(saveFile().isFile());
        LinearLayout.LayoutParams startParameters = new LinearLayout.LayoutParams(dp(188), dp(54)); startParameters.rightMargin = dp(10);
        row.addView(start, startParameters);
        row.addView(resume, new LinearLayout.LayoutParams(dp(188), dp(54)));
        menu.addView(row);
        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.LEFT); row2.setPadding(0, dp(10), 0, dp(12));
        LinearLayout.LayoutParams secondaryParameters = new LinearLayout.LayoutParams(dp(188), dp(48)); secondaryParameters.rightMargin = dp(10);
        row2.addView(button("Как играть", new Runnable() { @Override public void run() { showHelp(); } }),
                secondaryParameters);
        row2.addView(button("Настройки", new Runnable() { @Override public void run() { showSettings(); } }),
                new LinearLayout.LayoutParams(dp(188), dp(48)));
        menu.addView(row2);
        TextView edition = text("Нативная реконструкция 0.3 3D  ·  ранняя версия", 11);
        edition.setTextColor(ModernUiSkin.SECONDARY); menu.addView(edition);
        TextView status = text("Оригинальная кампания ещё восстанавливается.", 11);
        status.setTextColor(ModernUiSkin.SECONDARY); menu.addView(status);
        scroll.addView(menu);
        FrameLayout.LayoutParams foreground = new FrameLayout.LayoutParams(-1, -1);
        scene.addView(scroll, foreground);
        page.addView(scene, new LinearLayout.LayoutParams(-1, -1));
        setContentView(page);
        hideSystemBars();
        scheduleAudioAfterFirstDraw(page);
    }

    private void chooseMap() {
        String[] names = new String[repository.maps.size()];
        for (int i = 0; i < names.length; i++) names[i] = repository.maps.get(i).displayTitle();
        showModal(new AlertDialog.Builder(this).setTitle("Выберите планету")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int index) {
                        chooseMission(repository.maps.get(index));
                    }
                }).setNegativeButton("Назад", null));
    }

    private void chooseMission(final AssetRepository.MapEntry map) {
        // A combat objective on a peaceful source map would instantly complete
        // without playing. Offer it only where original hostile records exist.
        final int count = map.hasHostiles ? GameState.MISSION_COUNT : Math.min(4, GameState.MISSION_COUNT);
        String[] names = new String[count];
        for (int i = 0; i < names.length; i++) names[i] = GameState.missionTitle(i);
        showModal(new AlertDialog.Builder(this).setTitle("Задание реконструкции")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int index) { startGame(map, index); }
                }).setNegativeButton("Назад", null));
    }

    private interface GameLoader { GameState load() throws Exception; }

    private void startGame(final AssetRepository.MapEntry entry, final int mission) {
        loadGameAsync("Открываем планету…", "Не удалось открыть планету", new GameLoader() {
            @Override public GameState load() throws Exception {
                long seed = 0x47454E45L + entry.index * 1009L + mission;
                return repository.startGame(entry, mission, seed);
            }
        });
    }

    private void continueGame() {
        loadGameAsync("Загрузка сохранения…", "Не удалось загрузить сохранение", new GameLoader() {
            @Override public GameState load() throws Exception { return GameState.load(saveFile()); }
        });
    }

    private void loadGameAsync(String progress, final String errorTitle, final GameLoader loader) {
        if (loadingGame || destroyed) return;
        loadingGame = true;
        final int generation = ++loadingGeneration;
        loadingPreviousGame = game;
        loadingPreviousPage = page;
        loadingPreviousWorld = world;
        if (world != null) world.stop();
        world = null;
        page = basePage();
        TextView label = text(progress, 22);
        label.setGravity(Gravity.CENTER);
        page.addView(label, new LinearLayout.LayoutParams(-1, 0, 1f));
        page.addView(button("Отмена", new Runnable() { @Override public void run() { cancelGameLoad(); } }),
                new LinearLayout.LayoutParams(-1, dp(50)));
        setContentView(page);
        activeWorldLoad = worldLoader.submit(new Runnable() {
            @Override public void run() {
                try {
                    long started = android.os.SystemClock.elapsedRealtime();
                    final GameState loaded = loader.load();
                    if (Thread.currentThread().isInterrupted()) return;
                    android.util.Log.i("GeneWars", "Selected world ready in "
                            + (android.os.SystemClock.elapsedRealtime() - started) + " ms");
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != loadingGeneration || !loadingGame) return;
                            loadingGame = false;
                            activeWorldLoad = null;
                            clearPreviousLoad();
                            game = loaded;
                            showGame();
                        }
                    });
                } catch (final Exception exception) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != loadingGeneration || !loadingGame) return;
                            restorePreviousLoad(true);
                            showError(errorTitle, exception);
                        }
                    });
                }
            }
        });
    }

    private void clearPreviousLoad() {
        if (loadingPreviousWorld != null && loadingPreviousWorld != world) loadingPreviousWorld.release();
        loadingPreviousGame = null; loadingPreviousPage = null; loadingPreviousWorld = null;
    }

    private void restorePreviousLoad(boolean paused) {
        loadingGame = false;
        activeWorldLoad = null;
        game = loadingPreviousGame;
        page = loadingPreviousPage;
        world = loadingPreviousWorld;
        clearPreviousLoad();
        if (page == null || game == null) { showMainMenu(); return; }
        setContentView(page); hideSystemBars();
        if (game != null) {
            if (paused) game.paused = true;
            updateToolLabels(); updateHud();
            if (world != null && resumed && modalDepth == 0) world.start();
        }
    }

    private void cancelGameLoad() {
        if (!loadingGame) return;
        ++loadingGeneration;
        if (activeWorldLoad != null) activeWorldLoad.cancel(true);
        restorePreviousLoad(false);
    }

    private void showGame() {
        stopWorld();
        showingOutcome = false;
        nextHudUpdate = 0;
        page = basePage();
        hud = text("", 14);
        hud.setTextColor(ACCENT);
        hud.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        hud.setPadding(dp(12), dp(9), dp(12), dp(9));
        hud.setBackground(ModernUiSkin.panel(this, Color.argb(245, 20, 45, 55), Color.argb(245, 10, 28, 39), 13));
        objective = text("", 12);
        objective.setMaxLines(2); objective.setEllipsize(TextUtils.TruncateAt.END);
        objective.setTextColor(Color.rgb(180, 207, 210));
        objective.setPadding(dp(8), dp(7), dp(8), dp(2));
        message = text("", 12);
        message.setSingleLine(true);
        message.setTextColor(ModernUiSkin.GOLD);
        message.setPadding(dp(8), dp(3), dp(8), dp(5));
        page.addView(hud);
        page.addView(objective);
        page.addView(message);
        world = new WorldView(game);
        page.addView(world, new LinearLayout.LayoutParams(-1, 0, 1f));
        HorizontalScrollView barScroll = new HorizontalScrollView(this);
        barScroll.setHorizontalScrollBarEnabled(false);
        barScroll.setPadding(0, dp(6), 0, 0);
        LinearLayout bar = new LinearLayout(this);
        addTool(bar, "Строить", new Runnable() { @Override public void run() { showBuildMenu(); } });
        placementButton = addTool(bar, "Отмена", new Runnable() { @Override public void run() { world.cancelPlacement(); } });
        placementButton.setVisibility(View.GONE);
        addTool(bar, "Существа", new Runnable() { @Override public void run() { showCreatureMenu(); } });
        addTool(bar, "Скрестить", new Runnable() { @Override public void run() { showBreedMenu(); } });
        addTool(bar, "Действия", new Runnable() { @Override public void run() { showActions(); } });
        addTool(bar, "К отряду", new Runnable() { @Override public void run() { if (world != null) world.centerOnTeam(); } });
        addTool(bar, "Поворот", new Runnable() { @Override public void run() { if (world != null) world.rotateCamera(); } });
        pauseButton = addTool(bar, "Пауза", new Runnable() { @Override public void run() {
            game.paused = !game.paused; updateToolLabels();
        } });
        speedButton = addTool(bar, "×1", new Runnable() { @Override public void run() {
            speed = speed == 1 ? 2 : 1; updateToolLabels();
        } });
        filterButton = addTool(bar, "Детали", new Runnable() { @Override public void run() {
            smooth = !smooth; savePreferences(); updateToolLabels(); world.requestSceneFrame();
        } });
        soundButton = addTool(bar, "Звук", new Runnable() { @Override public void run() {
            muted = !muted; savePreferences(); updateToolLabels();
        } });
        addTool(bar, "Меню", new Runnable() { @Override public void run() { showPauseMenu(); } });
        barScroll.addView(bar, new FrameLayout.LayoutParams(-2, dp(52)));
        page.addView(barScroll, new LinearLayout.LayoutParams(-1, dp(58)));
        setContentView(page);
        hideSystemBars();
        updateToolLabels();
        updateHud();
        if (resumed && modalDepth == 0) world.start();
        scheduleAudioAfterFirstDraw(page);
    }

    private void updateToolLabels() {
        if (game == null || pauseButton == null) return;
        pauseButton.setText(game.paused ? "Дальше" : "Пауза");
        speedButton.setText(speed == 1 ? "×1" : "×2");
        filterButton.setText(smooth ? "3D HD" : "3D Эко");
        soundButton.setText(muted ? "Без звука" : "Звук");
    }

    private void updateHud() {
        if (game == null || hud == null) return;
        String counters = "Биогель: " + game.goop + "/" + game.goopCapacity + "    Древесина: " + game.wood
                + "    Целлюлоза: " + game.cellulose + "    Энергия: " + game.powerProduced + "/" + game.powerUsed;
        // Keep unchanged text/layout out of the 200 ms HUD path. TextView.setText
        // invalidates layout even when an equivalent fresh Spannable is passed.
        if (!TextUtils.equals(hud.getText(), counters)) {
            SpannableString rich = new SpannableString(counters);
            String[] labels = {"Биогель:", "Древесина:", "Целлюлоза:", "Энергия:"};
            int[] colors = {ACCENT, ModernUiSkin.GOLD, Color.rgb(156, 184, 243), Color.rgb(115, 220, 238)};
            for (int i = 0; i < labels.length; i++) {
                int start = counters.indexOf(labels[i]);
                if (start >= 0) rich.setSpan(new ForegroundColorSpan(colors[i]), start, start + labels[i].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            hud.setText(rich);
        }
        String objectiveText = game.objectiveText() + "  •  " + game.objectiveProgress();
        if (!TextUtils.equals(objective.getText(), objectiveText)) objective.setText(objectiveText);
        String selected = "";
        for (Unit unit : game.units) {
            if (unit.id == game.selectedId && unit.hp > 0) {
                selected = unit.title() + "  " + (int) unit.hp + "/" + (int) unit.maxHp;
                if (unit.task != null && !unit.task.isEmpty()) selected += "  ·  " + unit.task;
                break;
            }
        }
        if (selected.length() == 0) {
            Building building = game.selectedBuilding();
            if (building != null && building.hp > 0) selected = building.title() + "  "
                    + (int) building.hp + "/" + (int) building.maxHp + "  ·  " + building.status();
        }
        String info = selected.length() > 0 ? selected : game.message == null ? "Выберите специалиста или существо" : game.message;
        if (game.etherealETA >= 0) info += "  ·  Эфириалы: " + (int) game.etherealETA + " с";
        else if (game.etherealPoints > 0) info += "  ·  Очки эфириалов: " + game.etherealPoints;
        if (!TextUtils.equals(message.getText(), info)) message.setText(info);
    }

    private void frameUpdated() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now >= nextHudUpdate) { nextHudUpdate = now + 200; updateHud(); }
        for (String event : game.pollEvents()) {
            playSound(event);
            if (world != null) world.onGameEvent(event);
        }
        if (!showingOutcome && (game.victory || game.defeat)) {
            showingOutcome = true;
            game.paused = true;
            updateToolLabels();
            String title = game.victory ? "Задание выполнено" : "Отряд потерян";
            showModal(new AlertDialog.Builder(this).setTitle(title).setMessage(game.objectiveProgress())
                    .setPositiveButton("Выбрать планету", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) { showMainMenu(); chooseMap(); }
                    }).setNegativeButton("Осмотреть карту", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) { showingOutcome = true; }
                    }).setCancelable(false));
        }
    }

    private void showBuildMenu() {
        world.cancelPlacement();
        final Building.Kind[] kinds = Building.Kind.values();
        String[] names = new String[kinds.length];
        for (int i = 0; i < kinds.length; i++) names[i] = kinds[i].title + " — " + kinds[i].cost + " биогеля";
        showModal(new AlertDialog.Builder(this).setTitle("Постройка: затем коснитесь земли")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        world.beginBuilding(kinds[which]);
                        Toast.makeText(MainActivity.this, "Выберите место для постройки", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Отмена", null));
    }

    private void showCreatureMenu() {
        world.cancelPlacement();
        final String[] names = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
        showModal(new AlertDialog.Builder(this).setTitle("Вырастить существо")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        boolean done = game.trainCreature(which);
                        showCommandResult(done);
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showBreedMenu() {
        world.cancelPlacement();
        final String[] names = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
        showModal(new AlertDialog.Builder(this).setTitle("Первый родитель")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, final int first) {
                        showModal(new AlertDialog.Builder(MainActivity.this).setTitle("Второй родитель")
                                .setItems(names, new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface dialog, int second) {
                                        showCommandResult(game.breed(first, second));
                                    }
                                }).setNegativeButton("Отмена", null));
                    }
                }).setNegativeButton("Отмена", null));
    }

    private void showActions() {
        world.cancelPlacement();
        final String[] items = {"Собирать древесину", "Переработать древесину", "Исследовать существо", "Посадить дерево",
                "Улучшить выбранную постройку", "Пригласить специалиста", "Вызвать эфириалов"};
        showModal(new AlertDialog.Builder(this).setTitle("Действия отряда")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) showCommandResult(game.orderHarvest());
                        else if (which == 1) showCommandResult(game.recycleWood());
                        else if (which == 2) showCommandResult(game.researchSelected());
                        else if (which == 3) {
                            world.beginPlanting();
                            Toast.makeText(MainActivity.this, "Коснитесь земли для посадки", Toast.LENGTH_SHORT).show();
                        } else if (which == 4) showCommandResult(game.upgradeSelectedBuilding());
                        else if (which == 5) showRecruitMenu();
                        else showCommandResult(game.callEthereals());
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showRecruitMenu() {
        final Unit.Kind[] kinds = {Unit.Kind.ENGINEER, Unit.Kind.BOTANIST, Unit.Kind.GENETICIST, Unit.Kind.RANGER};
        showModal(new AlertDialog.Builder(this).setTitle("Пригласить через посадочную площадку")
                .setItems(new String[]{"Инженер", "Ботаник", "Генетик", "Егерь"}, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        showCommandResult(game.recruitSpecialist(kinds[which]));
                    }
                }).setNegativeButton("Назад", null));
    }

    private void showCommandResult(boolean accepted) {
        if (!accepted && game.message != null) Toast.makeText(this, game.message, Toast.LENGTH_LONG).show();
        updateHud();
    }

    private void showPauseMenu() {
        if (game == null) return;
        final boolean previous = game.paused;
        game.paused = true;
        updateToolLabels();
        showModal(new AlertDialog.Builder(this).setTitle("Игра приостановлена")
                .setItems(new String[]{"Сохранить", "Загрузить", "Как играть", "Настройки", "Главное меню"},
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) { saveGame(true); game.paused = previous; updateToolLabels(); }
                                else if (which == 1) continueGame();
                                else if (which == 2) { game.paused = previous; showHelp(); }
                                else if (which == 3) { game.paused = previous; showSettings(); }
                                else { saveGame(false); showMainMenu(); }
                            }
                        }).setNegativeButton("Продолжить", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                if (game != null) { game.paused = previous; updateToolLabels(); }
                            }
                        }).setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface dialog) {
                                if (game != null) { game.paused = previous; updateToolLabels(); }
                            }
                        }));
    }

    private void showHelp() {
        String instructions = "Коснитесь своего специалиста или существа, затем земли — отряд отправится туда. "
                + "Коснитесь врага, чтобы отдать приказ атаковать. Перетаскивайте карту одним пальцем; "
                + "сводите или разводите два пальца для масштаба. Долгое касание отдаёт приказ без смены выделения.\n\n"
                + "«Строить» → выберите здание и коснитесь места. «Отмена» или «Назад» отменяет размещение. Для существ нужна работающая генолаборатория. "
                + "«Действия» позволяют заготавливать и перерабатывать древесину, исследовать существ и сажать деревья. "
                + "Целлюлозатор перерабатывает древесину для улучшений. Выделите готовую постройку и улучшите её через «Действия». "
                + "Геномашина позволяет создавать гибридов. Посадочная площадка приглашает специалистов, а детектор вызывает эфириалов. "
                + "Следите за энергией и целью задания.\n\n"
                + "В меню доступны сохранение и загрузка. При сворачивании игра сохраняется автоматически. "
                + "«Поворот» меняет положение камеры вокруг трёхмерной сцены. «3D HD/Эко» меняет детализацию вывода.\n\n"
                + "Это нативная реконструкция 0.3: используются карты оригинала и новые трёхмерные модели, "
                + "но игровая механика, задания и баланс пока восстановлены частично. "
                + "Сохранения этой версии не совместимы с DOS-игрой.";
        showModal(new AlertDialog.Builder(this).setTitle("Как играть").setMessage(instructions).setPositiveButton("Понятно", null));
    }

    private void showSettings() {
        final String[] items = {"Высокая детализация 3D", "Отключить звук"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle("Настройки")
                .setMultiChoiceItems(items, new boolean[]{smooth, muted}, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which, boolean value) {
                        if (which == 0) smooth = value; else muted = value;
                        savePreferences(); updateToolLabels();
                        if (world != null) world.requestSceneFrame();
                    }
                }).setPositiveButton("Готово", null);
        if (repository != null && !repository.music.isEmpty()) builder.setNeutralButton("Музыка", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) { showMusicMenu(); }
        });
        showModal(builder);
    }

    private void showMusicMenu() {
        String[] names = new String[repository.music.size()];
        for (int i = 0; i < names.length; i++) names[i] = "Дорожка " + (i + 1);
        showModal(new AlertDialog.Builder(this).setTitle("Оригинальная музыка")
                .setSingleChoiceItems(names, Math.min(musicTrack, names.length - 1), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        musicTrack = which;
                        preferences.edit().putInt("musicTrack", which).apply();
                        prepareMusic(); dialog.dismiss();
                    }
                }).setNegativeButton("Назад", null));
    }

    private void savePreferences() {
        preferences.edit().putBoolean("graphics3dHigh", smooth).putBoolean("muted", muted).apply();
        updateAudioPlayback();
    }

    private File saveFile() { return new File(getFilesDir(), "game-v1.gws"); }

    private void saveGame(boolean notify) {
        if (game == null) return;
        try {
            game.saveAtomic(saveFile());
            if (notify) Toast.makeText(this, "Игра сохранена", Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            Toast.makeText(this, "Не удалось сохранить игру: " + errorText(exception), Toast.LENGTH_LONG).show();
        }
    }

    private void scheduleAudioAfterFirstDraw(final View content) {
        if (audioPreparationStarted) return;
        content.getViewTreeObserver().addOnDrawListener(new ViewTreeObserver.OnDrawListener() {
            private boolean posted;
            @Override public void onDraw() {
                if (posted) return;
                posted = true;
                final ViewTreeObserver.OnDrawListener listener = this;
                content.post(new Runnable() {
                    @Override public void run() {
                        if (content.getViewTreeObserver().isAlive()) content.getViewTreeObserver().removeOnDrawListener(listener);
                        if (destroyed || audioPreparationStarted) return;
                        audioPreparationStarted = true;
                        prepareAudio();
                        prepareMusic();
                    }
                });
            }
        });
    }

    private void prepareAudio() {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    AudioAttributes attributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                    final SoundPool preparedPool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attributes).build();
                    final Map<String, Integer> ids = new HashMap<String, Integer>();
                    preparedPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                        @Override public void onLoadComplete(SoundPool pool, int sampleId, int status) {
                            loadedSounds.put(sampleId, status == 0);
                        }
                    });
                    for (Map.Entry<String, String> entry : repository.sounds.entrySet()) {
                        try (AssetFileDescriptor descriptor = getAssets().openFd(entry.getValue())) {
                            ids.put(entry.getKey(), preparedPool.load(descriptor, 1));
                        } catch (Exception exception) {
                            android.util.Log.w("GeneWars", "Sound not loaded: " + entry.getKey(), exception);
                        }
                    }
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed) { preparedPool.release(); return; }
                            soundPool = preparedPool; soundIds.putAll(ids); updateAudioPlayback();
                        }
                    });
                } catch (Exception exception) { android.util.Log.w("GeneWars", "Sound initialization unavailable", exception); }
            }
        }, "native-sound-load").start();
    }

    private void playSound(String event) {
        if (muted || soundPool == null) return;
        String key = event;
        if ("win".equals(event)) key = "complete";
        else if ("birth".equals(event)) key = "build";
        Integer id = soundIds.get(key);
        if (id != null && Boolean.TRUE.equals(loadedSounds.get(id))) soundPool.play(id, .65f, .65f, 1, 0, 1f);
    }

    private void prepareMusic() {
        if (repository.music.isEmpty()) return;
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; }
        musicReady = false; musicFinished = false;
        musicTrack = Math.max(0, Math.min(repository.music.size() - 1, musicTrack));
        final String musicPath = repository.music.get(musicTrack);
        final int generation = ++musicGeneration;
        new Thread(new Runnable() {
            @Override public void run() {
                MediaPlayer pending = null;
                try {
                    final MediaPlayer player = new MediaPlayer(); pending = player;
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    try (AssetFileDescriptor descriptor = getAssets().openFd(musicPath)) {
                        player.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                    }
                    player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override public void onPrepared(final MediaPlayer prepared) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (destroyed || generation != musicGeneration) return;
                                    musicPlayer = prepared; musicReady = true;
                                    prepared.setLooping(false); prepared.setVolume(.28f, .28f);
                                    android.util.Log.i("GeneWars", "Original MIDI track prepared"); updateAudioPlayback();
                                }
                            });
                        }
                    });
                    player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override public void onCompletion(MediaPlayer completed) {
                            if (generation == musicGeneration && completed == musicPlayer) musicFinished = true;
                        }
                    });
                    player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                        @Override public boolean onError(MediaPlayer failed, int what, int extra) {
                            if (generation == musicGeneration && failed == musicPlayer) musicReady = false;
                            android.util.Log.w("GeneWars", "Music playback unavailable: " + what + "/" + extra); return true;
                        }
                    });
                    player.prepareAsync();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (destroyed || generation != musicGeneration) { player.release(); return; }
                            if (musicPlayer == null) musicPlayer = player;
                        }
                    });
                } catch (final Exception exception) {
                    if (pending != null) pending.release();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (generation == musicGeneration) { musicPlayer = null; musicReady = false; }
                            android.util.Log.w("GeneWars", "Music could not be prepared", exception);
                        }
                    });
                }
            }
        }, "native-music-load").start();
    }

    private void updateAudioPlayback() {
        if (soundPool != null) {
            if (resumed && !muted) soundPool.autoResume(); else soundPool.autoPause();
        }
        if (musicPlayer != null && musicReady) {
            try {
                if (resumed && !muted && !musicFinished) musicPlayer.start();
                else if (musicPlayer.isPlaying()) musicPlayer.pause();
            } catch (IllegalStateException exception) {
                musicReady = false;
                android.util.Log.w("GeneWars", "Music state changed", exception);
            }
        }
    }

    private void showError(String title, Exception exception) {
        showModal(new AlertDialog.Builder(this).setTitle(title).setMessage(errorText(exception)).setPositiveButton("Понятно", null));
    }

    /** Keep the game stationary under modal UI without changing manual pause. */
    private AlertDialog showModal(AlertDialog.Builder builder) {
        final boolean pausesWorld = game != null && world != null;
        final AlertDialog dialog = builder.create();
        if (pausesWorld) { modalDepth++; world.stop(); }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface ignored) {
                if (pausesWorld) modalDepth = Math.max(0, modalDepth - 1);
                if (!destroyed && resumed && !loadingGame && modalDepth == 0 && world != null) world.start();
            }
        });
        dialog.show();
        return dialog;
    }

    private void showFatal(String title, Exception exception) {
        page = basePage();
        TextView failure = text(title + "\n\n" + errorText(exception), 18);
        page.addView(failure, new LinearLayout.LayoutParams(-1, 0, 1f));
        page.addView(button("Закрыть", new Runnable() { @Override public void run() { finish(); } }));
        setContentView(page);
    }

    private String errorText(Exception exception) {
        android.util.Log.e("GeneWars", "Operation failed", exception);
        String detail = exception.getMessage();
        if (exception instanceof java.io.FileNotFoundException) return "Необходимый файл не найден.";
        if (detail != null) {
            String lower = detail.toLowerCase(Locale.ROOT);
            if (lower.contains("enospc") || lower.contains("no space")) return "Недостаточно свободного места на устройстве.";
            if (lower.contains("crc") || lower.contains("version") || lower.contains("invalid")
                    || lower.contains("truncated") || lower.contains("magic") || lower.contains("unsupported"))
                return "Файл повреждён или несовместим с этой версией.";
            if (detail.matches(".*[А-Яа-яЁё].*")) return detail;
        }
        return "Не удалось обработать игровые данные.";
    }

    private TextView text(String value, int size) {
        TextView label = new TextView(this);
        label.setText(value); label.setTextColor(FOREGROUND); label.setTextSize(size);
        label.setPadding(dp(4), dp(2), dp(4), dp(2));
        return label;
    }

    private Button button(String label, final Runnable action) {
        Button button = new Button(this);
        button.setText(label); button.setTextSize(13); button.setAllCaps(false);
        button.setMinimumHeight(dp(48)); button.setMinHeight(dp(48));
        button.setTextColor(FOREGROUND);
        ModernUiSkin.styleButton(button, false);
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { action.run(); }
        });
        return button;
    }

    private Button addTool(LinearLayout bar, String label, Runnable action) {
        Button button = button(label, action);
        button.setCompoundDrawablesWithIntrinsicBounds(ModernUiSkin.icon(this, label), null, null, null);
        button.setCompoundDrawablePadding(dp(6));
        LinearLayout.LayoutParams parameters = new LinearLayout.LayoutParams(-2, dp(50)); parameters.rightMargin = dp(6);
        bar.addView(button, parameters);
        return button;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private String unitName(Unit unit) {
        switch (unit.kind) {
            case ENGINEER: return "Инженер";
            case BOTANIST: return "Ботаник";
            case GENETICIST: return "Генетик";
            case RANGER: return "Егерь";
            default:
                String[] species = {"Дино", "Краб", "Лягушка", "Птица", "Мул"};
                return unit.species >= 0 && unit.species < 5 ? species[unit.species] : "Гибрид";
        }
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void stopWorld() { if (world != null) { world.release(); world = null; } }
    @Override protected void onPause() {
        resumed = false;
        saveGame(false);
        if (world != null) world.pauseSurface();
        if (loadingPreviousWorld != null) loadingPreviousWorld.pauseSurface();
        updateAudioPlayback();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume(); resumed = true; hideSystemBars();
        if (world != null && modalDepth == 0 && !loadingGame) world.start();
        updateAudioPlayback();
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        saveGame(false); state.putBoolean("playing", game != null); super.onSaveInstanceState(state);
    }
    @Override protected void onDestroy() {
        destroyed = true; resumed = false; stopWorld();
        ++loadingGeneration; ++musicGeneration;
        if (activeWorldLoad != null) activeWorldLoad.cancel(true);
        worldLoader.shutdownNow();
        if (loadingPreviousWorld != null) loadingPreviousWorld.stop();
        clearPreviousLoad();
        if (repository != null) repository.close();
        if (soundPool != null) { soundPool.release(); soundPool = null; }
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; musicReady = false; }
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (loadingGame) cancelGameLoad();
        else if (world != null && world.hasPlacement()) world.cancelPlacement();
        else if (game != null) showPauseMenu();
        else super.onBackPressed();
    }

    /** A real OpenGL scene with a separate native overlay, never actor billboards. */
    private final class WorldView extends FrameLayout {
        final GameState state;
        private final GLSurfaceView surface;
        private final Scene3DRenderer scene;
        private final Camera3D camera;
        private final Overlay overlay;
        private final GestureDetector gestures;
        private final ScaleGestureDetector scales;
        private boolean running, released, surfacePaused, secondaryGesture;
        private float visualTime, lastTwist = Float.NaN;
        private long previousFrame;
        private Building.Kind buildMode;
        private boolean plantMode;
        private float[] placementPoint;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                if (!running || released || destroyed) return;
                long now = android.os.SystemClock.uptimeMillis();
                float dt = (float)Math.min(.15, Math.max(0, (now - previousFrame) / 1000.0));
                previousFrame = now;
                state.update(dt * speed);
                if (!state.paused) visualTime += dt;
                frameUpdated();
                requestSceneFrame();
                if (running) postDelayed(this, 40);
            }
        };

        WorldView(GameState state) {
            super(MainActivity.this);
            this.state = state;
            setFocusable(true);
            setContentDescription("Карта планеты. Трёхмерная сцена. Касание: выделить или отдать приказ. Перетаскивание: прокрутка. Два пальца: масштаб и поворот.");
            camera = new Camera3D(state.map);
            scene = new Scene3DRenderer(getAssets(), camera);
            surface = new GLSurfaceView(MainActivity.this);
            surface.setEGLContextClientVersion(3);
            surface.setEGLConfigChooser(8, 8, 8, 0, 24, 0);
            surface.setPreserveEGLContextOnPause(true);
            surface.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            surface.setRenderer(scene);
            surface.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
            addView(surface, new FrameLayout.LayoutParams(-1, -1));
            overlay = new Overlay();
            overlay.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            addView(overlay, new FrameLayout.LayoutParams(-1, -1));
            centerOnTeam();
            scales = new ScaleGestureDetector(MainActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    camera.zoom(detector.getScaleFactor()); requestSceneFrame(); return true;
                }
            });
            gestures = new GestureDetector(MainActivity.this, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent event) { return true; }
                @Override public boolean onScroll(MotionEvent first, MotionEvent second, float dx, float dy) {
                    if (second.getPointerCount() == 1 && !scales.isInProgress()) {
                        camera.panScreen(dx, dy); requestSceneFrame();
                    }
                    return true;
                }
                @Override public boolean onSingleTapConfirmed(MotionEvent event) {
                    tap(event.getX(), event.getY(), false); performClick(); return true;
                }
                @Override public void onLongPress(MotionEvent event) { tap(event.getX(), event.getY(), true); }
                @Override public boolean onDoubleTap(MotionEvent event) {
                    camera.zoom(camera.zoomLevel() > 1.7f ? .62f : 1.35f); requestSceneFrame(); return true;
                }
            });
        }

        void start() {
            if (released) return;
            if (surfacePaused) { surface.onResume(); surfacePaused = false; }
            if (!running) { running = true; previousFrame = android.os.SystemClock.uptimeMillis(); post(frame); }
            requestSceneFrame();
        }
        void stop() { running = false; removeCallbacks(frame); }
        void pauseSurface() {
            stop();
            if (!released && !surfacePaused) { surface.onPause(); surfacePaused = true; }
        }
        void release() {
            if (released) return;
            stop(); released = true; scene.close();
            if (!surfacePaused) { surface.onPause(); surfacePaused = true; }
            removeView(surface);
        }
        void requestSceneFrame() {
            if (released || destroyed) return;
            // Capture is called only on the UI/game thread; the GL thread receives
            // immutable value records and never reads GameState's mutable lists.
            scene.setHighQuality(smooth);
            scene.submitFrame(Scene3DFrame.capture(state, visualTime, smooth));
            if (!surfacePaused) surface.requestRender();
            overlay.invalidate();
        }
        void onGameEvent(String event) { if (!released) overlay.invalidate(); }
        void rotateCamera() { camera.orbit(45, 0); requestSceneFrame(); }
        void centerOnTeam() {
            Unit selected = state.selectedUnit();
            if (selected != null && selected.team == 0 && selected.hp > 0) {
                camera.centerOn((float)selected.x, (float)selected.y); requestSceneFrame(); return;
            }
            for (Unit unit : state.units) if (unit.team == 0 && unit.hp > 0) {
                camera.centerOn((float)unit.x, (float)unit.y); requestSceneFrame(); return;
            }
            camera.centerOn(state.map.width * .5f, state.map.height * .5f); requestSceneFrame();
        }
        boolean hasPlacement() { return buildMode != null || plantMode; }
        void cancelPlacement() {
            buildMode = null; plantMode = false; placementPoint = null;
            if (placementButton != null) placementButton.setVisibility(View.GONE);
            overlay.invalidate();
        }
        void beginBuilding(Building.Kind kind) {
            cancelPlacement(); buildMode = kind;
            if (placementButton != null) placementButton.setVisibility(View.VISIBLE);
            overlay.invalidate();
        }
        void beginPlanting() {
            cancelPlacement(); plantMode = true;
            if (placementButton != null) placementButton.setVisibility(View.VISIBLE);
            overlay.invalidate();
        }
        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            super.onSizeChanged(width, height, oldWidth, oldHeight);
            camera.setViewport(width, height); requestSceneFrame();
        }
        @Override public boolean onInterceptTouchEvent(MotionEvent event) { return true; }

        private float[] projected(double x, double z, float aboveGround) {
            return camera.project((float)x, Camera3D.heightAt(state.map, (float)x, (float)z) + aboveGround, (float)z);
        }
        private float distanceTo(float[] projected, float x, float y) {
            if (projected == null || projected.length < 2 || !Float.isFinite(projected[0]) || !Float.isFinite(projected[1])) return Float.POSITIVE_INFINITY;
            float dx = projected[0] - x, dy = projected[1] - y; return dx * dx + dy * dy;
        }
        private void tap(float screenX, float screenY, boolean commandOnly) {
            float[] ground = camera.pickGround(screenX, screenY);
            if (ground == null || ground.length < 2) return;
            if (buildMode != null) {
                boolean accepted = state.build(buildMode, ground[0], ground[1]);
                showCommandResult(accepted); if (accepted) cancelPlacement(); requestSceneFrame(); return;
            }
            if (plantMode) {
                boolean accepted = state.plantTree(ground[0], ground[1]);
                showCommandResult(accepted); if (accepted) cancelPlacement(); requestSceneFrame(); return;
            }
            if (!commandOnly) {
                Unit best = null; float nearest = dp(29) * dp(29);
                for (Unit unit : state.units) if (unit.team == 0 && unit.hp > 0) {
                    float distance = distanceTo(projected(unit.x, unit.y, .65f), screenX, screenY);
                    if (distance < nearest) { nearest = distance; best = unit; }
                }
                if (best != null) { state.select(best.id); updateHud(); requestSceneFrame(); return; }
                Building nearestBuilding = null; float buildingDistance = dp(40) * dp(40);
                for (Building building : state.buildings) if (building.team == 0 && building.hp > 0) {
                    float distance = distanceTo(projected(building.x, building.y, 1.1f), screenX, screenY);
                    if (distance < buildingDistance) { buildingDistance = distance; nearestBuilding = building; }
                }
                if (nearestBuilding != null) {
                    Unit selected = state.selectedUnit();
                    if (selected != null && selected.kind == Unit.Kind.ENGINEER
                            && (nearestBuilding.progress < 1 || nearestBuilding.hp < nearestBuilding.maxHp))
                        showCommandResult(state.commandSelected(nearestBuilding.x, nearestBuilding.y));
                    else { state.select(nearestBuilding.id); updateHud(); }
                    requestSceneFrame(); return;
                }
            }
            double targetX = ground[0], targetZ = ground[1];
            float hitDistance = dp(31) * dp(31);
            for (Unit unit : state.units) if (unit.team != 0 && unit.hp > 0) {
                float distance = distanceTo(projected(unit.x, unit.y, .6f), screenX, screenY);
                if (distance < hitDistance) { hitDistance = distance; targetX = unit.x; targetZ = unit.y; }
            }
            for (Building building : state.buildings) if (building.team != 0 && building.hp > 0) {
                float distance = distanceTo(projected(building.x, building.y, 1.2f), screenX, screenY);
                if (distance < hitDistance) { hitDistance = distance; targetX = building.x; targetZ = building.y; }
            }
            for (Plant plant : state.plants) if (plant.biomass > 0) {
                float distance = distanceTo(projected(plant.x, plant.y, .8f), screenX, screenY);
                if (distance < hitDistance) { hitDistance = distance; targetX = plant.x; targetZ = plant.y; }
            }
            showCommandResult(state.commandSelected(targetX, targetZ)); requestSceneFrame();
        }
        @Override public boolean onTouchEvent(MotionEvent event) {
            if (released) return false;
            int secondary = MotionEvent.BUTTON_SECONDARY | MotionEvent.BUTTON_STYLUS_PRIMARY;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN && (event.getButtonState() & secondary) != 0) {
                if (!secondaryGesture) secondaryCommand(event); secondaryGesture = true; return true;
            }
            if (secondaryGesture) {
                if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) secondaryGesture = false;
                return true;
            }
            if (event.getPointerCount() >= 2) {
                float angle = (float)Math.toDegrees(Math.atan2(event.getY(1) - event.getY(0), event.getX(1) - event.getX(0)));
                if (event.getActionMasked() == MotionEvent.ACTION_MOVE && Float.isFinite(lastTwist)) {
                    float delta = angle - lastTwist;
                    if (delta > 180) delta -= 360; else if (delta < -180) delta += 360;
                    if (Math.abs(delta) < 35) { camera.orbit(delta, 0); requestSceneFrame(); }
                }
                lastTwist = angle;
            } else lastTwist = Float.NaN;
            if (hasPlacement() && event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                placementPoint = camera.pickGround(event.getX(), event.getY()); overlay.invalidate();
            }
            scales.onTouchEvent(event); gestures.onTouchEvent(event); return true;
        }
        @Override public boolean onGenericMotionEvent(MotionEvent event) {
            int secondary = MotionEvent.BUTTON_SECONDARY | MotionEvent.BUTTON_STYLUS_PRIMARY;
            if ((event.getActionButton() & secondary) != 0) {
                if (event.getActionMasked() == MotionEvent.ACTION_BUTTON_PRESS) {
                    if (!secondaryGesture) secondaryCommand(event); secondaryGesture = true; return true;
                }
                if (event.getActionMasked() == MotionEvent.ACTION_BUTTON_RELEASE) { secondaryGesture = false; return true; }
            }
            if (event.getAction() == MotionEvent.ACTION_SCROLL) {
                camera.zoom(event.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0 ? 1.12f : .89f); requestSceneFrame(); return true;
            }
            return super.onGenericMotionEvent(event);
        }
        private void secondaryCommand(MotionEvent event) { if (hasPlacement()) cancelPlacement(); else tap(event.getX(), event.getY(), true); }
        @Override public boolean performClick() { return super.performClick(); }

        private final class Overlay extends View {
            private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF rectangle = new RectF();
            Overlay() { super(MainActivity.this); setClickable(false); }
            @Override protected void onDraw(Canvas canvas) {
                if (!scene.isReady()) {
                    float halfWidth = Math.min(dp(190), getWidth() * .45f), middleX = getWidth() * .5f, middleY = getHeight() * .5f;
                    paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(235, 8, 24, 33));
                    rectangle.set(middleX - halfWidth, middleY - dp(37), middleX + halfWidth, middleY + dp(37));
                    canvas.drawRoundRect(rectangle, dp(14), dp(14), paint);
                    paint.setTextAlign(Paint.Align.CENTER); paint.setColor(FOREGROUND); paint.setTextSize(dp(15));
                    canvas.drawText("Загрузка планеты…", middleX, middleY - dp(2), paint);
                    paint.setColor(ACCENT); paint.setTextSize(dp(11));
                    canvas.drawText("Подготовка к высадке", middleX, middleY + dp(19), paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                    return;
                }
                paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(210, 8, 24, 33));
                rectangle.set(dp(10), dp(10), dp(210), dp(40)); canvas.drawRoundRect(rectangle, dp(12), dp(12), paint);
                paint.setColor(FOREGROUND); paint.setTextSize(dp(11));
                canvas.drawText("3D  ·  " + (int)camera.yawDegrees() + "°  ·  " + String.format(Locale.ROOT, "%.1f", camera.zoomLevel()) + "×", dp(23), dp(29), paint);
                int bars = 0;
                for (Unit unit : state.units) if (unit.hp > 0 && (unit.hp < unit.maxHp || unit.id == state.selectedId)) {
                    if (bars++ > 48 && unit.id != state.selectedId) continue;
                    drawBar(canvas, projected(unit.x, unit.y, 1.65f), unit.hp / unit.maxHp, unit.team == 0 ? ACCENT : Color.rgb(245, 125, 106));
                }
                for (Building building : state.buildings) if (building.hp > 0 && (building.hp < building.maxHp || building.progress < 1)) {
                    if (bars++ > 64) break;
                    drawBar(canvas, projected(building.x, building.y, 2.5f), building.progress < 1 ? building.progress : building.hp / building.maxHp,
                            building.progress < 1 ? ModernUiSkin.GOLD : ACCENT);
                }
                if (hasPlacement()) {
                    if (placementPoint != null && placementPoint.length >= 2) {
                        float[] point = projected(placementPoint[0], placementPoint[1], .03f);
                        if (point != null) {
                            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setColor(ACCENT);
                            canvas.drawCircle(point[0], point[1], dp(18), paint); paint.setStyle(Paint.Style.FILL);
                        }
                    }
                    paint.setColor(Color.argb(225, 8, 24, 33)); rectangle.set(dp(8), getHeight() - dp(42), getWidth() - dp(8), getHeight() - dp(8));
                    canvas.drawRoundRect(rectangle, dp(9), dp(9), paint); paint.setColor(ACCENT); paint.setTextSize(dp(12));
                    canvas.drawText(buildMode != null ? "Коснитесь поверхности: " + buildMode.title : "Коснитесь поверхности: посадить дерево", dp(17), getHeight() - dp(21), paint);
                }
            }
            private void drawBar(Canvas canvas, float[] point, double fraction, int color) {
                if (point == null || point[0] < -30 || point[0] > getWidth() + 30 || point[1] < 40 || point[1] > getHeight() + 30) return;
                float width = dp(30);
                paint.setColor(Color.argb(220, 7, 17, 25)); rectangle.set(point[0] - width / 2, point[1], point[0] + width / 2, point[1] + dp(4));
                canvas.drawRoundRect(rectangle, dp(2), dp(2), paint);
                paint.setColor(color); rectangle.right = rectangle.left + width * (float)Math.max(0, Math.min(1, fraction));
                canvas.drawRoundRect(rectangle, dp(2), dp(2), paint);
            }
        }
    }
}
