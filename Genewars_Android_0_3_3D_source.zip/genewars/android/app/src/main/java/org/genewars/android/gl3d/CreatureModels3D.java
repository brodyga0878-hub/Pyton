package org.genewars.android.gl3d;

/** Articulated solid creature meshes. +Z is the animal's forward direction. */
final class CreatureModels3D {
    private static final int[][] GENES={{0,0},{1,1},{2,2},{3,3},{4,4},{0,1},{0,2},{0,3},{0,4},
            {1,2},{1,3},{1,4},{2,3},{2,4},{3,4},{1,0},{2,0},{2,1},{3,0},{3,1},{3,2},{4,0},{4,1},{4,2},{4,3}};
    private static final float[][] PALETTE={{.23f,.49f,.29f,0},{.13f,.45f,.48f,0},{.41f,.53f,.17f,0},
            {.37f,.24f,.58f,0},{.37f,.31f,.23f,0}};
    private static final float[] IVORY={.83f,.80f,.63f,0},DARK={.09f,.13f,.14f,0},COPPER={.60f,.34f,.13f,0},
            EYE={.92f,.86f,.49f,.05f},PUPIL={.025f,.045f,.05f,0},GLOW={.12f,.78f,.79f,.55f};
    private static final class Rig {
        final MeshBuilder3D b;final int primary,secondary,body;
        final float[] skin,light,accent;
        final int[] feet=new int[8];final float[][] footAt=new float[8][3];int legCount;
        float y,rx,ry,rz,headY,headZ,headRY,headRZ;int head;
        Rig(int id){
            primary=GENES[id][0];secondary=GENES[id][1];b=new MeshBuilder3D("creature_"+id);
            skin=mix(PALETTE[primary],PALETTE[secondary],primary==secondary?0:.32f);
            light=mix(skin,IVORY,.35f);accent=mix(PALETTE[secondary],COPPER,.35f);
            y=primary==0?.62f:primary==1?.43f:primary==2?.32f:primary==3?.67f:.52f;
            rx=primary==0?.30f:primary==1?.46f:primary==2?.38f:primary==3?.27f:.36f;
            ry=primary==0?.33f:primary==1?.20f:primary==2?.25f:primary==3?.30f:.30f;
            rz=primary==0?.47f:primary==1?.40f:primary==2?.40f:primary==3?.38f:.51f;
            if(primary!=secondary&&secondary==4){rx*=1.10f;rz*=1.08f;}
            body=b.bone("thorax",0,0,y,0,Bone3D.ROOT,id*.37f,.02f);
        }
    }
    static MeshData3D build(int id){
        if(id<0||id>=25)throw new IllegalArgumentException("Creature species");
        Rig r=new Rig(id);MeshBuilder3D b=r.b;
        b.ellipsoid(0,r.y,0,r.rx,r.ry,r.rz,14,9,r.skin,r.body);
        b.ellipsoid(0,r.y-r.ry*.36f,r.rz*.16f,r.rx*.88f,r.ry*.72f,r.rz*.88f,12,7,r.light,r.body);
        if(r.primary==0)makeDinosaur(r);
        else if(r.primary==1)makeCrab(r);
        else if(r.primary==2)makeFrog(r);
        else if(r.primary==3)makeBird(r);
        else makeMule(r);
        if(r.primary!=r.secondary)addSecondary(r);
        // Biological plating and small material accents make the silhouette
        // readable without baking highlights into a flat billboard.
        if(r.primary!=1)for(int i=0;i<4;i++){
            float z=-r.rz*.65f+i*r.rz*.37f;
            b.ellipsoid(0,r.y+r.ry*.85f,z,r.rx*.58f,.055f,r.rz*.16f,8,4,r.accent,r.body);
        }
        return b.finish();
    }
    private static float[]mix(float[]a,float[]b,float f){return new float[]{a[0]*(1-f)+b[0]*f,a[1]*(1-f)+b[1]*f,a[2]*(1-f)+b[2]*f,0};}
    private static void leg(Rig r,float x,float z,float kneeX,float kneeZ,float footX,float footZ,float phase,boolean longLeg){
        MeshBuilder3D b=r.b;float hipY=r.y-r.ry*.28f,kneeY=longLeg?.28f:.17f;
        int upper=b.bone("leg"+r.legCount+"_hip",r.body,x,hipY,z,Bone3D.SWING_X,phase,.46f);
        int lower=b.bone("leg"+r.legCount+"_knee",upper,kneeX,kneeY,kneeZ,Bone3D.KNEE_X,phase+1.4f,.66f);
        float radius=r.primary==4?.075f:r.primary==1?.045f:.06f;
        b.cylinder(x,hipY,z,kneeX,kneeY,kneeZ,radius*1.35f,radius,9,r.skin,upper);
        b.ellipsoid(kneeX,kneeY,kneeZ,radius*1.22f,radius*1.2f,radius*1.2f,8,5,r.accent,lower);
        b.cylinder(kneeX,kneeY,kneeZ,footX,.065f,footZ,radius*.86f,radius*.64f,8,r.skin,lower);
        b.ellipsoid(footX,.055f,footZ+.035f,radius*1.3f,.05f,radius*1.8f,9,5,DARK,lower);
        r.feet[r.legCount]=lower;r.footAt[r.legCount][0]=footX;r.footAt[r.legCount][1]=.045f;r.footAt[r.legCount][2]=footZ;r.legCount++;
    }
    private static void makeDinosaur(Rig r){
        leg(r,-.20f,-.13f,-.24f,-.03f,-.24f,.13f,0,true);
        leg(r,.20f,-.13f,.24f,-.03f,.24f,.13f,(float)Math.PI,true);
        head(r,0,1.04f,.46f,.22f,.21f,.30f,0);
        for(int side=-1;side<=1;side+=2){
            int arm=r.b.bone("little_arm_"+side,r.body,side*.22f,.76f,.25f,Bone3D.WORK_ARM_X,side<0?0:(float)Math.PI,.75f);
            r.b.cylinder(side*.22f,.76f,.25f,side*.29f,.52f,.47f,.048f,.033f,8,r.skin,arm);
            r.b.ellipsoid(side*.29f,.52f,.47f,.045f,.04f,.065f,8,4,IVORY,arm);
        }
        tail(r,1.0f);spines(r,7,.13f);
    }
    private static void makeCrab(Rig r){
        for(int side=-1;side<=1;side+=2)for(int i=0;i<3;i++){
            float z=-.27f+i*.25f;
            leg(r,side*.35f,z,side*.61f,z-.08f,side*.71f,z+.04f,(i+(side>0?1:0))*(float)Math.PI/2,false);
        }
        shell(r,true);
        r.head=r.b.bone("eye_stalks",r.body,0,.54f,.29f,Bone3D.HEAD_Y,0,.07f);
        r.headY=.57f;r.headZ=.20f;r.headRY=.12f;r.headRZ=.16f;
        for(int side=-1;side<=1;side+=2){
            r.b.cylinder(side*.17f,.55f,.29f,side*.22f,.76f,.36f,.025f,.018f,8,r.accent,r.head);
            eye(r.b,side*.22f,.77f,.37f,.052f,r.head);
        }
        claws(r,true);
    }
    private static void makeFrog(Rig r){
        leg(r,-.28f,-.24f,-.43f,.00f,-.43f,.22f,0,false);
        leg(r,.28f,-.24f,.43f,.00f,.43f,.22f,(float)Math.PI,false);
        leg(r,-.25f,.22f,-.30f,.40f,-.31f,.58f,(float)Math.PI,false);
        leg(r,.25f,.22f,.30f,.40f,.31f,.58f,0,false);
        r.b.ellipsoid(-.32f,.30f,-.20f,.19f,.19f,.23f,10,6,r.skin,r.body);
        r.b.ellipsoid(.32f,.30f,-.20f,.19f,.19f,.23f,10,6,r.skin,r.body);
        head(r,0,.53f,.29f,.32f,.20f,.28f,2);spots(r);webFeet(r);
    }
    private static void makeBird(Rig r){
        leg(r,-.13f,.02f,-.15f,.21f,-.17f,.29f,0,true);
        leg(r,.13f,.02f,.15f,.21f,.17f,.29f,(float)Math.PI,true);
        head(r,0,1.04f,.30f,.18f,.21f,.19f,3);
        wings(r,.72f);crest(r,4);tail(r,.52f);
    }
    private static void makeMule(Rig r){
        for(int side=-1;side<=1;side+=2){
            leg(r,side*.25f,-.32f,side*.27f,-.31f,side*.28f,-.29f,side<0?0:(float)Math.PI,true);
            leg(r,side*.25f,.31f,side*.27f,.36f,side*.28f,.40f,side<0?(float)Math.PI:0,true);
        }
        head(r,0,.88f,.56f,.21f,.25f,.27f,4);pack(r);tail(r,.48f);
    }
    private static void head(Rig r,float x,float y,float z,float rx,float ry,float rz,int kind){
        MeshBuilder3D b=r.b;
        r.headY=y;r.headZ=z;r.headRY=ry;r.headRZ=rz;
        r.head=b.bone("head",r.body,x,y-ry*.65f,z-rz*.32f,Bone3D.HEAD_Y,.3f,.055f);
        b.cylinder(0,r.y+.06f,r.rz*.48f,x,y,z-rz*.15f,rx*.64f,rx*.70f,10,r.skin,r.head);
        b.ellipsoid(x,y,z,rx,ry,rz,14,8,r.skin,r.head);
        int jaw=b.bone("jaw",r.head,x,y-ry*.32f,z,Bone3D.JAW_X,0,.26f);
        if(kind==3){
            b.cylinder(0,y-.01f,z+rz*.7f,0,y-.03f,z+rz+.20f,.095f,.008f,8,COPPER,r.head);
            b.cylinder(0,y-.07f,z+rz*.67f,0,y-.055f,z+rz+.16f,.065f,.003f,8,IVORY,jaw);
        }else{
            b.ellipsoid(x,y-ry*.33f,z+rz*.65f,rx*.89f,ry*.50f,rz*.67f,12,6,r.light,r.head);
            b.ellipsoid(x,y-ry*.63f,z+rz*.64f,rx*.82f,ry*.25f,rz*.62f,10,5,r.accent,jaw);
            for(int side=-1;side<=1;side+=2){
                b.ellipsoid(side*rx*.36f,y-ry*.25f,z+rz*1.25f,.023f,.018f,.009f,7,4,DARK,r.head);
                if(kind==0)b.cylinder(side*rx*.65f,y-ry*.38f,z+rz*.93f,side*rx*.63f,y-ry*.60f,z+rz*.95f,.028f,.003f,7,IVORY,r.head);
            }
        }
        for(int side=-1;side<=1;side+=2){
            float ey=kind==2?y+ry*.75f:y+ry*.28f;
            float ez=kind==2?z+rz*.50f:z+rz*.47f;
            if(kind==2)b.ellipsoid(side*rx*.69f,ey,ez,.087f,.087f,.082f,10,6,r.light,r.head);
            eye(b,side*rx*.73f,ey,ez+(kind==2?.075f:.035f),kind==2?.055f:.045f,r.head);
            if(kind==4){
                b.ellipsoid(side*.13f,y+ry*.94f,z-rz*.20f,.065f,.18f,.055f,9,6,r.accent,r.head);
                b.cylinder(side*.16f,y-ry*.40f,z+rz*.80f,side*.23f,y-ry*.12f,z+rz*1.24f,.047f,.005f,8,IVORY,jaw);
            }
        }
    }
    private static void eye(MeshBuilder3D b,float x,float y,float z,float radius,int bone){
        b.ellipsoid(x,y,z,radius,radius*.91f,radius*.63f,9,6,EYE,bone);
        b.ellipsoid(x,y,z+radius*.52f,radius*.45f,radius*.60f,radius*.16f,8,5,PUPIL,bone);
        b.ellipsoid(x-radius*.16f,y+radius*.22f,z+radius*.66f,radius*.13f,radius*.15f,radius*.09f,6,4,IVORY,bone);
    }
    private static void shell(Rig r,boolean primary){
        MeshBuilder3D b=r.b;
        b.ellipsoid(0,r.y+r.ry*.42f,-.02f,r.rx*1.09f,r.ry*.88f,r.rz*1.04f,12,7,r.accent,r.body);
        for(int side=-1;side<=1;side+=2)for(int i=0;i<4;i++){
            float z=-r.rz*.62f+i*r.rz*.40f;
            b.cylinder(side*r.rx*.83f,r.y+r.ry*.75f,z,side*r.rx*1.19f,r.y+r.ry*1.18f,z-.04f,.055f,.001f,7,COPPER,r.body);
        }
        for(int i=0;i<3;i++)b.ellipsoid(0,r.y+r.ry*1.20f,-.2f+i*.2f,.115f,.025f,.13f,8,4,r.skin,r.body);
    }
    private static void claws(Rig r,boolean primary){
        MeshBuilder3D b=r.b;
        for(int side=-1;side<=1;side+=2){
            if(b.boneCount()>=22)return;
            float px=side*r.rx*.7f,py=r.y+.02f,pz=r.rz*.65f;
            int arm=b.bone("claw_arm_"+side,r.body,px,py,pz,Bone3D.WORK_ARM_X,side<0?0:2,.6f);
            float cx=side*(primary?.55f:.44f),cz=r.rz+.28f;
            b.cylinder(px,py,pz,cx,py-.12f,cz,.065f,.07f,9,r.skin,arm);
            b.ellipsoid(cx,py-.12f,cz,.14f,.12f,.18f,11,6,r.accent,arm);
            b.cylinder(cx-.075f,py-.12f,cz+.10f,cx-.028f,py-.12f,cz+.31f,.045f,.003f,8,IVORY,arm);
            b.cylinder(cx+.075f,py-.12f,cz+.10f,cx+.028f,py-.12f,cz+.31f,.045f,.003f,8,IVORY,arm);
        }
    }
    private static void tail(Rig r,float length){
        MeshBuilder3D b=r.b;
        int bone=b.bone("tail_base",r.body,0,r.y,-r.rz*.75f,Bone3D.TAIL_Y,0,.13f);
        int tip=b.bone("tail_tip",bone,0,r.y-.08f,-r.rz-length*.35f,Bone3D.TAIL_Y,1,.20f);
        b.cylinder(0,r.y,-r.rz*.7f,0,r.y-.08f,-r.rz-length*.35f,r.rx*.27f,.052f,10,r.skin,bone);
        b.cylinder(0,r.y-.08f,-r.rz-length*.35f,0,r.y+.02f,-r.rz-length,.055f,.004f,9,r.accent,tip);
        if(r.primary==3)for(int i=-1;i<=1;i++)b.ellipsoid(i*.055f,r.y,-r.rz-length*.74f,.06f,.04f,.19f,7,4,PALETTE[3],tip);
    }
    private static void wings(Rig r,float length){
        MeshBuilder3D b=r.b;
        for(int side=-1;side<=1;side+=2){
            if(b.boneCount()>=23)return;
            float x=side*r.rx*.72f,y=r.y+r.ry*.30f;
            int wing=b.bone("wing_"+side,r.body,x,y,-.05f,Bone3D.WING_Z,side<0?0:(float)Math.PI,side*.55f);
            b.ellipsoid(side*(r.rx*.75f+length*.30f),y-.015f,-.12f,length*.42f,.065f,.27f,10,5,PALETTE[3],wing);
            for(int i=0;i<5;i++){
                float outer=side*(r.rx*.76f+length*(.56f+i*.045f));
                float z=-.29f+i*.105f;
                b.cylinder(side*(r.rx*.75f+length*.30f),y-.025f,z,outer,y-.08f-i*.013f,z-.18f,.065f,.012f,7,i%2==0?PALETTE[3]:r.accent,wing);
            }
        }
    }
    private static void crest(Rig r,int count){
        // The feather roots follow each primary species' actual crown. A fixed
        // bird-height crown would leave a floating crest on crab/frog hybrids.
        for(int i=0;i<count;i++){
            float z=r.headZ+r.headRZ*.05f-i*r.headRZ*.35f;
            float y=r.headY+r.headRY*(.77f-i*.055f);
            r.b.cylinder(0,y,z,0,y+.17f-i*.012f,z-.085f,.047f,.002f,7,PALETTE[3],r.head);
        }
    }
    private static void spines(Rig r,int count,float height){
        for(int i=0;i<count;i++){
            float z=-r.rz*.8f+i*r.rz*1.50f/(count-1);
            r.b.cylinder(0,r.y+r.ry*.84f,z,0,r.y+r.ry+height*(.6f+.4f*(float)Math.sin(i)),z-.045f,.045f,.001f,7,COPPER,r.body);
        }
    }
    private static void spots(Rig r){
        for(int i=0;i<11;i++){
            float a=i*2.39996f,x=(float)Math.cos(a)*r.rx*.75f,z=(float)Math.sin(a)*r.rz*.75f;
            r.b.ellipsoid(x,r.y+r.ry*.75f,z,.047f,.025f,.051f,7,4,r.accent,r.body);
        }
    }
    private static void webFeet(Rig r){
        for(int i=0;i<r.legCount;i++)for(int toe=-1;toe<=1;toe++){
            float[]p=r.footAt[i];
            r.b.cylinder(p[0],p[1]+.008f,p[2],p[0]+toe*.07f,.028f,p[2]+.17f,.024f,.009f,6,r.light,r.feet[i]);
        }
    }
    private static void pack(Rig r){
        r.b.ellipsoid(0,r.y+r.ry*.75f,-.05f,r.rx*.88f,.11f,r.rz*.72f,12,5,COPPER,r.body);
        for(int side=-1;side<=1;side+=2){
            r.b.ellipsoid(side*r.rx*.85f,r.y+.04f,-.12f,.11f,.16f,.25f,9,6,r.accent,r.body);
            r.b.cylinder(side*r.rx*.85f,r.y+.23f,-.3f,side*r.rx*.85f,r.y+.23f,.12f,.015f,.015f,7,GLOW,r.body);
        }
    }
    private static void addSecondary(Rig r){
        switch(r.secondary){
            case 0:
                spines(r,6,.17f);
                if(r.primary!=3)tail(r,.42f);
                for(int i=0;i<r.legCount;i++){float[]p=r.footAt[i];for(int t=-1;t<=1;t++)r.b.cylinder(p[0]+t*.028f,.043f,p[2]+.05f,p[0]+t*.045f,.025f,p[2]+.145f,.018f,.001f,6,IVORY,r.feet[i]);}
                break;
            case 1:shell(r,false);if(r.primary!=1&&r.b.boneCount()<21)claws(r,false);break;
            case 2:spots(r);webFeet(r);r.b.ellipsoid(-r.rx*.8f,r.y-.05f,-.16f,.16f,.16f,.23f,9,5,r.skin,r.body);r.b.ellipsoid(r.rx*.8f,r.y-.05f,-.16f,.16f,.16f,.23f,9,5,r.skin,r.body);break;
            case 3:if(r.primary!=3)wings(r,.60f);crest(r,3);break;
            case 4:pack(r);for(int side=-1;side<=1;side+=2)r.b.cylinder(side*.18f,r.y+.27f,r.rz*.83f,side*.26f,r.y+.47f,r.rz+ .22f,.045f,.003f,8,IVORY,r.head);break;
            default:break;
        }
    }
}
