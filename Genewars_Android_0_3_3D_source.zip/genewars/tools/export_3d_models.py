#!/usr/bin/env python3
"""Export the production native 3D model library as skinned glTF 2.0 GLB files.

No alternate geometry or animation is constructed here. The Java adapter calls
ModelLibrary3D and MeshData3D.sampleLocalTRS from the Android production sources.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'android/app/src/main/java/org/genewars/android/gl3d'
SOURCES = ['Bone3D.java', 'MeshData3D.java', 'MeshBuilder3D.java', 'ModelLibrary3D.java',
           'CreatureModels3D.java', 'SpecialistModels3D.java', 'BuildingModels3D.java', 'PlantModels3D.java']
COMPONENT_BYTES = {5121: 1, 5123: 2, 5125: 4, 5126: 4}
TYPE_WIDTHS = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def floats(values, multiple: int, name: str) -> list[float]:
    if not isinstance(values, list) or not values or len(values) % multiple:
        raise ValueError(f'{name} has an invalid element count')
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
        raise ValueError(f'{name} must contain finite numbers')
    return [float(value) for value in values]


class Buffer:
    def __init__(self):
        self.data = bytearray()
        self.views = []
        self.accessors = []

    def add(self, values, kind: str, component=5126, bounds=False, target=None):
        width = TYPE_WIDTHS[kind]
        if not values or len(values) % width:
            raise ValueError('Accessor element count mismatch')
        while len(self.data) % 4:
            self.data.append(0)
        offset = len(self.data)
        code = {5121: 'B', 5123: 'H', 5125: 'I', 5126: 'f'}[component]
        payload = struct.pack('<' + code * len(values), *values)
        self.data.extend(payload)
        view = {'buffer': 0, 'byteOffset': offset, 'byteLength': len(payload)}
        if target is not None:
            view['target'] = target
        self.views.append(view)
        accessor = {'bufferView': len(self.views) - 1, 'byteOffset': 0,
                    'componentType': component, 'count': len(values) // width, 'type': kind}
        if bounds:
            accessor['min'] = [min(values[i::width]) for i in range(width)]
            accessor['max'] = [max(values[i::width]) for i in range(width)]
        self.accessors.append(accessor)
        return len(self.accessors) - 1


def matrix(t, q, s):
    x, y, z, w = q
    xx, yy, zz, xy, xz, yz, wx, wy, wz = x*x, y*y, z*z, x*y, x*z, y*z, w*x, w*y, w*z
    return [(1-2*(yy+zz))*s[0], 2*(xy+wz)*s[0], 2*(xz-wy)*s[0], 0,
            2*(xy-wz)*s[1], (1-2*(xx+zz))*s[1], 2*(yz+wx)*s[1], 0,
            2*(xz+wy)*s[2], 2*(yz-wx)*s[2], (1-2*(xx+yy))*s[2], 0, *t, 1]


def multiply(a, b):
    return [sum(a[k*4+r]*b[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]


def verify_native_skin(model):
    """Reconstruct glTF joint transforms and compare with independent native pose()."""
    worst = 0.0
    bones = model['bones']
    for clip in model['clips']:
        for check in clip.get('nativeSkinChecks', []):
            frame, world = check['frame'], []
            for j, bone in enumerate(bones):
                local = matrix(clip['translation'][frame][j*3:j*3+3],
                               clip['rotation'][frame][j*4:j*4+4], clip['scale'][frame][j*3:j*3+3])
                joint = local if bone['parent'] < 0 else multiply(world[bone['parent']], local)
                world.append(joint)
                inverse = matrix([-v for v in bone['pivot']], [0, 0, 0, 1], [1, 1, 1])
                actual = multiply(joint, inverse)
                expected = check['matrices'][j*16:j*16+16]
                worst = max(worst, max(abs(a-b) for a, b in zip(actual, expected)))
    if worst > .00002:
        raise ValueError(f'Exported skeleton differs from native pose: {worst}')
    return worst


def to_glb(model: dict) -> tuple[bytes, dict]:
    positions = floats(model.get('positions'), 3, 'positions')
    count = len(positions) // 3
    if count < 3 or count > 1000000:
        raise ValueError('Invalid vertex budget')
    normals = floats(model.get('normals'), 3, 'normals')
    if len(normals) != len(positions):
        raise ValueError('Normal count differs from geometry')
    if any(abs(sum(v*v for v in normals[i:i+3])**.5 - 1) > .005 for i in range(0, len(normals), 3)):
        raise ValueError('Native normals must be normalized')
    rgb = floats(model.get('rgb'), 3, 'RGB')
    emissive = floats(model.get('emissive'), 1, 'emissive')
    uv = floats(model.get('uv'), 2, 'UV')
    joints = floats(model.get('joints'), 1, 'joints')
    if len(rgb) != count*3 or len(emissive) != count or len(uv) != count*2 or len(joints) != count:
        raise ValueError('Vertex attribute count mismatch')
    if any(v < 0 or v > 1 for v in rgb+emissive):
        raise ValueError('Colour or emission outside [0,1]')
    indices = model.get('indices')
    if not isinstance(indices, list) or not indices or len(indices) % 3 or any(
        isinstance(v, bool) or not isinstance(v, int) or v < 0 or v >= count for v in indices
    ):
        raise ValueError('Invalid triangle indices')
    bones = model.get('bones')
    if not isinstance(bones, list) or not 1 <= len(bones) <= 24:
        raise ValueError('Invalid native rig size')
    for j, bone in enumerate(bones):
        floats(bone.get('pivot'), 3, 'bind pivot')
        if len(bone['pivot']) != 3 or not isinstance(bone.get('parent'), int) or not -1 <= bone['parent'] < j:
            raise ValueError('Bone parents must precede children')
    if any(v != int(v) or not 0 <= v < len(bones) for v in joints):
        raise ValueError('Vertex joint outside rig')
    native_error = verify_native_skin(model)
    buffer = Buffer()
    attributes = {'POSITION': buffer.add(positions, 'VEC3', bounds=True, target=34962),
                  'NORMAL': buffer.add(normals, 'VEC3', target=34962),
                  'COLOR_0': buffer.add([c for i in range(count) for c in [*rgb[i*3:i*3+3], 1]], 'VEC4', target=34962),
                  'TEXCOORD_0': buffer.add(uv, 'VEC2', target=34962),
                  'JOINTS_0': buffer.add([c for v in joints for c in [int(v), 0, 0, 0]], 'VEC4', 5121, target=34962),
                  'WEIGHTS_0': buffer.add([c for _ in joints for c in [1, 0, 0, 0]], 'VEC4', target=34962),
                  '_GENEWARS_EMISSIVE': buffer.add(emissive, 'SCALAR', target=34962)}
    # Every native primitive has a uniform RGB/emission. Keep the RGB in COLOR_0;
    # split index lists by emissive material for portable standard glTF emission.
    groups = {}
    for i in range(0, len(indices), 3):
        tri = indices[i:i+3]
        signatures = [tuple(rgb[v*3:v*3+3])+(emissive[v],) for v in tri]
        if len(set(signatures)) != 1:
            raise ValueError('Cannot preserve varying emission with one standard material')
        r, g, b, e = signatures[0]
        groups.setdefault((r*e, g*e, b*e), []).extend(tri)
    materials, primitives = [], []
    for emission, triangles in groups.items():
        materials.append({'name': 'native-emission-'+str(len(materials)), 'doubleSided': False,
                          'pbrMetallicRoughness': {'baseColorFactor': [1, 1, 1, 1], 'metallicFactor': .15, 'roughnessFactor': .65},
                          'emissiveFactor': list(emission)})
        primitives.append({'attributes': attributes, 'indices': buffer.add(triangles, 'SCALAR',
                           5123 if max(indices) < 65536 else 5125, target=34963), 'mode': 4, 'material': len(materials)-1})
    nodes = [{'name': model['name'], 'mesh': 0, 'skin': 0}]
    roots, inverses = [0], []
    for j, bone in enumerate(bones):
        pivot = bone['pivot']
        parent = bone['parent']
        t = pivot if parent < 0 else [v-p for v, p in zip(pivot, bones[parent]['pivot'])]
        nodes.append({'name': bone['name'], 'translation': t})
        if parent < 0:
            roots.append(j+1)
        else:
            nodes[parent+1].setdefault('children', []).append(j+1)
        inverses.extend(matrix([-v for v in pivot], [0, 0, 0, 1], [1, 1, 1]))
    skin = {'name': model['name']+'-native-rig', 'joints': list(range(1, len(bones)+1)),
            'inverseBindMatrices': buffer.add(inverses, 'MAT4')}
    bone_roots = [j+1 for j, bone in enumerate(bones) if bone['parent'] < 0]
    if len(bone_roots) == 1:
        skin['skeleton'] = bone_roots[0]
    animations = []
    for clip in model['clips']:
        times = floats(clip['times'], 1, 'sample times')
        if len(times) < 2 or times[0] != 0 or any(b <= a for a, b in zip(times, times[1:])):
            raise ValueError('Clip times must start at zero and strictly increase')
        input_accessor = buffer.add(times, 'SCALAR', bounds=True)
        samplers, channels = [], []
        for j in range(len(bones)):
            for path, width, kind in [('translation', 3, 'VEC3'), ('rotation', 4, 'VEC4'), ('scale', 3, 'VEC3')]:
                frames = clip[path]
                if len(frames) != len(times):
                    raise ValueError('TRS sample count mismatch')
                values, previous = [], None
                for frame in frames:
                    if len(frame) != len(bones)*width:
                        raise ValueError('TRS joint count mismatch')
                    v = floats(frame[j*width:j*width+width], width, path)
                    if path == 'rotation':
                        if abs(sum(c*c for c in v)-1) > .0001:
                            raise ValueError('Quaternion must be unit length')
                        if previous and sum(a*b for a, b in zip(previous, v)) < 0:
                            v = [-c for c in v]
                        previous = v
                    values.extend(v)
                # Constant curves are represented exactly by the two endpoints.
                constant = all(values[i:i+width] == values[:width] for i in range(width, len(values), width))
                curve_times = buffer.add([times[0], times[-1]], 'SCALAR', bounds=True) if constant else input_accessor
                output = buffer.add(values[:width]*2 if constant else values, kind)
                samplers.append({'input': curve_times, 'output': output, 'interpolation': 'LINEAR'})
                channels.append({'sampler': len(samplers)-1, 'target': {'node': j+1, 'path': path}})
        animations.append({'name': clip['name'], 'samplers': samplers, 'channels': channels,
                           'extras': {'nativeAction': clip['action'], 'nativeSpeed': clip['speed'], 'samplesPerSecond': 30}})
    document = {'asset': {'version': '2.0', 'generator': 'Gene Wars production-model exporter'},
        'scene': 0, 'scenes': [{'nodes': roots}], 'nodes': nodes,
        'meshes': [{'name': model['name'], 'primitives': primitives}], 'skins': [skin], 'materials': materials,
        'animations': animations, 'buffers': [{'byteLength': len(buffer.data)}],
        'bufferViews': buffer.views, 'accessors': buffer.accessors,
        'extras': {'nativeSource': model.get('source'), 'nativeName': model.get('nativeName'),
                   'category': model['category'], 'upAxis': 'Y', 'forwardAxis': '+Z',
                   'animationEncoding': 'production hierarchical skin; native local TRS sampled at 30 Hz',
                   'sampleInterpolation': 'exact at samples; glTF LINEAR interpolation between samples',
                   'nativeEmission': 'vertex field 9 is emission; COLOR_0 alpha is 1; preserved in custom _GENEWARS_EMISSIVE',
                   'nativePoseMaxError': native_error}}
    encoded = json.dumps(document, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    encoded += b' ' * ((-len(encoded)) % 4)
    binary = bytes(buffer.data) + b'\0' * ((-len(buffer.data)) % 4)
    length = 12 + 8 + len(encoded) + 8 + len(binary)
    glb = struct.pack('<4sII', b'glTF', 2, length) + struct.pack('<I4s', len(encoded), b'JSON') + encoded
    glb += struct.pack('<I4s', len(binary), b'BIN\0') + binary
    return glb, {'name': model['name'], 'category': model['category'], 'vertices': count, 'triangles': len(indices)//3,
                 'joints': len(bones), 'materials': len(materials), 'clips': [c['name'] for c in model['clips']],
                 'bounds': {'min': buffer.accessors[attributes['POSITION']]['min'], 'max': buffer.accessors[attributes['POSITION']]['max']},
                 'bytes': len(glb), 'sha256': hashlib.sha256(glb).hexdigest(), 'nativePoseMaxError': native_error}


def inspect_glb(data: bytes) -> dict:
    if len(data) < 28:
        raise ValueError('Truncated GLB')
    magic, version, length = struct.unpack_from('<4sII', data)
    if magic != b'glTF' or version != 2 or length != len(data):
        raise ValueError('Invalid GLB header')
    position, chunks = 12, []
    while position < len(data):
        if position + 8 > len(data):
            raise ValueError('Truncated GLB chunk')
        size, kind = struct.unpack_from('<I4s', data, position)
        position += 8
        if size % 4 or position + size > len(data):
            raise ValueError('Invalid GLB chunk length')
        chunks.append((kind, data[position:position+size])); position += size
    if [kind for kind, _ in chunks] != [b'JSON', b'BIN\0']:
        raise ValueError('Expected JSON then BIN chunks')
    document = json.loads(chunks[0][1].decode('utf-8'))
    binary = chunks[1][1]
    if document.get('asset', {}).get('version') != '2.0' or document['buffers'][0]['byteLength'] > len(binary):
        raise ValueError('Invalid glTF buffer')
    for view in document['bufferViews']:
        if view.get('buffer') != 0 or view.get('byteOffset', 0) % 4 or view['byteOffset'] + view['byteLength'] > len(binary):
            raise ValueError('Buffer view exceeds BIN chunk')
    for accessor in document['accessors']:
        view = document['bufferViews'][accessor['bufferView']]
        size = COMPONENT_BYTES[accessor['componentType']] * TYPE_WIDTHS[accessor['type']] * accessor['count']
        if accessor.get('byteOffset', 0) + size > view['byteLength']:
            raise ValueError('Accessor exceeds its view')
    return {'document': document, 'binary': binary}


def accessor_values(parsed, index):
    document, binary = parsed['document'], parsed['binary']
    accessor = document['accessors'][index]
    view = document['bufferViews'][accessor['bufferView']]
    code = {5121: 'B', 5123: 'H', 5125: 'I', 5126: 'f'}[accessor['componentType']]
    count = accessor['count']*TYPE_WIDTHS[accessor['type']]
    return list(struct.unpack_from('<'+code*count, binary, view.get('byteOffset', 0)+accessor.get('byteOffset', 0)))


def verify_serialized_skin(data, model):
    """Check the serialized float32 GLB against native skin matrices, not just input JSON."""
    parsed, worst = inspect_glb(data), 0.0
    document = parsed['document']
    for animation, native in zip(document['animations'], model['clips']):
        for check in native['nativeSkinChecks']:
            time = native['times'][check['frame']]
            transforms = {i: {'translation': node.get('translation', [0, 0, 0]),
                              'rotation': node.get('rotation', [0, 0, 0, 1]),
                              'scale': node.get('scale', [1, 1, 1])}
                          for i, node in enumerate(document['nodes'])}
            for channel in animation['channels']:
                sampler = animation['samplers'][channel['sampler']]
                times, values = accessor_values(parsed, sampler['input']), accessor_values(parsed, sampler['output'])
                path, node = channel['target']['path'], channel['target']['node']
                width = 4 if path == 'rotation' else 3
                # Native check frames are recorded sample times (or constant channels).
                nearest = min(range(len(times)), key=lambda i: abs(times[i]-time))
                if abs(times[nearest]-time) < .000001:
                    value = values[nearest*width:nearest*width+width]
                elif all(values[i:i+width] == values[:width] for i in range(width, len(values), width)):
                    value = values[:width]
                else:
                    raise ValueError('Native check is not an exported sample')
                transforms[node][path] = value
            world = []
            inverse_bind = accessor_values(parsed, document['skins'][0]['inverseBindMatrices'])
            for j, bone in enumerate(model['bones']):
                trs = transforms[document['skins'][0]['joints'][j]]
                local = matrix(trs['translation'], trs['rotation'], trs['scale'])
                joint = local if bone['parent'] < 0 else multiply(world[bone['parent']], local)
                world.append(joint)
                skin = multiply(joint, inverse_bind[j*16:j*16+16])
                expected = check['matrices'][j*16:j*16+16]
                worst = max(worst, max(abs(a-b) for a, b in zip(skin, expected)))
    if worst > .00002:
        raise ValueError(f'Serialized GLB differs from native pose: {worst}')
    return worst


def export_json(input_path: Path, output: Path) -> dict:
    model = json.loads(input_path.read_text(encoding='utf-8'))
    data, summary = to_glb(model)
    summary['serializedPoseMaxError'] = verify_serialized_skin(data, model)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    return summary


def export_library(output: Path, java_home: Path | None = None) -> dict:
    java_home = java_home or (Path(os.environ['JAVA_HOME']) if os.environ.get('JAVA_HOME') else None)
    javac = str(java_home/'bin/javac') if java_home else shutil.which('javac')
    java = str(java_home/'bin/java') if java_home else shutil.which('java')
    if not javac or not java:
        raise ValueError('A JDK (Java 8+) is required; set --java-home or JAVA_HOME')
    adapter = ROOT/'tools/model-export/ModelExportMain.java'
    sources = [SOURCE/name for name in SOURCES]+[adapter]
    hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    with tempfile.TemporaryDirectory(prefix='genewars-model-export-') as temp:
        temp = Path(temp)
        classes, extracted = temp/'classes', temp/'native-arrays'
        classes.mkdir(); extracted.mkdir()
        subprocess.run([javac, '-source', '8', '-target', '8', '-Xlint:-options', '-d', str(classes), *map(str, sources)], check=True)
        subprocess.run([java, '-cp', str(classes), 'ModelExportMain', str(extracted)], check=True)
        output.mkdir(parents=True, exist_ok=True)
        models = [export_json(path, output/(path.stem+'.glb')) for path in sorted(extracted.glob('*.json'))]
    if len(models) != 55:
        raise ValueError('Native library coverage must be 55 models')
    for path, expected in hashes.items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Production model changed while exporting: {path}; rerun exporter')
    manifest = {'format': 'glTF 2.0 GLB', 'version': '0.3', 'models': models, 'sourceSha256': hashes,
                'totalBytes': sum(m['bytes'] for m in models), 'vertices': sum(m['vertices'] for m in models),
                'triangles': sum(m['triangles'] for m in models), 'nativePoseMaxError': max(m['nativePoseMaxError'] for m in models),
                'serializedPoseMaxError': max(m['serializedPoseMaxError'] for m in models),
                'scope': 'Native stylized procedural solid meshes; not photoreal or AAA assets',
                'runtime': 'Android uses these exact source-generated meshes and rigs; GLBs are editor/audit exports outside APK',
                'animation': 'Actual native skin and local TRS, sampled at 30 Hz; exact at samples, interpolated between. Clips are excerpts, not authored seamless loops.'}
    (output/'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-json', type=Path, help='Export one already extracted native model')
    parser.add_argument('--output', type=Path, default=ROOT/'graphics/models-v03')
    parser.add_argument('--java-home', type=Path)
    args = parser.parse_args()
    result = export_json(args.input_json, args.output) if args.input_json else export_library(args.output, args.java_home)
    print(json.dumps(result if args.input_json else {k: v for k, v in result.items() if k not in ['models', 'sourceSha256']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
