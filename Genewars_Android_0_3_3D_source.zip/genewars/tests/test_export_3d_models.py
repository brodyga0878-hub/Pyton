import hashlib
import json
from pathlib import Path
import struct
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from export_3d_models import accessor_values, inspect_glb, to_glb, verify_serialized_skin


def example():
    identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    return {'name': 'format-test', 'nativeName': 'format-test', 'category': 'plant',
            'positions': [0, 0, 0, 1, 0, 0, 0, 1, 0], 'normals': [0, 0, 1]*3,
            'rgb': [.2, .4, .8]*3, 'emissive': [.5]*3, 'uv': [0, 0, 1, 0, 0, 1],
            'joints': [0, 0, 0], 'indices': [0, 1, 2],
            'bones': [{'name': 'root', 'parent': -1, 'pivot': [0, 0, 0]}],
            'clips': [{'name': 'idle', 'action': 0, 'speed': 0, 'times': [0, 1],
                       'translation': [[0, 0, 0], [0, 0, 0]], 'rotation': [[0, 0, 0, 1]]*2,
                       'scale': [[1, 1, 1]]*2,
                       'nativeSkinChecks': [{'frame': 0, 'matrices': identity}, {'frame': 1, 'matrices': identity}]}]}


class NativeModelExportTests(unittest.TestCase):
    def test_standard_skin_opaque_vertex_colour_and_emission(self):
        model = example()
        data, summary = to_glb(model)
        parsed = inspect_glb(data)
        document = parsed['document']
        primitive = document['meshes'][0]['primitives'][0]
        attributes = primitive['attributes']
        self.assertEqual(document['skins'][0]['joints'], [1])
        self.assertEqual(document['nodes'][0]['skin'], 0)
        self.assertEqual(accessor_values(parsed, attributes['JOINTS_0']), [0]*12)
        self.assertEqual(accessor_values(parsed, attributes['WEIGHTS_0']), [1, 0, 0, 0]*3)
        self.assertEqual(accessor_values(parsed, attributes['COLOR_0'])[3::4], [1]*3)
        self.assertEqual(accessor_values(parsed, attributes['_GENEWARS_EMISSIVE']), [.5]*3)
        self.assertEqual(document['materials'][0]['emissiveFactor'], [.1, .2, .4])
        self.assertEqual(document['animations'][0]['name'], 'idle')
        self.assertEqual(summary['triangles'], 1)
        self.assertEqual(verify_serialized_skin(data, model), 0)

    def test_native_pose_disagreement_and_invalid_rigs_are_rejected(self):
        model = example()
        model['clips'][0]['nativeSkinChecks'][0]['matrices'][12] = 1
        with self.assertRaisesRegex(ValueError, 'differs from native pose'):
            to_glb(model)
        model = example()
        model['bones'][0]['parent'] = 0
        with self.assertRaisesRegex(ValueError, 'parents'):
            to_glb(model)
        model = example()
        model['joints'][0] = 1
        with self.assertRaisesRegex(ValueError, 'joint outside'):
            to_glb(model)
        model = example()
        model['indices'][0] = 3
        with self.assertRaisesRegex(ValueError, 'indices'):
            to_glb(model)

    def test_header_and_accessor_overrun_are_rejected(self):
        data, _ = to_glb(example())
        with self.assertRaises(ValueError):
            inspect_glb(data[:-1])
        broken = bytearray(data)
        struct.pack_into('<I', broken, 16, 0xFFFFFFFF)
        with self.assertRaises(ValueError):
            inspect_glb(bytes(broken))

    def test_frozen_library_coverage_sources_and_distinct_geometry(self):
        directory = ROOT / 'graphics/models-v03'
        manifest = json.loads((directory/'manifest.json').read_text())
        models = manifest['models']
        self.assertEqual(len(models), 55)
        self.assertEqual({category: sum(model['category'] == category for model in models)
                          for category in ['creature', 'building', 'specialist', 'plant']},
                         {'creature': 25, 'building': 14, 'specialist': 4, 'plant': 12})
        for path, digest in manifest['sourceSha256'].items():
            self.assertEqual(hashlib.sha256((ROOT/path).read_bytes()).hexdigest(), digest, path)
        signatures = set()
        for model in models:
            data = (directory/(model['name']+'.glb')).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), model['sha256'])
            parsed = inspect_glb(data)
            document = parsed['document']
            primitive = document['meshes'][0]['primitives'][0]
            positions = accessor_values(parsed, primitive['attributes']['POSITION'])
            self.assertEqual(len(positions), model['vertices']*3)
            signatures.add(hashlib.sha256(struct.pack('<'+'f'*len(positions), *positions)).hexdigest())
            for axis in range(3):
                self.assertAlmostEqual(min(positions[axis::3]), model['bounds']['min'][axis], places=5)
                self.assertAlmostEqual(max(positions[axis::3]), model['bounds']['max'][axis], places=5)
            names = {clip['name'] for clip in document['animations']}
            if model['category'] in ['creature', 'specialist']:
                self.assertTrue({'idle', 'walk', 'attack'} <= names)
            elif model['category'] == 'building':
                self.assertEqual(names, {'idle', 'work'})
            else:
                self.assertEqual(names, {'idle'})
            self.assertLess(model['serializedPoseMaxError'], .00002)
        self.assertEqual(len(signatures), 55)


if __name__ == '__main__':
    unittest.main()
