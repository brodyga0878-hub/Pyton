import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from pack_terrain_materials import NAMES, pack


class TerrainMaterialTests(unittest.TestCase):
    def source(self, base):
        Image.new('RGB', (769, 769), (11, 51, 91)).save(base/'source.png')
        return {'version': 1, 'sources': {'albedo': 'source.png'},
                'textures': {name: {'roughness': .8, 'metallic': 0, 'normalScale': .04} for name in NAMES}}

    def write(self, base, spec):
        path = base/'spec.json'
        path.write_text(json.dumps(spec))
        return path

    def test_png_is_byte_identical_grid_covers_every_pixel_and_repeatable(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source = self.write(base, self.source(base))
            manifest = pack(source, base/'output')
            self.assertEqual((base/'source.png').read_bytes(), (base/'output/terrain_albedo.png').read_bytes())
            self.assertEqual(manifest['textures']['water']['rect'], [0, 0, 256, 256])
            self.assertEqual(manifest['textures']['biotech']['rect'], [512, 512, 257, 257])
            self.assertEqual(sum(entry['rect'][2]*entry['rect'][3] for entry in manifest['textures'].values()), 769*769)
            self.assertEqual(manifest, pack(source, base/'output'))
            audit = json.loads((base/'output/assets-audit.json').read_text())
            self.assertEqual(audit['sources']['albedo']['sha256'], hashlib.sha256((base/'source.png').read_bytes()).hexdigest())
            self.assertEqual(audit['optionalMaps'], [])
            self.assertNotIn('normal', manifest['atlas'])

    def test_invalid_scalars_missing_coverage_and_alpha_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            original = self.source(base)
            for value in [float('nan'), -.1, 1.1, True]:
                spec = copy.deepcopy(original)
                spec['textures']['rock']['roughness'] = value
                with self.assertRaises(ValueError):
                    pack(self.write(base, spec), base/'output')
            spec = copy.deepcopy(original)
            del spec['textures']['snow']
            with self.assertRaisesRegex(ValueError, 'nine'):
                pack(self.write(base, spec), base/'output')
            Image.new('RGBA', (769, 769), (12, 24, 48, 254)).save(base/'source.png')
            with self.assertRaisesRegex(ValueError, 'opaque'):
                pack(self.write(base, original), base/'output')

    def test_optional_map_dimensions_and_unowned_files_are_protected(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            spec = self.source(base)
            Image.new('RGB', (768, 768), (128, 128, 255)).save(base/'normal.png')
            spec['sources']['normal'] = 'normal.png'
            with self.assertRaisesRegex(ValueError, 'dimensions'):
                pack(self.write(base, spec), base/'output')
            Image.new('RGB', (769, 769), (128, 128, 255)).save(base/'normal.png')
            manifest = pack(self.write(base, spec), base/'output')
            self.assertIn('normal', manifest['atlas'])
            self.assertEqual((base/'normal.png').read_bytes(), (base/'output/terrain_normal.png').read_bytes())
            (base/'output/keep.txt').write_text('user file')
            with self.assertRaisesRegex(ValueError, 'unowned'):
                pack(self.write(base, spec), base/'output')
            self.assertEqual((base/'output/keep.txt').read_text(), 'user file')

    def test_actual_authored_runtime_atlas_provenance(self):
        root = Path(__file__).resolve().parents[1]
        source = root/'graphics-source/v04/terrain-albedo.png'
        runtime = root/'android/app/src/main/assets/native/materials-v04/terrain_albedo.png'
        provenance = json.loads((source.parent/'provenance.json').read_text())
        self.assertEqual(source.read_bytes(), runtime.read_bytes())
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), provenance['sha256'])
        self.assertIn('photorealistic', provenance['prompt'].lower())
        self.assertEqual(provenance['tool'], 'image_gen.imagegen')


if __name__ == '__main__':
    unittest.main()
