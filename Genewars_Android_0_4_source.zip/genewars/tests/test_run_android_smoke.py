import importlib.util
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location("smoke_runner", Path(__file__).resolve().parents[1] / "tools/run_android_smoke.py")
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


def bundle(checks, count=None, status="passed", code=-1):
    return ("INSTRUMENTATION_RESULT: checks=[" + ", ".join(checks) + "]\n"
            + "INSTRUMENTATION_RESULT: passed_checks=" + str(len(checks) if count is None else count) + "\n"
            + "INSTRUMENTATION_RESULT: status=" + status + "\nINSTRUMENTATION_CODE: " + str(code) + "\n")


class SmokeRunnerResults(unittest.TestCase):
    def test_complete_raw_success_bundle_passes(self):
        self.assertTrue(RUNNER.parse_result(bundle(RUNNER.EXPECTED_CHECKS), 0)["passed"])

    def test_previous_seven_checks_do_not_prove_new_feature(self):
        old = [v for v in RUNNER.EXPECTED_CHECKS if "squad_card" not in v]
        self.assertFalse(RUNNER.parse_result(bundle(old), 0)["passed"])

    def test_count_alone_and_duplicate_checks_cannot_pass(self):
        wrong = RUNNER.EXPECTED_CHECKS[:-1] + [RUNNER.EXPECTED_CHECKS[0]]
        self.assertFalse(RUNNER.parse_result(bundle(wrong), 0)["passed"])
        self.assertFalse(RUNNER.parse_result(bundle(RUNNER.EXPECTED_CHECKS, count=80), 0)["passed"])

    def test_failed_or_interrupted_instrumentation_cannot_pass(self):
        self.assertFalse(RUNNER.parse_result(bundle(RUNNER.EXPECTED_CHECKS, status="failed"), 0)["passed"])
        self.assertFalse(RUNNER.parse_result(bundle(RUNNER.EXPECTED_CHECKS), -9)["passed"])
        self.assertFalse(RUNNER.parse_result(bundle(RUNNER.EXPECTED_CHECKS, code=0), 0)["passed"])

    def test_compatibility_mode_has_separate_exact_contract(self):
        output = bundle([RUNNER.LEGACY_CHECK])
        self.assertTrue(RUNNER.parse_result(output, 0, True)["passed"])
        self.assertFalse(RUNNER.parse_result(output, 0)["passed"])


if __name__ == "__main__":
    unittest.main()
