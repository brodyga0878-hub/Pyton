import json
from pathlib import Path
import sys
import tempfile
import unittest

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from check_hd_release import BUILDINGS, SPECIALISTS, check


class HdReleaseChecks(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="hd-release-test-")
        self.assets = Path(self.temporary.name)
        self.hd = self.assets / "native/hd"
        self.hd.mkdir(parents=True)
        # Deliberately simple test fixture, never shipped as game artwork.
        image = Image.new("RGBA", (192, 192), (0, 0, 0, 0))
        image.putpixel((96, 96), (32, 96, 64, 255))
        image.save(self.hd / "fixture.png")
        keys = ([f"creature_{i}" for i in range(25)] + ["building_" + key for key in BUILDINGS]
                + ["specialist_" + key for key in SPECIALISTS] + [f"plant_{i}" for i in range(12)])
        visual = {"file": "native/hd/fixture.png", "scale": 1, "anchor": [.5, 1]}
        self.manifest = {"format": 1, "sprites": {key: visual.copy() for key in keys},
                         "images": {"ui/keyart": visual.copy()},
                         "textures": {key: visual.copy() for key in ["grass", "sand", "rock", "snow", "water", "alien"]}}

    def tearDown(self):
        self.temporary.cleanup()

    def run_check(self):
        (self.hd / "manifest.json").write_text(json.dumps(self.manifest))
        return check(self.assets)

    def test_complete_coverage_and_alias_memory_are_counted_once(self):
        result = self.run_check()
        self.assertTrue(result["passed"], result["errors"])
        self.assertEqual(result["required_sprites"], 55)
        self.assertEqual(result["conservative_unique_rgba_bytes"], 192 * 192 * 4)
        self.assertEqual(result["unique_primary_visuals"], 1)
        self.assertTrue(any("identical pixels" in warning for warning in result["warnings"]))

    def test_missing_family_and_outside_atlas_are_rejected(self):
        del self.manifest["sprites"]["building_FUSION"]
        self.manifest["sprites"]["creature_0"]["rect"] = [100, 100, 192, 192]
        result = self.run_check()
        self.assertFalse(result["passed"])
        self.assertTrue(any("building_FUSION" in e for e in result["errors"]))
        self.assertTrue(any("crop outside image" in e for e in result["errors"]))

    def test_opaque_or_empty_sprite_cannot_pass_as_alpha_asset(self):
        Image.new("RGBA", (192, 192), (1, 2, 3, 255)).save(self.hd / "opaque.png")
        self.manifest["sprites"]["creature_0"]["file"] = "native/hd/opaque.png"
        result = self.run_check()
        self.assertFalse(result["passed"])
        self.assertTrue(any("transparency" in e for e in result["errors"]))

    def test_path_escape_and_nonfinite_geometry_are_rejected(self):
        self.manifest["sprites"]["creature_0"]["file"] = "native/hd/../../fixture.png"
        self.manifest["sprites"]["creature_1"]["anchor"] = [float("nan"), .5]
        result = self.run_check()
        self.assertFalse(result["passed"])
        self.assertTrue(any("unsafe resource path" in e for e in result["errors"]))
        self.assertTrue(any("invalid anchor" in e for e in result["errors"]))


if __name__ == "__main__":
    unittest.main()
