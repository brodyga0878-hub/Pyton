import json
from pathlib import Path
import sys
import tempfile
import unittest

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from pack_hd_assets import crop_asset, pack, regions


class HdPackingTests(unittest.TestCase):
    def test_exact_rgba_pixels_and_trim_are_preserved(self):
        source = Image.new("RGBA", (8, 8))
        source.putpixel((3, 4), (17, 38, 91, 127))
        source.putpixel((4, 4), (92, 18, 37, 255))
        result, audit = crop_asset(source, {"rect": [2, 2, 4, 4], "padding": 0}, True)
        self.assertEqual(result.size, (2, 1))
        self.assertEqual(result.tobytes(), bytes([17, 38, 91, 127, 92, 18, 37, 255]))
        self.assertEqual(audit["trimBounds"], [1, 2, 3, 3])

    def test_transparent_source_margin_is_retained_without_painting(self):
        source = Image.new("RGBA", (10, 10))
        source.putpixel((4, 4), (91, 32, 77, 128))
        result, audit = crop_asset(source, {}, True)
        self.assertEqual(result.size, (5, 5))
        self.assertEqual(result.getpixel((2, 2)), (91, 32, 77, 128))
        self.assertEqual(result.getpixel((0, 0)), source.getpixel((2, 2)))
        self.assertEqual(audit["trimBounds"], [2, 2, 7, 7])

    def test_bad_region_opaque_or_empty_sprite_is_rejected(self):
        image = Image.new("RGBA", (8, 8), (255, 255, 255, 255))
        for value in [{"rect": [7, 0, 2, 2]}, {"rect": [0, 0, -1, 8]}, {"rect": [0, 0, 1.2, 8]}, {}]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                crop_asset(image, value, True)
        with self.assertRaisesRegex(ValueError, "Empty"):
            crop_asset(Image.new("RGBA", (8, 8)), {}, True)

    def test_grid_boundaries_cover_non_divisible_dimensions(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            Image.new("RGB", (11, 7), (11, 22, 33)).save(base / "atlas.png")
            result = regions({"atlases": [{"source": "atlas.png", "section": "textures", "columns": 3,
                "rows": 2, "keys": ["a", "b", "c", "d", "e", "f"]}]}, base)
            self.assertEqual(result["textures"]["a"]["rect"], [0, 0, 3, 3])
            self.assertEqual(result["textures"]["f"]["rect"], [7, 3, 4, 4])

    def test_pack_runtime_index_audit_and_repeatability(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            image = Image.new("RGBA", (8, 8))
            image.putpixel((4, 3), (10, 120, 220, 255))
            image.save(base / "sprite.png")
            specification = base / "spec.json"
            specification.write_text(json.dumps({"format": 1, "sprites": {"creature_0": {
                "source": "sprite.png", "scale": 1.2, "anchor": [0.5, 0.95], "padding": 0}}}))
            first = pack(specification, base / "output")
            self.assertEqual(first["sprites"]["creature_0"]["scale"], 1.2)
            asset = base / "output" / Path(first["sprites"]["creature_0"]["file"]).name
            self.assertEqual(Image.open(asset).getpixel((0, 0)), (10, 120, 220, 255))
            audit = json.loads((base / "output/assets-audit.json").read_text())
            self.assertIn("sourceSha256", audit["assets"]["sprites/creature_0"])
            self.assertEqual(pack(specification, base / "output"), first)

    def test_unsafe_names_and_invalid_geometry_cannot_overwrite_files(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            Image.new("RGB", (4, 4), (1, 2, 3)).save(base / "a.png")
            for name, data in [("../key", {}), ("ui/key", {"outputName": "../escape.png"}),
                               ("ui/key", {"scale": float("nan")}), ("ui/key", {"anchor": [2, 0]})]:
                specification = base / "spec.json"
                specification.write_text(json.dumps({"images": {name: dict(source="a.png", **data)}}))
                with self.subTest(name=name, data=data), self.assertRaises(ValueError):
                    pack(specification, base / "output")

    def test_unowned_existing_file_is_not_replaced(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            Image.new("RGB", (4, 4), (1, 2, 3)).save(base / "a.png")
            specification = base / "spec.json"
            specification.write_text(json.dumps({"images": {"ui/key": {"source": "a.png", "outputName": "key.png"}}}))
            output = base / "output"
            output.mkdir()
            (output / "key.png").write_bytes(b"existing user data")
            with self.assertRaises(FileExistsError):
                pack(specification, output)
            self.assertEqual((output / "key.png").read_bytes(), b"existing user data")


if __name__ == "__main__":
    unittest.main()
