package org.genewars.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.zip.CRC32;

/**
 * Native, deterministic RTS reconstruction. It never executes original x86 code.
 * Retail data tables and tutorial goals are recovered; timings/AI/combat/power
 * rules are new, explicitly documented implementations, not claims of fidelity.
 * All methods run on a single simulation/UI thread.
 */
public final class GameState {
    public static final int MISSION_COUNT = 5;
    public static final int MAX_UNITS = 256, MAX_BUILDINGS = 256, MAX_PLANTS = 1024;
    public static final String[] SPECIES_NAMES = {
        "Дино", "Краб", "Лягушка", "Птица", "Мул", "Динокраб", "Динолягушка", "Диноптица", "Диномул",
        "Краболягушка", "Крабоптица", "Крабомул", "Лягуптица", "Лягумул", "Птицемул", "Крабозавр",
        "Лягузавр", "Лягокраб", "Птицезавр", "Птицекраб", "Птицелягушка", "Мулозавр", "Мулокраб", "Мулолягушка", "Мулоптица"
    };
    public static final String[] SPECIES_SPRITES = {
        "DINO", "CRAB", "FROG", "BIRD", "MULE", "DINOCRAB", "DINOFROG", "DINOBIRD", "DINOMULE",
        "CRABFROG", "CRABBIRD", "CRABMULE", "FROGBIRD", "FROGMULE", "BIRDMULE", "CRABDINO", "FROGDINO",
        "FROGCRAB", "BIRDDINO", "BIRDCRAB", "BIRDFROG", "MULEDINO", "MULECRAB", "MULEFROG", "MULEBIRD"
    };
    private static final int IDLE = 0, MOVE = 1, HARVEST = 2, BUILD = 3, ATTACK = 4,
            RESEARCH = 5, FEED = 6, HEAL = 7, REPAIR = 8;
    private static final double STEP = .1;
    private static final int SAVE_VERSION = 3, MAX_SAVE_BYTES = 8 * 1024 * 1024;
    public final WorldMap map;
    public final List<Unit> units = new ArrayList<Unit>();
    public final List<Building> buildings = new ArrayList<Building>();
    public final List<Plant> plants = new ArrayList<Plant>();
    public final int[] researchLevels = new int[25];
    public int goop = 2000, wood = 50, cellulose, etherealPoints, goopCapacity = 5000;
    public int powerProduced, powerUsed, selectedId, missionIndex;
    public int recycledGoop, bornCreatures, bornMules, killedEnemies, plantedTrees;
    public double elapsed, zoneX, zoneY, zoneRadius = 4, etherealETA = -1;
    public boolean victory, defeat, paused;
    public String message = "Выберите специалиста. Касание земли отдаёт приказ.";
    private final List<String> events = new ArrayList<String>();
    private int nextId = 1, enemyGoop = 1500;
    private long randomState;
    private double accumulator, aiClock, ecologyClock, enemyTrainClock, holdClock;
    private double spawnX, spawnY;

    private GameState(WorldMap map, int missionIndex, long seed) {
        if (map == null || missionIndex < 0 || missionIndex >= MISSION_COUNT) throw new IllegalArgumentException("Invalid mission");
        this.map = map; this.missionIndex = missionIndex; this.randomState = seed;
    }

    public static GameState newGame(WorldMap map, int missionIndex, long seed) {
        return newGame(map, missionIndex, seed, map.width * .2, map.height * .2);
    }

    public static GameState newGame(WorldMap map, int missionIndex, long seed, double requestedX, double requestedY) {
        return createGame(map, missionIndex, seed, requestedX, requestedY, true);
    }

    /** Initializes only the crew/zone before importing original scenario records. */
    public static GameState newImportedGame(WorldMap map, int missionIndex, long seed, double requestedX, double requestedY) {
        return createGame(map, missionIndex, seed, requestedX, requestedY, false);
    }

    public static GameState newImportedGame(WorldMap map, int missionIndex, long seed) {
        return newImportedGame(map, missionIndex, seed, map.width * .2, map.height * .2);
    }

    private static GameState createGame(WorldMap map, int missionIndex, long seed, double requestedX, double requestedY, boolean seedProvisional) {
        GameState game = new GameState(map, missionIndex, seed);
        int start = game.nearestFree(requestedX, requestedY, false);
        if (start < 0) throw new IllegalArgumentException("Map contains no walkable cells");
        game.spawnX = start % map.width + .5; game.spawnY = start / map.width + .5;
        for (int i = 0; i < 4; i++) {
            Unit unit = game.addUnit(0, Unit.Kind.values()[i], 0, game.spawnX + (i % 2) * 1.2, game.spawnY + (i / 2) * 1.2);
            if (i == 0) game.select(unit.id);
        }
        int zone = game.nearestFree(game.spawnX + 8, game.spawnY + 5, false);
        game.zoneX = zone % map.width + .5; game.zoneY = zone / map.width + .5;
        if (!seedProvisional) { game.recalculatePower(); game.events.clear(); return game; }
        game.addUnit(0, Unit.Kind.CREATURE, 4, game.spawnX + 2.2, game.spawnY);
        game.addUnit(0, Unit.Kind.CREATURE, 4, game.spawnX + 2.2, game.spawnY + 1.5);
        game.researchLevels[4] = 100;
        // Initial ecology is newly seeded; original Thing records are not decoded.
        int targetPlants = Math.min(220, map.width * map.height / 25);
        for (int tries = 0; tries < targetPlants * 20 && game.plants.size() < targetPlants; tries++) {
            int x = game.randomInt(map.width), y = game.randomInt(map.height);
            if (map.walkable(x, y) && distance(x + .5, y + .5, game.spawnX, game.spawnY) > 2.5 && game.plantNear(x + .5, y + .5, .7) == null) {
                int terrain = map.terrain[map.index(x, y)] & 255;
                game.plants.add(new Plant(game.nextId++, terrain >= 5 ? 3 + terrain % 3 : terrain % 3, x + .5, y + .5, 60 + game.randomInt(41)));
            }
        }
        // Nearby renewable forest makes the reconstructed tutorial self-contained.
        for (int i = 0; i < 20; i++) {
            int tile = game.nearestFree(game.spawnX + 5 + i % 5 * 1.5, game.spawnY - 5 + i / 5 * 1.5, false);
            if (tile >= 0 && game.plantNear(tile % map.width + .5, tile / map.width + .5, .7) == null)
                game.plants.add(new Plant(game.nextId++, i % 3, tile % map.width + .5, tile / map.width + .5, 90));
        }
        for (int species = 0; species < 5; species++) {
            int tile = game.nearestFree(game.spawnX + 7 + species * 1.6, game.spawnY + 7, species == 3);
            if (tile >= 0) game.addUnit(2, Unit.Kind.CREATURE, species, tile % map.width + .5, tile / map.width + .5);
        }
        if (missionIndex >= 3) game.createEnemyBase();
        game.recalculatePower(); game.events.clear(); return game;
    }

    public static String missionTitle(int index) {
        String[] titles = {"1. Наблюдательная база", "2. Разведение мулов", "3. Переработка биомассы", "4. Восстановление биозоны", "5. Схватка"};
        return index >= 0 && index < titles.length ? titles[index] : "Неизвестное задание";
    }

    /**
     * Replace provisional initial ecology with decoded source records. The four
     * specialist crew remain until source crew selection is implemented. Called
     * only during initial loading, before the simulation has advanced.
     */
    public void clearScenarioEntities() {
        if (elapsed != 0) throw new IllegalStateException("Import is only allowed before simulation starts");
        plants.clear(); buildings.clear();
        Arrays.fill(researchLevels, 0);
        for (int i = units.size() - 1; i >= 0; i--) if (units.get(i).kind == Unit.Kind.CREATURE || units.get(i).team != 0) units.remove(i);
        recalculatePower();
    }

    public void importCreature(int species, double x, double y, int team, double health, double energy) {
        if (species < 0 || species >= 25) throw new IllegalArgumentException("Invalid original species");
        importCreature(species, x, y, team, health, energy, RetailRules.SPECIES_HEALTH[species],
                RetailRules.SPECIES_ENERGY[species], RetailRules.SPECIES_LIFESPAN[species]);
    }

    public void importCreature(int species, double x, double y, int team, double health, double energy,
                               double maximumHealth, double maximumEnergy, double lifespan) {
        if (elapsed != 0 || species < 0 || species >= 25 || team < 0 || team > 2 || !validPoint(x, y)
                || !finite(health) || !finite(energy) || !finite(maximumHealth) || maximumHealth < 1 || maximumHealth > 10000
                || !finite(maximumEnergy) || maximumEnergy < 1 || maximumEnergy > 100000
                || !finite(lifespan) || lifespan < 1 || lifespan > 1e9
                || units.size() >= MAX_UNITS) throw new IllegalArgumentException("Invalid original creature");
        if (health <= 0) return;
        Unit u = new Unit(nextId++, team, Unit.Kind.CREATURE, species, x, y);
        u.maxHp = maximumHealth; u.energyCapacity = maximumEnergy; u.lifespan = lifespan;
        u.hp = Math.min(u.maxHp, health); u.energy = clamp(energy, 0, u.maxEnergy()); units.add(u);
    }

    public void importPlant(int species, double x, double y, int biomass) {
        if (elapsed != 0 || species < 0 || species >= 12 || !validPoint(x, y) || biomass < 0 || biomass > 10000
                || plants.size() >= MAX_PLANTS) throw new IllegalArgumentException("Invalid original plant");
        if (biomass > 0) plants.add(new Plant(nextId++, species, x, y, biomass));
    }

    /** Returns false for a source building type whose native behavior is not implemented. */
    public boolean importBuilding(int retailType, int stage, double x, double y, int team, int buildValue) {
        return importBuilding(retailType, stage, x, y, team, buildValue, 1);
    }

    public boolean importBuilding(int retailType, int stage, double x, double y, int team, int buildValue, int flags) {
        if (elapsed != 0 || retailType < 0 || retailType >= 14 || stage < 0 || stage > 2 || team < 0 || team > 1
                || !validPoint(x, y) || buildings.size() >= MAX_BUILDINGS) throw new IllegalArgumentException("Invalid original building");
        Building.Kind kind;
        switch (retailType) {
            case 0: kind = Building.Kind.GENE_LAB; break;
            case 1: kind = Building.Kind.TURRET; break;
            case 2: kind = Building.Kind.PULPER; break;
            case 3: kind = Building.Kind.DISTRIBUTOR; break;
            case 4: kind = Building.Kind.RECYCLER; break;
            case 5: kind = Building.Kind.LANDING_PAD; break;
            case 6: kind = Building.Kind.SOLAR; break;
            case 7: kind = Building.Kind.DETECTOR; break;
            case 8: kind = Building.Kind.WIND; break;
            case 9: kind = Building.Kind.FUSION; break;
            case 10: kind = Building.Kind.TECH; break;
            case 11: kind = Building.Kind.EXTRACTOR; break;
            case 12: kind = Building.Kind.SHIELD; break;
            case 13: kind = Building.Kind.VAT; break;
            default: return false;
        }
        boolean built = (flags & 1) != 0;
        Building b = new Building(nextId++, team, kind, x, y, built);
        b.stage = stage; b.maxHp = RetailRules.BUILDING_BMAX[retailType][stage];
        // Real IsBuilt tests flags&1; IsDamaged compares build against BMax.
        b.hp = clamp(buildValue, 1, b.maxHp);
        b.progress = built ? 1 : clamp(buildValue / b.maxHp, 0, .99);
        buildings.add(b); return true;
    }

    public void finishScenarioImport(int initialGoop) {
        if (elapsed != 0 || initialGoop < 0 || initialGoop > 10000000) throw new IllegalArgumentException("Invalid starting resources");
        goop = initialGoop; recalculatePower(); events.clear();
    }

    public void setObjectiveZone(double x, double y, double radius) {
        if (elapsed != 0 || !validPoint(x, y) || !finite(radius) || radius <= 0 || radius > 50) throw new IllegalArgumentException("Invalid zone");
        zoneX = x; zoneY = y; zoneRadius = radius;
    }

    public String objectiveText() {
        switch (missionIndex) {
            case 0: return "Постройте экстрактор, распределитель I и три фотонных процессора.";
            case 1: return "Постройте генокапсулу, создайте не менее трёх новых мулов и приведите трёх мулов в отмеченную зону.";
            case 2: return "Переработайте 1400 единиц биомассы в биогель. Постройте и обеспечьте энергией перерабатывающий завод.";
            case 3: return "Посадите растения в биозоне и приведите туда четыре существа. Поддерживайте биомассу не ниже 150 в течение 30 секунд.";
            default: return "Уничтожьте все войска и постройки противника. Не потеряйте свою команду.";
        }
    }

    public String objectiveProgress() {
        switch (missionIndex) {
            case 0: return "Экстрактор " + countBuildings(0, Building.Kind.EXTRACTOR) + "/1 · Распределитель "
                    + countBuildings(0, Building.Kind.DISTRIBUTOR) + "/1 · Фотонные " + countBuildings(0, Building.Kind.SOLAR) + "/3";
            case 1: return "Новые мулы " + bornMules + "/3 · Мулы в зоне " + creaturesInZone(4) + "/3";
            case 2: return "Переработано: " + recycledGoop + "/1400";
            case 3: return "Существа " + creaturesInZone(-1) + "/4 · Биомасса " + biomassInZone() + "/150 · " + (int) holdClock + "/30 с";
            default: return "Враги: " + countUnits(1) + " · Постройки: " + countBuildings(1, null);
        }
    }

    public Unit selectedUnit() { return unitById(selectedId); }
    public Building selectedBuilding() { return buildingById(selectedId); }

    public void clearSelection() { selectedId = 0; for (Unit unit : units) unit.selected = false; }
    public void select(int id) {
        Unit unit = unitById(id); Building building = buildingById(id);
        if ((unit == null || unit.team != 0 || !unit.alive()) && (building == null || building.team != 0 || !building.alive())) return;
        clearSelection(); selectedId = id; if (unit != null) unit.selected = true; event("select");
    }
    public int selectAt(double x, double y, double radius) {
        if (!validPoint(x, y) || !finite(radius) || radius <= 0) return 0;
        double best = radius; int id = 0;
        for (Unit unit : units) if (unit.team == 0 && unit.alive()) {
            double d = distance(x, y, unit.x, unit.y); if (d < best) { best = d; id = unit.id; }
        }
        for (Building b : buildings) if (b.team == 0 && b.alive()) {
            double d = distance(x, y, b.x, b.y); if (d < best) { best = d; id = b.id; }
        }
        if (id != 0) select(id); return id;
    }

    public boolean commandSelected(double x, double y) {
        Unit unit = selectedUnit();
        if (terminal() || unit == null || !unit.alive() || !validPoint(x, y)) return false;
        Unit target = nearestUnit(x, y, .9, -1, unit.id);
        Building b = buildingNear(x, y, .8);
        Plant plant = plantNear(x, y, .8);
        if (target != null && target.team != 0) {
            if (unit.kind == Unit.Kind.GENETICIST && target.kind == Unit.Kind.CREATURE)
                return assignNear(unit, target.x, target.y, RESEARCH, target.id, "Изучение " + target.title());
            return assignNear(unit, target.x, target.y, ATTACK, target.id, "Атака");
        }
        if (b != null && b.team != 0) return assignNear(unit, b.x, b.y, ATTACK, b.id, "Атака постройки");
        if (b != null && unit.kind == Unit.Kind.ENGINEER && b.team == 0 && (!b.complete() || b.hp < b.maxHp))
            return assignNear(unit, b.x, b.y, b.complete() ? REPAIR : BUILD, b.id, b.complete() ? "Ремонт" : "Строительство");
        if (plant != null && (unit.kind == Unit.Kind.BOTANIST || unit.kind == Unit.Kind.CREATURE)) {
            unit.repeatHarvest = true; return assignNear(unit, plant.x, plant.y, HARVEST, plant.id, "Сбор биомассы");
        }
        if (target != null && target.team == 0 && target.hp < target.maxHp && unit.kind == Unit.Kind.GENETICIST)
            return assignNear(unit, target.x, target.y, HEAL, target.id, "Лечение");
        unit.repeatHarvest = false; return assignMove(unit, x, y, MOVE, 0, "Движение");
    }

    /** Explicit ground movement, without contextual attack, harvest or repair. */
    public boolean moveSelectedTo(double x, double y) {
        Unit unit = selectedUnit();
        if (terminal() || unit == null || unit.team != 0 || !unit.alive() || !validPoint(x, y))
            return reject("Выберите союзника и доступную точку поверхности");
        if (!assignMove(unit, x, y, MOVE, 0, "Движение")) return false;
        unit.repeatHarvest = false; unit.workTimer = 0;
        return true;
    }

    /** Cancel the selected ally's current path and work without moving it. */
    public boolean stopSelected() {
        Unit unit = selectedUnit();
        if (terminal() || unit == null || unit.team != 0 || !unit.alive())
            return reject("Выберите живого союзника");
        idle(unit); unit.repeatHarvest = false; unit.workTimer = 0;
        unit.targetX = unit.x; unit.targetY = unit.y;
        message = "Приказ отменён: " + unit.title(); event("select"); return true;
    }

    public boolean build(Building.Kind kind, double x, double y) {
        if (terminal() || kind == null || !validPoint(x, y) || buildings.size() >= MAX_BUILDINGS) return reject("Строительство недоступно");
        int cellX = (int) x, cellY = (int) y; x = cellX + .5; y = cellY + .5;
        if (!map.walkable(cellX, cellY) || buildingNear(x, y, 1.25) != null || plantNear(x, y, .7) != null)
            return reject("Место занято или непригодно для строительства");
        if ((kind == Building.Kind.TURRET || kind == Building.Kind.FUSION || kind == Building.Kind.SHIELD) && !hasPowered(Building.Kind.TECH))
            return reject("Сначала постройте и включите технический центр");
        Unit engineer = nearestFriendlySpecialist(Unit.Kind.ENGINEER, x, y);
        if (engineer == null) return reject("Для строительства нужен инженер");
        int cost = Math.max(0, kind.cost - engineer.ability * 2);
        if (goop < cost) return reject("Недостаточно биогеля: требуется " + cost);
        Building building = new Building(nextId++, 0, kind, x, y, false);
        buildings.add(building);
        if (!assignNear(engineer, x, y, BUILD, building.id, "Строительство")) {
            buildings.remove(building); return reject("Инженер не может добраться к площадке");
        }
        goop -= cost; message = "Заложено: " + kind.title; event("build"); return true;
    }

    public boolean upgradeSelectedBuilding() {
        Building b = selectedBuilding();
        if (terminal() || b == null || !b.complete() || b.stage >= b.maxStage())
            return reject("Эту постройку нельзя улучшить");
        int price = b.kind.cost / 2 * (b.stage + 1);
        if (goop < price || cellulose < 20) return reject("Улучшение требует " + price + " биогеля и 20 целлюлозы из целлюлозатора");
        if (b.stage == 1 && !hasPowered(Building.Kind.TECH)) return reject("Высшее улучшение требует технический центр");
        goop -= price; cellulose -= 20; b.stage++; b.maxHp = RetailRules.BUILDING_BMAX[b.retailType()][b.stage]; b.hp = b.maxHp;
        message = "Постройка улучшена: " + b.title(); event("build"); return true;
    }

    public boolean trainCreature(int species) {
        if (terminal() || species < 0 || species >= 25) return reject("Недопустимый вид");
        if (researchLevels[species] < 50) return reject("Сначала изучите этот вид генетиком до 50%");
        Building lab = availableLab(species >= 5 ? 1 : 0);
        if (lab == null) return reject("Нужна свободная работающая " + (species >= 5 ? "геномашина" : "генокапсула"));
        return queueCreature(lab, species);
    }

    public boolean breed(int speciesA, int speciesB) {
        if (terminal() || speciesA < 0 || speciesA >= 5 || speciesB < 0 || speciesB >= 5)
            return reject("Для гибридизации выберите два базовых вида");
        if (researchLevels[speciesA] < 50 || researchLevels[speciesB] < 50)
            return reject("Оба исходных вида должны быть изучены до 50%");
        if (!ownsSpecies(speciesA) || !ownsSpecies(speciesB)) return reject("В команде должны быть оба исходных вида");
        Building lab = availableLab(speciesA == speciesB ? 0 : 1);
        if (lab == null) return reject("Для гибридов нужна свободная геномашина с энергией");
        int species = RetailRules.SPECIES_LOOKUP[speciesA][speciesB];
        if (!queueCreature(lab, species)) return false;
        researchLevels[species] = Math.max(50, researchLevels[species]); return true;
    }

    public boolean orderHarvest() {
        Unit unit = selectedUnit();
        if (terminal() || unit == null || (unit.kind != Unit.Kind.BOTANIST && unit.kind != Unit.Kind.CREATURE))
            return reject("Выберите ботаника или существо");
        Plant plant = closestPlant(unit.x, unit.y);
        if (plant == null) return reject("Поблизости нет биомассы");
        unit.repeatHarvest = true; return assignNear(unit, plant.x, plant.y, HARVEST, plant.id, "Сбор биомассы");
    }

    public boolean recycleWood() {
        if (terminal() || !hasPowered(Building.Kind.RECYCLER)) return reject("Нужен работающий перерабатывающий завод");
        int amount = Math.min(100, wood);
        if (amount <= 0) return reject("Нет древесины для переработки");
        wood -= amount; goop += amount; recycledGoop += amount; message = "Переработано: " + amount; event("build"); return true;
    }

    public boolean recruitSpecialist(Unit.Kind kind) {
        if (terminal() || kind == null || kind == Unit.Kind.CREATURE) return reject("Недопустимый специалист");
        if (units.size() >= MAX_UNITS) return reject("Достигнут предел команды");
        if (goop < 200) return reject("Перевод специалиста требует 200 биогеля");
        for (Building b : buildings) if (b.team == 0 && b.kind == Building.Kind.LANDING_PAD && b.complete() && b.powered && b.queuedSpecialist < 0) {
            goop -= 200; b.queuedSpecialist = kind.ordinal(); b.training = 0; message = "Ожидается специалист"; return true;
        }
        return reject("Нужна свободная посадочная площадка с энергией");
    }

    public boolean callEthereals() {
        if (terminal() || !hasPowered(Building.Kind.DETECTOR)) return reject("Нужен работающий эфириальный детектор");
        if (etherealETA >= 0) return reject("Эфириалы уже в пути");
        etherealETA = 30; message = "Эфириалы прибудут через 30 секунд"; return true;
    }

    public boolean researchSelected() {
        Unit scientist = selectedUnit();
        if (terminal() || scientist == null || scientist.kind != Unit.Kind.GENETICIST) return reject("Выберите генетика");
        Unit best = null; double bestScore = Double.MAX_VALUE;
        for (Unit unit : units) if (unit.alive() && unit.kind == Unit.Kind.CREATURE && researchLevels[unit.species] < 100) {
            double d = distance(scientist.x, scientist.y, unit.x, unit.y);
            if (d < bestScore) { best = unit; bestScore = d; }
        }
        if (best == null) return reject("Нет существ, нуждающихся в изучении");
        return assignNear(scientist, best.x, best.y, RESEARCH, best.id, "Изучение " + best.title());
    }

    public boolean plantTree(double x, double y) {
        Unit botanist = selectedUnit();
        if (terminal() || botanist == null || botanist.kind != Unit.Kind.BOTANIST) return reject("Выберите ботаника");
        if (!validPoint(x, y) || !map.walkable((int) x, (int) y) || buildingNear(x, y, 1) != null
                || plantNear(x, y, .8) != null || plants.size() >= MAX_PLANTS) return reject("Неподходящее место для растения");
        if (distance(botanist.x, botanist.y, x, y) > 3) return reject("Подведите ботаника ближе к месту посадки");
        if (goop < 10) return reject("Посадка требует 10 биогеля");
        goop -= 10; plants.add(new Plant(nextId++, 0, x, y, 50)); plantedTrees++;
        message = "Растение посажено"; event("build"); return true;
    }

    public void update(double deltaSeconds) {
        if (!finite(deltaSeconds) || deltaSeconds < 0) throw new IllegalArgumentException("Invalid time delta");
        if (paused || terminal()) return;
        // A stalled frame cannot trigger minutes of unbounded catch-up work.
        accumulator += Math.min(1, deltaSeconds);
        while (accumulator + 1e-9 >= STEP && !terminal()) { accumulator -= STEP; tick(STEP); }
    }

    public List<String> pollEvents() { List<String> result = new ArrayList<String>(events); events.clear(); return result; }

    private void tick(double dt) {
        elapsed += dt; aiClock += dt; ecologyClock += dt; enemyTrainClock += dt;
        recalculatePower();
        for (Building b : buildings) {
            if (!b.alive() || !b.complete()) continue;
            b.cooldown = Math.max(0, b.cooldown - dt);
            if (b.powered && b.kind == Building.Kind.EXTRACTOR) {
                b.production += dt * 5 * (b.stage + 1);
                int income = (int) b.production; b.production -= income;
                if (b.team == 0) goop += income; else enemyGoop += income;
            }
            if (b.team == 0 && b.powered && b.kind == Building.Kind.PULPER && wood > 0) {
                b.production += dt * 4 * (b.stage + 1);
                int amount = Math.min(wood, (int) b.production); b.production -= amount; wood -= amount; cellulose += amount;
            }
            if (b.team == 0 && b.powered && b.kind == Building.Kind.DETECTOR) {
                b.production += dt * (b.stage + 1);
                int points = (int) b.production; b.production -= points; etherealPoints += points;
            }
            if (b.powered && b.queuedSpecies >= 0 && units.size() < MAX_UNITS) {
                b.training += dt / 7;
                if (b.training >= 1) {
                    addUnit(b.team, Unit.Kind.CREATURE, b.queuedSpecies, b.x + 1.3, b.y);
                    if (b.team == 0) { bornCreatures++; if (b.queuedSpecies == 4) bornMules++; }
                    b.training = 0; b.queuedSpecies = -1; event("birth");
                }
            }
            if (b.powered && b.queuedSpecialist >= 0 && units.size() < MAX_UNITS) {
                b.training += dt / 8;
                if (b.training >= 1) {
                    addUnit(b.team, Unit.Kind.values()[b.queuedSpecialist], 0, b.x + 1.3, b.y);
                    b.training = 0; b.queuedSpecialist = -1; event("birth");
                }
            }
            if (b.kind == Building.Kind.TURRET && b.powered && b.cooldown <= 0) {
                Unit target = nearestEnemyUnit(b.team, b.x, b.y, 7);
                if (target != null) {
                    boolean aliveBefore = target.alive(); hurt(target, 15 * (b.stage + 1), null);
                    if (aliveBefore && !target.alive() && b.team == 0 && target.team == 1) killedEnemies++;
                    b.cooldown = 1.2; event("attack");
                }
            }
        }
        for (Unit unit : new ArrayList<Unit>(units)) {
            if (!unit.alive()) continue;
            unit.age += dt; unit.cooldown = Math.max(0, unit.cooldown - dt); unit.workTimer = Math.max(0, unit.workTimer - dt);
            if (unit.kind == Unit.Kind.CREATURE) {
                unit.energy = Math.max(0, unit.energy - dt * .08);
                if (unit.energy == 0) unit.hp = Math.max(0, unit.hp - dt * 2);
                if (unit.age > unit.lifespan / 10.0) unit.hp = Math.max(0, unit.hp - dt * .2);
            }
            moveUnit(unit, dt); act(unit, dt);
        }
        if (aiClock >= 1) { aiClock -= 1; updateAI(); }
        if (ecologyClock >= 10) { ecologyClock -= 10; updateEcology(); }
        if (enemyTrainClock >= 35) { enemyTrainClock -= 35; enemyTrain(); }
        if (etherealETA >= 0) {
            etherealETA -= dt;
            if (etherealETA <= 0) { etherealETA = -1; etherealPoints += biomassInZone() + creaturesInZone(-1) * 30; message = "Эфириалы оценили биозону"; event("ethereal"); }
        }
        removeDead(); checkObjectives(dt);
        goop = Math.min(goopCapacity, Math.max(0, goop)); wood = Math.min(10000000, Math.max(0, wood));
        cellulose = Math.min(10000000, Math.max(0, cellulose)); etherealPoints = Math.min(10000000, Math.max(0, etherealPoints));
    }

    private void act(Unit u, double dt) {
        if (!u.alive()) return;
        if (u.action == BUILD || u.action == REPAIR) {
            Building b = buildingById(u.targetId);
            if (b == null || !b.alive()) { idle(u); return; }
            if (distance(u.x, u.y, b.x, b.y) > 1.7) { ensureApproach(u, b.x, b.y); return; }
            if (u.action == BUILD) {
                double added = Math.min(1 - b.progress, dt / 8);
                b.progress += added; b.hp = Math.min(b.maxHp, b.hp + added * b.maxHp * .85);
                if (b.complete()) { b.progress = 1; b.hp = b.maxHp; idle(u); message = "Готово: " + b.kind.title; event("build"); autoBuild(u); }
            } else {
                if (wood <= 0) { idle(u); message = "Для ремонта нужна древесина"; return; }
                if (u.workTimer <= 0) { wood--; b.hp = Math.min(b.maxHp, b.hp + 12); u.workTimer = .5; }
                if (b.hp >= b.maxHp) idle(u);
            }
        } else if (u.action == HARVEST || u.action == FEED) {
            Plant p = plantById(u.targetId);
            if (p == null || p.biomass <= 0) {
                if (u.repeatHarvest) { Plant next = closestPlant(u.x, u.y); if (next != null) { assignNear(u, next.x, next.y, HARVEST, next.id, "Сбор биомассы"); return; } }
                idle(u); return;
            }
            if (distance(u.x, u.y, p.x, p.y) > 1.5) { ensureApproach(u, p.x, p.y); return; }
            if (u.workTimer <= 0) {
                int amount = Math.min(6, p.biomass); p.biomass -= amount; u.workTimer = .5;
                if (u.action == FEED) { u.energy = Math.min(u.maxEnergy(), u.energy + amount * 3); if (u.energy >= u.maxEnergy() * .85) idle(u); }
                else if (u.team == 0) {
                    wood += amount;
                    if (hasPowered(Building.Kind.RECYCLER)) { wood -= amount; goop += amount; recycledGoop += amount; }
                }
            }
        } else if (u.action == ATTACK) {
            Unit target = unitById(u.targetId); Building b = buildingById(u.targetId);
            if ((target == null || !target.alive()) && (b == null || !b.alive())) { idle(u); return; }
            double x = target != null ? target.x : b.x, y = target != null ? target.y : b.y;
            if (distance(u.x, u.y, x, y) > attackRange(u)) { ensureApproach(u, x, y); return; }
            u.path = new int[0]; u.pathCursor = 0;
            if (u.cooldown <= 0) {
                double strength = u.kind == Unit.Kind.CREATURE ? RetailRules.SPECIES_STRENGTH[u.species] : (u.kind == Unit.Kind.RANGER ? 30 : 8);
                double defense = target != null && target.kind == Unit.Kind.CREATURE ? RetailRules.SPECIES_DEFENSE[target.species] : 2;
                double damage = Math.max(1, strength * .6 - defense * .25);
                if (target != null) hurt(target, damage, u); else b.hp = Math.max(0, b.hp - damage * shieldFactor(b.team, b.x, b.y));
                u.cooldown = 1; event("attack");
            }
        } else if (u.action == RESEARCH || u.action == HEAL) {
            Unit target = unitById(u.targetId);
            if (target == null || !target.alive()) { idle(u); return; }
            if (distance(u.x, u.y, target.x, target.y) > 2) { ensureApproach(u, target.x, target.y); return; }
            if (u.workTimer <= 0) {
                if (u.action == HEAL) { target.hp = Math.min(target.maxHp, target.hp + 6); if (target.hp == target.maxHp) idle(u); }
                else {
                    int cap = 50; for (Building b : buildings) if (b.team == 0 && b.kind == Building.Kind.GENE_LAB && b.complete()) cap = Math.max(cap, b.stage == 2 ? 100 : b.stage == 1 ? 75 : 50);
                    researchLevels[target.species] = Math.min(cap, researchLevels[target.species] + 2);
                    message = target.title() + ": изучено " + researchLevels[target.species] + "%";
                    if (researchLevels[target.species] >= cap) idle(u);
                }
                u.workTimer = .25;
            }
        }
    }

    private void moveUnit(Unit u, double dt) {
        if (u.pathCursor >= u.path.length) { if (u.action == MOVE) idle(u); return; }
        int tile = u.path[u.pathCursor]; int x = tile % map.width, y = tile / map.width;
        if (!passable(u, x, y)) { u.path = new int[0]; u.pathCursor = 0; return; }
        double tx = x + .5, ty = y + .5, dx = tx - u.x, dy = ty - u.y, length = Math.sqrt(dx * dx + dy * dy);
        double speed = u.kind == Unit.Kind.CREATURE ? RetailRules.SPECIES_SPEED[u.species] / 512.0 : 2;
        double friction = 1;
        int terrain = map.terrain[tile] & 255;
        if (!flies(u)) {
            int[] recoveredFriction = {512, 704, 448, 320, 384, 384, 256, 320};
            friction = terrain < recoveredFriction.length ? 512.0 / recoveredFriction[terrain] : 1;
        }
        double amount = Math.max(.2, speed) * friction * dt;
        if (length <= amount) { u.x = tx; u.y = ty; u.pathCursor++; }
        else { u.x += dx / length * amount; u.y += dy / length * amount; }
    }

    private void updateAI() {
        for (Unit u : units) {
            if (!u.alive()) continue;
            if (u.team == 1 && (u.action == IDLE || u.action == MOVE || u.action == ATTACK)) {
                Unit target = nearestEnemyUnit(1, u.x, u.y, map.width + map.height);
                Building b = nearestEnemyBuilding(1, u.x, u.y);
                if (target != null && (b == null || distance(u.x, u.y, target.x, target.y) < distance(u.x, u.y, b.x, b.y)))
                    assignNear(u, target.x, target.y, ATTACK, target.id, "Атака");
                else if (b != null) assignNear(u, b.x, b.y, ATTACK, b.id, "Атака базы");
            } else if (u.team == 0 && u.action == IDLE && (u.kind == Unit.Kind.CREATURE || u.kind == Unit.Kind.RANGER)) {
                Unit enemy = nearestEnemyUnit(0, u.x, u.y, 6);
                if (enemy != null) assignNear(u, enemy.x, enemy.y, ATTACK, enemy.id, "Защита команды");
            }
            if (u.kind == Unit.Kind.CREATURE && u.action == IDLE && u.energy < u.maxEnergy() * .4) {
                Plant p = closestPlant(u.x, u.y); if (p != null) assignNear(u, p.x, p.y, FEED, p.id, "Питание");
            }
            if (u.team == 2 && u.action == IDLE && randomInt(4) == 0)
                assignMove(u, clamp(u.x + randomInt(7) - 3, .5, map.width - .5), clamp(u.y + randomInt(7) - 3, .5, map.height - .5), MOVE, 0, "Бродит");
        }
    }

    private void updateEcology() {
        for (Plant p : plants) if (p.biomass > 0) p.biomass = Math.min(120, p.biomass + 2);
        if (plants.size() < Math.min(MAX_PLANTS, 350) && !plants.isEmpty()) {
            Plant parent = plants.get(randomInt(plants.size()));
            double x = parent.x + randomInt(7) - 3, y = parent.y + randomInt(7) - 3;
            if (validPoint(x, y) && map.walkable((int) x, (int) y) && plantNear(x, y, 1) == null && buildingNear(x, y, 1) == null)
                plants.add(new Plant(nextId++, parent.species, x, y, 30));
        }
    }

    private void recalculatePower() {
        powerProduced = powerUsed = 0; goopCapacity = 5000;
        for (Building b : buildings) if (b.team == 0 && b.alive() && b.complete() && b.kind == Building.Kind.VAT) goopCapacity += 3000;
        for (Building b : buildings) b.powered = false;
        for (int team = 0; team <= 1; team++) {
            List<Building> distributors = new ArrayList<Building>(); int supplied = 0, used = 0;
            for (Building b : buildings) if (b.team == team && b.alive() && b.complete() && b.kind == Building.Kind.DISTRIBUTOR) {
                distributors.add(b); b.powered = true; supplied += b.kind.powerOutput;
            }
            for (Building b : buildings) if (b.team == team && b.alive() && b.complete()
                    && (b.kind == Building.Kind.SOLAR || b.kind == Building.Kind.WIND || b.kind == Building.Kind.FUSION)) {
                if (nearDistributor(distributors, b.x, b.y)) { b.powered = true; supplied += b.kind.powerOutput * (b.stage + 1); }
            }
            for (Building b : buildings) if (b.team == team && b.alive() && b.complete() && b.kind.powerUse > 0) {
                if (nearDistributor(distributors, b.x, b.y)) {
                    used += b.kind.powerUse;
                    if (used <= supplied) b.powered = true;
                }
            }
            if (team == 0) { powerProduced = supplied; powerUsed = used; }
        }
    }
    private boolean nearDistributor(List<Building> distributors, double x, double y) {
        for (Building d : distributors) if (distance(d.x, d.y, x, y) <= 10 + d.stage * 5) return true;
        return false;
    }

    private void checkObjectives(double dt) {
        if (countUnits(0) == 0) { defeat = true; message = "Команда потеряна"; event("lose"); return; }
        boolean completed;
        switch (missionIndex) {
            case 0: completed = countBuildings(0, Building.Kind.EXTRACTOR) >= 1 && countBuildings(0, Building.Kind.DISTRIBUTOR) >= 1 && countBuildings(0, Building.Kind.SOLAR) >= 3; break;
            case 1: completed = bornMules >= 3 && countBuildings(0, Building.Kind.GENE_LAB) >= 1 && creaturesInZone(4) >= 3; break;
            case 2: completed = recycledGoop >= 1400; break;
            case 3:
                if (creaturesInZone(-1) >= 4 && biomassInZone() >= 150) holdClock += dt; else holdClock = 0;
                completed = holdClock + 1e-9 >= 30; break;
            default: completed = countUnits(1) == 0 && countBuildings(1, null) == 0; break;
        }
        if (completed) { victory = true; message = "Задание выполнено!"; event("win"); }
    }

    private void createEnemyBase() {
        int tile = nearestFree(map.width - spawnX, map.height - spawnY, false);
        if (tile < 0) return;
        double x = tile % map.width + .5, y = tile / map.width + .5;
        addFinishedBuilding(1, Building.Kind.DISTRIBUTOR, x, y);
        addFinishedBuilding(1, Building.Kind.SOLAR, x + 2, y);
        addFinishedBuilding(1, Building.Kind.SOLAR, x - 2, y);
        addFinishedBuilding(1, Building.Kind.GENE_LAB, x, y + 2);
        addFinishedBuilding(1, Building.Kind.EXTRACTOR, x, y - 2);
        for (int i = 0; i < 4; i++) addUnit(1, Unit.Kind.CREATURE, i % 3, x + i, y + 4);
    }
    private void addFinishedBuilding(int team, Building.Kind kind, double x, double y) {
        int tile = nearestFree(x, y, false);
        if (tile >= 0) buildings.add(new Building(nextId++, team, kind, tile % map.width + .5, tile / map.width + .5, true));
    }
    private void enemyTrain() {
        if (missionIndex < 3 || countUnits(1) >= 16) return;
        for (Building b : buildings) if (b.team == 1 && b.kind == Building.Kind.GENE_LAB && b.powered && b.queuedSpecies < 0) {
            int species = randomInt(3), cost = RetailRules.SPECIES_COST[species];
            if (enemyGoop >= cost) { enemyGoop -= cost; b.queuedSpecies = species; b.training = 0; }
            return;
        }
    }

    private boolean assignMove(Unit u, double x, double y, int action, int targetId, String task) {
        if (!validPoint(x, y)) return false;
        int goal = map.index((int) x, (int) y);
        int[] path = findPath(u, goal);
        if (path == null) { message = "Путь перекрыт"; return false; }
        u.path = path; u.pathCursor = 0; u.targetX = x; u.targetY = y;
        u.action = action; u.targetId = targetId; u.task = task; return true;
    }
    private boolean assignNear(Unit u, double x, double y, int action, int targetId, String task) {
        if (!validPoint(x, y)) return false;
        if (distance(u.x, u.y, x, y) <= 1.5) {
            u.path = new int[0]; u.pathCursor = 0; u.action = action; u.targetId = targetId; u.task = task; return true;
        }
        List<Integer> candidates = new ArrayList<Integer>();
        int tx = (int) x, ty = (int) y;
        for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
            int cx = tx + dx, cy = ty + dy;
            if (passable(u, cx, cy)) candidates.add(map.index(cx, cy));
        }
        final Unit moving = u;
        java.util.Collections.sort(candidates, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return Double.compare(distance(moving.x, moving.y, a % map.width + .5, a / map.width + .5),
                        distance(moving.x, moving.y, b % map.width + .5, b / map.width + .5));
            }
        });
        // The closest open workstation may be isolated. Try every bounded
        // neighbor before declaring a reachable object inaccessible.
        for (int candidate : candidates)
            if (assignMove(u, candidate % map.width + .5, candidate / map.width + .5, action, targetId, task)) return true;
        return false;
    }
    private void ensureApproach(Unit u, double x, double y) {
        if (u.pathCursor >= u.path.length) assignNear(u, x, y, u.action, u.targetId, u.task);
    }
    private void autoBuild(Unit u) {
        if (u.kind != Unit.Kind.ENGINEER || u.team != 0) return;
        Building best = null; double d = Double.MAX_VALUE;
        for (Building b : buildings) if (b.team == 0 && b.alive() && !b.complete()) {
            double dist = distance(u.x, u.y, b.x, b.y); if (dist < d) { best = b; d = dist; }
        }
        if (best != null) assignNear(u, best.x, best.y, BUILD, best.id, "Строительство");
    }

    private static final class Node implements Comparable<Node> {
        final int tile, distance, score;
        Node(int tile, int distance, int score) { this.tile = tile; this.distance = distance; this.score = score; }
        public int compareTo(Node other) { int d = Integer.compare(score, other.score); return d != 0 ? d : Integer.compare(tile, other.tile); }
    }
    private int[] findPath(Unit u, int goal) {
        int sx = (int) u.x, sy = (int) u.y, gx = goal % map.width, gy = goal / map.width;
        if (!passable(u, gx, gy)) return null;
        int start = map.index(sx, sy); if (start == goal) return new int[0];
        int[] cost = new int[map.width * map.height], parent = new int[cost.length];
        Arrays.fill(cost, Integer.MAX_VALUE); Arrays.fill(parent, -1); cost[start] = 0;
        PriorityQueue<Node> open = new PriorityQueue<Node>(); open.add(new Node(start, 0, Math.abs(gx - sx) + Math.abs(gy - sy)));
        int visited = 0; boolean[] closed = new boolean[cost.length];
        int[] dx = {0, 1, 0, -1}, dy = {-1, 0, 1, 0};
        while (!open.isEmpty() && visited < cost.length) {
            Node node = open.poll(); if (node.distance != cost[node.tile] || closed[node.tile]) continue;
            closed[node.tile] = true; visited++;
            if (node.tile == goal) {
                int length = 0; for (int at = goal; at != start; at = parent[at]) { if (at < 0 || length++ > cost.length) return null; }
                int[] path = new int[length]; int at = goal;
                for (int i = length - 1; i >= 0; i--) { path[i] = at; at = parent[at]; }
                return path;
            }
            int x = node.tile % map.width, y = node.tile / map.width;
            for (int direction = 0; direction < 4; direction++) {
                int nx = x + dx[direction], ny = y + dy[direction]; if (!passable(u, nx, ny)) continue;
                int next = map.index(nx, ny), distance = node.distance + 1;
                if (distance < cost[next]) { cost[next] = distance; parent[next] = node.tile; open.add(new Node(next, distance, distance + Math.abs(gx - nx) + Math.abs(gy - ny))); }
            }
        }
        return null;
    }
    private boolean passable(Unit u, int x, int y) {
        if (!map.contains(x, y) || (!flies(u) && !map.walkable(x, y))) return false;
        for (Building b : buildings) if (b.alive() && (int) b.x == x && (int) b.y == y) return false;
        return true;
    }
    private boolean flies(Unit u) { return u.kind == Unit.Kind.CREATURE && RetailRules.SPECIES_GENES[u.species][0] == 3; }
    private int nearestFree(double x, double y, boolean flying) {
        int best = -1; double bestDistance = Double.MAX_VALUE;
        for (int cy = 0; cy < map.height; cy++) for (int cx = 0; cx < map.width; cx++) {
            if ((flying || map.walkable(cx, cy)) && buildingNear(cx + .5, cy + .5, .8) == null) {
                double d = distance(cx + .5, cy + .5, x, y); if (d < bestDistance) { bestDistance = d; best = map.index(cx, cy); }
            }
        }
        return best;
    }
    private Unit addUnit(int team, Unit.Kind kind, int species, double x, double y) {
        int tile = nearestFree(x, y, kind == Unit.Kind.CREATURE && RetailRules.SPECIES_GENES[species][0] == 3);
        if (tile < 0) throw new IllegalStateException("No spawn position");
        Unit unit = new Unit(nextId++, team, kind, species, tile % map.width + .5, tile / map.width + .5);
        units.add(unit); return unit;
    }

    private boolean queueCreature(Building lab, int species) {
        int cost = RetailRules.SPECIES_COST[species];
        if (goop < cost) return reject("Недостаточно биогеля: требуется " + cost);
        if (units.size() >= MAX_UNITS) return reject("Достигнут предел существ");
        goop -= cost; lab.queuedSpecies = species; lab.training = 0; message = "Создание: " + SPECIES_NAMES[species]; return true;
    }
    private Building availableLab(int stage) {
        for (Building b : buildings) if (b.team == 0 && b.alive() && b.complete() && b.powered && b.kind == Building.Kind.GENE_LAB && b.stage >= stage && b.queuedSpecies < 0) return b;
        return null;
    }
    private boolean ownsSpecies(int species) { for (Unit u : units) if (u.team == 0 && u.alive() && u.kind == Unit.Kind.CREATURE && u.species == species) return true; return false; }
    private boolean hasPowered(Building.Kind kind) { for (Building b : buildings) if (b.team == 0 && b.kind == kind && b.alive() && b.complete() && b.powered) return true; return false; }
    private int countUnits(int team) { int n = 0; for (Unit u : units) if (u.team == team && u.alive()) n++; return n; }
    private int countBuildings(int team, Building.Kind kind) { int n = 0; for (Building b : buildings) if (b.team == team && b.alive() && b.complete() && (kind == null || b.kind == kind)) n++; return n; }
    private int creaturesInZone(int species) { int n = 0; for (Unit u : units) if (u.team == 0 && u.alive() && u.kind == Unit.Kind.CREATURE && (species < 0 || u.species == species) && distance(u.x, u.y, zoneX, zoneY) <= zoneRadius) n++; return n; }
    private int biomassInZone() { int result = 0; for (Plant p : plants) if (distance(p.x, p.y, zoneX, zoneY) <= zoneRadius) result += p.biomass; return result; }
    private Unit unitById(int id) { for (Unit u : units) if (u.id == id) return u; return null; }
    private Building buildingById(int id) { for (Building b : buildings) if (b.id == id) return b; return null; }
    private Plant plantById(int id) { for (Plant p : plants) if (p.id == id) return p; return null; }
    private Plant plantNear(double x, double y, double radius) { Plant best = null; for (Plant p : plants) { double d = distance(p.x, p.y, x, y); if (p.biomass > 0 && d < radius) { best = p; radius = d; } } return best; }
    private Plant closestPlant(double x, double y) { return plantNear(x, y, map.width + map.height); }
    private Building buildingNear(double x, double y, double radius) { Building best = null; for (Building b : buildings) { double d = distance(b.x, b.y, x, y); if (b.alive() && d < radius) { best = b; radius = d; } } return best; }
    private Unit nearestUnit(double x, double y, double radius, int team, int ignoreId) {
        Unit best = null; for (Unit u : units) { double d = distance(u.x, u.y, x, y); if (u.alive() && u.id != ignoreId && (team < 0 || u.team == team) && d < radius) { best = u; radius = d; } } return best;
    }
    private Unit nearestEnemyUnit(int team, double x, double y, double radius) {
        Unit best = null; for (Unit u : units) if (u.alive() && u.team != team && u.team != 2) { double d = distance(u.x, u.y, x, y); if (d < radius) { best = u; radius = d; } } return best;
    }
    private Building nearestEnemyBuilding(int team, double x, double y) {
        Building best = null; double distance = Double.MAX_VALUE;
        for (Building b : buildings) if (b.alive() && b.team != team) { double d = distance(b.x, b.y, x, y); if (d < distance) { best = b; distance = d; } }
        return best;
    }
    private Unit nearestFriendlySpecialist(Unit.Kind kind, double x, double y) {
        Unit best = null; double d = Double.MAX_VALUE;
        for (Unit u : units) if (u.team == 0 && u.alive() && u.kind == kind) { double n = distance(u.x, u.y, x, y); if (n < d) { best = u; d = n; } }
        return best;
    }
    private double attackRange(Unit u) {
        if (u.kind == Unit.Kind.RANGER) return 5;
        if (u.kind != Unit.Kind.CREATURE) return 1.5;
        int base = RetailRules.SPECIES_GENES[u.species][0]; return base == 2 ? 4 : base == 3 ? 2.5 : 1.6;
    }
    private void hurt(Unit target, double damage, Unit attacker) {
        boolean wasAlive = target.alive(); target.hp = Math.max(0, target.hp - damage * shieldFactor(target.team, target.x, target.y));
        if (wasAlive && !target.alive() && target.team == 1 && attacker != null && attacker.team == 0) killedEnemies++;
        if (target.alive() && target.team == 2 && attacker != null)
            assignNear(target, attacker.x, attacker.y, ATTACK, attacker.id, "Самозащита");
    }
    private double shieldFactor(int team, double x, double y) {
        for (Building b : buildings) if (b.team == team && b.kind == Building.Kind.SHIELD && b.alive() && b.complete() && b.powered
                && distance(b.x, b.y, x, y) <= 6 + b.stage * 3) return .4;
        return 1;
    }
    private void removeDead() {
        for (int i = units.size() - 1; i >= 0; i--) if (!units.get(i).alive()) {
            Unit u = units.remove(i); if (selectedId == u.id) clearSelection();
            // Carcass biomass can be recovered by the same harvesting chain.
            if (plants.size() < MAX_PLANTS) plants.add(new Plant(nextId++, 11, u.x, u.y, 25));
        }
        for (int i = buildings.size() - 1; i >= 0; i--) if (!buildings.get(i).alive()) {
            if (selectedId == buildings.get(i).id) clearSelection(); buildings.remove(i);
        }
        for (int i = plants.size() - 1; i >= 0; i--) if (plants.get(i).biomass <= 0) plants.remove(i);
    }
    private void idle(Unit u) { u.action = IDLE; u.targetId = 0; u.path = new int[0]; u.pathCursor = 0; u.task = "Ожидание"; }
    private boolean terminal() { return victory || defeat; }
    private boolean validPoint(double x, double y) { return finite(x) && finite(y) && x >= 0 && y >= 0 && x < map.width && y < map.height; }
    private boolean reject(String text) { message = text; return false; }
    private void event(String name) { if (events.size() < 32) events.add(name); }
    private int randomInt(int bound) { randomState = randomState * 6364136223846793005L + 1442695040888963407L; return (int) ((randomState >>> 1) % bound); }
    private static double distance(double x, double y, double xx, double yy) { return Math.hypot(x - xx, y - yy); }
    private static double clamp(double x, double min, double max) { return Math.max(min, Math.min(max, x)); }
    private static boolean finite(double value) { return !Double.isNaN(value) && !Double.isInfinite(value); }

    // Save format: checksummed envelope, embedded checksummed map, bounded arrays.
    public byte[] save() throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(buffer);
        out.writeInt(0x47575356); out.writeInt(SAVE_VERSION);
        byte[] mapBytes = map.toBytes(); out.writeInt(mapBytes.length); out.write(mapBytes);
        out.writeInt(missionIndex); out.writeLong(randomState); out.writeInt(nextId); out.writeInt(enemyGoop);
        out.writeInt(goop); out.writeInt(wood); out.writeInt(cellulose); out.writeInt(etherealPoints); out.writeDouble(etherealETA);
        out.writeInt(selectedId); out.writeInt(recycledGoop); out.writeInt(bornCreatures); out.writeInt(bornMules); out.writeInt(killedEnemies); out.writeInt(plantedTrees);
        out.writeDouble(elapsed); out.writeDouble(accumulator); out.writeDouble(aiClock); out.writeDouble(ecologyClock); out.writeDouble(enemyTrainClock); out.writeDouble(holdClock);
        out.writeDouble(spawnX); out.writeDouble(spawnY); out.writeDouble(zoneX); out.writeDouble(zoneY); out.writeDouble(zoneRadius);
        out.writeBoolean(victory); out.writeBoolean(defeat); out.writeBoolean(paused); out.writeUTF(message);
        for (int value : researchLevels) out.writeInt(value);
        out.writeInt(units.size());
        for (Unit u : units) {
            out.writeInt(u.id); out.writeInt(u.team); out.writeInt(u.kind.ordinal()); out.writeInt(u.species);
            out.writeDouble(u.x); out.writeDouble(u.y); out.writeDouble(u.hp); out.writeDouble(u.maxHp); out.writeDouble(u.energy); out.writeDouble(u.age);
            out.writeDouble(u.energyCapacity); out.writeDouble(u.lifespan); out.writeInt(u.ability);
            out.writeUTF(u.task); out.writeInt(u.action); out.writeInt(u.targetId); out.writeDouble(u.targetX); out.writeDouble(u.targetY); out.writeDouble(u.cooldown); out.writeDouble(u.workTimer); out.writeBoolean(u.repeatHarvest);
            out.writeInt(u.path.length); out.writeInt(u.pathCursor); for (int tile : u.path) out.writeInt(tile);
        }
        out.writeInt(buildings.size());
        for (Building b : buildings) {
            out.writeInt(b.id); out.writeInt(b.team); out.writeInt(b.kind.ordinal()); out.writeInt(b.stage);
            out.writeDouble(b.x); out.writeDouble(b.y); out.writeDouble(b.hp); out.writeDouble(b.maxHp); out.writeDouble(b.progress);
            out.writeDouble(b.production); out.writeDouble(b.cooldown); out.writeInt(b.queuedSpecies); out.writeInt(b.queuedSpecialist); out.writeDouble(b.training);
        }
        out.writeInt(plants.size());
        for (Plant p : plants) { out.writeInt(p.id); out.writeInt(p.species); out.writeDouble(p.x); out.writeDouble(p.y); out.writeInt(p.biomass); out.writeDouble(p.growth); }
        out.flush(); if (buffer.size() > MAX_SAVE_BYTES - 4) throw new IOException("Save too large");
        CRC32 crc = new CRC32(); crc.update(buffer.toByteArray()); out.writeInt((int) crc.getValue()); out.flush(); return buffer.toByteArray();
    }

    public static GameState load(byte[] bytes) throws IOException {
        if (bytes == null || bytes.length < 64 || bytes.length > MAX_SAVE_BYTES) throw new IOException("Invalid save length");
        CRC32 crc = new CRC32(); crc.update(bytes, 0, bytes.length - 4);
        DataInputStream tail = new DataInputStream(new ByteArrayInputStream(bytes, bytes.length - 4, 4));
        if ((int) crc.getValue() != tail.readInt()) throw new IOException("Save CRC mismatch");
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes, 0, bytes.length - 4));
        if (in.readInt() != 0x47575356 || in.readInt() != SAVE_VERSION) throw new IOException("Unsupported save version");
        int mapLength = bounded(in.readInt(), 24, 1024 * 1024, "map length");
        if (mapLength > in.available()) throw new IOException("Truncated embedded map");
        byte[] mapBytes = new byte[mapLength]; in.readFully(mapBytes);
        WorldMap map = WorldMap.read(new ByteArrayInputStream(mapBytes));
        int mission = bounded(in.readInt(), 0, MISSION_COUNT - 1, "mission");
        GameState g = new GameState(map, mission, in.readLong());
        g.nextId = bounded(in.readInt(), 1, 100000000, "next id"); g.enemyGoop = bounded(in.readInt(), 0, 10000000, "enemy resources");
        g.goop = bounded(in.readInt(), 0, 10000000, "resources"); g.wood = bounded(in.readInt(), 0, 10000000, "wood");
        g.cellulose = bounded(in.readInt(), 0, 10000000, "cellulose"); g.etherealPoints = bounded(in.readInt(), 0, 10000000, "ethereal points"); g.etherealETA = number(in, -1, 1000000, "arrival time");
        g.selectedId = bounded(in.readInt(), 0, 100000000, "selection");
        g.recycledGoop = bounded(in.readInt(), 0, 10000000, "recycled"); g.bornCreatures = bounded(in.readInt(), 0, 1000000, "birth count");
        g.bornMules = bounded(in.readInt(), 0, g.bornCreatures, "mule birth count");
        g.killedEnemies = bounded(in.readInt(), 0, 1000000, "kill count"); g.plantedTrees = bounded(in.readInt(), 0, 1000000, "plant count");
        g.elapsed = number(in, 0, 1e9, "time"); g.accumulator = number(in, -.000001, 2, "accumulator"); g.aiClock = number(in, 0, 2, "AI clock"); g.ecologyClock = number(in, 0, 11, "ecology clock"); g.enemyTrainClock = number(in, 0, 36, "training clock"); g.holdClock = number(in, 0, 1e9, "mission clock");
        g.spawnX = number(in, 0, map.width, "spawn x"); g.spawnY = number(in, 0, map.height, "spawn y");
        g.zoneX = number(in, 0, map.width, "zone x"); g.zoneY = number(in, 0, map.height, "zone y"); g.zoneRadius = number(in, .1, 50, "zone radius");
        g.victory = in.readBoolean(); g.defeat = in.readBoolean(); g.paused = in.readBoolean(); g.message = in.readUTF();
        if (g.message.length() > 512 || (g.victory && g.defeat)) throw new IOException("Invalid save state");
        for (int i = 0; i < 25; i++) g.researchLevels[i] = bounded(in.readInt(), 0, 100, "research");
        Set<Integer> ids = new HashSet<Integer>(); int maxId = 0;
        int count = bounded(in.readInt(), 0, MAX_UNITS, "units");
        for (int i = 0; i < count; i++) {
            int id = readId(in, ids); maxId = Math.max(maxId, id);
            int team = bounded(in.readInt(), 0, 2, "team"), kind = bounded(in.readInt(), 0, Unit.Kind.values().length - 1, "unit kind"), species = bounded(in.readInt(), 0, 24, "species");
            double x = coordinate(in, map.width), y = coordinate(in, map.height);
            Unit u = new Unit(id, team, Unit.Kind.values()[kind], species, x, y);
            u.hp = number(in, 0, 10000, "health"); u.maxHp = number(in, 1, 10000, "maximum health"); u.energy = number(in, 0, 100000, "energy"); u.age = number(in, 0, 1e9, "age");
            u.energyCapacity = number(in, 1, 100000, "maximum energy"); u.lifespan = number(in, 1, 1e9, "lifespan"); u.ability = bounded(in.readInt(), 0, 100, "ability");
            if (u.hp > u.maxHp || u.energy > u.energyCapacity) throw new IOException("Health or energy exceeds maximum");
            u.task = in.readUTF(); if (u.task.length() > 256) throw new IOException("Invalid task");
            u.action = bounded(in.readInt(), IDLE, REPAIR, "action"); u.targetId = bounded(in.readInt(), 0, 100000000, "target");
            u.targetX = coordinate(in, map.width); u.targetY = coordinate(in, map.height); u.cooldown = number(in, 0, 10000, "cooldown"); u.workTimer = number(in, 0, 10000, "work timer"); u.repeatHarvest = in.readBoolean();
            int pathLength = bounded(in.readInt(), 0, map.width * map.height, "path length"); u.pathCursor = bounded(in.readInt(), 0, pathLength, "path cursor");
            if (pathLength > in.available() / 4) throw new IOException("Truncated path");
            u.path = new int[pathLength]; for (int j = 0; j < pathLength; j++) u.path[j] = bounded(in.readInt(), 0, map.width * map.height - 1, "path cell");
            g.units.add(u);
        }
        count = bounded(in.readInt(), 0, MAX_BUILDINGS, "buildings");
        for (int i = 0; i < count; i++) {
            int id = readId(in, ids); maxId = Math.max(maxId, id); int team = bounded(in.readInt(), 0, 1, "building team"), kind = bounded(in.readInt(), 0, Building.Kind.values().length - 1, "building kind"), stage = bounded(in.readInt(), 0, 2, "stage");
            Building b = new Building(id, team, Building.Kind.values()[kind], coordinate(in, map.width), coordinate(in, map.height), false); b.stage = stage;
            b.hp = number(in, 0, 10000, "building health"); b.maxHp = number(in, 1, 10000, "building maximum health"); b.progress = number(in, 0, 1, "progress");
            if (b.hp > b.maxHp) throw new IOException("Building health exceeds maximum");
            b.production = number(in, 0, 10000, "production"); b.cooldown = number(in, 0, 10000, "building cooldown"); b.queuedSpecies = bounded(in.readInt(), -1, 24, "queued species");
            b.queuedSpecialist = bounded(in.readInt(), -1, 3, "queued specialist"); b.training = number(in, 0, 1.1, "training");
            if ((b.queuedSpecies >= 0 && (b.kind != Building.Kind.GENE_LAB || b.queuedSpecialist >= 0))
                    || (b.queuedSpecialist >= 0 && b.kind != Building.Kind.LANDING_PAD)) throw new IOException("Invalid production queue");
            g.buildings.add(b);
        }
        count = bounded(in.readInt(), 0, MAX_PLANTS, "plants");
        for (int i = 0; i < count; i++) {
            int id = readId(in, ids); maxId = Math.max(maxId, id); int species = bounded(in.readInt(), 0, 11, "plant species");
            Plant p = new Plant(id, species, coordinate(in, map.width), coordinate(in, map.height), bounded(in.readInt(), 0, 10000, "biomass")); p.growth = number(in, 0, 10000, "growth"); g.plants.add(p);
        }
        if (in.available() != 0 || g.nextId <= maxId) throw new IOException("Invalid trailing data or next id");
        if (g.selectedId != 0) {
            Unit selected = g.unitById(g.selectedId); Building selectedBuilding = g.buildingById(g.selectedId);
            if ((selected == null || selected.team != 0) && (selectedBuilding == null || selectedBuilding.team != 0)) throw new IOException("Invalid selected entity");
            if (selected != null) selected.selected = true;
        }
        g.recalculatePower(); return g;
    }

    public void saveAtomic(File file) throws IOException {
        File absolute = file.getAbsoluteFile(), parent = absolute.getParentFile();
        if (parent == null || (!parent.isDirectory() && !parent.mkdirs())) throw new IOException("Cannot create save directory");
        File temporary = File.createTempFile(absolute.getName() + ".", ".tmp", parent);
        try {
            FileOutputStream out = new FileOutputStream(temporary);
            try { out.write(save()); out.getFD().sync(); } finally { out.close(); }
            try { Files.move(temporary.toPath(), absolute.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException error) { throw new IOException("Filesystem does not support atomic save replacement", error); }
        } finally { if (temporary.exists()) temporary.delete(); }
    }
    public static GameState load(File file) throws IOException {
        FileInputStream input = new FileInputStream(file);
        try { return load(WorldMap.readLimited(input, MAX_SAVE_BYTES)); } finally { input.close(); }
    }
    private static int bounded(int value, int min, int max, String field) throws IOException { if (value < min || value > max) throw new IOException("Invalid " + field); return value; }
    private static double number(DataInputStream in, double min, double max, String field) throws IOException { double value = in.readDouble(); if (!finite(value) || value < min || value > max) throw new IOException("Invalid " + field); return value; }
    private static double coordinate(DataInputStream in, int max) throws IOException { double value = number(in, 0, max, "coordinate"); if (value >= max) throw new IOException("Coordinate outside map"); return value; }
    private static int readId(DataInputStream in, Set<Integer> ids) throws IOException { int id = bounded(in.readInt(), 1, 100000000, "entity id"); if (!ids.add(id)) throw new IOException("Duplicate entity ID"); return id; }
}
