package org.genewars.core;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;

/** Plain-JVM integration and corruption tests, no Android or test framework. */
public final class CoreTests {
    private static int passed;
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static WorldMap map(int size) {
        byte[] terrain = new byte[size * size]; Arrays.fill(terrain, (byte) 2);
        return new WorldMap(size, size, terrain, new short[size * size], new boolean[size * size], "test");
    }
    private static GameState scenario(WorldMap map, int mission) {
        GameState game = GameState.newGame(map, mission, 1234, 2.5, 2.5);
        game.clearScenarioEntities(); game.finishScenarioImport(2000); return game;
    }
    private static void advance(GameState game, double seconds) {
        int frames = (int) Math.round(seconds * 10);
        for (int i = 0; i < frames; i++) game.update(.1);
    }
    private static Building building(GameState game, Building.Kind kind) {
        for (Building b : game.buildings) if (b.kind == kind && b.team == 0) return b;
        throw new AssertionError("No building " + kind);
    }
    private static void completePowerLab(GameState game) {
        game.importBuilding(3, 0, 5.5, 5.5, 0, 240, 1);
        game.importBuilding(6, 0, 7.5, 5.5, 0, 80, 1);
        game.importBuilding(0, 0, 5.5, 7.5, 0, 280, 1);
        game.importBuilding(2, 0, 7.5, 7.5, 0, 160, 1);
        game.finishScenarioImport(2000);
    }

    private static void worldMapIntegrity() throws Exception {
        WorldMap source = map(16); source.blocked[12] = true; source.elevation[42] = 1234;
        byte[] encoded = source.toBytes(); WorldMap loaded = WorldMap.read(new ByteArrayInputStream(encoded));
        check(loaded.width == 16 && loaded.blocked[12] && loaded.elevation[42] == 1234, "Map data changed");
        encoded[20] ^= 1;
        try { WorldMap.read(new ByteArrayInputStream(encoded)); throw new AssertionError("Corrupt map accepted"); }
        catch (IOException expected) { }
        passed++;
    }

    private static void recoveredDataTables() {
        check(RetailRules.SPECIES_HEALTH[0] == 200 && RetailRules.SPECIES_COST[4] == 75, "Retail creature data mismatch");
        check(RetailRules.BUILDING_BASE_COST[11] == 650 && Building.Kind.EXTRACTOR.cost == 650, "Retail extractor cost mismatch");
        check(RetailRules.SPECIES_LOOKUP[0][1] == 5 && RetailRules.SPECIES_LOOKUP[1][0] == 15, "Directional hybrids lost");
        passed++;
    }

    private static void originalScenarioImport() {
        GameState game = scenario(map(16), 0);
        check(game.units.size() == 4 && game.plants.isEmpty() && game.buildings.isEmpty() && game.researchLevels[4] == 0, "Provisional scenario or research was not cleared");
        game.importCreature(4, 8.25, 9.5, 2, 70, 120);
        game.importPlant(3, 11.25, 6.5, 80);
        game.importBuilding(3, 0, 5.5, 5.5, 0, 280, 1);
        game.finishScenarioImport(2000);
        check(game.units.size() == 5 && game.units.get(4).x == 8.25 && game.units.get(4).team == 2, "Original creature position/owner lost");
        check(game.plants.get(0).species == 3 && game.plants.get(0).x == 11.25, "Original plant changed");
        check(game.buildings.get(0).complete() && game.buildings.get(0).hp == 240, "Source built flag not respected");
        advance(game, .1);
        try { game.clearScenarioEntities(); throw new AssertionError("Import allowed into live simulation"); }
        catch (IllegalStateException expected) { }
        passed++;
    }

    private static void pathAroundWaterAndBlockedDestination() {
        WorldMap map = map(16);
        for (int y = 0; y < 15; y++) map.blocked[map.index(5, y)] = true;
        GameState game = scenario(map, 0); Unit engineer = game.selectedUnit();
        check(game.commandSelected(9.5, 2.5), "Reachable goal rejected");
        for (int i = 0; i < 240; i++) {
            game.update(.1); check(!map.blocked[map.index((int) engineer.x, (int) engineer.y)], "Walked through deep water");
        }
        check(Math.hypot(engineer.x - 9.5, engineer.y - 2.5) < .01, "Did not take detour through gap");
        check(!game.commandSelected(5.5, 4.5), "Blocked destination accepted");
        check(!game.commandSelected(Double.NaN, 3), "NaN command accepted");
        passed++;
    }

    private static void reachableWorkstationRegression() {
        WorldMap map = map(8);
        for (int[] p : new int[][]{{3,2},{2,3},{4,3},{3,4}}) map.blocked[map.index(p[0], p[1])] = true;
        GameState game = scenario(map, 0);
        check(game.build(Building.Kind.SOLAR, 4.5, 4.5), "Isolated nearest workstation hid reachable alternatives");
        advance(game, 30); check(building(game, Building.Kind.SOLAR).complete(), "Builder failed to use reachable workstation");
        passed++;
    }

    private static void completeFirstTutorialAndPower() {
        GameState game = scenario(map(24), 0);
        check(game.build(Building.Kind.DISTRIBUTOR, 4.5, 3.5), "Cannot build distributor");
        check(game.build(Building.Kind.EXTRACTOR, 6.5, 3.5), "Cannot build extractor");
        check(game.build(Building.Kind.SOLAR, 4.5, 5.5), "Cannot build solar one");
        check(game.build(Building.Kind.SOLAR, 6.5, 5.5), "Cannot build solar two");
        check(game.build(Building.Kind.SOLAR, 8.5, 5.5), "Cannot build solar three");
        advance(game, 90);
        check(game.victory && !game.defeat, "Real first-tutorial construction objective did not complete");
        check(game.powerProduced >= 32 && building(game, Building.Kind.EXTRACTOR).powered, "Connected power network failed");
        check(game.goop >= 200, "Economy spent more than recovered construction costs");
        double time = game.elapsed; advance(game, 1); check(game.elapsed == time, "Completed scenario kept simulating");
        passed++;
    }

    private static void noCostOnRejectedBuild() {
        GameState game = scenario(map(16), 0); game.goop = 0;
        check(!game.build(Building.Kind.SOLAR, 4.5, 3.5) && game.buildings.isEmpty() && game.goop == 0, "Rejected build changed state");
        game.goop = 2000; check(game.build(Building.Kind.SOLAR, 4.5, 3.5), "Valid build failed"); int remaining = game.goop;
        check(!game.build(Building.Kind.SOLAR, 4.5, 3.5) && game.goop == remaining, "Overlapping build charged player");
        passed++;
    }

    private static void harvestAndRecycleChain() {
        GameState game = scenario(map(24), 2);
        game.importPlant(0, 9.5, 2.5, 90);
        game.importBuilding(3, 0, 5.5, 5.5, 0, 240, 1);
        game.importBuilding(6, 0, 7.5, 5.5, 0, 80, 1);
        game.importBuilding(4, 0, 5.5, 7.5, 0, 240, 1);
        game.finishScenarioImport(2000);
        Unit botanist = null; for (Unit unit : game.units) if (unit.kind == Unit.Kind.BOTANIST) botanist = unit;
        game.select(botanist.id); check(game.orderHarvest(), "Harvest command rejected");
        advance(game, 18);
        check(game.recycledGoop >= 80 && game.goop > 2000, "Harvest did not reach powered recycling chain");
        int wood = game.wood; check(game.recycleWood(), "Stored wood could not be recycled"); check(game.wood < wood, "Recycling did not consume wood");
        check(!game.victory, "Starting resources incorrectly satisfied recycle mission");
        passed++;
    }

    private static void creatureCreationAndOrderedHybrids() throws Exception {
        GameState game = scenario(map(24), 1); completePowerLab(game);
        game.importCreature(0, 8.5, 8.5, 0, 200, 60); game.importCreature(4, 9.5, 8.5, 0, 80, 160);
        game.researchLevels[0] = 100;
        game.researchLevels[4] = 100;
        int before = game.goop; check(game.trainCreature(4), "Mule creation failed");
        check(game.goop == before - 75, "Wrong recovered mule cost");
        check(!game.trainCreature(4) && game.goop == before - 75, "Busy lab charged twice");
        advance(game, 8); check(game.bornCreatures == 1 && game.bornMules == 1, "Creation count mismatch");
        Building lab = building(game, Building.Kind.GENE_LAB); game.select(lab.id);
        check(game.upgradeSelectedBuilding(), "Gene machine upgrade failed");
        check(game.breed(0, 4), "Directional hybrid command failed");
        advance(game, 8); boolean hybridFound = false;
        for (Unit u : game.units) if (u.team == 0 && u.kind == Unit.Kind.CREATURE && u.species == 8) hybridFound = true;
        check(hybridFound, "Dino×Mule did not create retail species index 8");
        check(GameState.load(game.save()).bornMules == 1, "Mule-specific births lost in save");
        passed++;
    }

    private static void muleGoalDoesNotCountOtherSpecies() {
        GameState game = scenario(map(24), 1); completePowerLab(game);
        game.setObjectiveZone(10.5, 10.5, 4);
        for (int i = 0; i < 3; i++) game.importCreature(4, 10 + i, 10, 0, 80, 160);
        game.bornCreatures = 3; game.bornMules = 1; advance(game, .1);
        check(!game.victory, "Non-mule births incorrectly completed mule objective");
        game.bornMules = 3; advance(game, .1); check(game.victory, "Mule objective did not complete");
        passed++;
    }

    private static void combatAndEnemyAI() {
        GameState game = scenario(map(24), 4);
        game.importCreature(0, 5.5, 5.5, 0, 200, 60); game.importCreature(2, 7.5, 5.5, 1, 50, 90);
        game.finishScenarioImport(2000);
        Unit dino = game.units.get(4); game.select(dino.id);
        check(game.commandSelected(7.5, 5.5), "Attack command rejected"); advance(game, 10);
        check(game.killedEnemies == 1 && game.victory && dino.hp > 0, "Combat did not destroy opponent and resolve mission");
        GameState enemyAI = scenario(map(24), 3);
        enemyAI.importCreature(2, 7.5, 5.5, 0, 50, 90); enemyAI.importCreature(0, 9.5, 5.5, 1, 200, 60);
        enemyAI.finishScenarioImport(2000); int friendlyBefore = enemyAI.units.size(); advance(enemyAI, 15);
        check(enemyAI.units.size() < friendlyBefore, "Enemy never acquired or fought a target");
        passed++;
    }

    private static void deterministicSaveAndCorruption() throws Exception {
        GameState game = scenario(map(24), 2); completePowerLab(game);
        game.select(game.units.get(0).id); check(game.commandSelected(18.5, 17.5), "Save test move failed");
        advance(game, 1.3); byte[] bytes = game.save(); GameState restored = GameState.load(bytes);
        check(Arrays.equals(bytes, restored.save()), "Save did not reproduce exact state");
        advance(game, 4); advance(restored, 4);
        check(Arrays.equals(game.save(), restored.save()), "Simulation diverged after save/load");
        byte[] corrupt = bytes.clone(); corrupt[corrupt.length / 2] ^= 1;
        try { GameState.load(corrupt); throw new AssertionError("Corrupt save accepted"); } catch (IOException expected) { }
        try { GameState.load(Arrays.copyOf(bytes, bytes.length - 1)); throw new AssertionError("Truncated save accepted"); } catch (IOException expected) { }
        File directory = Files.createTempDirectory("gene-wars-core-test-").toFile(); File save = new File(directory, "slot.gws");
        try { game.saveAtomic(save); check(Arrays.equals(game.save(), GameState.load(save).save()), "Atomic on-disk save differs"); }
        finally { save.delete(); directory.delete(); }
        passed++;
    }

    private static void pauseAndDefeat() {
        GameState game = scenario(map(16), 0); game.paused = true; advance(game, 5);
        check(game.elapsed == 0, "Paused game advanced"); game.paused = false;
        for (Unit u : game.units) u.hp = 0; advance(game, .1);
        check(game.defeat && !game.victory, "Losing the team did not cause defeat");
        passed++;
    }

    private static void allBuildingFamiliesAndProduction() throws Exception {
        GameState game = scenario(map(32), 2); completePowerLab(game);
        game.importBuilding(5, 0, 9.5, 5.5, 0, 160, 1);
        game.importBuilding(7, 0, 9.5, 7.5, 0, 240, 1);
        game.importBuilding(8, 0, 5.5, 9.5, 0, 150, 1);
        game.importBuilding(9, 0, 7.5, 9.5, 0, 240, 1);
        game.importBuilding(10, 0, 9.5, 9.5, 0, 400, 1);
        game.importBuilding(12, 0, 11.5, 5.5, 0, 140, 1);
        game.importBuilding(13, 0, 11.5, 7.5, 0, 80, 1);
        game.finishScenarioImport(2000);
        check(game.powerProduced == 97 && game.powerUsed >= 40, "Wind/fusion supply or consumers missing");
        check(game.goopCapacity == 8000, "Vat did not increase storage capacity");
        int crew = game.units.size(); check(game.recruitSpecialist(Unit.Kind.GENETICIST), "Landing pad recruitment failed");
        advance(game, 9); check(game.units.size() == crew + 1, "Queued specialist did not land");
        check(game.cellulose >= 20 && game.wood < 50, "Pulper did not convert raw wood into cellulose");
        check(game.etherealPoints > 0 && game.callEthereals(), "Detector did not observe or call Ethereals");
        advance(game, 31); check(game.etherealETA < 0 && game.etherealPoints >= 30, "Ethereal arrival did not resolve");
        byte[] save = game.save(); check(Arrays.equals(save, GameState.load(save).save()), "Extended family state failed save roundtrip");
        GameState all = scenario(map(32), 2);
        for (int type = 0; type < 14; type++) check(all.importBuilding(type, 0, 3.5 + (type % 7) * 2, 7.5 + type / 7 * 2, 0, 100, 1), "Unsupported original family " + type);
        check(all.buildings.size() == 14, "Original families were omitted");
        passed++;
    }

    private static void technologyAndBuildingUpgrades() {
        GameState game = scenario(map(32), 2); completePowerLab(game);
        int before = game.goop;
        check(!game.build(Building.Kind.TURRET, 12.5, 12.5) && game.goop == before, "Advanced turret ignored technical facility gate");
        advance(game, 6);
        Building solar = building(game, Building.Kind.SOLAR); game.select(solar.id);
        check(game.upgradeSelectedBuilding(), "Solar upgrade did not consume cellulose");
        check(solar.stage == 1 && solar.maxHp == 200 && game.cellulose < 20, "Upgrade ignored recovered HP or material cost");
        game.cellulose = 20; int priceBefore = game.goop;
        check(!game.upgradeSelectedBuilding() && game.goop == priceBefore, "Top-stage upgrade ignored technical center");
        passed++;
    }

    private static GameState shieldScenario(boolean shield) {
        GameState game = scenario(map(32), 3);
        game.importBuilding(3, 0, 9.5, 9.5, 0, 240, 1);
        game.importBuilding(6, 0, 8.5, 9.5, 0, 80, 1);
        game.importBuilding(9, 0, 7.5, 9.5, 0, 240, 1);
        if (shield) game.importBuilding(12, 0, 9.5, 11.5, 0, 140, 1);
        game.importCreature(0, 10.5, 10.5, 0, 200, 60);
        game.importCreature(0, 11.5, 10.5, 1, 200, 60);
        game.finishScenarioImport(2000); return game;
    }

    private static void poweredShieldReducesRealCombatDamage() {
        GameState shield = shieldScenario(true), bare = shieldScenario(false);
        Unit protectedDino = shield.units.get(4), unprotectedDino = bare.units.get(4);
        advance(shield, 3); advance(bare, 3);
        check(protectedDino.hp > unprotectedDino.hp && protectedDino.hp < 200, "Shield did not reduce actual enemy attacks");
        passed++;
    }

    private static void individualSourceStatsAndEngineerDiscount() throws Exception {
        GameState game = scenario(map(24), 0);
        game.importCreature(4, 8.5, 8.5, 2, 36, 78, 36, 78, 9085);
        Unit mule = game.units.get(4);
        check(mule.maxHp == 36 && mule.hp == 36 && mule.maxEnergy() == 78 && mule.lifespan == 9085, "Instance source stats were replaced by species defaults");
        Unit engineer = game.selectedUnit(); engineer.ability = 40;
        int before = game.goop; check(game.build(Building.Kind.EXTRACTOR, 5.5, 3.5), "Discounted build rejected");
        check(game.goop == before - 570, "Recovered base cost minus 2*ability formula not applied");
        GameState restored = GameState.load(game.save());
        Unit restoredMule = restored.units.get(4);
        check(restoredMule.maxHp == 36 && restoredMule.maxEnergy() == 78 && restoredMule.lifespan == 9085, "Individual creature statistics lost in save");
        check(restored.selectedUnit().ability == 40, "Engineer ability lost in save");
        passed++;
    }

    private static void structurallyInvalidChecksummedSaveRejected() throws Exception {
        GameState game = scenario(map(16), 0);
        // Deliberately create duplicate source records with a valid envelope CRC.
        // The reader must validate semantics, not just transport integrity.
        game.units.add(game.units.get(0));
        try { GameState.load(game.save()); throw new AssertionError("Duplicate IDs accepted despite valid CRC"); }
        catch (IOException expected) { check(expected.getMessage().contains("Duplicate"), "Wrong structural validation failure"); }
        game.units.remove(game.units.size() - 1);
        game.units.get(0).x = Double.NaN;
        try { GameState.load(game.save()); throw new AssertionError("Checksummed NaN coordinate accepted"); }
        catch (IOException expected) { check(expected.getMessage().contains("coordinate"), "NaN was not rejected by coordinate validation"); }
        passed++;
    }

    private static void importedConstructorAvoidsProvisionalWorld() {
        WorldMap map = map(24);
        GameState legacy = GameState.newGame(map, 3, 12345, 2.5, 2.5); legacy.clearScenarioEntities();
        GameState direct = GameState.newImportedGame(map, 3, 12345, 2.5, 2.5);
        check(direct.units.size() == 4 && direct.plants.isEmpty() && direct.buildings.isEmpty(), "Original constructor seeded provisional entities");
        check(direct.zoneX == legacy.zoneX && direct.zoneY == legacy.zoneY, "Original constructor changed initial zone");
        for (int i = 0; i < 4; i++) {
            Unit before = legacy.units.get(i), after = direct.units.get(i);
            check(after.kind == before.kind && after.x == before.x && after.y == before.y && after.id == before.id, "Original constructor changed crew");
        }
        check(direct.researchLevels[4] == 0, "Provisional Mule research leaked into original constructor");
        passed++;
    }

    private static void explicitMoveAndStopCommands() throws Exception {
        GameState game = scenario(map(24), 0);
        Unit botanist = game.units.get(1); game.select(botanist.id);
        game.importPlant(0, 10.5, 10.5, 80);
        game.importCreature(0, 18.5, 18.5, 1, 200, 120); Unit enemy = game.units.get(game.units.size() - 1);
        int goop = game.goop, wood = game.wood, cellulose = game.cellulose;
        double startX = botanist.x, startY = botanist.y;
        check(game.orderHarvest() && botanist.repeatHarvest, "Harvest setup failed");
        check(game.moveSelectedTo(10.5, 10.5), "Explicit move to plant tile rejected");
        check("Движение".equals(botanist.task) && botanist.targetId == 0 && !botanist.repeatHarvest,
                "Explicit move became a contextual work order");
        check(botanist.x == startX && botanist.y == startY && botanist.path.length > 0, "Move teleported instead of assigning a path");
        advance(game, .3);
        check(Math.hypot(botanist.x - startX, botanist.y - startY) > 0, "Move did not advance along path");
        GameState moving = GameState.load(game.save());
        check(Arrays.equals(game.save(), moving.save()), "Explicit move lost state in save roundtrip");
        double stopX = botanist.x, stopY = botanist.y; botanist.workTimer = .4; botanist.repeatHarvest = true;
        check(game.stopSelected(), "Stop rejected active ally");
        check("Ожидание".equals(botanist.task) && botanist.path.length == 0 && botanist.pathCursor == 0
                && botanist.targetId == 0 && !botanist.repeatHarvest && botanist.workTimer == 0
                && botanist.targetX == stopX && botanist.targetY == stopY, "Stop retained pending work or path");
        advance(game, 1);
        check(botanist.x == stopX && botanist.y == stopY, "Stopped ally kept moving");
        check(game.goop == goop && game.wood == wood && game.cellulose == cellulose && game.plants.get(0).biomass == 80,
                "Move/stop changed resources or harvested plant");
        check(Arrays.equals(game.save(), GameState.load(game.save()).save()), "Stopped order failed save roundtrip");
        check(game.moveSelectedTo(enemy.x, enemy.y) && botanist.targetId == 0 && "Движение".equals(botanist.task),
                "Explicit move to enemy tile became an attack order");
        int[] acceptedPath = botanist.path; double acceptedX = botanist.targetX, acceptedY = botanist.targetY;
        game.map.blocked[game.map.index(12, 12)] = true;
        check(!game.moveSelectedTo(12.5, 12.5) && botanist.path == acceptedPath
                && botanist.targetX == acceptedX && botanist.targetY == acceptedY,
                "Rejected explicit move destroyed the previous accepted order");
        check(enemy.hp == 200 && game.stopSelected(), "Move/stop directly damaged an enemy");
        game.clearSelection(); check(!game.stopSelected() && !game.moveSelectedTo(3, 3), "Missing selection accepted");
        game.selectedId = botanist.id; botanist.hp = 0;
        check(!game.stopSelected() && !game.moveSelectedTo(3, 3), "Dead unit accepted move/stop");
        botanist.hp = botanist.maxHp; botanist.team = 1;
        check(!game.stopSelected() && !game.moveSelectedTo(3, 3), "Enemy selection accepted move/stop");
        botanist.team = 0; game.victory = true;
        check(!game.stopSelected() && !game.moveSelectedTo(3, 3), "Terminal game accepted move/stop");
        game.victory = false;
        check(!game.moveSelectedTo(Double.NaN, 3) && !game.moveSelectedTo(100, 3), "Invalid movement coordinates accepted");
        check(!game.moveSelectedTo(12.5, 12.5), "Blocked explicit destination accepted");
        passed++;
    }

    public static void main(String[] args) throws Exception {
        worldMapIntegrity(); recoveredDataTables(); originalScenarioImport(); pathAroundWaterAndBlockedDestination();
        reachableWorkstationRegression(); completeFirstTutorialAndPower(); noCostOnRejectedBuild(); harvestAndRecycleChain();
        creatureCreationAndOrderedHybrids(); muleGoalDoesNotCountOtherSpecies(); combatAndEnemyAI(); deterministicSaveAndCorruption(); pauseAndDefeat();
        allBuildingFamiliesAndProduction(); technologyAndBuildingUpgrades(); poweredShieldReducesRealCombatDamage();
        individualSourceStatsAndEngineerDiscount(); structurallyInvalidChecksummedSaveRejected();
        importedConstructorAvoidsProvisionalWorld(); explicitMoveAndStopCommands();
        System.out.println("PASS: " + passed + " native core integration tests");
    }
}
