# 0.4 authored terrain and model-material exports

The 0.4 terrain set replaces the painted terrain swatches with nine realistic,
flat, straight-down albedo materials. It was created using `image_gen.imagegen`.
The original 1254×1254 RGB PNG, complete generation prompt and SHA-256 are retained
in `graphics-source/v04/`. Packing copies the PNG byte for byte; it does not
retouch the materials, generate normals from colour, or invent measured PBR maps.

## Terrain contract

The runtime files are `android/app/src/main/assets/native/materials-v04/`.
`terrain_albedo.png` contains a 3×3 atlas, with each cell 418×418 pixels. It is
4,079,361 bytes; its SHA-256 is
`b942bf84530f6491217115d9bbe6776448304853cc88578ab790fa28f3161032`.

| Position | Material | Roughness | Metallic | Micro-normal amplitude |
| --- | --- | ---: | ---: | ---: |
| 0,0 | Water | 0.12 | 0 | 0.035 |
| 1,0 | Wet shore sand/pebbles | 0.48 | 0 | 0.025 |
| 2,0 | Dry sand | 0.90 | 0 | 0.018 |
| 0,1 | Grass/soil | 0.88 | 0 | 0.045 |
| 1,1 | Weathered rock | 0.82 | 0 | 0.055 |
| 2,1 | Muted alien mineral soil | 0.78 | 0 | 0.045 |
| 0,2 | Snow/ice grains | 0.70 | 0 | 0.022 |
| 1,2 | Moss/leaf litter | 0.95 | 0 | 0.055 |
| 2,2 | Industrial steel | 0.40 | 0.75 | 0.018 |

`manifest.json` contains `atlas.albedo`, `columns`, `rows`, `width`, `height`, and
`textures.<name> = {file, rect:[x,y,w,h], roughness, metallic, normalScale}`. Paths
are Android asset paths. The renderer decodes the shared source once and builds
its GPU atlas with 256-pixel cells. `normalScale` is the actual XZ normal-component
amplitude of shader detail, rather than a multiplier on an undocumented constant.
Albedo is sRGB. The renderer supplies water optics, lighting and material shading.

The schema can carry aligned `normal` and `orm` atlases (linear data;
ORM R=occlusion, G=roughness, B=metallic). Those files are **absent** in this release.
Roughness/metallic are artistic scalar parameters, and micro-normals are procedural
shader detail. They should not be described as measured physical texture maps.

Reproduce and verify:

```sh
python3 tools/pack_terrain_materials.py
python3 -m unittest discover -s tests -p test_terrain_materials.py -v
```

The source is selected by `graphics/terrain-v04-spec.json`. The packer validates
all nine names, finite/ranged material factors, opaque RGB/RGBA PNGs, matching
optional-map dimensions and complete grid coverage. It preserves PNG bytes,
checks source/output hashes, stages its outputs, and refuses to overwrite a
folder containing unowned files. Four tests cover the actual provenance/copy,
non-divisible grids, repeatability and failure cases.

## Native mesh material export

Production `ModelLibrary3D.MATERIAL_VERSION = 4` keeps the 13-float vertex stride
but changes its former UV pair: field 10 is roughness and field 11 is metallic.
The model exporter reads those exact values. `COLOR_0` is linearized with
`pow(sRGB,2.2)`, matching the Android shader; original RGB remains in custom
`_GENEWARS_SRGB`. Alpha is 1; native field 9 remains emissiveness.

GLB triangles are grouped by emissive RGB, roughness and metallic. Standard
`pbrMetallicRoughness.roughnessFactor` and `.metallicFactor` therefore match their
production primitives. Custom `_GENEWARS_ROUGHNESS`, `_GENEWARS_METALLIC` and
`_GENEWARS_EMISSIVE` preserve the native per-vertex data for audit. No
`TEXCOORD_0` is emitted because the production actor meshes have no texture UVs.
The terrain image is separate and is not attached falsely to actor models.

The exact production model geometry, hierarchical skin and native animation
samples are exported to `graphics/models-v04/`, outside the APK. The app builds
and caches the production meshes directly. The historical 0.3 GLBs remain in
`graphics/models-v03/` and describe the old geometry/material contract.

```sh
python3 tools/export_3d_models.py --java-home /path/to/jdk
python3 -m unittest discover -s tests -p test_export_3d_models.py -v
python3 tools/check_glb_models3d.py
```

Exported clips sample the actual native rig at 30 Hz; they are exact at recorded
sample times and use glTF LINEAR interpolation between samples. They are short
motion excerpts, not newly authored seamless loops. Native motion continues to
be evaluated continuously by the Android app. Source hashes, GLB hashes, bounds,
coverage and pose errors are recorded in the export manifest. The final 55 models
contain 177,860 vertices and 222,666 triangles; GLBs total 19,462,204 bytes. The
maximum decoded-GLB versus native pose matrix error is 2.12 × 10⁻⁷. A second
complete export reproduces the manifest and all 55 GLB hashes identically.

These improvements provide richer stylized procedural 3D and natural ground
materials. The project does not claim photorealistic characters, AAA production
assets, measured material capture or hardware subsurface scattering.
