# Graphics and selected squad card 0.4 QA

Independent source and CPU/binary validation passed before the final Android run. Runtime acceptance is performed separately on the single test device; building the instrumentation APK does not establish that its eight checks passed.

## Checked implementation

- All 55 model rigs passed the existing geometry/index/bone/pose invariants, with 222,666 triangles (1.61× version 0.3, below the 276,380 budget). All 25 creatures have distinct geometry signatures; all 55 rigs animate. Vertex fields 10/11 now contain bounded roughness/metallic values. Each specialist and building uses multiple material responses.
- The final 55 GLB files contain 177,860 vertices, 222,666 triangles and 131 animation clips (19,462,204 bytes). Independent binary checks verify source/file hashes, geometry counts against native model tests, finite attributes, joints/weights/quaternions and changing clip channels. Standard `COLOR_0` is linearized from the preserved native sRGB attribute; standard material roughness/metallic and emission match the corresponding native custom attributes. Material scalar fields are not mislabeled as UV coordinates.
- The terrain bundle has nine distinct 418×418 regions covering its 1254×1254 sRGB atlas exactly. Packaged PNG bytes equal the generated source and provenance hash. Scalars and bounds passed. Conservative decoded RGBA memory is 6,290,064 bytes; the uploaded 768×768 base atlas occupies 2,359,296 RGBA bytes before mipmaps. This is authored albedo plus scalar material response and procedural micro-normals, not measured normal/ORM maps.
- The exact production GLES shader strings passed host Mesa ES3 compile/link for all six stages and three programs with GL error 0. Fragment material arrays and the 24-bone vertex uniform budget fit the required limits. Actual Android driver acceptance remains separate.
- Portrait rendering uses the same selected actor snapshot, production mesh, skeletal pose and GLES context. Viewport/scissor/depth clear and full-world viewport restoration were reviewed. Texture decoding remains outside ordinary frame drawing. Terrain type texture upload uses byte alignment 1 and restores alignment 4.
- The corner card shows role, health and task. Its complete touch gesture bypasses world interception; padding consumes touches. Actions use the selected unit, explicit movement avoids contextual attack/harvest, and attack mode requires a real target. The two new core entry points validate live friendly selection and keep the existing save format. Native core tests passed 20 scenarios.

## Reproduce non-device checks

```sh
python3 tools/check_models3d.py
python3 tools/check_glb_models3d.py
python3 tools/check_materials_v04.py
python3 tools/check_gles3_shaders.py
python3 -m unittest discover -s tests -p 'test_run_android_smoke.py' -v
```

JVM checks accept `--java-home`; the optional shader check requires Linux Mesa/EGL. Reports are written under `build/`.

## Android smoke contract

The previous seven checks remain. The eighth, `selected_squad_card_live_portrait_and_role_action`, requires actual touch input through the card, selection Engineer→Botanist→Engineer, correct labels, valid HP and role commands. Completed portrait frames must identify the corresponding selected actors, align with the visible portrait window and yield nonflat, changing screenshots. Construction is opened through the card's own button and must debit real resources before the new card check passes.

Evidence is saved in private `files/smoke-v04/`: scene before/after rotation, portrait/card images for Engineer and Botanist, scene and portrait GLES logs. Bundle fields `three_d` and `squad_card` record the measured result. The host runner accepts only the complete exact eight-name result set and successful raw instrumentation result. Five parser tests reject old seven-check results, duplicate names, misleading counts and interrupted/failed runs.

Use `tools/run_android_smoke.py --serial ... --output ...` after installing matching-signed application and instrumentation APKs. `--timeout` changes only the host watchdog, not device assertions. `--compatibility-only` uses a separate one-check contract to load an existing private slot and verify its unchanged SHA-256 before the main smoke replaces that slot.

The graphics use more natural material response, smoother geometry and restrained colors. These checks establish the implementation and resource correctness; they do not establish photorealism, AAA asset quality or physical Galaxy S23 Ultra frame rate.
