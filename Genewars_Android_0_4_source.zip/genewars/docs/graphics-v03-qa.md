# Native 3D 0.3 independent QA

The final model library, camera/snapshot code and exported GLB collection passed independent CPU/binary checks on 2026-10-31. All six production core source files match the 0.2 checkpoint byte-for-byte. Android installation, first rendered frames, camera screenshots and persisted-save loading remain separate release acceptance checks.

## Reproduce

Use a JDK with `javac` and `java` on PATH, or pass `--java-home` to the JVM checks:

```sh
python3 tools/check_scene3d.py
python3 tools/check_models3d.py
python3 tools/check_glb_models3d.py
```

The GLB checker requires the current `build/models3d-audit.json` produced by the independent model checker. Optional Linux Mesa/EGL validation can also compile and link the exact production shader strings:

```sh
python3 tools/check_gles3_shaders.py
```

This optional host driver check does not replace Android driver validation. A full Java 8 compilation of the Android and native-core sources against Android SDK 35 also passed; it emitted only obsolete-option/deprecation warnings.

## Actual CPU and binary results

| Check | Result |
| --- | --- |
| Cached models | 55 |
| Creature / specialist / building / plant models | 25 / 4 / 14 / 12 |
| Geometry vertices | 114,010 |
| Geometry triangles | 138,190 |
| Degenerate triangles | 0 |
| Distinct creature geometry signatures | 25 |
| Models with changing finite rig transforms | 55 |
| Camera projection/picking round trips | 300 |
| Maximum round-trip world error | 0.000344 |
| Optimized terrain fixtures compared with original algorithm | 6 |
| Terrain float attributes equal bit-for-bit | 2,572,284 |
| Terrain indices equal exactly | 296,802 |
| Portable GLB files | 55 |
| Portable animation clips | 131 |
| Portable GLB bytes | 12,035,592 |

The model test checks actual production geometry: stride, finite positions/normals/colors, unit normals, valid indices and bone attributes, valid parent-before-child joint hierarchies, finite bone parameters, bounds along all three axes and nonzero signed mesh volume. Every creature and specialist uses at least three influenced joints and has nonrigid motion; moving the complete object as one rigid body does not satisfy that test. Idle, walk, attack, work and dead pose calculations are checked for finite affine nonsingular transforms. This establishes the model and rig implementation, not that every state is exercised in the final Android UI.

The camera test covers sloped terrain, 12 camera settings and 300 independently projected/picked points. It checks that the camera target remains at the viewport center, orbit changes projection and invalid gesture numbers do not corrupt the camera. It also checks actor-value/list isolation, copied terrain arrays and the camera's private source-map copy by mutating the original game/map after capture.

After a software-emulator trace identified repeated terrain height interpolation as a CPU bottleneck, terrain preparation was changed to precompute shared corner heights and normals. The independent test re-evaluates the original per-corner algorithm on six flat, sloped and irregular fixtures (8×8, 17×11 and 128×128), including signed-short extremes and map-edge discontinuities. Every generated float attribute is bitwise identical and every index is equal. This verifies geometry equivalence; the emulator's resulting load time still needs runtime observation.

The GLB check decodes the actual binary files independently of the exporter. It verifies headers/chunks, accessors and buffer bounds/alignment, file/source hashes, geometry counts against the native CPU audit, joint/weight bounds, normalized quaternions, strictly increasing animation timelines and changing TRS channels in every clip. Standard `COLOR_0` alpha stays 1; emission is checked against the custom native emission attribute and the corresponding standard material emission values.

Reports are `build/scene3d-audit.json`, `build/models3d-audit.json`, `build/glb3d-audit.json`, `build/shader3d-host-audit.json` and `build/core-v02-v03-audit.json`.

## Renderer and integration review

The live world uses an ES3 `GLSurfaceView`. Actors are indexed solid geometry in VAO/VBO/index buffers, transformed by model and hierarchical skin matrices. The renderer enables depth testing and back-face culling, uses a perspective orbit camera and renders an optional depth shadow map. Canvas is used for the native HUD/health overlay and to assemble the terrain material atlas; it does not draw actor image planes. Together with the independently measured nonzero mesh volume, this provides source-level evidence that actors are real 3D models.

`Scene3DFrame.capture` runs on the UI/simulation thread and publishes scalar actor records plus copied, cached terrain through an atomic reference. The GL thread does not traverse mutable simulation objects. Camera methods synchronize access, while GL resource calls remain on the GL thread. Context recreation clears context-specific caches and recreates programs/buffers/textures. Pause/resume, release, old-world cancellation and modal stopping paths were reviewed without an outstanding P1 finding.

Actual motion between snapshots determines heading and gives walking priority over a unit's work/attack task while it is travelling. A stopped unit can then use the corresponding action pose. Frame time remains fixed during a simulation pause. Model assets are cached and reused between actors.

All six shader stages and all three programs compiled/linked with empty logs on headless Mesa OpenGL ES 3.2 (`llvmpipe`, Mesa 25.0.7). That check returned GL error 0. The host report records the checked renderer source SHA-256.

## Android acceptance

The final APK must provide these runtime observations before publication:

1. Preserve the older private GWSV v3 save before instrumentation replaces its slot. Install the new APK as an update, load that older slot and inspect the restored state.
2. Confirm Android GLES3 context creation, successful program initialization and a populated actor mesh frame with `GL_NO_ERROR=true`. Inspect the current process's renderer log for `GL_ERROR` and Android crash/ANR records.
3. Pause simulation and capture the same world at two camera azimuths. Inspect changed visible model faces and occlusion, in addition to measuring changed central-scene pixels.
4. Observe a moving unit with changing root position and articulated walking, followed by an idle or work/attack state. CPU rig checks alone do not demonstrate the final UI's state transition.
5. Exercise pause/resume, background/foreground and leaving/re-entering a world. Context preservation is optional; a recreated context must render correctly.
6. Run the updated seven-check Android smoke scenario. It retains the original six checks for menu/world, real construction resource debit, private saving, Activity restart and restored counter equality, and adds central-scene rotation plus GLES3 diagnostics. Its screenshot crop excludes the HUD and camera-angle label; simulation is paused during the comparison.

The result is a native, stylized 3D reconstruction with segmented skeletal rigs. It is not a claim of AAA art, exact original campaign behavior or measured physical Galaxy S23 Ultra performance. Portable GLB files are exports of the production native model library; Android renders that library directly rather than relying on a separate mock asset set.
