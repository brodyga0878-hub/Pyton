# Graphics 0.2 independent QA

The final HD resource bundle passed the independent read-only resource audit on 2026-10-31. Source review found no outstanding P1 issue in the graphics integration. This document records asset and source checks; final APK installation, Android instrumentation and screenshots are separate release checks.

## Reproduce the resource check

```sh
python3 tools/check_hd_release.py
python3 -m unittest discover -s tests -p 'test_check_hd_release.py' -v
```

The checker writes `build/hd-release-audit.json` and exits nonzero for missing required art, unsafe paths, invalid geometry, missing transparency, inadequate source resolution or excessive decoded resource memory. Its four tests cover complete coverage and deduplication, missing art and invalid crops, opaque sprites, path escapes and nonfinite geometry.

The final bundle result was:

| Check | Result |
| --- | --- |
| Required primary sprites | 55 / 55 |
| Creature species | 25 / 25 |
| Buildings, including FUSION | 14 / 14 |
| Specialists | 4 / 4 |
| Plants | 12 / 12 |
| UI image entries | 3 |
| Terrain texture entries | 9 |
| Unique PNG files | 67 |
| Unique primary sprite pixel hashes | 55 |
| Packaged visual bytes | 10,840,619 |
| Conservative decoded RGBA bytes | 29,616,476 (28.2 MiB) |
| Errors / warnings | 0 / 0 |

Every required sprite has transparency, nonempty visible pixels and source dimensions of at least 192 pixels along its longer edge and 48 along its shorter edge. The checker checks file and decoded-region bounds against the loader limits, valid anchors and scale, and SHA-256 hashes of both files and decoded region pixels. Runtime aliases sharing a cache key count once in its memory estimate.

The estimate includes every manifest visual, even optional art that may never be loaded. It excludes the viewport cache, old caches retained temporarily by Android display lists, platform/GPU copies, audio, simulation state and other process memory. It is an asset budget, not a process-memory measurement. Runtime usage must also be observed during scrolling and loading.

`native/hd/assets-audit.json` records the packer's source hashes, source rectangles, alpha-trim bounds, raw-pixel hashes and output hashes. The original generated atlases are retained under `graphics-source/`, with the packing specification in `graphics/hd-v02-spec.json`.

## Source review

- `AssetRepository` reads the small resource index separately from graphics. Sprite and menu image decoding runs on workers; drawing requests do not open files. Bitmap dimensions, crop rectangles, manifest size and safe paths are bounded. Failed HD assets fall back to existing original art.
- HD aliases reach original core sprite names, all 25 species and every building kind, including FUSION. The final primary keys all have explicit HD images. Metadata scale and anchor apply after the requested image is ready; the current bundle uses scale 1 and bottom-center anchors.
- `ModernWorldPainter` loads textures once per world on its worker and publishes a completed texture set. UI callbacks post cache invalidation and reject released views. Its shader matrices are updated in the UI terrain-cache pass. The ordinary animated pass does not scan the map.
- Dynamic terrain work is bounded to 48 water highlights, 32 foam segments, eight motes and two cloud shadows. UI effects are bounded to 64. Contact shadows and powered-building/zone glows reuse shaders.
- World release closes the texture worker; pause and modal dialogs stop the ticker without releasing the live world. Cancelled loads restore the previous world, and successful loads release it. Generation checks prevent late workers from replacing newer state. Activity destruction closes both active and previous world resources.
- Sprite placement uses the same terrain projection as terrain rendering. Bottom-center anchors, touch hit offsets and enlarged building hit radius are present. Existing selection, placement, drag and pinch gesture paths remain integrated.
- The graphics update does not change the GWSV v3 serialization format or add graphical data to saves. Cross-version runtime loading is an APK-level acceptance check.

Two review findings were corrected by their file owners before source freeze: the shared atmosphere Paint now resets alpha before shader passes, and powered-building/zone glows reuse shaders rather than creating native radial shaders each frame.

## Release acceptance and limits

The renderer remains a stylized native 2.5D renderer. The HD set supplies new detailed illustrations and materials; this audit does not establish a fully animated 3D engine, exact original campaign behavior or physical Galaxy S23 Ultra performance.

Before publication, verify the final APK with the existing six-check Android smoke contract, capture menu and world screenshots, resume an older v3 save and inspect Android error logs. Observe `Terrain viewport cached in ... ms` while panning and zooming: a cache rebuild currently scans the whole map before culling cells, although ordinary stationary frames reuse the cached viewport.

The generated material edges are not strictly seamless. Mirrored texture tiling can remove the sharp repeat boundary without modifying PNG pixels, but introduces symmetric material patterns, especially on the diagonal shore image. The final screenshot review should confirm that the chosen tiling is acceptable.
