# Native terrain renderer 0.2

This is a stylized 2.5D Canvas renderer, not a new fully animated 3D engine. It consumes the original 128×128 terrain/elevation data without changing gameplay.

## Static viewport pass

`ModernWorldPainter.drawTerrain` is called only while rebuilding the existing WorldView bitmap cache. A normal frame draws that cached bitmap once. Cell corners share the same four projected world vertices, so different heights do not leave independent floating diamonds or black gaps.

The pass adds:

- Continuous world-aligned material shaders for water, shore, sand, grass, rock, alien soil, snow and moss.
- New generated 418×418 material PNGs from the version 0.2 art set. They are decoded on a worker; texture memory is bounded by eight current material images.
- Height-slope directional lighting, subtle triangular lighting, sparse grass/stone details and local dark creases at steep height changes.
- Shore foam along actual water/land boundaries and a soft cached atmospheric grade.

Materials repeat every 3.5 world cells. The shader matrix follows world coordinates and isometric scale, so individual terrain quads do not each start the texture again. The palette remains a fallback if modern art is missing; the original B32 image is used only as low-opacity grain and is not described as HD art.

## Bounded animated pass

`drawDynamic` never scans the full map. It uses immutable arrays built during the static pass: at most 48 water highlights and 32 shoreline foam segments. Eight small airborne motes and two broad cloud shadows complete the atmospheric layer. This gives at most 90 simple dynamic draw operations per frame, independent of total map area.

`drawContactShadow` provides a soft radial ellipse below an entity without bitmap allocation or disk access.

## API and lifecycle

```java
ModernWorldPainter painter = new ModernWorldPainter(assetManager, onTexturesReady);
painter.requestTextures();
painter.drawTerrain(cacheCanvas, worldMap, projection, smooth);
painter.drawDynamic(frameCanvas, worldMap, projection, seconds);
painter.drawContactShadow(frameCanvas, x, y, width, height, opacity);
painter.close();
```

`Projection` exposes x/y world projection, scaled half-width/half-height, viewport width/height and display density. Texture IO is scheduled once on a daemon executor. The texture-ready callback must post cache invalidation to the View/UI thread. `close()` cancels pending work; closed painters do not publish late textures.

HD metadata is read from `native/hd/manifest.json`, with `textures` entries containing a safe `native/…` file and an optional `[x,y,width,height]` rect. Image bounds, regions and manifest size are checked. The drawing methods themselves do not open files.

## Verification and limits

The renderer compiles against Android 35 with Java 8/minSdk 26. Actual Android screenshots and gameplay smoke checks belong to the final app validation; compilation alone does not establish runtime performance.

The renderer does not add skeletal 3D models, a 3D camera, full state/direction animation, physically based lighting or exact original terrain texture reconstruction. Generated art and new lighting are a visual redesign on the native reconstruction. Physical Galaxy S23 Ultra performance still requires device testing.
