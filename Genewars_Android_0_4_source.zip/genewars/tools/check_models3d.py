#!/usr/bin/env python3
"""Compile/run independent JVM geometry and rig acceptance checks, without Android."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--java-home", type=Path)
    parser.add_argument("--output", type=Path, default=root / "build/models3d-audit.json")
    args = parser.parse_args()
    java_home = args.java_home or (Path(os.environ["JAVA_HOME"]) if os.environ.get("JAVA_HOME") else None)
    javac = str(java_home / "bin/javac") if java_home else shutil.which("javac")
    java = str(java_home / "bin/java") if java_home else shutil.which("java")
    if not javac or not java:
        parser.error("A JDK is required; pass --java-home or set JAVA_HOME")
    source = root / "android/app/src/main/java/org/genewars/android/gl3d"
    paths = [source / "MeshData3D.java", source / "ModelLibrary3D.java",
             root / "android/model-tests/Model3DAcceptance.java"]
    classes = root / "build/model3d-qa-classes"
    classes.mkdir(parents=True, exist_ok=True)
    try:
        compile_result = subprocess.run([javac, "--release", "8", "-encoding", "UTF-8", "-sourcepath", str(root / "android/app/src/main/java"),
                                         "-d", str(classes), *map(str, paths)], capture_output=True, text=True, timeout=120)
        if compile_result.returncode:
            raise RuntimeError("CPU QA compile failed:\n" + compile_result.stdout + compile_result.stderr)
        run = subprocess.run([java, "-cp", str(classes), "org.genewars.qa.Model3DAcceptance"],
                             capture_output=True, text=True, timeout=120)
        if run.returncode:
            raise RuntimeError("CPU QA failed:\n" + run.stdout + run.stderr)
        result = json.loads(run.stdout)
        result["scope"] = "CPU geometry, index safety and rig invariants; not Android shader, animation appearance or phone performance"
    except (OSError, RuntimeError, subprocess.TimeoutExpired, ValueError) as error:
        result = {"passed": False, "errors": [str(error)]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))
    return 0 if result.get("passed") else 1


if __name__ == "__main__":
    sys.exit(main())
