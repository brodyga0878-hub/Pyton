#!/usr/bin/env python3
"""Independent binary glTF geometry/material/skin/animation audit of exported 0.4 models."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[1]
WIDTHS = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
FORMATS = {5121: "B", 5123: "H", 5125: "I", 5126: "f"}
BUILDINGS = ["EXTRACTOR", "DISTRIBUTOR", "SOLAR", "GENE_LAB", "RECYCLER", "TURRET", "PULPER",
             "LANDING_PAD", "DETECTOR", "WIND", "FUSION", "TECH", "SHIELD", "VAT"]
SPECIALISTS = ["ENGINEER", "BOTANIST", "GENETICIST", "RANGER"]


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def audit(path, expected):
    data = path.read_bytes()
    require(len(data) >= 28 and struct.unpack_from("<4sII", data) == (b"glTF", 2, len(data)), "GLB header/length")
    at, chunks = 12, []
    while at < len(data):
        size, kind = struct.unpack_from("<I4s", data, at)
        require(size % 4 == 0 and at + 8 + size <= len(data), "GLB chunk bounds/alignment")
        chunks.append((kind, data[at + 8:at + 8 + size])); at += 8 + size
    require(at == len(data) and [kind for kind, _ in chunks] == [b"JSON", b"BIN\x00"], "GLB chunks")
    doc, binary = json.loads(chunks[0][1]), chunks[1][1]
    require(doc["asset"]["version"] == "2.0", "glTF version")
    require(len(doc["buffers"]) == 1 and "uri" not in doc["buffers"][0], "External/multiple buffers")
    require(0 <= len(binary) - doc["buffers"][0]["byteLength"] <= 3, "BIN length")
    decoded = {}

    def accessor(number):
        if number in decoded:
            return decoded[number]
        record = doc["accessors"][number]; view = doc["bufferViews"][record["bufferView"]]
        require(view.get("buffer", 0) == 0 and "sparse" not in record, "Unsupported external/sparse accessor")
        code = FORMATS[record["componentType"]]; width = WIDTHS[record["type"]]
        item = struct.calcsize("<" + code * width); count = record["count"]
        stride = view.get("byteStride", item); view_at = view.get("byteOffset", 0)
        local = record.get("byteOffset", 0); start = view_at + local
        require(count > 0 and stride >= item and stride % struct.calcsize(code) == 0, "Accessor count/stride")
        require(view_at >= 0 and view_at + view["byteLength"] <= len(binary), "BufferView bounds")
        require(local >= 0 and local + (count - 1) * stride + item <= view["byteLength"], "Accessor bounds")
        rows = [struct.unpack_from("<" + code * width, binary, start + i * stride) for i in range(count)]
        require(all(math.isfinite(v) for row in rows for v in row), "Nonfinite binary accessor")
        decoded[number] = rows
        return rows

    for number in range(len(doc["accessors"])):
        accessor(number)
    require(len(doc["skins"]) == 1, "Missing/multiple skins")
    skin = doc["skins"][0]; joints = skin["joints"]
    require(len(joints) == expected["joints"] and len(set(joints)) == len(joints), "Skin joints")
    require(all(0 <= node < len(doc["nodes"]) for node in joints), "Joint node bounds")
    require(len(accessor(skin["inverseBindMatrices"])) == len(joints), "Inverse bind count")
    primitives = doc["meshes"][0]["primitives"]
    first = primitives[0]["attributes"]
    positions, normals = accessor(first["POSITION"]), accessor(first["NORMAL"])
    colors, weights, bone_ids = accessor(first["COLOR_0"]), accessor(first["WEIGHTS_0"]), accessor(first["JOINTS_0"])
    emission = accessor(first["_GENEWARS_EMISSIVE"])
    srgb = accessor(first["_GENEWARS_SRGB"])
    roughness, metallic = accessor(first["_GENEWARS_ROUGHNESS"]), accessor(first["_GENEWARS_METALLIC"])
    require("TEXCOORD_0" not in first, "Material scalar fields were mislabeled as UV data")
    count = len(positions)
    require(count == expected["vertices"] and all(len(v) == count for v in [normals, colors, weights, bone_ids, emission, srgb, roughness, metallic]), "Attribute counts")
    require(all(abs(sum(v*v for v in n) - 1) < .01 for n in normals), "Non-unit normals")
    require(all(all(0 <= v <= 1 for v in c) and c[3] == 1 for c in colors), "COLOR_0 transparency/range")
    require(all(0 <= e[0] <= 1 for e in emission), "Emission range")
    require(all(.119999 <= v[0] <= 1 for v in roughness) and all(0 <= v[0] <= 1 for v in metallic), "PBR scalar range")
    for i in range(count):
        require(all(0 <= v <= 1 for v in srgb[i]) and max(abs(colors[i][axis] - srgb[i][axis] ** 2.2) for axis in range(3)) < .000002,
                "glTF vertex color is not correctly linearized native sRGB")
    require(all(abs(sum(w) - 1) < .00001 and all(0 <= v <= 1 for v in w) for w in weights), "Skin weights")
    require(all(all(0 <= v < len(joints) for v in row) for row in bone_ids), "Joint attribute bounds")
    for axis in range(3):
        require(abs(min(p[axis] for p in positions) - expected["bounds"]["min"][axis]) < .00002
                and abs(max(p[axis] for p in positions) - expected["bounds"]["max"][axis]) < .00002, "Geometry bounds")
    triangles = 0
    for primitive in primitives:
        require(primitive.get("mode", 4) == 4 and primitive["attributes"] == first, "Primitive mode/attributes")
        indices = [row[0] for row in accessor(primitive["indices"])]
        require(len(indices) % 3 == 0 and min(indices) >= 0 and max(indices) < count, "Triangle index bounds")
        triangles += len(indices) // 3
        material = doc["materials"][primitive["material"]]
        require(material.get("alphaMode", "OPAQUE") == "OPAQUE", "Unexpected material transparency")
        pbr = material["pbrMetallicRoughness"]
        for vertex in set(indices):
            require(max(abs(colors[vertex][axis] * emission[vertex][0] - material["emissiveFactor"][axis]) for axis in range(3)) < .000002,
                    "Emissive material differs from native vertex emission")
            require(abs(roughness[vertex][0] - pbr["roughnessFactor"]) < .000002
                    and abs(metallic[vertex][0] - pbr["metallicFactor"]) < .000002, "Standard PBR factors differ from native material scalars")
    require(triangles == expected["triangles"], "Triangle count")
    clips = []
    for animation in doc["animations"]:
        changed = 0; targets = set()
        for channel in animation["channels"]:
            target = channel["target"]; node, kind = target["node"], target["path"]
            require(node in joints and kind in ["translation", "rotation", "scale"], "Animation target")
            require((node, kind) not in targets, "Duplicate animation target")
            targets.add((node, kind))
            sampler = animation["samplers"][channel["sampler"]]
            times = [row[0] for row in accessor(sampler["input"])]; values = accessor(sampler["output"])
            require(sampler.get("interpolation", "LINEAR") == "LINEAR" and len(times) >= 2 and times[0] == 0
                    and all(b > a for a, b in zip(times, times[1:])) and len(values) == len(times), "Animation timeline")
            if kind == "rotation":
                require(all(abs(sum(v*v for v in q) - 1) < .001 for q in values), "Animation quaternion")
            if any(max(abs(a-b) for a, b in zip(row, values[0])) > .0000001 for row in values[1:]):
                changed += 1
        require(len(targets) == len(joints) * 3 and changed > 0, "Static or incomplete animation clip")
        clips.append(animation["name"])
    require(sorted(clips) == sorted(expected["clips"]), "Animation clip coverage")
    return {"name": path.stem, "vertices": count, "triangles": triangles, "joints": len(joints), "clips": clips}


def main():
    folder = ROOT / "graphics/models-v04"
    manifest = json.loads((folder / "manifest.json").read_text())
    expected_names = ({"creature_" + str(i) for i in range(25)} | {"plant_" + str(i) for i in range(12)}
                      | {"building_" + k for k in BUILDINGS} | {"specialist_" + k for k in SPECIALISTS})
    require({item["name"] for item in manifest["models"]} == expected_names and len(manifest["models"]) == 55, "Model coverage")
    native = json.loads((ROOT / "build/models3d-audit.json").read_text())
    require(native.get("passed") and native["models"] == 55, "Run independent native model CPU audit first")
    native_records = {item["key"]: item for item in native["records"]}
    for file, digest in manifest["sourceSha256"].items():
        require(not Path(file).is_absolute() and ".." not in Path(file).parts, "Unsafe source path")
        require(hashlib.sha256((ROOT / file).read_bytes()).hexdigest() == digest, "Stale export: " + file)
    records, size = [], 0
    for item in manifest["models"]:
        name = item["name"]; require(re.fullmatch(r"[A-Za-z0-9_]+", name), "Unsafe model name")
        native_key = ("building_" + str(BUILDINGS.index(name[9:]))) if name.startswith("building_") else (
            "specialist_" + str(SPECIALISTS.index(name[11:]))) if name.startswith("specialist_") else name
        require(item["vertices"] == native_records[native_key]["vertices"]
                and item["triangles"] == native_records[native_key]["triangles"]
                and item["joints"] == native_records[native_key]["bones"], "Native/export geometry counts: " + name)
        path = folder / (name + ".glb"); data = path.read_bytes()
        require(len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"], "File hash/size: " + name)
        records.append(audit(path, item)); size += len(data)
    result = {"passed": True, "models": len(records), "bytes": size,
              "vertices": sum(v["vertices"] for v in records), "triangles": sum(v["triangles"] for v in records),
              "animation_clips": sum(len(v["clips"]) for v in records), "records": records,
              "scope": "Independent GLB binary/header/accessor/PBR material/skin/animation validation; not visual or Android rendering acceptance"}
    require(result["vertices"] == manifest["vertices"] and result["triangles"] == manifest["triangles"]
            and size == manifest["totalBytes"], "Manifest totals")
    output = ROOT / "build/glb3d-audit.json"; output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
