#!/usr/bin/env python3
"""Optional Linux Mesa/EGL headless shader check; Android runtime is separate."""
import ctypes as C
import json,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'android/app/src/main/java/org/genewars/android/gl3d/Scene3DRenderer.java'
E=C.CDLL('libEGL.so.1'); P=C.c_void_p; I=C.c_int; U=C.c_uint
E.eglGetProcAddress.restype=P;E.eglGetProcAddress.argtypes=[C.c_char_p]
def ep(name,restype,args):
 f=getattr(E,name);f.restype=restype;f.argtypes=args;return f
def gp(name,restype,args):
 p=E.eglGetProcAddress(name.encode());assert p,name
 return C.CFUNCTYPE(restype,*args)(p)
getdisplay=gp('eglGetPlatformDisplayEXT',P,[U,P,C.POINTER(I)])
display=getdisplay(0x31DD,None,None)
major=I();minor=I();assert ep('eglInitialize',U,[P,C.POINTER(I),C.POINTER(I)])(display,C.byref(major),C.byref(minor))
assert ep('eglBindAPI',U,[U])(0x30A0)
attrs=(I*13)(0x3033,1,0x3040,0x40,0x3024,8,0x3023,8,0x3022,8,0x3025,24,0x3038)
config=P();num=I();assert ep('eglChooseConfig',U,[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)])(display,attrs,C.byref(config),1,C.byref(num)) and num.value
surface=ep('eglCreatePbufferSurface',P,[P,P,C.POINTER(I)])(display,config,(I*5)(0x3057,16,0x3056,16,0x3038))
context=ep('eglCreateContext',P,[P,P,P,C.POINTER(I)])(display,config,None,(I*3)(0x3098,3,0x3038))
assert surface and context
assert ep('eglMakeCurrent',U,[P,P,P,P])(display,surface,surface,context)
glstr=gp('glGetString',C.c_char_p,[U]); version=glstr(0x1F02).decode(); renderer=glstr(0x1F01).decode()
create=gp('glCreateShader',U,[U]);ss=gp('glShaderSource',None,[U,I,C.POINTER(C.c_char_p),C.POINTER(I)]);compile=gp('glCompileShader',None,[U]);getsh=gp('glGetShaderiv',None,[U,U,C.POINTER(I)]);shlog=gp('glGetShaderInfoLog',None,[U,I,C.POINTER(I),C.c_char_p])
createp=gp('glCreateProgram',U,[]);attach=gp('glAttachShader',None,[U,U]);link=gp('glLinkProgram',None,[U]);getp=gp('glGetProgramiv',None,[U,U,C.POINTER(I)]);plog=gp('glGetProgramInfoLog',None,[U,I,C.POINTER(I),C.c_char_p]);err=gp('glGetError',U,[])
text=SOURCE.read_text()
def source(name):
 s=text.split('private static final String '+name+'=',1)[1].split('private static final String',1)[0]
 return ''.join(json.loads(v) for v in re.findall(r'"(?:[^"\\]|\\.)*"',s))
def log(getter,logger,obj):
 n=I();getter(obj,0x8B84,C.byref(n));b=C.create_string_buffer(max(1,n.value));logger(obj,len(b),None,b);return b.value.decode()
results=[]
for vs,fs in [('VERTEX_SHADER','FRAGMENT_SHADER'),('DEPTH_VERTEX','DEPTH_FRAGMENT'),('FLAT_VERTEX','FLAT_FRAGMENT')]:
 program=createp()
 for name,kind in [(vs,0x8B31),(fs,0x8B30)]:
  shader=create(kind);s=C.c_char_p(source(name).encode());ss(shader,1,C.byref(s),None);compile(shader)
  status=I();getsh(shader,0x8B81,C.byref(status));detail=log(getsh,shlog,shader)
  results.append({'shader':name,'compiled':bool(status.value),'log':detail})
  assert status.value,results[-1]
  attach(program,shader)
 link(program);status=I();getp(program,0x8B82,C.byref(status));detail=log(getp,plog,program)
 results.append({'program':vs+'/'+fs,'linked':bool(status.value),'log':detail});assert status.value,results[-1]
result={'passed':True,'renderer_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'GL_VERSION':version,'GL_RENDERER':renderer,'GL_ERROR':err(),'results':results,'scope':'Headless host Mesa GLES3 compile/link only; not Android driver runtime acceptance'}
print(json.dumps(result,indent=2))
(ROOT/'build').mkdir(exist_ok=True)
(ROOT/'build/shader3d-host-audit.json').write_text(json.dumps(result,indent=2)+'\n')
ep('eglMakeCurrent',U,[P,P,P,P])(display,None,None,None);ep('eglDestroyContext',U,[P,P])(display,context);ep('eglDestroySurface',U,[P,P])(display,surface);ep('eglTerminate',U,[P])(display)
