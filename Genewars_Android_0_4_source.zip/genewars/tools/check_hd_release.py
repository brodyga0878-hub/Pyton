#!/usr/bin/env python3
"""Independent, read-only validation of the v0.2 HD resource bundle.

Checks release coverage, image geometry/alpha, crop boundaries and a conservative
decoded-image memory estimate. It never edits art or supplies gameplay state.
It does not establish visual quality, animation completeness or phone FPS.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

from PIL import Image


BUILDINGS = ["EXTRACTOR", "DISTRIBUTOR", "SOLAR", "GENE_LAB", "RECYCLER", "TURRET",
             "PULPER", "LANDING_PAD", "DETECTOR", "WIND", "FUSION", "TECH", "SHIELD", "VAT"]
SPECIALISTS = ["ENGINEER", "BOTANIST", "GENETICIST", "RANGER"]
REQUIRED_TEXTURES = ["grass", "sand", "rock", "snow", "water", "alien"]
MAX_IMAGE_BYTES = 128 * 1024 * 1024


def check(assets: Path) -> dict:
    assets = assets.resolve()
    manifest_path = assets / "native/hd/manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict) or manifest.get("format", 1) != 1:
        raise ValueError("Unsupported HD manifest")
    errors, warnings, records = [], [], []
    expected = ([f"creature_{i}" for i in range(25)]
                + ["building_" + name for name in BUILDINGS]
                + ["specialist_" + name for name in SPECIALISTS]
                + [f"plant_{i}" for i in range(12)])
    groups = {}
    for name in ["sprites", "images", "textures"]:
        value = manifest.get(name, {})
        if not isinstance(value, dict) or len(value) > 512:
            raise ValueError(f"Invalid group {name}")
        groups[name] = value
    missing = sorted(set(expected) - set(groups["sprites"]))
    errors.extend("Missing HD sprite: " + key for key in missing)
    for key in REQUIRED_TEXTURES:
        if key not in groups["textures"]:
            errors.append("Missing HD texture: " + key)
    if "ui/keyart" not in groups["images"]:
        errors.append("Missing HD menu art")
    decoded = {}
    total_asset_bytes = 0
    unique_files = set()
    for group, entries in groups.items():
        for key, raw in entries.items():
            try:
                entry = {"file": raw} if isinstance(raw, str) else raw
                if not isinstance(entry, dict):
                    raise ValueError("record must be an object")
                name = entry["file"]
                if not isinstance(name, str) or not name.startswith("native/hd/") or ".." in Path(name).parts or "\\" in name:
                    raise ValueError("unsafe resource path")
                path = (assets / name).resolve()
                if not path.is_relative_to(assets / "native/hd"):
                    raise ValueError("resource escapes HD root")
                with Image.open(path) as image:
                    source_width, source_height = image.size
                    if max(image.size) > 4096 or min(image.size) < 1:
                        raise ValueError("image outside loader bounds")
                    image.load()
                    rect = entry.get("rect")
                    if rect is None:
                        x = y = 0
                        width, height = image.size
                    else:
                        if (not isinstance(rect, list) or len(rect) != 4
                                or any(type(v) is not int for v in rect)):
                            raise ValueError("rect must contain four integers")
                        x, y, width, height = rect
                    if min(x, y) < 0 or min(width, height) < 1 or x + width > source_width or y + height > source_height:
                        raise ValueError("crop outside image")
                    if max(width, height) > 2048:
                        raise ValueError("decoded visual exceeds sprite loader bounds")
                    scale = entry.get("scale", 1)
                    anchor = entry.get("anchor", [.5, 1])
                    if (not isinstance(scale, (int, float)) or not math.isfinite(scale)
                            or not .25 <= scale <= 4):
                        raise ValueError("invalid scale")
                    if (not isinstance(anchor, list) or len(anchor) != 2
                            or any(not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 or v > 1 for v in anchor)):
                        raise ValueError("invalid anchor")
                    alpha = None
                    region = image.crop((x, y, x + width, y + height))
                    if group == "sprites":
                        if "A" not in region.getbands():
                            raise ValueError("sprite has no alpha channel")
                        alpha_channel = region.getchannel("A")
                        alpha = alpha_channel.getextrema()
                        if alpha[0] != 0 or alpha[1] < 128 or alpha_channel.getbbox() is None:
                            raise ValueError("sprite transparency is absent or sprite is empty")
                        if key in expected and (max(width, height) < 192 or min(width, height) < 48):
                            errors.append(f"Insufficient HD source resolution for {key}: {width}x{height}")
                    # Aliases decoded by the same runtime cache key count once.
                    cache_key = name if rect is None else name + "#" + ":".join(map(str, rect))
                    decoded[cache_key] = width * height * 4
                    if name not in unique_files:
                        total_asset_bytes += path.stat().st_size
                        unique_files.add(name)
                    records.append({"group": group, "key": key, "file": name,
                                    "source_dimensions": [source_width, source_height],
                                    "decoded_dimensions": [width, height], "alpha": alpha,
                                    "rgba_bytes": width * height * 4,
                                    "pixel_sha256": hashlib.sha256(region.tobytes()).hexdigest(),
                                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
            except (KeyError, OSError, ValueError, TypeError) as error:
                errors.append(f"{group}/{key}: {error}")
    memory = sum(decoded.values())
    if memory > MAX_IMAGE_BYTES:
        errors.append(f"Decoded HD visuals exceed 128 MiB budget: {memory} bytes")
    if memory > 64 * 1024 * 1024:
        warnings.append("Decoded visuals exceed 64 MiB; inspect device memory alongside viewport cache.")
    primary_pixels = {r["pixel_sha256"] for r in records if r["group"] == "sprites" and r["key"] in expected}
    if len(primary_pixels) < len(expected) - len(missing):
        warnings.append("Some primary sprite images have identical pixels; inspect whether the reuse is intentional.")
    return {"passed": not errors, "required_sprites": len(expected), "required_sprite_keys": expected,
            "sprite_entries": len(groups["sprites"]), "image_entries": len(groups["images"]),
            "texture_entries": len(groups["textures"]), "unique_files": len(unique_files),
            "packaged_visual_bytes": total_asset_bytes, "conservative_unique_rgba_bytes": memory,
            "unique_primary_visuals": len(primary_pixels),
            "max_decoded_budget_bytes": MAX_IMAGE_BYTES, "errors": errors, "warnings": warnings,
            "records": records,
            "scope": "asset coverage and safety; not a visual/FPS/campaign acceptance test"}


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=root / "android/app/src/main/assets")
    parser.add_argument("--output", type=Path, default=root / "build/hd-release-audit.json")
    args = parser.parse_args()
    try:
        result = check(args.assets)
    except (OSError, ValueError, TypeError) as error:
        result = {"passed": False, "errors": [str(error)], "scope": "HD resources unavailable or malformed"}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ["records", "required_sprite_keys"]}, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
