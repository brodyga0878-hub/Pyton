#!/usr/bin/env python3
"""Independent coverage/bounds/scalar/provenance audit of the 0.4 terrain atlas."""
import hashlib
import json
import math
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MATERIALS = ["water", "shore", "sand", "grass", "rock", "alien", "snow", "moss", "biotech"]


def main():
    assets = ROOT / "android/app/src/main/assets"
    manifest = json.loads((assets / "native/materials-v04/manifest.json").read_text())
    provenance = json.loads((ROOT / "graphics-source/v04/provenance.json").read_text())
    assert manifest["release"] == "0.4" and manifest["colorSpace"]["albedo"] == "sRGB"
    assert set(manifest["textures"]) == set(MATERIALS)
    source = ROOT / "graphics-source/v04/terrain-albedo.png"
    atlas = assets / manifest["atlas"]["albedo"]
    digest = hashlib.sha256(atlas.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(source.read_bytes()).hexdigest() == provenance["sha256"]
    rectangles, pixel_hashes = [], set()
    with Image.open(atlas) as image:
        assert image.size == (1254, 1254) and image.mode == "RGB"
        for key in MATERIALS:
            entry = manifest["textures"][key]
            assert entry["file"] == manifest["atlas"]["albedo"]
            x, y, width, height = entry["rect"]
            assert all(type(value) is int for value in entry["rect"])
            assert width == height == 418 and x >= 0 and y >= 0 and x + width <= image.width and y + height <= image.height
            box = (x, y, x + width, y + height)
            assert all(min(box[2], old[2]) <= max(box[0], old[0]) or min(box[3], old[3]) <= max(box[1], old[1]) for old in rectangles)
            rectangles.append(box)
            for field, low, high in [("roughness", .08, 1), ("metallic", 0, 1), ("normalScale", 0, .3)]:
                value = entry[field]
                assert type(value) in [int, float] and math.isfinite(value) and low <= value <= high
            pixel_hashes.add(hashlib.sha256(image.crop(box).tobytes()).hexdigest())
        assert len(rectangles) * 418 * 418 == image.width * image.height and len(pixel_hashes) == 9
        result = {"passed": True, "materials": 9, "distinct_regions": len(pixel_hashes),
                  "source_bytes_identical": True, "sha256": digest, "bytes": atlas.stat().st_size,
                  "source_dimensions": list(image.size), "conservative_decode_rgba_bytes": image.width * image.height * 4,
                  "gpu_atlas_base_rgba_bytes": 768 * 768 * 4,
                  "scope": "authored sRGB albedo plus bounded roughness/metallic/procedural-normal scalars; no measured normal/ORM claim"}
    output = ROOT / "build/materials-v04-audit.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
