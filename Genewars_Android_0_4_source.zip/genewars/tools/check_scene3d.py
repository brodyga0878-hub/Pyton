#!/usr/bin/env python3
"""Run independent JVM camera/picking/snapshot checks, without Android."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--java-home", type=Path)
    parser.add_argument("--output", type=Path, default=root / "build/scene3d-audit.json")
    args = parser.parse_args()
    java_home = args.java_home or (Path(os.environ["JAVA_HOME"]) if os.environ.get("JAVA_HOME") else None)
    javac = str(java_home / "bin/javac") if java_home else shutil.which("javac")
    java = str(java_home / "bin/java") if java_home else shutil.which("java")
    if not javac or not java:
        parser.error("A JDK is required; pass --java-home or set JAVA_HOME")
    app = root / "android/app/src/main/java/org/genewars/android/gl3d"
    paths = list((root / "native-core/src").rglob("*.java"))
    paths += [app / (name + ".java") for name in ["Matrix3D", "Camera3D", "Scene3DFrame", "TerrainMesh3D"]]
    paths += [root / "android/model-tests/Scene3DAcceptance.java"]
    classes = root / "build/scene3d-qa-classes"
    classes.mkdir(parents=True, exist_ok=True)
    try:
        build = subprocess.run([javac, "--release", "8", "-encoding", "UTF-8", "-d", str(classes), *map(str, paths)],
                               capture_output=True, text=True, timeout=120)
        if build.returncode:
            raise RuntimeError("Scene CPU QA compile failed:\n" + build.stdout + build.stderr)
        run = subprocess.run([java, "-cp", str(classes), "org.genewars.android.gl3d.Scene3DAcceptance"],
                             capture_output=True, text=True, timeout=120)
        if run.returncode:
            raise RuntimeError("Scene CPU QA failed:\n" + run.stdout + run.stderr)
        result = json.loads(run.stdout)
        result["scope"] = "CPU camera/pick consistency, snapshot isolation and terrain equivalence; not Android shader or lifecycle acceptance"
    except (OSError, RuntimeError, subprocess.TimeoutExpired, ValueError) as error:
        result = {"passed": False, "errors": [str(error)]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result.get("passed") else 1


if __name__ == "__main__":
    raise SystemExit(main())
