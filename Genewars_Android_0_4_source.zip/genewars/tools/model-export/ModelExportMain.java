// SPDX-License-Identifier: GPL-2.0-or-later
import org.genewars.android.gl3d.Bone3D;
import org.genewars.android.gl3d.MeshData3D;
import org.genewars.android.gl3d.ModelLibrary3D;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Host-only adapter: serializes production meshes and the production animation rig. */
public final class ModelExportMain {
    private static final String[] BUILDINGS={"EXTRACTOR","DISTRIBUTOR","SOLAR","GENE_LAB","RECYCLER","TURRET","PULPER","LANDING_PAD","DETECTOR","WIND","FUSION","TECH","SHIELD","VAT"};
    private static final String[] PEOPLE={"ENGINEER","BOTANIST","GENETICIST","RANGER"};
    private static BufferedWriter out;
    private static void write(String value)throws IOException{out.write(value);}
    private static void string(String value)throws IOException{
        write("\"");for(int i=0;i<value.length();i++){char c=value.charAt(i);if(c=='\\'||c=='\"')write("\\"+c);else if(c<32)throw new IOException("Control character in name");else out.write(c);}write("\"");
    }
    private static void floats(float[] values,int count)throws IOException{
        write("[");for(int i=0;i<count;i++){if(i>0)write(",");if(!Float.isFinite(values[i]))throw new IOException("Non-finite production value");write(Float.toString(values[i]));}write("]");
    }
    private static void component(MeshData3D mesh,int offset,int width)throws IOException{
        write("[");int n=mesh.vertices.length/MeshData3D.STRIDE_FLOATS;
        for(int i=0;i<n;i++)for(int c=0;c<width;c++){if(i+c>0)write(",");float v=mesh.vertices[i*13+offset+c];if(!Float.isFinite(v))throw new IOException("Invalid vertex");write(Float.toString(v));}write("]");
    }
    private static void clip(MeshData3D mesh,String name,int action,float duration,float speed,boolean comma)throws IOException{
        if(comma)write(",");int frames=Math.round(duration*30);float[]t=new float[72],q=new float[96],s=new float[72],pose=new float[384];
        write("{\"name\":");string(name);write(",\"action\":"+action+",\"speed\":"+speed+",\"times\":[");
        for(int i=0;i<=frames;i++){if(i>0)write(",");write(Float.toString(i/30f));}write("],\"translation\":[");
        for(int i=0;i<=frames;i++){if(i>0)write(",");mesh.sampleLocalTRS(i/30f,action,speed,t,q,s);floats(t,mesh.boneCount*3);}write("],\"rotation\":[");
        for(int i=0;i<=frames;i++){if(i>0)write(",");mesh.sampleLocalTRS(i/30f,action,speed,t,q,s);floats(q,mesh.boneCount*4);}write("],\"scale\":[");
        for(int i=0;i<=frames;i++){if(i>0)write(",");mesh.sampleLocalTRS(i/30f,action,speed,t,q,s);floats(s,mesh.boneCount*3);}write("],\"nativeSkinChecks\":[");
        for(int k=0;k<3;k++){int frame=k==0?0:k==1?frames/2:frames;if(k>0)write(",");mesh.pose(frame/30f,action,speed,pose);write("{\"frame\":"+frame+",\"matrices\":");floats(pose,mesh.boneCount*16);write("}");}write("]}");
    }
    private static void save(Path directory,String name,String category,MeshData3D mesh)throws IOException{
        Path path=directory.resolve(name+".json");
        try(BufferedWriter writer=Files.newBufferedWriter(path,StandardCharsets.UTF_8)){
            out=writer;write("{\"name\":");string(name);write(",\"nativeName\":");string(mesh.name);write(",\"category\":");string(category);
            write(",\"source\":\"ModelLibrary3D (unmodified production geometry and sampled native rig)\",\"positions\":");component(mesh,0,3);
            write(",\"normals\":");component(mesh,3,3);write(",\"rgb\":");component(mesh,6,3);write(",\"emissive\":");component(mesh,9,1);
            write(",\"materialVersion\":"+ModelLibrary3D.MATERIAL_VERSION+",\"roughness\":");component(mesh,10,1);write(",\"metallic\":");component(mesh,11,1);write(",\"joints\":");component(mesh,12,1);
            write(",\"indices\":[");for(int i=0;i<mesh.indices.length;i++){if(i>0)write(",");write(Integer.toString(mesh.indices[i]));}write("],\"bones\":[");
            for(int i=0;i<mesh.boneCount;i++){Bone3D b=mesh.bones[i];if(i>0)write(",");write("{\"name\":");string(b.name);write(",\"parent\":"+b.parent+",\"pivot\":["+b.x+","+b.y+","+b.z+"],\"nativeAnimation\":"+b.animation+",\"phase\":"+b.phase+",\"amplitude\":"+b.amplitude+"}");}
            write("],\"clips\":[");clip(mesh,"idle",MeshData3D.IDLE,category.equals("plant")?4:2,0,false);
            if(category.equals("creature")||category.equals("specialist")){clip(mesh,"walk",MeshData3D.WALK,2,1,true);clip(mesh,"attack",MeshData3D.ATTACK,2,0,true);}
            if(category.equals("building")||category.equals("specialist"))clip(mesh,"work",MeshData3D.WORK,2,0,true);
            write("]}");
        }
    }
    public static void main(String[]args)throws Exception{
        if(args.length!=1)throw new IllegalArgumentException("Output directory required");Path dir=Paths.get(args[0]);Files.createDirectories(dir);
        for(int i=0;i<25;i++)save(dir,"creature_"+i,"creature",ModelLibrary3D.getCreature(i));
        for(int i=0;i<14;i++)save(dir,"building_"+BUILDINGS[i],"building",ModelLibrary3D.getBuilding(i));
        for(int i=0;i<4;i++)save(dir,"specialist_"+PEOPLE[i],"specialist",ModelLibrary3D.getSpecialist(i));
        for(int i=0;i<12;i++)save(dir,"plant_"+i,"plant",ModelLibrary3D.getPlant(i));
        System.out.println("Serialized 55 exact native model assets");
    }
}
