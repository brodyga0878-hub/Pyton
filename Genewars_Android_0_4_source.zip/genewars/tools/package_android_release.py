#!/usr/bin/env python3
"""Package a verified APK with matching source, excluding local keys/toolchains."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIRS = ("android", "native-core", "tools", "tests", "docs", "localization",
               "licenses", "graphics", "graphics-source")
SECRET_SUFFIXES = (".p12", ".jks", ".keystore", ".pyc")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--tag", required=True, help="Safe filename tag, e.g. 0_3_3D")
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--release-notes", type=Path, required=True)
    args = parser.parse_args()
    if not args.tag or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" for c in args.tag):
        raise ValueError("Unsafe filename tag")
    metadata = json.loads(args.apk.with_suffix(".json").read_text())
    if digest(args.apk) != metadata["sha256"]:
        raise ValueError("APK checksum differs from build metadata")
    from build_android import source_fingerprint
    if source_fingerprint() != metadata["source_and_assets_sha256"]:
        raise ValueError("Source/assets changed since APK build")
    release = ROOT / "build" / ("release-" + args.tag)
    release.mkdir(parents=True, exist_ok=True)
    apk = release / ("Genewars_Android_" + args.tag + ".apk")
    shutil.copy2(args.apk, apk)
    source = release / ("Genewars_Android_" + args.tag + "_source.zip")
    paths = [ROOT / name for name in ("README.md", "LICENSE", ".gitignore", "requirements.txt")]
    for directory in SOURCE_DIRS:
        paths.extend(p for p in (ROOT / directory).rglob("*") if p.is_file())
    with zipfile.ZipFile(source, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(paths):
            if "__pycache__" in path.parts or path.name.endswith(SECRET_SUFFIXES):
                continue
            if path.is_symlink():
                raise ValueError("Unexpected source symlink: " + str(path))
            archive.write(path, "genewars/" + path.relative_to(ROOT).as_posix())
        for path in sorted(args.evidence.rglob("*")):
            if path.is_file():
                archive.write(path, "genewars/release-evidence/" + path.relative_to(args.evidence).as_posix())
        archive.write(args.apk.with_suffix(".json"), "genewars/release-evidence/apk-build.json")
    with zipfile.ZipFile(source) as archive:
        if archive.testzip() is not None:
            raise ValueError("Source ZIP CRC failed")
        names = archive.namelist()
        if len(set(names)) != len(names) or any(n.endswith(SECRET_SUFFIXES) for n in names):
            raise ValueError("Invalid source archive entries")
    if source_fingerprint() != metadata["source_and_assets_sha256"]:
        raise ValueError("Source/assets changed during packaging")
    shutil.copy2(ROOT / "LICENSE", release / "LICENSE")
    shutil.copy2(args.release_notes, release / "README.md")
    artifacts = [apk, source, release / "LICENSE", release / "README.md"]
    (release / "SHA256SUMS").write_text("".join(digest(p) + "  " + p.name + "\n" for p in artifacts))
    print(json.dumps({"directory": str(release), "artifacts": [
        {"file": p.name, "bytes": p.stat().st_size, "sha256": digest(p)} for p in artifacts
    ]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
