#!/usr/bin/env python3
"""Run installed native smoke instrumentation and preserve its real result.

Use only on a development device: the test replaces the game's local save slot.
Both application APKs must already be installed and signed with the same key.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import subprocess
import threading
import time


EXPECTED_CHECKS = [
    "native_main_menu", "original_map_loaded_and_native_frames_running",
    "gles3_mesh_frame_and_visible_camera_rotation",
    "selected_squad_card_live_portrait_and_role_action",
    "native_construction_command_debits_resources", "private_game_save_created",
    "native_activity_restarted_with_persisted_slot",
    "changed_resource_state_restored_after_activity_restart",
]
LEGACY_CHECK = "legacy_private_save_loaded_by_android_current"


def parse_result(output: str, exit_code: int, compatibility_only: bool = False) -> dict:
    """Only the final raw Bundle and complete expected check set prove success."""
    fields = dict(re.findall(r"^INSTRUMENTATION_RESULT: ([a-z_]+)=(.*)$", output, re.MULTILINE))
    fields = {key: value.strip() for key, value in fields.items()}
    raw_checks = fields.get("checks", "")
    checks = [value.strip() for value in raw_checks[1:-1].split(",")] if raw_checks.startswith("[") and raw_checks.endswith("]") else []
    expected = [LEGACY_CHECK] if compatibility_only else EXPECTED_CHECKS
    codes = re.findall(r"^INSTRUMENTATION_CODE:\s*(-?\d+)\s*$", output, re.MULTILINE)
    passed = (exit_code == 0 and fields.get("status") == "passed"
              and fields.get("passed_checks") == str(len(expected))
              and len(checks) == len(expected) and set(checks) == set(expected)
              and bool(codes) and codes[-1] == "-1")
    return {"passed": passed, "expected_checks": len(expected), "reported_checks": checks,
            "status": fields.get("status"), "stage": fields.get("stage"), "reason": fields.get("reason"),
            "three_d": fields.get("three_d"), "squad_card": fields.get("squad_card"),
            "infrastructure_notes": fields.get("infrastructure_notes")}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--adb", default="adb")
    parser.add_argument("--serial", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--compatibility-only", action="store_true", help="Load existing private save without a new game or explicit save")
    parser.add_argument("--timeout", type=int, default=600, help="Host watchdog seconds; does not change Android assertions")
    args = parser.parse_args()
    if args.timeout < 1:
        parser.error("--timeout must be positive")
    args.output.mkdir(parents=True, exist_ok=True)
    name = "smoke-" + time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    log = args.output / (name + ".log")
    command = [args.adb, "-s", args.serial, "shell", "am", "instrument", "-w", "-r"]
    if args.compatibility_only:
        command += ["-e", "compatibility_only", "true"]
    command += ["org.genewars.smoke/.NativeSmokeInstrumentation"]
    started = time.monotonic()
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, bufsize=1)
    timed_out = threading.Event()
    def expire():
        timed_out.set()
        process.kill()
    timer = threading.Timer(args.timeout, expire)
    timer.start()
    lines = []
    try:
        with log.open("x", encoding="utf-8") as handle:
            for line in process.stdout:
                handle.write(line)
                handle.flush()
                lines.append(line)
                print(line, end="", flush=True)
        exit_code = process.wait()
    finally:
        timer.cancel()
    output = "".join(lines)
    result = parse_result(output, exit_code, args.compatibility_only)
    result.update({"adb_exit_code": exit_code, "timed_out": timed_out.is_set(),
              "serial": args.serial, "seconds": round(time.monotonic() - started, 3),
              "log": str(log), "scope": "existing-save compatibility" if args.compatibility_only else
              "native UI/GLES3 mesh frame/central scene rotation/selected squad card and portrait/command/save/Activity restart"})
    log.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
