#!/usr/bin/env python3
"""Pack authored terrain albedo atlases losslessly with runtime PBR scalar metadata.

Only PNG validation and byte-for-byte copying happen here. No new surface detail,
normal map, roughness map, retouching, resizing or lighting is synthesized.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import tempfile

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
NAMES = ('water', 'shore', 'sand', 'grass', 'rock', 'alien', 'snow', 'moss', 'biotech')
FILES = {'albedo': 'terrain_albedo.png', 'normal': 'terrain_normal.png', 'orm': 'terrain_orm.png'}


def finite(value, name, minimum, maximum):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(f'{name} must be in [{minimum},{maximum}]')
    return float(value)


def png_info(path):
    with Image.open(path) as image:
        if image.format != 'PNG' or image.mode not in ('RGB', 'RGBA'):
            raise ValueError('Terrain atlas must be an RGB/RGBA PNG')
        width, height = image.size
        if width != height or not 768 <= width <= 4096:
            raise ValueError('Terrain 3x3 atlas must be square and 768..4096 pixels')
        image.load()
        if image.mode == 'RGBA' and image.getextrema()[3] != (255, 255):
            raise ValueError('Terrain surfaces must be opaque')
        return {'width': width, 'height': height, 'mode': image.mode,
                'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def pack(spec_path: Path, output: Path):
    spec_path = spec_path.resolve()
    spec = json.loads(spec_path.read_text(encoding='utf-8'))
    if spec.get('version') != 1 or not isinstance(spec.get('textures'), dict) or set(spec['textures']) != set(NAMES):
        raise ValueError('Specification needs version 1 and exactly nine terrain names')
    sources = spec.get('sources', {})
    if not isinstance(sources, dict) or 'albedo' not in sources or set(sources) - set(FILES):
        raise ValueError('Need albedo source; only optional normal/orm sources are accepted')
    paths, infos = {}, {}
    for channel, value in sources.items():
        if not isinstance(value, str) or not value:
            raise ValueError('Source path must be a string')
        paths[channel] = (spec_path.parent/value).resolve()
        infos[channel] = png_info(paths[channel])
    width, height = infos['albedo']['width'], infos['albedo']['height']
    if any((info['width'], info['height']) != (width, height) for info in infos.values()):
        raise ValueError('All optional maps must match the albedo atlas dimensions')
    prefix = 'native/materials-v04/'
    manifest = {'version': 1, 'release': '0.4',
                'colorSpace': {'albedo': 'sRGB', 'normal': 'linear', 'orm': 'linear'},
                'mapSemantics': {'normal': 'tangent RGB, +Y convention; optional', 'orm': 'R=AO G=roughness B=metallic; optional'},
                'atlas': {channel: prefix+FILES[channel] for channel in sources},
                'textures': {},
                'scope': 'Authored albedo with PBR scalars; optional maps are absent unless explicitly supplied. Shader micro-normals are procedural, not measured maps.'}
    manifest['atlas'].update({'columns': 3, 'rows': 3, 'width': width, 'height': height})
    for i, name in enumerate(NAMES):
        entry = spec['textures'][name]
        if not isinstance(entry, dict) or set(entry) != {'roughness', 'metallic', 'normalScale'}:
            raise ValueError('Each material needs only roughness, metallic and normalScale scalars')
        x0, y0 = (i % 3)*width//3, (i//3)*height//3
        x1, y1 = ((i % 3)+1)*width//3, ((i//3)+1)*height//3
        material = {'file': prefix+FILES['albedo'], 'rect': [x0, y0, x1-x0, y1-y0],
                    'roughness': finite(entry['roughness'], 'roughness', .04, 1),
                    'metallic': finite(entry['metallic'], 'metallic', 0, 1),
                    'normalScale': finite(entry['normalScale'], 'normalScale', 0, 2)}
        for channel in ('normal', 'orm'):
            if channel in sources:
                material[channel] = prefix+FILES[channel]
        manifest['textures'][name] = material
    output.mkdir(parents=True, exist_ok=True)
    allowed = {'manifest.json', 'assets-audit.json', *FILES.values()}
    if any(path.name not in allowed for path in output.iterdir()):
        raise ValueError('Refusing to replace a directory containing unowned files')
    audit = {'version': 1, 'sources': {channel: {'path': str(paths[channel].relative_to(ROOT)) if paths[channel].is_relative_to(ROOT) else paths[channel].name,
                                                **infos[channel]} for channel in sources},
             'copyPolicy': 'Source PNG bytes are copied identically; grid regions cover the full atlas exactly',
             'materials': list(NAMES), 'optionalMaps': [channel for channel in sources if channel != 'albedo']}
    with tempfile.TemporaryDirectory(prefix='.terrain-pack-', dir=output.parent) as directory:
        staging = Path(directory)
        for channel, source in paths.items():
            shutil.copyfile(source, staging/FILES[channel])
            if hashlib.sha256((staging/FILES[channel]).read_bytes()).hexdigest() != infos[channel]['sha256']:
                raise ValueError('Lossless copy verification failed')
        (staging/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        (staging/'assets-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        for path in staging.iterdir():
            path.replace(output/path.name)
        for channel in set(FILES)-set(sources):
            (output/FILES[channel]).unlink(missing_ok=True)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', type=Path, default=ROOT/'graphics/terrain-v04-spec.json')
    parser.add_argument('--output', type=Path, default=ROOT/'android/app/src/main/assets/native/materials-v04')
    args = parser.parse_args()
    manifest = pack(args.spec, args.output)
    print(json.dumps({'materials': len(manifest['textures']), 'atlas': manifest['atlas'], 'output': str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
