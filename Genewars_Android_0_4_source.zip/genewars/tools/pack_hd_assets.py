#!/usr/bin/env python3
"""Pack generated HD art into Android resources without changing its pixels.

The input is a JSON specification with sprites/images/textures dictionaries or
regular-grid atlases. Whole images are copied; regions and transparent padding
are cropped losslessly. This tool does not paint, upscale, recolour, remove
backgrounds, or create replacement art. Visual design belongs to image_gen.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import tempfile

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SECTIONS = ("sprites", "images", "textures")
MAX_SOURCE = 4096
MAX_OUTPUT = 2048


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def integer(value, name: str, minimum=0, maximum=MAX_SOURCE) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise ValueError(f"Invalid {name}: {value!r}")
    return value


def key_name(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_./-]{1,128}", value) or ".." in value:
        raise ValueError(f"Invalid asset key: {value!r}")
    return value


def geometry(value: dict) -> tuple[float, list[float]]:
    scale = value.get("scale", 1.0)
    anchor = value.get("anchor", [0.5, 1.0])
    if isinstance(scale, bool) or not isinstance(scale, (int, float)) or not math.isfinite(scale) or not 0.25 <= scale <= 4:
        raise ValueError("Scale must be finite and between 0.25 and 4")
    if not isinstance(anchor, list) or len(anchor) != 2 or any(
        isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n) or not 0 <= n <= 1 for n in anchor
    ):
        raise ValueError("Anchor must contain two finite coordinates in [0, 1]")
    return float(scale), [float(n) for n in anchor]


def load_source(path: Path) -> Image.Image:
    with Image.open(path) as image:
        if image.format != "PNG" or image.mode not in ["RGB", "RGBA"]:
            raise ValueError(f"Expected RGB/RGBA PNG: {path}")
        if not 0 < image.width <= MAX_SOURCE or not 0 < image.height <= MAX_SOURCE:
            raise ValueError(f"Source image exceeds {MAX_SOURCE}px: {path}")
        image.load()
        return image.copy()


def source_path(base: Path, value: dict) -> Path:
    raw = value.get("source")
    if not isinstance(raw, str) or not raw:
        raise ValueError("Every asset needs a source PNG path")
    path = Path(raw)
    return path if path.is_absolute() else base / path


def regions(spec: dict, base: Path) -> dict:
    result = {section: {} for section in SECTIONS}
    for section in SECTIONS:
        values = spec.get(section, {})
        if not isinstance(values, dict):
            raise ValueError(f"{section} must be a dictionary")
        for name, value in values.items():
            name = key_name(name)
            if not isinstance(value, dict):
                raise ValueError(f"{section}/{name} must be an object")
            result[section][name] = dict(value)
    for atlas in spec.get("atlases", []):
        section = atlas.get("section", "sprites")
        if section not in SECTIONS:
            raise ValueError("Unknown atlas section")
        columns = integer(atlas.get("columns"), "columns", 1, 32)
        rows = integer(atlas.get("rows"), "rows", 1, 32)
        names = atlas.get("keys")
        if not isinstance(names, list) or len(names) > columns * rows:
            raise ValueError("Atlas keys exceed the grid")
        image = load_source(source_path(base, atlas))
        for index, name in enumerate(names):
            if name is None:
                continue
            name = key_name(name)
            if name in result[section]:
                raise ValueError(f"Duplicate asset key: {section}/{name}")
            x, y = index % columns, index // columns
            left, right = x * image.width // columns, (x + 1) * image.width // columns
            top, bottom = y * image.height // rows, (y + 1) * image.height // rows
            value = {k: v for k, v in atlas.items() if k not in ["keys", "columns", "rows", "section"]}
            value["rect"] = [left, top, right - left, bottom - top]
            result[section][name] = value
    return result


def crop_asset(image: Image.Image, value: dict, sprite: bool) -> tuple[Image.Image, dict]:
    rectangle = value.get("rect", [0, 0, image.width, image.height])
    if not isinstance(rectangle, list) or len(rectangle) != 4:
        raise ValueError("Rect must be [x, y, width, height]")
    x, y = integer(rectangle[0], "rect x"), integer(rectangle[1], "rect y")
    width = integer(rectangle[2], "rect width", 1)
    height = integer(rectangle[3], "rect height", 1)
    if x + width > image.width or y + height > image.height:
        raise ValueError("Rectangle exceeds the source PNG")
    result = image.crop((x, y, x + width, y + height))
    trim = [0, 0, width, height]
    transparent = value.get("transparent", sprite)
    if transparent:
        if result.mode != "RGBA":
            raise ValueError("Sprites must have a real alpha channel; no automatic background removal is performed")
        alpha = result.getchannel("A")
        bounds = alpha.getbbox()
        if bounds is None:
            raise ValueError("Empty transparent sprite")
        if alpha.getextrema()[0] != 0:
            raise ValueError("Sprite has no fully transparent padding")
        if value.get("trim", sprite):
            padding = integer(value.get("padding", 2), "transparent padding", 0, 16)
            trim = [max(0, bounds[0] - padding), max(0, bounds[1] - padding),
                    min(width, bounds[2] + padding), min(height, bounds[3] + padding)]
            result = result.crop(tuple(trim))
    if result.width > MAX_OUTPUT or result.height > MAX_OUTPUT:
        raise ValueError(f"Packed images must fit {MAX_OUTPUT}px; provide a smaller source or an atlas region")
    return result, {"sourceRect": rectangle, "trimBounds": trim, "width": result.width, "height": result.height}


def pack(spec_path: Path, output: Path) -> dict:
    spec_path = spec_path.resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if spec.get("format", 1) != 1:
        raise ValueError("Unsupported HD specification version")
    prepared = regions(spec, spec_path.parent)
    if not any(prepared.values()):
        raise ValueError("The HD package is empty")
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    previous = {}
    if output.exists() and (output / "manifest.json").exists():
        previous = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
    owned = set(previous.get("generatedFiles", []))
    manifest = {"format": 1, "style": spec.get("style", "stylized high-definition isometric"),
                "sprites": {}, "images": {}, "textures": {}}
    audit = {"format": 1, "specificationSha256": sha(spec_path.read_bytes()),
             "operation": "lossless cropping and packing only; no visual editing or upscaling", "assets": {}}
    source_cache = {}
    names = set()
    with tempfile.TemporaryDirectory(prefix=".hd-pack-", dir=output.parent) as temp:
        stage = Path(temp)
        for section in SECTIONS:
            for name, value in prepared[section].items():
                scale, anchor = geometry(value)
                path = source_path(spec_path.parent, value).resolve()
                if path not in source_cache:
                    source_cache[path] = load_source(path)
                source = source_cache[path]
                picture, information = crop_asset(source, value, section == "sprites")
                filename = value.get("outputName", section + "_" + re.sub(r"[^A-Za-z0-9_-]", "_", name) + ".png")
                if not isinstance(filename, str) or not re.fullmatch(r"[A-Za-z0-9_-]+\.png", filename):
                    raise ValueError("Output name must be a plain PNG filename")
                if filename in names:
                    raise ValueError("Asset keys collide after filename normalization")
                names.add(filename)
                target = stage / filename
                # Encoding may change; decoded RGBA/RGB samples remain exact.
                picture.save(target, format="PNG", optimize=True)
                with Image.open(target) as verify:
                    if verify.mode != picture.mode or verify.size != picture.size or verify.tobytes() != picture.tobytes():
                        raise AssertionError("Packing changed image pixels")
                entry = {"file": "native/hd/" + filename}
                if section == "sprites":
                    entry.update(scale=scale, anchor=anchor)
                manifest[section][name] = entry
                audit["assets"][section + "/" + name] = dict(information, source=str(path),
                    sourceSha256=sha(path.read_bytes()), sourceSize=list(source.size),
                    output=filename, outputSha256=sha(target.read_bytes()), mode=picture.mode,
                    rawPixelsSha256=sha(picture.tobytes()))
        generated = names | {"manifest.json", "assets-audit.json"}
        manifest["generatedFiles"] = sorted(generated | owned)
        (stage / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (stage / "assets-audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        output.mkdir(exist_ok=True)
        # Preserve unrelated files; overwrite only files owned by an earlier run.
        for target in stage.iterdir():
            existing = output / target.name
            if existing.exists() and target.name not in owned and existing.read_bytes() != target.read_bytes():
                raise FileExistsError(f"Refusing to overwrite a file not owned by this packer: {existing}")
        for target in stage.iterdir():
            shutil.copyfile(target, output / target.name)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("specification", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "android/app/src/main/assets/native/hd")
    args = parser.parse_args()
    result = pack(args.specification, args.output)
    print(json.dumps({"output": str(args.output), **{section: len(result[section]) for section in SECTIONS}}))


if __name__ == "__main__":
    main()
