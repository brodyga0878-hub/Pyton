package org.genewars.smoke;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.security.MessageDigest;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Black-box native UI, command and persisted-save smoke test. No AndroidX. */
public final class NativeSmokeInstrumentation extends Instrumentation {
    private final List<String> checks = new ArrayList<String>();
    private Activity activity;
    private UiAutomation automation;
    private String stage = "launch";
    private String lastAccessibilitySnapshot = "No accessibility root was sampled";
    private String threeDMetrics = "not sampled";
    private String squadCardMetrics = "not sampled";
    private final ArrayList<String> infrastructureNotes = new ArrayList<String>();
    private boolean compatibilityOnly;

    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        compatibilityOnly = arguments != null && "true".equalsIgnoreCase(arguments.getString("compatibility_only", "false"));
        start();
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            automation = getUiAutomation();
            if (compatibilityOnly) { verifyLegacyCompatibility(result); return; }
            activity = launch();
            awaitExact("Новая игра", 60000).recycle();
            pass("native_main_menu");

            stage = "choose original map and mission";
            clickExact("Новая игра");
            awaitExact("Выберите планету", 10000).recycle();
            clickFirstListItem();
            awaitExact("Задание реконструкции", 10000).recycle();
            clickFirstListItem();
            awaitHud(30000);
            awaitExact("Строить", 10000).recycle();
            SystemClock.sleep(2200);
            pass("original_map_loaded_and_native_frames_running");

            stage = "verify genuine 3D frame and changed camera view";
            verifyThreeDScene();
            pass("gles3_mesh_frame_and_visible_camera_rotation");

            stage = "verify selected squad card and live portrait";
            verifySquadCard();

            stage = "select engineer and start construction";
            int before = goop(hudOnMainThread());
            Rect world = worldBounds();
            float density = getTargetContext().getResources().getDisplayMetrics().density;
            injectTap(world.exactCenterX(), world.exactCenterY() - 9 * density);
            SystemClock.sleep(500);
            tapDescriptionExact("Приказ выбранному: Строить");
            awaitPrefix("Постройка:", 10000).recycle();
            clickFirstListItem();
            awaitHud(10000);
            int[][] offsets = {{3,0}, {0,3}, {-3,0}, {0,-3}, {3,3}, {-3,-3}, {5,0}, {0,5}, {-5,0}, {0,-5}};
            boolean spent = false;
            int after = before;
            for (int[] offset : offsets) {
                float x = world.exactCenterX() + (offset[0] - offset[1]) * 18 * density;
                float y = world.exactCenterY() + (offset[0] + offset[1]) * 9 * density;
                if (x <= world.left + 8 || x >= world.right - 8 || y <= world.top + 8 || y >= world.bottom - 8) continue;
                injectTap(x, y);
                long deadline = SystemClock.uptimeMillis() + 1800;
                while (SystemClock.uptimeMillis() < deadline) {
                    after = goop(hudOnMainThread());
                    if (after < before) { spent = true; break; }
                    SystemClock.sleep(100);
                }
                if (spent) break;
            }
            require(spent, "Construction command did not debit GOOP; before=" + before + ", after=" + after);
            squadCardMetrics += "; card_build_action_debits_resources=true";
            pass("selected_squad_card_live_portrait_and_role_action");
            pass("native_construction_command_debits_resources");

            stage = "save game through native menu";
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            String savedHud = hudOnMainThread();
            require(goop(savedHud) < before, "Changed resource state was not retained before saving");
            clickExact("Сохранить");
            File save = new File(getTargetContext().getFilesDir(), "game-v1.gws");
            long saveDeadline = SystemClock.uptimeMillis() + 10000;
            while ((!save.isFile() || save.length() < 32) && SystemClock.uptimeMillis() < saveDeadline) SystemClock.sleep(100);
            require(save.isFile() && save.length() >= 32, "No durable private save file");
            pass("private_game_save_created");

            stage = "leave game and restart Activity";
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            savedHud = hudOnMainThread();
            clickExact("Главное меню");
            awaitExact("Новая игра", 10000).recycle();
            runOnMainSync(new Runnable() { @Override public void run() { activity.finish(); } });
            waitForIdleSync();
            activity = launch();
            awaitExact("Продолжить", 30000).recycle();
            pass("native_activity_restarted_with_persisted_slot");
            clickExact("Продолжить");
            awaitHud(30000);
            pressBack();
            awaitExact("Игра приостановлена", 10000).recycle();
            String restoredHud = hudOnMainThread();
            require(savedHud.equals(restoredHud), "Restored counters differ: saved=" + savedHud + ", loaded=" + restoredHud);
            pass("changed_resource_state_restored_after_activity_restart");

            result.putString("status", "passed");
            result.putInt("passed_checks", checks.size());
            result.putStringArrayList("checks", new ArrayList<String>(checks));
            result.putString("saved_hud", savedHud);
            result.putString("restored_hud", restoredHud);
            result.putString("three_d", threeDMetrics);
            result.putString("squad_card", squadCardMetrics);
            result.putStringArrayList("infrastructure_notes", new ArrayList<String>(infrastructureNotes));
            result.putString("scope", "native UI, GLES3 mesh frame/scene rotation, selected squad card/live portrait/role action, real command, private save and Activity restart; not process-kill or physical-device performance");
            result.putString("stream", "\nPASS: " + checks.size() + " native smoke checks\n");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable failure) {
            android.util.Log.e("GeneWarsSmoke", "Failure at " + stage, failure);
            String diagnostic = "Accessibility: " + accessibilitySnapshot() + " | Activity: " + activitySnapshot();
            android.util.Log.e("GeneWarsSmoke", diagnostic);
            String detail = failure.getMessage();
            if (detail == null) detail = failure.getClass().getSimpleName();
            if (detail.length() > 600) detail = detail.substring(0, 600);
            result.putString("status", "failed");
            result.putString("stage", stage);
            result.putString("reason", detail);
            result.putString("ui_snapshot", diagnostic);
            result.putString("three_d", threeDMetrics);
            result.putString("squad_card", squadCardMetrics);
            result.putStringArrayList("infrastructure_notes", new ArrayList<String>(infrastructureNotes));
            result.putInt("passed_checks", checks.size());
            result.putStringArrayList("checks", new ArrayList<String>(checks));
            result.putString("stream", "\nFAIL at " + stage + ": " + detail + "\n" + diagnostic + "\n");
            finish(Activity.RESULT_CANCELED, result);
        }
    }

    private Activity launch() {
        Intent launch = new Intent(Intent.ACTION_MAIN);
        launch.setClassName("org.genewars.android", "org.genewars.android.MainActivity");
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return startActivitySync(launch);
    }

    /** Loads the existing private slot without creating a game or saving over it. */
    private void verifyLegacyCompatibility(Bundle result) throws Exception {
        stage = "legacy compatibility: existing slot before launch";
        File save = new File(getTargetContext().getFilesDir(), "game-v1.gws");
        require(save.isFile() && save.length() >= 32, "No existing private save supplied for compatibility test");
        long bytes = save.length();
        String before = sha256(save);
        activity = launch();
        stage = "legacy compatibility: continue existing game";
        awaitExact("Продолжить", 60000).recycle();
        require(before.equals(sha256(save)), "Existing save changed before Continue was clicked");
        clickExact("Продолжить");
        awaitHud(30000);
        stage = "legacy compatibility: completed world and selected portrait";
        long worldFrame = awaitCompletedFrame(45, 0, 120000);
        AccessibilityNodeInfo selectedTitle = awaitDescriptionPrefix("Выбран:", 30000);
        String selectedName;
        try { selectedName = selectedTitle.getContentDescription().toString().substring("Выбран:".length()).trim(); }
        finally { selectedTitle.recycle(); }
        AccessibilityNodeInfo portrait = awaitDescriptionPrefix("3D-портрет выбранного:", 30000);
        try { require(portrait.getContentDescription().toString().startsWith("3D-портрет выбранного: " + selectedName + "."),
                "Legacy selected card/portrait names differ"); }
        finally { portrait.recycle(); }
        long portraitDeadline = SystemClock.uptimeMillis() + 60000;
        Pattern portraitComplete = Pattern.compile("Portrait frame: frame=(\\d+), actor=\\d+, type=\\d+, kind=\\d+, viewport=-?\\d+,-?\\d+,\\d+,\\d+, GL_NO_ERROR=true");
        boolean portraitReady = false;
        String compatibilityGl = "";
        while (SystemClock.uptimeMillis() < portraitDeadline) {
            compatibilityGl = rendererLog();
            require(!compatibilityGl.contains("GL_ERROR "), "GLES error while rendering the legacy world");
            Matcher completed = portraitComplete.matcher(compatibilityGl);
            while (completed.find()) if (Long.parseLong(completed.group(1)) >= worldFrame) portraitReady = true;
            if (portraitReady) break;
            SystemClock.sleep(500);
        }
        require(portraitReady, "Legacy world did not complete the selected portrait: " + limit(compatibilityGl, 1500));
        SystemClock.sleep(250);
        File evidence = new File(getTargetContext().getFilesDir(), "smoke-v04");
        require(evidence.isDirectory() || evidence.mkdirs(), "Cannot create legacy render evidence directory");
        Bitmap legacyScene = screenshot();
        try (FileOutputStream output = new FileOutputStream(new File(evidence, "scene-full-compatibility.png"))) {
            require(legacyScene.compress(Bitmap.CompressFormat.PNG, 100, output), "Cannot write legacy world screenshot");
        } finally { legacyScene.recycle(); }
        try (FileOutputStream output = new FileOutputStream(new File(evidence, "compatibility-runtime.log"))) {
            output.write(compatibilityGl.getBytes("UTF-8"));
        }
        result.putLong("world_completed_frame", worldFrame);
        result.putString("compatibility_scene", "smoke-v04/scene-full-compatibility.png");
        stage = "legacy compatibility: pause loaded game";
        pressBack();
        awaitExact("Игра приостановлена", 10000).recycle();
        String loadedHud = hudOnMainThread();
        String after = sha256(save);
        require(before.equals(after), "Compatibility test changed the supplied save before verification");
        pass("legacy_private_save_loaded_by_android_current");
        result.putString("status", "passed");
        result.putInt("passed_checks", checks.size());
        result.putStringArrayList("checks", new ArrayList<String>(checks));
        result.putString("saved_hud", loadedHud);
        result.putString("save_sha256_before", before);
        result.putString("save_sha256_after", after);
        result.putLong("save_bytes", bytes);
        result.putStringArrayList("infrastructure_notes", new ArrayList<String>(infrastructureNotes));
        result.putString("scope", "compatibility_only: existing private save loaded by Continue and paused; no new game or explicit save");
        result.putString("stream", "\nPASS: existing private save loaded and paused; source SHA-256 unchanged\n");
        finish(Activity.RESULT_OK, result);
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        StringBuilder hex = new StringBuilder();
        for (byte value : digest.digest()) hex.append(String.format(Locale.ROOT, "%02x", value & 255));
        return hex.toString();
    }

    private void pass(String check) {
        checks.add(check);
        Bundle progress = new Bundle();
        progress.putString("stream", "PASS " + check + "\n");
        progress.putString("check", check);
        sendStatus(1, progress);
    }

    /** Uses rendered pixels and public Android diagnostics, never private game fields. */
    private void verifyThreeDScene() throws Exception {
        // Software GLES can still be initializing after the native HUD appears.
        // Await actual completed GPU work, rather than extending a blind sleep.
        scrollToolbarTo("Пауза"); clickExact("Пауза");
        awaitExact("Дальше", 10000).recycle();
        long initialFrame = awaitCompletedFrame(45, 0, 120000);
        scrollToolbarTo("Поворот");
        Rect world = worldBounds();
        float density = getTargetContext().getResources().getDisplayMetrics().density;
        Rect center = new Rect(world.left + world.width() / 6,
                Math.max(world.top + world.height() / 5, world.top + Math.round(48 * density)),
                world.right - world.width() / 6, world.bottom - world.height() / 5);
        require(center.width() >= 120 && center.height() >= 60, "3D world crop is too small: " + center);
        SystemClock.sleep(500);
        Bitmap before = screenshot();
        Bitmap after = null;
        try {
            clickExact("Поворот");
            long rotatedFrame = awaitCompletedFrame(90, initialFrame + 1, 60000);
            SystemClock.sleep(250); // Allow SurfaceFlinger to present the completed buffer.
            after = screenshot();
            require(center.right <= before.getWidth() && center.bottom <= before.getHeight()
                    && before.getWidth() == after.getWidth() && before.getHeight() == after.getHeight(),
                    "Screenshot geometry changed during camera proof");
            long delta = 0; int changed = 0, samples = 0, low = 255, high = 0;
            Set<Integer> colors = new HashSet<Integer>();
            int step = Math.max(2, center.width() / 160);
            for (int y = center.top; y < center.bottom; y += step) for (int x = center.left; x < center.right; x += step) {
                int a = before.getPixel(x, y), b = after.getPixel(x, y);
                int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
                int dr = Math.abs(ar - ((b >> 16) & 255)), dg = Math.abs(ag - ((b >> 8) & 255)), db = Math.abs(ab - (b & 255));
                if (Math.max(dr, Math.max(dg, db)) > 24) changed++;
                delta += dr + dg + db; samples++;
                int luma = (ar * 54 + ag * 183 + ab * 19) / 256;
                low = Math.min(low, luma); high = Math.max(high, luma);
                colors.add(((ar >> 4) << 8) | ((ag >> 4) << 4) | (ab >> 4));
            }
            float fraction = changed / (float)samples, meanDelta = delta / (float)(samples * 3);
            threeDMetrics = String.format(Locale.ROOT,
                    "completed_frames=%d/%d; central_crop=%s; sampled=%d; quantized_colors=%d; luma_span=%d; changed_fraction=%.4f; mean_rgb_delta=%.3f",
                    initialFrame, rotatedFrame, center, samples, colors.size(), high - low, fraction, meanDelta);
            File directory = new File(getTargetContext().getFilesDir(), "smoke-v04");
            require(directory.isDirectory() || directory.mkdirs(), "Cannot create 3D evidence directory");
            saveCrop(before, center, new File(directory, "scene-before-rotation.png"));
            saveCrop(after, center, new File(directory, "scene-after-rotation.png"));
            require(colors.size() >= 24 && high - low >= 32, "Central GL scene is flat or empty: " + threeDMetrics);
            require(fraction > .04f && meanDelta > 2.5f, "Camera button did not visibly change the central scene: " + threeDMetrics);
            String log = rendererLog();
            Matcher actors = Pattern.compile("mesh actors=(\\d+)").matcher(log);
            boolean populated = false; while (actors.find()) if (Integer.parseInt(actors.group(1)) > 0) populated = true;
            require(Pattern.compile("GL_VERSION=OpenGL ES(?:-CM)? 3\\.").matcher(log).find(), "No GLES3 runtime context: " + limit(log, 1200));
            require(log.contains("GLES3 shader programs linked; initialization GL error count=0"), "No successful GLES3 shader initialization: " + limit(log, 1200));
            require(populated && log.contains("Rendered genuine 3D scene:") && log.contains("GL_NO_ERROR=true"), "No successful populated GL frame: " + limit(log, 1500));
            require(!log.contains("GL_ERROR "), "GLES runtime reported an error: " + limit(log, 1500));
            try (FileOutputStream output = new FileOutputStream(new File(directory, "gles3-runtime.log"))) {
                output.write(log.getBytes("UTF-8"));
            }
            threeDMetrics += "; GLES3_linked=true; populated_mesh_frame=true; GL_NO_ERROR=true; private_artifacts=smoke-v04/";
        } finally {
            before.recycle(); if (after != null) after.recycle();
        }
        // Return to the initial yaw before preserving the existing command test.
        for (int i = 0; i < 7; i++) clickExact("Поворот");
        awaitCompletedFrame(45, initialFrame + 2, 60000);
        scrollToolbarTo("Дальше"); clickExact("Дальше");
        scrollToolbarTo("Строить");
    }

    /** Public native UI and completed GL pixels prove the selected member changed. */
    private void verifySquadCard() throws Exception {
        int before = goop(hudOnMainThread());
        inspectCard("Инженер", "Строить");
        PortraitFrame engineer = awaitPortrait(0, 0, 60000);
        int[] engineerPixels = capturePortrait("Инженер", engineer, "portrait-engineer.png");
        tapDescriptionExact("3D-портрет выбранного: Инженер. Следующий член отряда");
        inspectCard("Ботаник", "Собирать");
        PortraitFrame botanist = awaitPortrait(1, engineer.frame + 1, 60000);
        require(botanist.actor != engineer.actor, "Portrait kept the previous selected actor");
        int[] botanistPixels = capturePortrait("Ботаник", botanist, "portrait-botanist.png");
        require(engineerPixels.length == botanistPixels.length, "Portrait dimensions changed across squad selection");
        long delta = 0;
        for (int i = 0; i < engineerPixels.length; i++) {
            int a = engineerPixels[i], b = botanistPixels[i];
            delta += Math.abs(((a >> 16) & 255) - ((b >> 16) & 255))
                    + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) + Math.abs((a & 255) - (b & 255));
        }
        float meanDelta = delta / (float)(engineerPixels.length * 3);
        require(meanDelta > 1.5f, "Engineer/Botanist portrait pixels did not change: " + meanDelta);
        boolean engineerSelected = false;
        for (int attempt = 0; attempt < 64; attempt++) {
            AccessibilityNodeInfo portrait = awaitDescriptionPrefix("3D-портрет выбранного:", 10000);
            try {
                if (portrait.getContentDescription().toString().startsWith("3D-портрет выбранного: Инженер.")) {
                    engineerSelected = true; break;
                }
                Rect bounds = new Rect(); portrait.getBoundsInScreen(bounds);
                injectTap(bounds.exactCenterX(), bounds.exactCenterY());
            } finally { portrait.recycle(); }
            SystemClock.sleep(250);
        }
        require(engineerSelected, "Squad portrait selector did not cycle back to the engineer");
        inspectCard("Инженер", "Строить");
        PortraitFrame restored = awaitPortrait(0, botanist.frame + 1, 60000);
        require(restored.actor == engineer.actor, "Squad cycle restored a different engineer");
        require(goop(hudOnMainThread()) == before, "Portrait selection unexpectedly changed resources");
        try (FileOutputStream output = new FileOutputStream(new File(getTargetContext().getFilesDir(), "smoke-v04/portrait-runtime.log"))) {
            output.write(rendererLog().getBytes("UTF-8"));
        }
        squadCardMetrics = "Engineer->Botanist->Engineer; title/task/HP=true; roles=Строить/Собирать; portrait_actors="
                + engineer.actor + "/" + botanist.actor + "; completed_frames=" + engineer.frame + "/" + botanist.frame
                + "; mean_rgb_delta=" + String.format(Locale.ROOT, "%.3f", meanDelta) + "; private_artifacts=smoke-v04/";
    }

    private void inspectCard(String role, String action) {
        awaitDescriptionExact("Выбран: " + role, 30000).recycle();
        AccessibilityNodeInfo health = awaitDescriptionPrefix("Здоровье выбранного:", 10000);
        try {
            Matcher hp = Pattern.compile("Здоровье выбранного:\\s*(\\d+)\\s+из\\s+(\\d+)").matcher(health.getContentDescription());
            require(hp.matches() && Integer.parseInt(hp.group(2)) > 0 && Integer.parseInt(hp.group(1)) > 0
                    && Integer.parseInt(hp.group(1)) <= Integer.parseInt(hp.group(2)), "Invalid selected health label");
        } finally { health.recycle(); }
        AccessibilityNodeInfo task = awaitPrefix("Задача:", 10000);
        try { require(task.getText().toString().trim().length() > "Задача:".length(), "Selected task is empty"); }
        finally { task.recycle(); }
        AccessibilityNodeInfo command = awaitDescriptionExact("Приказ выбранному: " + action, 10000);
        try { require(command.isEnabled() && command.isClickable(), "Selected role action is unavailable: " + action); }
        finally { command.recycle(); }
        AccessibilityNodeInfo card = awaitDescriptionExact("Карточка выбранного члена отряда", 10000);
        try {
            Rect bounds = new Rect(); card.getBoundsInScreen(bounds); Rect world = worldBounds();
            require(bounds.left <= world.left + world.width() / 10 && bounds.bottom >= world.bottom - world.height() / 10
                    && bounds.width() < world.width() / 2, "Selection card is not in the corner: " + bounds);
        } finally { card.recycle(); }
    }

    private PortraitFrame awaitPortrait(int kind, long minimumFrame, long timeout) throws Exception {
        long deadline = SystemClock.uptimeMillis() + timeout;
        Pattern pattern = Pattern.compile("Portrait frame: frame=(\\d+), actor=(\\d+), type=1, kind=(\\d+), viewport=(-?\\d+),(-?\\d+),(\\d+),(\\d+), GL_NO_ERROR=true");
        String last = "";
        while (SystemClock.uptimeMillis() < deadline) {
            last = rendererLog(); Matcher match = pattern.matcher(last); PortraitFrame found = null;
            while (match.find()) if (Integer.parseInt(match.group(3)) == kind && Long.parseLong(match.group(1)) >= minimumFrame)
                found = new PortraitFrame(Long.parseLong(match.group(1)), Integer.parseInt(match.group(2)),
                        Integer.parseInt(match.group(4)), Integer.parseInt(match.group(5)), Integer.parseInt(match.group(6)), Integer.parseInt(match.group(7)));
            require(!last.contains("GL_ERROR "), "GLES runtime error during selected portrait: " + limit(last, 1500));
            if (found != null) return found;
            SystemClock.sleep(500);
        }
        throw new AssertionError("No completed selected portrait kind=" + kind + " frame>=" + minimumFrame + ": " + limit(last, 1500));
    }

    private int[] capturePortrait(String role, PortraitFrame frame, String filename) throws Exception {
        AccessibilityNodeInfo node = awaitDescriptionExact("3D-портрет выбранного: " + role + ". Следующий член отряда", 10000);
        Rect bounds = new Rect(); try { node.getBoundsInScreen(bounds); } finally { node.recycle(); }
        Rect world = worldBounds();
        require(Math.abs(bounds.left - world.left - frame.left) <= 3 && Math.abs(bounds.top - world.top - frame.top) <= 3
                && Math.abs(bounds.width() - frame.width) <= 3 && Math.abs(bounds.height() - frame.height) <= 3,
                "Portrait GL viewport is not aligned with the visible card: " + bounds);
        SystemClock.sleep(250);
        Bitmap screen = screenshot();
        try {
            Rect crop = new Rect(bounds.left + bounds.width() / 10, bounds.top + bounds.height() / 20,
                    bounds.right - bounds.width() / 10, bounds.bottom - bounds.height() / 6);
            require(crop.width() >= 24 && crop.height() >= 36 && crop.left >= 0 && crop.top >= 0
                    && crop.right <= screen.getWidth() && crop.bottom <= screen.getHeight(), "Invalid portrait evidence crop");
            int[] pixels = new int[crop.width() * crop.height()];
            screen.getPixels(pixels, 0, crop.width(), crop.left, crop.top, crop.width(), crop.height());
            Set<Integer> colors = new HashSet<Integer>(); int low = 255, high = 0, foreground = 0;
            for (int pixel : pixels) {
                int r = (pixel >> 16) & 255, g = (pixel >> 8) & 255, b = pixel & 255;
                colors.add(((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4));
                int luma = (r * 54 + g * 183 + b * 19) / 256; low = Math.min(low, luma); high = Math.max(high, luma);
                if (Math.max(Math.abs(r - 7), Math.max(Math.abs(g - 11), Math.abs(b - 15))) > 12) foreground++;
            }
            require(colors.size() >= 12 && high - low >= 35 && foreground > pixels.length * .08f,
                    "Selected GL portrait is empty/flat: " + role + " colors=" + colors.size() + ", luma=" + (high-low));
            File directory = new File(getTargetContext().getFilesDir(), "smoke-v04");
            require(directory.isDirectory() || directory.mkdirs(), "Cannot create portrait evidence directory");
            try (FileOutputStream output = new FileOutputStream(new File(directory, filename.replace("portrait-", "scene-full-")))) {
                require(screen.compress(Bitmap.CompressFormat.PNG, 100, output), "Cannot write full scene screenshot evidence");
            }
            saveCrop(screen, crop, new File(directory, filename));
            AccessibilityNodeInfo card = awaitDescriptionExact("Карточка выбранного члена отряда", 10000);
            Rect cardBounds = new Rect(); try { card.getBoundsInScreen(cardBounds); } finally { card.recycle(); }
            require(cardBounds.left >= 0 && cardBounds.top >= 0 && cardBounds.right <= screen.getWidth()
                    && cardBounds.bottom <= screen.getHeight(), "Corner card lies outside screenshot");
            saveCrop(screen, cardBounds, new File(directory, filename.replace("portrait-", "card-")));
            return pixels;
        } finally { screen.recycle(); }
    }

    private static final class PortraitFrame {
        final long frame; final int actor, left, top, width, height;
        PortraitFrame(long frame, int actor, int left, int top, int width, int height) {
            this.frame=frame; this.actor=actor; this.left=left; this.top=top; this.width=width; this.height=height;
        }
    }

    private AccessibilityNodeInfo awaitDescriptionExact(final String value, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && value.contentEquals(node.getContentDescription() == null ? "" : node.getContentDescription());
        } }, timeout);
    }
    private AccessibilityNodeInfo awaitDescriptionPrefix(final String value, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && node.getContentDescription() != null && node.getContentDescription().toString().startsWith(value);
        } }, timeout);
    }
    private void tapDescriptionExact(String value) {
        AccessibilityNodeInfo node = awaitDescriptionExact(value, 10000);
        try {
            require(node.isEnabled() && node.isClickable(), "Native card control is not actionable: " + value);
            Rect bounds = new Rect(); node.getBoundsInScreen(bounds); require(!bounds.isEmpty(), "Card control has no touch bounds");
            injectTap(bounds.exactCenterX(), bounds.exactCenterY());
        } finally { node.recycle(); }
        SystemClock.sleep(150);
    }

    private Bitmap screenshot() {
        Bitmap screen = automation.takeScreenshot();
        require(screen != null, "Android did not return a screenshot of the GL scene");
        if (screen.getConfig() == Bitmap.Config.HARDWARE) {
            Bitmap readable = screen.copy(Bitmap.Config.ARGB_8888, false); screen.recycle();
            require(readable != null, "Cannot read screenshot pixels"); return readable;
        }
        return screen;
    }

    private void saveCrop(Bitmap screenshot, Rect crop, File file) throws Exception {
        Bitmap center = Bitmap.createBitmap(screenshot, crop.left, crop.top, crop.width(), crop.height());
        try (FileOutputStream output = new FileOutputStream(file)) {
            require(center.compress(Bitmap.CompressFormat.PNG, 100, output), "Cannot write 3D screenshot evidence");
        } finally { center.recycle(); }
    }

    private String rendererLog() throws Exception {
        String command = "logcat -d --pid=" + android.os.Process.myPid() + " -v brief -s GeneWars3D:I";
        try (ParcelFileDescriptor descriptor = automation.executeShellCommand(command);
                ParcelFileDescriptor.AutoCloseInputStream input = new ParcelFileDescriptor.AutoCloseInputStream(descriptor)) {
            ByteArrayOutputStream text = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int count;
            while ((count = input.read(buffer)) != -1 && text.size() < 1024 * 1024) text.write(buffer, 0, count);
            return text.toString("UTF-8");
        }
    }

    private long awaitCompletedFrame(float yaw, long minimumFrame, long timeout) throws Exception {
        long deadline = SystemClock.uptimeMillis() + timeout;
        Pattern completed = Pattern.compile("Frame complete: frame=(\\d+), yaw=([\\d.\\-]+),[^\\n]*GL_NO_ERROR=true");
        String last = "No renderer log sampled";
        while (SystemClock.uptimeMillis() < deadline) {
            last = rendererLog(); Matcher matcher = completed.matcher(last);
            while (matcher.find()) {
                long number = Long.parseLong(matcher.group(1));
                float renderedYaw = Float.parseFloat(matcher.group(2));
                if (number >= minimumFrame && Math.abs(renderedYaw - yaw) < .01f) return number;
            }
            require(!last.contains("GL_ERROR "), "GLES runtime reported an error: " + limit(last, 1500));
            SystemClock.sleep(1000);
        }
        throw new AssertionError("No completed GLES3 frame at yaw=" + yaw + " with frame>=" + minimumFrame
                + " within " + timeout + " ms: " + limit(last, 1800));
    }

    private boolean exactIsVisible(final String text) {
        AccessibilityNodeInfo root = automation.getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo found = null;
        try {
            found = find(root, new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
                return node.isVisibleToUser() && text.contentEquals(node.getText() == null ? "" : node.getText());
            } });
            return found != null;
        } finally { if (found != null) found.recycle(); root.recycle(); }
    }

    private void scrollToolbarTo(String text) {
        for (int direction : new int[]{AccessibilityNodeInfo.ACTION_SCROLL_FORWARD, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD}) {
            for (int attempt = 0; attempt < 8; attempt++) {
                if (exactIsVisible(text)) return;
                AccessibilityNodeInfo scroller = await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
                    return node.isVisibleToUser() && "android.widget.HorizontalScrollView".contentEquals(node.getClassName() == null ? "" : node.getClassName());
                } }, 10000);
                boolean moved;
                try { moved = scroller.performAction(direction); } finally { scroller.recycle(); }
                SystemClock.sleep(200); if (!moved) break;
            }
        }
        require(exactIsVisible(text), "Toolbar command did not become visible: " + text);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private interface Match { boolean accepts(AccessibilityNodeInfo node); }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, Match match) {
        if (node == null) return null;
        if (match.accepts(node)) return AccessibilityNodeInfo.obtain(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo found;
            try { found = find(child, match); } finally { child.recycle(); }
            if (found != null) return found;
        }
        return null;
    }

    private AccessibilityNodeInfo await(Match match, long timeout) {
        long deadline = SystemClock.uptimeMillis() + timeout;
        while (SystemClock.uptimeMillis() < deadline) {
            AccessibilityNodeInfo root = automation.getRootInActiveWindow();
            if (root != null) {
                AccessibilityNodeInfo found = null;
                try {
                    lastAccessibilitySnapshot = "root=" + root.getPackageName() + '/' + root.getClassName();
                    if (!dismissKnownInfrastructureAnr(root)) found = find(root, match);
                } finally { root.recycle(); }
                if (found != null) return found;
            } else lastAccessibilitySnapshot = "root=null";
            SystemClock.sleep(100);
        }
        throw new AssertionError("UI condition timed out after " + timeout + " ms");
    }

    /** Only these two Android system processes may be closed by the test harness. */
    private boolean dismissKnownInfrastructureAnr(AccessibilityNodeInfo root) {
        if (!"android".contentEquals(root.getPackageName() == null ? "" : root.getPackageName())) return false;
        AccessibilityNodeInfo title = find(root, new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && "android".contentEquals(node.getPackageName() == null ? "" : node.getPackageName())
                    && "android:id/alertTitle".equals(node.getViewIdResourceName()) && node.getText() != null;
        } });
        if (title == null) return false;
        String label;
        try { label = title.getText().toString(); } finally { title.recycle(); }
        boolean known = label.equals("System UI isn't responding") || label.equals("System UI isn’t responding")
                || label.equals("Quickstep isn't responding") || label.equals("Quickstep isn’t responding");
        if (!known) {
            require(!label.contains("isn't responding") && !label.contains("isn’t responding"),
                    "Application or unknown ANR remains visible: " + label);
            return false;
        }
        AccessibilityNodeInfo close = find(root, new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && node.isEnabled() && node.isClickable()
                    && "android".contentEquals(node.getPackageName() == null ? "" : node.getPackageName())
                    && "android:id/aerr_close".equals(node.getViewIdResourceName())
                    && "Close app".contentEquals(node.getText() == null ? "" : node.getText());
        } });
        if (close == null) return false;
        try { click(close); } finally { close.recycle(); }
        String note = "Closed known foreign Android ANR at " + stage + ": " + label;
        infrastructureNotes.add(note);
        android.util.Log.w("GeneWarsSmoke", note);
        Bundle progress = new Bundle(); progress.putString("infrastructure_note", note);
        progress.putString("stream", "INFRASTRUCTURE: " + note + "\n"); sendStatus(2, progress);
        return true;
    }

    private AccessibilityNodeInfo awaitExact(final String text, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && text.contentEquals(node.getText() == null ? "" : node.getText());
        } }, timeout);
    }

    private AccessibilityNodeInfo awaitPrefix(final String text, long timeout) {
        return await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && node.getText() != null && node.getText().toString().startsWith(text);
        } }, timeout);
    }

    private void awaitHud(long timeout) { AccessibilityNodeInfo node = awaitPrefix("Биогель:", timeout); node.recycle(); }

    private void clickExact(String text) {
        AccessibilityNodeInfo node = awaitExact(text, 10000);
        try { click(node); } finally { node.recycle(); }
        SystemClock.sleep(150);
    }

    private void clickFirstListItem() {
        AccessibilityNodeInfo list = await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            return node.isVisibleToUser() && "android.widget.ListView".contentEquals(node.getClassName() == null ? "" : node.getClassName()) && node.getChildCount() > 0;
        } }, 10000);
        try {
            AccessibilityNodeInfo first = list.getChild(0);
            require(first != null, "Dialog list has no first item");
            try { click(first); } finally { first.recycle(); }
        } finally { list.recycle(); }
        SystemClock.sleep(200);
    }

    private void click(AccessibilityNodeInfo node) {
        require(node.isEnabled(), "Control is disabled: " + node.getText());
        if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
            require(!bounds.isEmpty(), "Control has empty bounds");
            injectTap(bounds.exactCenterX(), bounds.exactCenterY());
        }
    }

    private void injectTap(float x, float y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
        MotionEvent up = MotionEvent.obtain(now, now + 100, MotionEvent.ACTION_UP, x, y, 0);
        down.setSource(InputDevice.SOURCE_TOUCHSCREEN); up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        try {
            require(automation.injectInputEvent(down, true), "Touch down injection failed");
            require(automation.injectInputEvent(up, true), "Touch up injection failed");
        } finally { down.recycle(); up.recycle(); }
    }

    private void pressBack() {
        sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
        SystemClock.sleep(150);
    }

    private Rect worldBounds() {
        AccessibilityNodeInfo node = await(new Match() { @Override public boolean accepts(AccessibilityNodeInfo node) {
            CharSequence description = node.getContentDescription();
            return node.isVisibleToUser() && description != null && description.toString().startsWith("Карта планеты.");
        } }, 10000);
        try { Rect bounds = new Rect(); node.getBoundsInScreen(bounds); return bounds; }
        finally { node.recycle(); }
    }

    private String hudOnMainThread() {
        final String[] value = {null};
        runOnMainSync(new Runnable() { @Override public void run() { value[0] = hudText(activity.getWindow().getDecorView()); } });
        require(value[0] != null, "Native HUD view disappeared");
        return value[0];
    }

    private String hudText(View view) {
        if (view instanceof TextView) {
            String value = ((TextView) view).getText().toString();
            if (value.startsWith("Биогель:")) return value;
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                String found = hudText(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private int goop(String hud) {
        Matcher matcher = Pattern.compile("Биогель:\\s*(\\d+)").matcher(hud);
        require(matcher.find(), "Cannot parse GOOP counter: " + hud);
        return Integer.parseInt(matcher.group(1));
    }

    private void describeAccessibility(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || out.length() >= 1800 || depth > 12) return;
        CharSequence value = node.getText();
        if (depth == 0 || value != null && value.length() > 0) {
            if (out.length() > 0) out.append("; ");
            out.append(node.getPackageName()).append('/').append(node.getClassName());
            out.append(" visible=").append(node.isVisibleToUser());
            if (value != null) out.append(" text=").append(limit(value.toString(), 100));
        }
        for (int i = 0; i < node.getChildCount() && out.length() < 1800; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            try { describeAccessibility(child, out, depth + 1); } finally { child.recycle(); }
        }
    }

    private String accessibilitySnapshot() {
        try {
            AccessibilityNodeInfo root = automation == null ? null : automation.getRootInActiveWindow();
            if (root == null) return "root=null; last=" + lastAccessibilitySnapshot;
            try {
                StringBuilder out = new StringBuilder();
                describeAccessibility(root, out, 0);
                return out.toString();
            } finally { root.recycle(); }
        } catch (Throwable diagnosticError) {
            return "snapshot failed: " + diagnosticError.getClass().getSimpleName()
                    + "; last=" + lastAccessibilitySnapshot;
        }
    }

    private String activitySnapshot() {
        final Activity current = activity;
        if (current == null) return "Activity=null";
        final String[] value = {"main thread did not answer within 1500 ms"};
        final CountDownLatch completed = new CountDownLatch(1);
        current.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    View decor = current.getWindow().getDecorView();
                    StringBuilder text = new StringBuilder();
                    describeViews(decor, text, 0);
                    value[0] = "finishing=" + current.isFinishing() + ", destroyed=" + current.isDestroyed()
                            + ", windowFocus=" + current.hasWindowFocus() + ", shown=" + decor.isShown()
                            + ", attached=" + decor.isAttachedToWindow() + ", views=" + text;
                } catch (Throwable diagnosticError) {
                    value[0] = "snapshot failed: " + diagnosticError.getClass().getSimpleName();
                } finally { completed.countDown(); }
            }
        });
        try { completed.await(1500, TimeUnit.MILLISECONDS); }
        catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
        return limit(value[0], 2000);
    }

    private void describeViews(View view, StringBuilder out, int depth) {
        if (view == null || out.length() >= 1500 || depth > 12) return;
        if (view instanceof TextView) {
            String value = ((TextView) view).getText().toString();
            if (!value.isEmpty()) {
                if (out.length() > 0) out.append("; ");
                out.append(view.getClass().getSimpleName()).append(" shown=").append(view.isShown())
                        .append(" text=").append(limit(value, 100));
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount() && out.length() < 1500; i++)
                describeViews(group.getChildAt(i), out, depth + 1);
        }
    }

    private static String limit(String text, int max) {
        return text.length() > max ? text.substring(0, max) : text;
    }
}
