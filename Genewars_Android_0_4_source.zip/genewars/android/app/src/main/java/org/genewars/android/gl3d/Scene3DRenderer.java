package org.genewars.android.gl3d;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Genuine GLES3 mesh renderer. All GLES calls remain on the GLSurfaceView thread. */
public final class Scene3DRenderer implements GLSurfaceView.Renderer {
    private static final String TAG="GeneWars3D";
    private static final int STRIDE=13,MAX_BONES=24,SHADOW_SIZE=1024;
    private static final float[] LIGHT={-.436f,.873f,.218f};
    private final AssetManager assets;
    private final Camera3D camera;
    private final AtomicReference<Scene3DFrame> submitted=new AtomicReference<Scene3DFrame>();
    private final AtomicReference<PortraitViewport> portrait=new AtomicReference<PortraitViewport>();
    private volatile boolean closed,ready,highQuality=true;
    private final Map<String,GpuMesh> meshes=new HashMap<String,GpuMesh>();
    private final Map<Integer,Motion> motion=new HashMap<Integer,Motion>();
    private Scene3DFrame previousFrame;
    private Scene3DFrame.Terrain loadedTerrain;
    private GpuMesh ground,disk;
    private int mainProgram,depthProgram,flatProgram,materialTexture,terrainTypesTexture,shadowTexture,shadowFbo;
    private final float[] materialParameters={.17f,0,.06f,1, .42f,0,.035f,1, .87f,0,.065f,1, .86f,0,.09f,1, .78f,0,.1f,1, .61f,.04f,.08f,1, .65f,0,.035f,1, .88f,0,.07f,1, .34f,.55f,.04f,1};
    private PortraitViewport lastPortraitViewport;
    private int lastPortraitActor=-1;
    private boolean shadowReady,loggedFirstFrame;
    private long frameNumber;
    private float completedYaw=Float.NaN;
    private float[] lightViewProjection=Matrix3D.identity();
    private final float[] model=new float[16],normal=new float[9],bones=new float[MAX_BONES*16];
    private Uniforms uniforms,depthUniforms;
    private int flatMvp,flatColor;

    public Scene3DRenderer(AssetManager assets,Camera3D camera){this.assets=assets;this.camera=camera;}
    public void submitFrame(Scene3DFrame frame){if(!closed)submitted.set(frame);}
    public void setHighQuality(boolean enabled){highQuality=enabled;}
    /** Surface-local top-left pixel rectangle; a nonpositive size disables the portrait. */
    public void setPortraitViewport(int left,int top,int width,int height){
        PortraitViewport old=portrait.get();
        if(width<=0||height<=0){portrait.set(null);return;}
        if(old==null||old.left!=left||old.top!=top||old.width!=width||old.height!=height)portrait.set(new PortraitViewport(left,top,width,height));
    }
    public boolean isReady(){return ready&&!closed;}
    /** No GL calls here: context-owned resources disappear when the View detaches. */
    public void close(){closed=true;ready=false;submitted.set(null);portrait.set(null);}

    @Override public void onSurfaceCreated(GL10 unused,EGLConfig config){
        if(closed)return;
        ready=false;
        meshes.clear();motion.clear();loadedTerrain=null;ground=null;disk=null;previousFrame=null;loggedFirstFrame=false;frameNumber=0;completedYaw=Float.NaN;terrainTypesTexture=0;lastPortraitViewport=null;lastPortraitActor=-1;
        int[] limit=new int[1];GLES30.glGetIntegerv(GLES30.GL_MAX_VERTEX_UNIFORM_VECTORS,limit,0);
        Log.i(TAG,"GL_VERSION="+GLES30.glGetString(GLES30.GL_VERSION)+"; max vertex uniform vectors="+limit[0]);
        if(limit[0]<128)throw new IllegalStateException("Insufficient vertex uniforms for 24-bone models");
        mainProgram=program(VERTEX_SHADER,FRAGMENT_SHADER);uniforms=new Uniforms(mainProgram,false);
        depthProgram=program(DEPTH_VERTEX,DEPTH_FRAGMENT);depthUniforms=new Uniforms(depthProgram,true);
        flatProgram=program(FLAT_VERTEX,FLAT_FRAGMENT);flatMvp=GLES30.glGetUniformLocation(flatProgram,"uMVP");flatColor=GLES30.glGetUniformLocation(flatProgram,"uColor");
        materialTexture=loadMaterialAtlas();createShadowMap();disk=createDisk();
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);GLES30.glDepthFunc(GLES30.GL_LEQUAL);
        GLES30.glEnable(GLES30.GL_CULL_FACE);GLES30.glCullFace(GLES30.GL_BACK);
        GLES30.glClearColor(.085f,.14f,.19f,1);
        Log.i(TAG,"GLES3 shader programs linked; initialization GL error count="+checkError("surface initialization"));
    }
    @Override public void onSurfaceChanged(GL10 unused,int width,int height){camera.setViewport(width,height);GLES30.glViewport(0,0,Math.max(1,width),Math.max(1,height));}

    @Override public void onDrawFrame(GL10 unused){
        if(closed)return;
        long drawStarted=System.nanoTime();
        Scene3DFrame frame=submitted.get();Camera3D.Snapshot view=camera.snapshot();
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);GLES30.glViewport(0,0,view.width,view.height);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
        if(frame==null)return;
        if(loadedTerrain!=frame.terrain){if(ground!=null)ground.delete();ground=buildTerrain(frame.terrain);loadedTerrain=frame.terrain;motion.clear();previousFrame=null;}
        updateMotion(frame);
        boolean detailed=highQuality&&frame.highQuality;
        lightViewProjection=Matrix3D.multiply(Matrix3D.ortho(-34,34,-34,34,1,125),
                Matrix3D.lookAt(view.targetX+LIGHT[0]*65,view.targetY+LIGHT[1]*65,view.targetZ+LIGHT[2]*65,
                        view.targetX,view.targetY,view.targetZ));
        if(detailed&&shadowReady)renderShadowMap(frame,view);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);GLES30.glViewport(0,0,view.width,view.height);
        GLES30.glUseProgram(mainProgram);
        GLES30.glUniformMatrix4fv(uniforms.vp,1,false,view.viewProjection,0);
        GLES30.glUniformMatrix4fv(uniforms.lightVp,1,false,lightViewProjection,0);
        GLES30.glUniform3f(uniforms.eye,view.eyeX,view.eyeY,view.eyeZ);
        GLES30.glUniform3f(uniforms.light,LIGHT[0],LIGHT[1],LIGHT[2]);
        GLES30.glUniform1f(uniforms.time,frame.seconds);
        GLES30.glUniform1i(uniforms.portrait,0);GLES30.glUniform4fv(uniforms.materialParameters,9,materialParameters,0);
        GLES30.glUniform1i(uniforms.highQuality,detailed?1:0);GLES30.glUniform1i(uniforms.shadowEnabled,detailed&&shadowReady?1:0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,materialTexture);GLES30.glUniform1i(uniforms.materials,0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,shadowTexture);GLES30.glUniform1i(uniforms.shadowMap,1);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,terrainTypesTexture);GLES30.glUniform1i(uniforms.terrainTypes,2);
        Matrix3D.identity(model);normalIdentity();GLES30.glUniformMatrix4fv(uniforms.model,1,false,model,0);GLES30.glUniformMatrix3fv(uniforms.normal,1,false,normal,0);
        GLES30.glUniform1i(uniforms.skinned,0);GLES30.glUniform1i(uniforms.terrain,1);GLES30.glUniform3f(uniforms.tint,1,1,1);ground.draw();
        renderGroundMarkers(frame,view);
        GLES30.glUseProgram(mainProgram);GLES30.glUniform1i(uniforms.terrain,0);GLES30.glUniform1i(uniforms.skinned,1);
        int drawnActors=0;
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;
            MeshData3D data=modelFor(actor);GpuMesh mesh=gpuModel(actor,data);Motion moving=motion.get(actor.id);
            applyModel(actor,frame.terrain,data,moving);
            data.pose(frame.seconds,moving!=null&&moving.speed>.05f?1:actor.action,moving==null?0:moving.speed,bones);
            GLES30.glUniformMatrix4fv(uniforms.model,1,false,model,0);GLES30.glUniformMatrix3fv(uniforms.normal,1,false,normal,0);
            GLES30.glUniformMatrix4fv(uniforms.bones,MAX_BONES,false,bones,0);
            teamTint(uniforms.tint,actor.team);mesh.draw();drawnActors++;
        }
        PortraitViewport portraitViewport=portrait.get();
        Scene3DFrame.Actor portraitActor=renderPortrait(frame,view,portraitViewport);
        boolean reportPortrait=portraitActor!=null&&(portraitActor.id!=lastPortraitActor||portraitViewport!=lastPortraitViewport);
        // A bounded diagnostic fence makes the logged camera safe to capture in device tests.
        // Ordinary animation frames keep their asynchronous GPU pipeline.
        boolean reportCompletion=!loggedFirstFrame||Float.compare(completedYaw,view.yaw)!=0;
        if(reportCompletion||reportPortrait)GLES30.glFinish();
        int errors=checkError("frame");
        if(errors==0&&drawnActors>0&&!closed)ready=true;
        if(!loggedFirstFrame){loggedFirstFrame=true;Log.i(TAG,"Rendered genuine 3D scene: terrain="+frame.terrain.width+"x"+frame.terrain.height+", mesh actors="+frame.actors.size()+", shadowMap="+(detailed&&shadowReady)+", GL_NO_ERROR="+(errors==0));}
        frameNumber++;
        if(reportCompletion){
            completedYaw=view.yaw;
            Log.i(TAG,"Frame complete: frame="+frameNumber+", yaw="+view.yaw+", pitch="+view.pitch+", meshActors="+frame.actors.size()+", renderMs="+((System.nanoTime()-drawStarted)/1000000L)+", GL_NO_ERROR="+(errors==0));
        }
        if(reportPortrait){
            lastPortraitActor=portraitActor.id;lastPortraitViewport=portraitViewport;
            Log.i(TAG,"Portrait frame: frame="+frameNumber+", actor="+portraitActor.id+", type="+portraitActor.type+", kind="+portraitActor.kind+", viewport="+portraitViewport.left+","+portraitViewport.top+","+portraitViewport.width+","+portraitViewport.height+", GL_NO_ERROR="+(errors==0));
        }else if(portraitActor==null){lastPortraitActor=-1;lastPortraitViewport=null;}
    }

    private Scene3DFrame.Actor renderPortrait(Scene3DFrame frame,Camera3D.Snapshot view,PortraitViewport viewport){
        if(viewport==null)return null;
        Scene3DFrame.Actor selected=null;for(Scene3DFrame.Actor actor:frame.actors)if(actor.id==frame.selectedId){selected=actor;break;}
        if(selected==null)return null;
        int left=Math.max(0,viewport.left),top=Math.max(0,viewport.top),width=Math.min(view.width-left,viewport.width),height=Math.min(view.height-top,viewport.height);
        if(width<8||height<8)return null;
        MeshData3D data=modelFor(selected);float aspect=width/(float)height;
        float targetY=data.height*.52f,distance=Math.max(data.height*1.9f,data.radius*3.4f/Math.max(.3f,aspect));
        float eyeY=targetY+distance*.08f;
        float[] vp=Matrix3D.multiply(Matrix3D.perspective(32,aspect,.05f,50),Matrix3D.lookAt(0,eyeY,distance,0,targetY,0));
        GLES30.glEnable(GLES30.GL_SCISSOR_TEST);GLES30.glScissor(left,view.height-top-height,width,height);GLES30.glViewport(left,view.height-top-height,width,height);
        GLES30.glClearColor(.028f,.045f,.06f,1);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glUseProgram(mainProgram);GLES30.glUniformMatrix4fv(uniforms.vp,1,false,vp,0);
        GLES30.glUniform3f(uniforms.eye,0,eyeY,distance);GLES30.glUniform3f(uniforms.light,-.42f,.75f,.51f);
        GLES30.glUniform1i(uniforms.portrait,1);GLES30.glUniform1i(uniforms.terrain,0);GLES30.glUniform1i(uniforms.skinned,1);GLES30.glUniform1i(uniforms.shadowEnabled,0);
        Matrix3D.model(model,0,0,0,-.30f,1,1,1);float c=(float)Math.cos(-.30f),s=(float)Math.sin(-.30f);
        normal[0]=c;normal[1]=0;normal[2]=-s;normal[3]=0;normal[4]=1;normal[5]=0;normal[6]=s;normal[7]=0;normal[8]=c;
        Motion selectedMotion=motion.get(selected.id);float selectedSpeed=selectedMotion==null?0:selectedMotion.speed;
        data.pose(frame.seconds,selectedSpeed>.05f?1:selected.action,selectedSpeed,bones);GLES30.glUniformMatrix4fv(uniforms.model,1,false,model,0);GLES30.glUniformMatrix3fv(uniforms.normal,1,false,normal,0);GLES30.glUniformMatrix4fv(uniforms.bones,MAX_BONES,false,bones,0);
        teamTint(uniforms.tint,selected.team);gpuModel(selected,data).draw();
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST);GLES30.glViewport(0,0,view.width,view.height);GLES30.glClearColor(.085f,.14f,.19f,1);
        return selected;
    }

    private void renderShadowMap(Scene3DFrame frame,Camera3D.Snapshot view){
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,shadowFbo);GLES30.glViewport(0,0,SHADOW_SIZE,SHADOW_SIZE);
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);GLES30.glUseProgram(depthProgram);
        GLES30.glUniformMatrix4fv(depthUniforms.vp,1,false,lightViewProjection,0);
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL);GLES30.glPolygonOffset(1.5f,3);
        Matrix3D.identity(model);GLES30.glUniformMatrix4fv(depthUniforms.model,1,false,model,0);GLES30.glUniform1i(depthUniforms.skinned,0);ground.draw();
        GLES30.glUniform1i(depthUniforms.skinned,1);
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;
            MeshData3D data=modelFor(actor);Motion moving=motion.get(actor.id);applyModel(actor,frame.terrain,data,moving);
            data.pose(frame.seconds,moving!=null&&moving.speed>.05f?1:actor.action,moving==null?0:moving.speed,bones);
            GLES30.glUniformMatrix4fv(depthUniforms.model,1,false,model,0);GLES30.glUniformMatrix4fv(depthUniforms.bones,MAX_BONES,false,bones,0);gpuModel(actor,data).draw();
        }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL);
    }

    private void renderGroundMarkers(Scene3DFrame frame,Camera3D.Snapshot view){
        GLES30.glUseProgram(flatProgram);GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glDepthMask(false);GLES30.glDisable(GLES30.GL_CULL_FACE);
        for(Scene3DFrame.Actor actor:frame.actors){
            if(!visible(actor,view))continue;MeshData3D data=modelFor(actor);
            float radius=Math.max(.22f,Math.min(1.4f,data.radius*.72f)),y=frame.terrain.height(actor.x,actor.z)+.012f;
            Matrix3D.model(model,actor.x,y,actor.z,0,radius,1,radius*.65f);
            GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);
            GLES30.glUniform4f(flatColor,.025f,.045f,.05f,actor.type==3?.14f:.25f);disk.draw();
            if(actor.id==frame.selectedId){
                Matrix3D.model(model,actor.x,y+.006f,actor.z,0,radius*1.18f,1,radius*.87f);
                GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);GLES30.glUniform4f(flatColor,.15f,.95f,.78f,.32f);disk.draw();
            }
        }
        if(frame.zoneRadius>0){
            Matrix3D.model(model,frame.zoneX,frame.terrain.height(frame.zoneX,frame.zoneZ)+.018f,frame.zoneZ,0,frame.zoneRadius,1,frame.zoneRadius);
            GLES30.glUniformMatrix4fv(flatMvp,1,false,Matrix3D.multiply(view.viewProjection,model),0);GLES30.glUniform4f(flatColor,.95f,.82f,.25f,.12f);disk.draw();
        }
        GLES30.glEnable(GLES30.GL_CULL_FACE);GLES30.glDepthMask(true);GLES30.glDisable(GLES30.GL_BLEND);
    }

    private void applyModel(Scene3DFrame.Actor actor,Scene3DFrame.Terrain terrain,MeshData3D data,Motion moving){
        float yaw=actor.type>=2?0:moving==null?0:moving.yaw;
        float scale=actor.type==1?1:actor.type==2?1+(actor.stage*.08f):1;
        float vertical=actor.type==2?Math.max(.08f,actor.progress):1;
        Matrix3D.model(model,actor.x,terrain.height(actor.x,actor.z),actor.z,yaw,scale,scale*vertical,scale);
        float c=(float)Math.cos(yaw),s=(float)Math.sin(yaw);
        normal[0]=c/scale;normal[1]=0;normal[2]=-s/scale;normal[3]=0;normal[4]=1/(scale*vertical);normal[5]=0;normal[6]=s/scale;normal[7]=0;normal[8]=c/scale;
    }
    private void normalIdentity(){for(int i=0;i<9;i++)normal[i]=0;normal[0]=normal[4]=normal[8]=1;}
    private static void teamTint(int uniform,int team){
        if(team==0)GLES30.glUniform3f(uniform,.64f,1,.91f);
        else if(team==1)GLES30.glUniform3f(uniform,1,.65f,.60f);
        else GLES30.glUniform3f(uniform,1,1,1);
    }
    private boolean visible(Scene3DFrame.Actor actor,Camera3D.Snapshot view){
        float dx=actor.x-view.targetX,dz=actor.z-view.targetZ;float limit=Math.min(86,view.distance*2.6f+8);return dx*dx+dz*dz<limit*limit;
    }
    private void updateMotion(Scene3DFrame frame){
        if(frame==previousFrame)return;
        float dt=previousFrame==null?0:frame.seconds-previousFrame.seconds;
        for(Scene3DFrame.Actor actor:frame.actors){
            Motion m=motion.get(actor.id);if(m==null){m=new Motion();m.x=actor.x;m.z=actor.z;motion.put(actor.id,m);}
            else if(dt>0&&dt<2){float dx=actor.x-m.x,dz=actor.z-m.z;float distance=(float)Math.sqrt(dx*dx+dz*dz);m.speed=distance/dt;if(distance>.0001f)m.yaw=(float)Math.atan2(dx,dz);}
            else if(dt>0)m.speed=0;
            m.x=actor.x;m.z=actor.z;m.seen=frameNumber;
        }
        Iterator<Motion> iterator=motion.values().iterator();while(iterator.hasNext())if(iterator.next().seen!=frameNumber)iterator.remove();previousFrame=frame;
    }
    private static MeshData3D modelFor(Scene3DFrame.Actor actor){
        if(actor.type==0)return ModelLibrary3D.getCreature(actor.kind);
        if(actor.type==1)return ModelLibrary3D.getSpecialist(actor.kind);
        if(actor.type==2)return ModelLibrary3D.getBuilding(actor.kind);
        return ModelLibrary3D.getPlant(actor.kind);
    }
    private GpuMesh gpuModel(Scene3DFrame.Actor actor,MeshData3D data){
        String key=actor.type+":"+actor.kind;GpuMesh mesh=meshes.get(key);if(mesh==null){mesh=new GpuMesh(data.vertices,data.indices);meshes.put(key,mesh);}return mesh;
    }
    private GpuMesh buildTerrain(Scene3DFrame.Terrain map){
        long started=System.nanoTime();TerrainMesh3D mesh=TerrainMesh3D.build(map);
        Log.i(TAG,"Terrain mesh: "+(mesh.vertices.length/STRIDE)+" genuine vertices, "+(mesh.indices.length/3)+" triangles; prepareMs="+((System.nanoTime()-started)/1000000L));
        if(terrainTypesTexture!=0)GLES30.glDeleteTextures(1,new int[]{terrainTypesTexture},0);
        ByteBuffer types=ByteBuffer.allocateDirect(map.width*map.height);
        for(int z=0;z<map.height;z++)for(int x=0;x<map.width;x++)types.put((byte)map.type(x,z));types.position(0);
        int[] id=new int[1];GLES30.glGenTextures(1,id,0);terrainTypesTexture=id[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,terrainTypesTexture);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT,1);GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D,0,GLES30.GL_R8,map.width,map.height,0,GLES30.GL_RED,GLES30.GL_UNSIGNED_BYTE,types);GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT,4);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_NEAREST);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);
        return new GpuMesh(mesh.vertices,mesh.indices);
    }
    private GpuMesh createDisk(){
        int segments=32;float[] v=new float[(segments+2)*STRIDE];int[] index=new int[segments*3];
        v[4]=1;v[6]=v[7]=v[8]=1;v[9]=1;
        for(int i=0;i<=segments;i++){double a=i*Math.PI*2/segments;int at=(i+1)*STRIDE;v[at]=(float)Math.cos(a);v[at+2]=(float)Math.sin(a);v[at+4]=1;v[at+6]=v[at+7]=v[at+8]=1;v[at+9]=0;if(i<segments){index[i*3]=0;index[i*3+1]=i+2;index[i*3+2]=i+1;}}
        return new GpuMesh(v,index);
    }

    private int loadMaterialAtlas(){
        String[] names={"water","shore","sand","grass","rock","alien","snow","moss","biotech"};
        int[] colors={0xFF1C566B,0xFF519FA6,0xFFB8A775,0xFF578A53,0xFF808A87,0xFF65728B,0xFFD2DEDD,0xFF4A7E5A,0xFF6A9A95};
        int cell=256;Bitmap atlas=Bitmap.createBitmap(cell*3,cell*3,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(atlas);Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
        JSONObject entries=null;boolean pbr=false;
        try{entries=new JSONObject(readText("native/materials-v04/manifest.json")).getJSONObject("textures");pbr=true;}
        catch(Exception e){try{entries=new JSONObject(readText("native/hd/manifest.json")).optJSONObject("textures");}catch(Exception missing){Log.w(TAG,"Material metadata missing; using base palette");}}
        Map<String,Bitmap> decodedImages=new HashMap<String,Bitmap>();
        int decoded=0;
        for(int i=0;i<names.length;i++){
            int x=(i%3)*cell,y=(i/3)*cell;paint.setColor(colors[i]);canvas.drawRect(x,y,x+cell,y+cell,paint);
            JSONObject entry=entries==null?null:entries.optJSONObject(names[i]);
            if(entry!=null)try{
                String path=entry.getString("file");if(!path.startsWith("native/")||path.contains(".."))throw new IOException("Unsafe material path");
                Bitmap bitmap=decodedImages.get(path);
                if(bitmap==null){
                    BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(InputStream input=assets.open(path)){BitmapFactory.decodeStream(input,null,bounds);}
                    if(bounds.outWidth<1||bounds.outHeight<1||bounds.outWidth>4096||bounds.outHeight>4096)throw new IOException("Invalid texture bounds");
                    BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;try(InputStream input=assets.open(path)){bitmap=BitmapFactory.decodeStream(input,null,options);}
                    if(bitmap==null)throw new IOException("Invalid texture bitmap");decodedImages.put(path,bitmap);
                }
                org.json.JSONArray rect=entry.optJSONArray("rect");android.graphics.Rect source=null;
                if(rect!=null){int left=rect.getInt(0),top=rect.getInt(1),width=rect.getInt(2),height=rect.getInt(3);if(left<0||top<0||width<1||height<1||left+width>bitmap.getWidth()||top+height>bitmap.getHeight())throw new IOException("Invalid material rectangle");source=new android.graphics.Rect(left,top,left+width,top+height);}
                canvas.drawBitmap(bitmap,source,new android.graphics.Rect(x,y,x+cell,y+cell),paint);decoded++;
                if(pbr){materialParameters[i*4]=finiteParameter(entry,"roughness",materialParameters[i*4],.08f,1);materialParameters[i*4+1]=finiteParameter(entry,"metallic",materialParameters[i*4+1],0,1);materialParameters[i*4+2]=finiteParameter(entry,"normalScale",materialParameters[i*4+2],0,.3f);}
            }catch(Exception e){Log.w(TAG,"Material fallback: "+names[i],e);}
        }
        for(Bitmap bitmap:decodedImages.values())bitmap.recycle();
        int[] id=new int[1];GLES30.glGenTextures(1,id,0);GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,id[0]);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR_MIPMAP_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,atlas,0);GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);atlas.recycle();
        Log.i(TAG,"Uploaded "+decoded+" HD materials to real GLES texture atlas");
        Log.i(TAG,"PBR materials v"+(pbr?"04":"03 fallback")+": albedo atlas, scalar roughness/metallic, analytic micro-normal; GGX lighting");return id[0];
    }
    private static float finiteParameter(JSONObject entry,String key,float fallback,float low,float high){double value=entry.optDouble(key,fallback);return Double.isNaN(value)||Double.isInfinite(value)?fallback:(float)Math.max(low,Math.min(high,value));}
    private String readText(String path)throws IOException{
        try(InputStream in=assets.open(path);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException("Manifest too big");out.write(buffer,0,n);}return out.toString("UTF-8");}
    }
    private void createShadowMap(){
        int[] id=new int[1];GLES30.glGenTextures(1,id,0);shadowTexture=id[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,shadowTexture);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D,0,GLES30.GL_DEPTH_COMPONENT24,SHADOW_SIZE,SHADOW_SIZE,0,GLES30.GL_DEPTH_COMPONENT,GLES30.GL_UNSIGNED_INT,null);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_NEAREST);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glGenFramebuffers(1,id,0);shadowFbo=id[0];GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,shadowFbo);GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER,GLES30.GL_DEPTH_ATTACHMENT,GLES30.GL_TEXTURE_2D,shadowTexture,0);
        GLES30.glDrawBuffers(1,new int[]{GLES30.GL_NONE},0);GLES30.glReadBuffer(GLES30.GL_NONE);
        shadowReady=GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)==GLES30.GL_FRAMEBUFFER_COMPLETE;
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER,0);Log.i(TAG,"Shadow framebuffer complete="+shadowReady);
    }
    private static int program(String vertex,String fragment){
        int vs=shader(GLES30.GL_VERTEX_SHADER,vertex),fs=shader(GLES30.GL_FRAGMENT_SHADER,fragment),program=GLES30.glCreateProgram();
        GLES30.glAttachShader(program,vs);GLES30.glAttachShader(program,fs);GLES30.glLinkProgram(program);int[] status=new int[1];GLES30.glGetProgramiv(program,GLES30.GL_LINK_STATUS,status,0);
        String log=GLES30.glGetProgramInfoLog(program);if(!log.isEmpty())Log.i(TAG,"Program log: "+log);
        GLES30.glDeleteShader(vs);GLES30.glDeleteShader(fs);if(status[0]!=GLES30.GL_TRUE)throw new IllegalStateException("GLES link failed: "+log);return program;
    }
    private static int shader(int type,String source){
        int shader=GLES30.glCreateShader(type);GLES30.glShaderSource(shader,source);GLES30.glCompileShader(shader);int[] status=new int[1];GLES30.glGetShaderiv(shader,GLES30.GL_COMPILE_STATUS,status,0);
        String log=GLES30.glGetShaderInfoLog(shader);if(!log.isEmpty())Log.i(TAG,"Shader log: "+log);if(status[0]!=GLES30.GL_TRUE)throw new IllegalStateException("GLES shader failed: "+log);return shader;
    }
    private static int checkError(String operation){int error,count=0;while((error=GLES30.glGetError())!=GLES30.GL_NO_ERROR){count++;Log.e(TAG,"GL_ERROR "+operation+": 0x"+Integer.toHexString(error));}return count;}
    private static final class Motion {float x,z,yaw,speed;long seen;}
    private static final class PortraitViewport {final int left,top,width,height;PortraitViewport(int l,int t,int w,int h){left=l;top=t;width=w;height=h;}}
    private static final class GpuMesh {
        final int vao,vbo,ibo,count;
        GpuMesh(float[] vertices,int[] indices){
            if(vertices.length%STRIDE!=0||indices.length%3!=0)throw new IllegalArgumentException("Invalid mesh stride");int verticesCount=vertices.length/STRIDE;
            for(int index:indices)if(index<0||index>=verticesCount)throw new IllegalArgumentException("Mesh index out of range");
            count=indices.length;int[] id=new int[1],buffers=new int[2];GLES30.glGenVertexArrays(1,id,0);vao=id[0];GLES30.glBindVertexArray(vao);GLES30.glGenBuffers(2,buffers,0);vbo=buffers[0];ibo=buffers[1];
            FloatBuffer data=ByteBuffer.allocateDirect(vertices.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();data.put(vertices).position(0);
            IntBuffer elements=ByteBuffer.allocateDirect(indices.length*4).order(ByteOrder.nativeOrder()).asIntBuffer();elements.put(indices).position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,vbo);GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER,vertices.length*4,data,GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,ibo);GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER,indices.length*4,elements,GLES30.GL_STATIC_DRAW);
            int[] sizes={3,3,4,2,1},offsets={0,12,24,40,48};for(int i=0;i<5;i++){GLES30.glEnableVertexAttribArray(i);GLES30.glVertexAttribPointer(i,sizes[i],GLES30.GL_FLOAT,false,STRIDE*4,offsets[i]);}GLES30.glBindVertexArray(0);
        }
        void draw(){GLES30.glBindVertexArray(vao);GLES30.glDrawElements(GLES30.GL_TRIANGLES,count,GLES30.GL_UNSIGNED_INT,0);GLES30.glBindVertexArray(0);}
        void delete(){GLES30.glDeleteVertexArrays(1,new int[]{vao},0);GLES30.glDeleteBuffers(2,new int[]{vbo,ibo},0);}
    }
    private static final class Uniforms {
        final int vp,model,bones,skinned,normal,lightVp,eye,light,time,highQuality,shadowEnabled,materials,shadowMap,tint,terrain,portrait,materialParameters,terrainTypes;
        Uniforms(int program,boolean depth){
            vp=loc(program,"uVP");model=loc(program,"uModel");bones=loc(program,"uBones[0]");skinned=loc(program,"uSkinned");normal=loc(program,"uNormal");lightVp=loc(program,"uLightVP");eye=loc(program,"uEye");light=loc(program,"uLight");time=loc(program,"uTime");highQuality=loc(program,"uHighQuality");shadowEnabled=loc(program,"uShadowEnabled");materials=loc(program,"uMaterials");shadowMap=loc(program,"uShadowMap");tint=loc(program,"uTint");terrain=loc(program,"uTerrain");
            portrait=loc(program,"uPortrait");materialParameters=loc(program,"uMaterialParameters[0]");terrainTypes=loc(program,"uTerrainTypes");
        }
        private static int loc(int p,String n){return GLES30.glGetUniformLocation(p,n);}
    }

    private static final String VERTEX_SHADER="#version 300 es\n"
        +"precision highp float;\n"
        +"layout(location=0) in vec3 aPosition; layout(location=1) in vec3 aNormal; layout(location=2) in vec4 aColor; layout(location=3) in vec2 aUV; layout(location=4) in float aBone;\n"
        +"uniform mat4 uVP,uModel,uLightVP,uBones[24]; uniform mat3 uNormal; uniform bool uSkinned,uTerrain,uHighQuality; uniform float uTime;\n"
        +"out vec3 vWorld,vNormal; out vec4 vColor,vShadow; out vec2 vUV;\n"
        +"void main(){mat4 skin=uSkinned?uBones[clamp(int(aBone+.5),0,23)]:mat4(1.0); vec4 world=uModel*skin*vec4(aPosition,1.0); vWorld=world.xyz; vNormal=normalize(uNormal*mat3(skin)*aNormal); vColor=aColor; vUV=aUV; vShadow=uLightVP*world; gl_Position=uVP*world;}\n";
    private static final String FRAGMENT_SHADER="#version 300 es\n"
        +"precision highp float;\n"
        +"in vec3 vWorld,vNormal; in vec4 vColor,vShadow; in vec2 vUV;\n"
        +"uniform sampler2D uMaterials,uShadowMap,uTerrainTypes; uniform vec4 uMaterialParameters[9]; uniform vec3 uEye,uLight,uTint; uniform float uTime; uniform bool uTerrain,uHighQuality,uShadowEnabled,uPortrait;\n"
        +"out vec4 fragColor;\n"
        +"const float PI=3.14159265;\n"
        +"float visibility(vec3 n){if(!uShadowEnabled)return 1.0;vec3 q=vShadow.xyz/vShadow.w*.5+.5;if(q.x<0.0||q.x>1.0||q.y<0.0||q.y>1.0||q.z>1.0||q.z<0.0)return 1.0;float bias=max(.0007*(1.0-dot(n,uLight)),.00025);float sum=0.0;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){float d=texture(uShadowMap,q.xy+vec2(float(x),float(y))/1024.0).r;sum+=q.z-bias<=d?1.0:0.0;}return sum/9.0;}\n"
        +"vec3 albedo(int material,vec2 uv,vec2 dx,vec2 dy){vec2 tile=vec2(float(material%3),float(material/3));return pow(max(textureGrad(uMaterials,(tile+vec2(.012)+uv*.976)/3.0,dx,dy).rgb,vec3(.001)),vec3(2.2));}\n"
        +"int terrainAt(ivec2 at){ivec2 size=textureSize(uTerrainTypes,0);return clamp(int(texelFetch(uTerrainTypes,clamp(at,ivec2(0),size-1),0).r*255.0+.5),0,8);}\n"
        +"void addMaterial(int material,float weight,vec2 uv,vec2 dx,vec2 dy,inout vec3 base,inout vec4 properties,inout float water){base+=albedo(material,uv,dx,dy)*weight;properties+=uMaterialParameters[material]*weight;if(material==0)water+=weight;}\n"
        +"vec3 fresnel(float cosTheta,vec3 f0){return f0+(1.0-f0)*pow(clamp(1.0-cosTheta,0.0,1.0),5.0);}\n"
        +"vec3 skyRadiance(vec3 direction){return mix(vec3(.10,.085,.065),vec3(.43,.57,.73),smoothstep(-.25,.65,direction.y));}\n"
        +"vec3 toneMap(vec3 color){return clamp((color*(2.51*color+.03))/(color*(2.43*color+.59)+.14),0.0,1.0);}\n"
        +"void main(){\n"
        +" vec3 n=normalize(vNormal);vec3 base=pow(max(vColor.rgb,vec3(.001)),vec3(2.2));float roughness=clamp(vUV.x,.12,1.0),metallic=clamp(vUV.y,0.0,1.0),ao=1.0,water=0.0;\n"
        +" if(uTerrain){\n"
        +"  vec2 uv=abs(fract(vWorld.xz*.14)*2.0-1.0);vec2 cell=vWorld.xz-vec2(.5);ivec2 at=ivec2(floor(cell));vec2 blend=smoothstep(vec2(.13),vec2(.87),fract(cell));\n"
        +"  vec2 dx=dFdx(uv)*(.976/3.0),dy=dFdy(uv)*(.976/3.0);int a=terrainAt(at),b=terrainAt(at+ivec2(1,0)),c=terrainAt(at+ivec2(0,1)),d=terrainAt(at+ivec2(1,1));vec4 properties=vec4(0.0);base=vec3(0.0);\n"
        +"  if(a==b&&a==c&&a==d){addMaterial(a,1.0,uv,dx,dy,base,properties,water);}else{\n"
        +"   addMaterial(a,(1.0-blend.x)*(1.0-blend.y),uv,dx,dy,base,properties,water);addMaterial(b,blend.x*(1.0-blend.y),uv,dx,dy,base,properties,water);addMaterial(c,(1.0-blend.x)*blend.y,uv,dx,dy,base,properties,water);addMaterial(d,blend.x*blend.y,uv,dx,dy,base,properties,water);\n"
        +"  }\n"
        +"  roughness=properties.x;metallic=properties.y;ao=properties.w;\n"
        +"  if(uHighQuality){vec2 detail=vec2(sin(vWorld.x*19.0+vWorld.z*7.0),cos(vWorld.z*17.0-vWorld.x*5.0));n=normalize(n+vec3(detail.x,0.0,detail.y)*properties.z);}\n"
        +"  if(water>0.0){\n"
        +"   if(uHighQuality){vec2 wave=vec2(sin(vWorld.x*3.2+vWorld.z*.9+uTime*1.2),cos(vWorld.z*2.8-vWorld.x*1.7+uTime*.7));n=normalize(n+vec3(wave.x,0.0,wave.y)*.065*water);}\n"
        +"   base=mix(base,vec3(.012,.07,.095),water*.6);roughness=mix(roughness,.12,water);metallic=mix(metallic,0.0,water);\n"
        +"   float foam=4.0*water*(1.0-water)*(.28+.09*sin(vWorld.x*8.0+vWorld.z*11.0+uTime*1.4));base=mix(base,vec3(.6,.68,.65),foam);\n"
        +"  }\n"
        +"  ao*=mix(.80,1.0,clamp(n.y,0.0,1.0));\n"
        +" }else{base=mix(base,base*uTint,.18);}\n"
        +" roughness=clamp(roughness,.10,1.0);vec3 V=normalize(uEye-vWorld),L=normalize(uLight),H=normalize(V+L);float nv=max(dot(n,V),.001),nl=max(dot(n,L),0.0),nh=max(dot(n,H),0.0),vh=max(dot(V,H),0.0);\n"
        +" vec3 f0=mix(vec3(.04),base,metallic),F=fresnel(vh,f0);float alpha=roughness*roughness,a2=alpha*alpha,den=nh*nh*(a2-1.0)+1.0;float D=a2/max(PI*den*den,.0001);float k=(roughness+1.0)*(roughness+1.0)/8.0;float G=(nv/(nv*(1.0-k)+k))*(nl/(nl*(1.0-k)+k));\n"
        +" vec3 specular=D*G*F/max(4.0*nv*nl,.001);vec3 diffuse=(1.0-F)*(1.0-metallic)*base/PI;float shadow=visibility(n);vec3 direct=(diffuse+specular)*vec3(3.2,3.02,2.75)*nl*shadow;\n"
        +" vec3 irradiance=mix(vec3(.11,.095,.07),vec3(.27,.35,.43),n.y*.5+.5);vec3 ambient=base*(1.0-metallic)*irradiance*ao;\n"
        +" vec3 R=reflect(-V,n);vec3 environment=mix(skyRadiance(R),vec3(.23,.28,.32),roughness*roughness);vec3 ambientF=fresnel(nv,f0);vec3 reflection=environment*ambientF*mix(.85,.25,roughness)*ao;\n"
        +" vec3 color=direct+ambient+reflection;if(!uTerrain)color+=base*vColor.a*.7;\n"
        +" if(!uPortrait){float fog=smoothstep(40.0,112.0,length(uEye-vWorld));color=mix(color,vec3(.16,.23,.28),fog*.78);}else{color+=base*.07;}\n"
        +" fragColor=vec4(pow(toneMap(max(color,vec3(0.0))*1.08),vec3(1.0/2.2)),1.0);\n"
        +"}\n";
    private static final String DEPTH_VERTEX="#version 300 es\nprecision highp float;layout(location=0) in vec3 aPosition;layout(location=4) in float aBone;uniform mat4 uVP,uModel,uBones[24];uniform bool uSkinned;void main(){vec4 p=vec4(aPosition,1.0);if(uSkinned)p=uBones[clamp(int(aBone+.5),0,23)]*p;gl_Position=uVP*uModel*p;}";
    private static final String DEPTH_FRAGMENT="#version 300 es\nprecision mediump float;void main(){}";
    private static final String FLAT_VERTEX="#version 300 es\nprecision highp float;layout(location=0) in vec3 aPosition;layout(location=2) in vec4 aColor;uniform mat4 uMVP;out float vAlpha;void main(){gl_Position=uMVP*vec4(aPosition,1.0);vAlpha=aColor.a;}";
    private static final String FLAT_FRAGMENT="#version 300 es\nprecision mediump float;in float vAlpha;uniform vec4 uColor;out vec4 fragColor;void main(){fragColor=vec4(uColor.rgb,uColor.a*vAlpha);}";
}
