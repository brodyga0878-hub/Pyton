package org.genewars.android.gl3d;

/** CPU terrain preparation, independent of Android/GLES and immutable after build. */
public final class TerrainMesh3D {
    public static final int STRIDE=13;
    public final float[] vertices;
    public final int[] indices;

    private TerrainMesh3D(float[] vertices,int[] indices){this.vertices=vertices;this.indices=indices;}

    public static TerrainMesh3D build(Scene3DFrame.Terrain map){
        int columns=map.width+1,rows=map.height+1,corners=columns*rows;
        float[] heights=new float[corners],normals=new float[corners*3];
        // Each actual height and normal is evaluated once per shared grid corner.
        // Cell-local vertices below only copy these results, retaining material seams.
        for(int z=0;z<rows;z++)for(int x=0;x<columns;x++)heights[z*columns+x]=map.vertexHeight(x,z);
        for(int z=0;z<rows;z++)for(int x=0;x<columns;x++){
            float nx=heights[z*columns+Math.max(0,x-1)]-heights[z*columns+Math.min(columns-1,x+1)];
            float nz=heights[Math.max(0,z-1)*columns+x]-heights[Math.min(rows-1,z+1)*columns+x];
            float length=(float)Math.sqrt(nx*nx+4+nz*nz);int normal=(z*columns+x)*3;
            normals[normal]=nx/length;normals[normal+1]=2/length;normals[normal+2]=nz/length;
        }
        int count=map.width*map.height;
        float[] vertices=new float[count*4*STRIDE];int[] indices=new int[count*6];int v=0,k=0;
        int[] ox={0,1,1,0},oz={0,0,1,1};
        for(int z=0;z<map.height;z++)for(int x=0;x<map.width;x++){
            int base=v/STRIDE,kind=map.type(x,z);
            for(int corner=0;corner<4;corner++){
                int wx=x+ox[corner],wz=z+oz[corner],grid=wz*columns+wx,normal=grid*3;
                vertices[v++]=wx;vertices[v++]=heights[grid];vertices[v++]=wz;
                vertices[v++]=normals[normal];vertices[v++]=normals[normal+1];vertices[v++]=normals[normal+2];
                vertices[v++]=1;vertices[v++]=1;vertices[v++]=1;vertices[v++]=0;
                vertices[v++]=wx/3.5f;vertices[v++]=wz/3.5f;vertices[v++]=kind;
            }
            // Same two +Y triangles used by Camera3D ground picking.
            indices[k++]=base;indices[k++]=base+2;indices[k++]=base+1;
            indices[k++]=base;indices[k++]=base+3;indices[k++]=base+2;
        }
        return new TerrainMesh3D(vertices,indices);
    }
}
