package org.genewars.android.gl3d;

/** Twelve distinct, closed-volume plants generated from the same native mesh primitives. */
public final class PlantModels3D {
    private PlantModels3D() {}
    private static final float TAU=(float)(Math.PI*2);
    private static float[] colour(float r,float g,float b,float emission){return new float[]{r,g,b,emission,.78f,0};}
    private static final float[] BARK=colour(.24f,.20f,.15f,0),WOOD=colour(.31f,.27f,.20f,0),
            GREEN=colour(.23f,.32f,.18f,0),TEAL=colour(.18f,.29f,.24f,0),
            GOLD=colour(.52f,.37f,.15f,0),SNOW=colour(.68f,.72f,.71f,0),
            BLUE=colour(.19f,.28f,.28f,0),PURPLE=colour(.29f,.22f,.32f,.02f),
            CYAN=new float[]{.17f,.43f,.45f,.12f,.24f,.08f};

    public static MeshData3D build(int species){
        if(species<0||species>=12)throw new IllegalArgumentException("Unknown plant species");
        MeshBuilder3D m=new MeshBuilder3D("plant_"+species);
        int stem=m.bone("stem",0,0,.06f,0,Bone3D.PLANT_SWAY_Z,species*.71f,species==7?.012f:.045f);
        if(species==0)broadleaf(m,stem);
        else if(species==1)fruit(m,stem);
        else if(species==2)fern(m,stem);
        else if(species==3)bloom(m,stem);
        else if(species==4)desertCanopy(m,stem);
        else if(species==5)palm(m,stem);
        else if(species==6)snowTree(m,stem);
        else if(species==7)crystals(m,stem);
        else if(species==8)pine(m,stem);
        else if(species==9)fungus(m,stem);
        else if(species==10)spiral(m,stem);
        else cone(m,stem);
        return m.finish();
    }

    private static void root(MeshBuilder3D m,int b,float height,float radius,float[]c){
        m.cylinder(0,.025f,0,-.018f,height*.40f,.012f,radius,radius*.81f,10,c,b);
        m.cylinder(-.018f,height*.40f,.012f,.035f,height*.74f,-.012f,radius*.81f,radius*.63f,10,c,b);
        m.cylinder(.035f,height*.74f,-.012f,.04f,height,0,radius*.63f,radius*.45f,9,c,b);
        for(int i=0;i<5;i++){
            float a=i*TAU/5,dx=(float)Math.cos(a),dz=(float)Math.sin(a);
            m.cylinder(dx*radius*2.5f,.015f,dz*radius*2.5f,0,.22f,0,.018f,radius*.44f,7,c,b);
            if(height>.75f)m.cylinder(dx*radius*.79f,.16f,dz*radius*.79f,.025f+dx*radius*.54f,height*.84f,dz*radius*.54f,.007f,.004f,5,WOOD,b);
        }
    }
    private static void leaf(MeshBuilder3D m,int b,float x,float y,float z,float rx,float ry,float rz,float[]c){
        m.ellipsoid(x,y,z,rx,ry,rz,10,6,c,b);
    }
    private static void broadleaf(MeshBuilder3D m,int b){
        root(m,b,1.12f,.085f,BARK);
        for(int i=0;i<6;i++){
            float a=i*TAU/6+.3f,x=(float)Math.cos(a)*(.30f+(i%2)*.10f),z=(float)Math.sin(a)*.38f,y=1.0f+(i%3)*.18f;
            m.cylinder(.02f,.65f,0,x*.55f,y-.12f,z*.55f,.038f,.023f,8,BARK,b);
            m.cylinder(x*.55f,y-.12f,z*.55f,x,y,z,.023f,.009f,7,WOOD,b);
            canopy(m,b,x,y+.04f,z,.29f,.16f,.27f,i);
        }
        canopy(m,b,.03f,1.45f,0,.28f,.19f,.24f,6);
    }
    private static void fruit(MeshBuilder3D m,int b){
        root(m,b,1.16f,.09f,BARK);
        for(int i=0;i<5;i++){
            float a=i*TAU/5,x=(float)Math.cos(a)*.36f,z=(float)Math.sin(a)*.36f,y=1.08f+(i%3)*.15f;
            m.cylinder(.02f,.74f,0,x,y,z,.036f,.012f,8,WOOD,b);
            canopy(m,b,x,y+.14f,z,.30f,.17f,.27f,i+2);
            for(int f=0;f<3;f++){float fx=x+(f-1)*.09f,fz=z+.03f*(f%2);m.cylinder(fx,y+.02f,fz,fx,y-.075f,fz,.004f,.004f,5,WOOD,b);leaf(m,b,fx,y-.09f,fz,.041f,.054f,.041f,GOLD);}
        }
        canopy(m,b,0,1.5f,0,.27f,.18f,.24f,8);
    }
    private static void canopy(MeshBuilder3D m,int b,float x,float y,float z,float rx,float ry,float rz,int seed){
        // An irregular tapered crown with actual oriented outer leaves; the
        // branch visibly enters the foliage instead of ending under a ball.
        m.ellipsoidBetween(x-rx*.72f,y-ry*.25f,z-rz*.48f,x+rx*.72f,y+ry*.3f,z+rz*.48f,ry*.75f,rz*.72f,10,6,seed%2==0?GREEN:TEAL,b);
        for(int j=0;j<13;j++){
            float a=j*2.39996f+seed*.45f,d=.46f+(j%3)*.20f;
            float lx=x+(float)Math.cos(a)*rx*d,lz=z+(float)Math.sin(a)*rz*d,ly=y+ry*(.2f+(j%4)*.16f);
            m.ellipsoidBetween(lx-.043f*(float)Math.sin(a),ly-.014f,lz-.055f*(float)Math.cos(a),lx+.043f*(float)Math.sin(a),ly+.025f,lz+.055f*(float)Math.cos(a),.028f,.012f,7,4,j%3==0?TEAL:GREEN,b);
        }
    }
    private static void fern(MeshBuilder3D m,int b){
        root(m,b,.65f,.075f,WOOD);
        for(int i=0;i<10;i++){
            float a=i*TAU/10,c=(float)Math.cos(a),s=(float)Math.sin(a),y=.72f+(i%3)*.13f;
            m.cylinder(0,.48f,0,c*.62f,y-.13f,s*.62f,.025f,.008f,6,TEAL,b);
            for(int j=1;j<=3;j++){
                float d=j*.16f;
                leaf(m,b,c*d,y-j*.035f,s*d,.18f,.075f,.13f,TEAL);
            }
        }
        leaf(m,b,0,1.05f,0,.18f,.15f,.18f,GREEN);
    }
    private static void bloom(MeshBuilder3D m,int b){
        root(m,b,.72f,.07f,WOOD);
        float[]petal=colour(.57f,.29f,.15f,.01f);
        for(int i=0;i<4;i++){
            float a=i*TAU/4+.3f,x=(float)Math.cos(a)*.26f,z=(float)Math.sin(a)*.26f,y=1.05f+(i%2)*.22f;
            m.cylinder(0,.50f,0,x,y,z,.045f,.025f,8,WOOD,b);
            int flower=m.bone("bloom_"+i,b,x,y,z,Bone3D.PULSE,i*.8f,.03f);
            for(int j=0;j<6;j++){
                float f=j*TAU/6;
                leaf(m,flower,x+(float)Math.cos(f)*.13f,y+.04f,z+(float)Math.sin(f)*.13f,.12f,.09f,.10f,petal);
            }
            leaf(m,flower,x,y+.10f,z,.09f,.10f,.09f,GOLD);
        }
    }
    private static void desertCanopy(MeshBuilder3D m,int b){
        root(m,b,.80f,.13f,WOOD);
        float[]rust=colour(.36f,.28f,.18f,0),amber=colour(.43f,.33f,.19f,0);
        for(int i=0;i<6;i++){
            float a=i*TAU/6,x=(float)Math.cos(a)*.40f,z=(float)Math.sin(a)*.40f,y=1.03f+(i%2)*.20f;
            m.cylinder(0,.52f,0,x,y,z,.07f,.035f,8,WOOD,b);
            m.ellipsoidBetween(x-.22f,y+.03f,z-.10f,x+.22f,y+.11f,z+.10f,.10f,.23f,10,6,i%2==0?rust:amber,b);
        }
        leaf(m,b,.03f,1.32f,0,.30f,.16f,.29f,rust);
    }
    private static void palm(MeshBuilder3D m,int b){
        root(m,b,1.25f,.09f,BARK);
        float[]olive=colour(.32f,.36f,.16f,0);
        for(int i=0;i<8;i++){
            float a=i*TAU/8,x=(float)Math.cos(a),z=(float)Math.sin(a);
            m.cylinder(.04f,1.20f,0,x*.60f,1.43f,z*.60f,.027f,.009f,6,olive,b);
            for(int j=1;j<=5;j++){float d=j*.12f;for(int side=-1;side<=1;side+=2)m.ellipsoidBetween(x*d,1.46f-j*.012f,z*d,x*d+z*side*.17f,1.44f-j*.02f,z*d-x*side*.17f,.031f,.012f,7,4,olive,b);}
            if(i%2==0)leaf(m,b,x*.12f,1.13f,z*.12f,.07f,.09f,.07f,GOLD);
        }
    }
    private static void snowTree(MeshBuilder3D m,int b){
        root(m,b,1.40f,.075f,colour(.46f,.46f,.40f,0));
        for(int i=0;i<7;i++){
            float a=i*TAU/7,x=(float)Math.cos(a)*.43f,z=(float)Math.sin(a)*.43f,y=1.18f+(i%3)*.21f;
            float sy=.78f+i*.045f;
            m.cylinder(.02f,sy,0,x,y,z,.028f,.008f,8,WOOD,b);
            m.ellipsoidBetween(.017f+x*.15f,sy+(y-sy)*.15f+.02f,z*.15f,.002f+x*.90f,sy+(y-sy)*.90f+.025f,z*.90f,.025f,.052f,8,5,SNOW,b);
            for(int t=0;t<3;t++){
                float d=.48f+t*.20f,tx=x*d+(float)Math.sin(a)*.16f*(t%2==0?1:-1),tz=z*d-(float)Math.cos(a)*.16f*(t%2==0?1:-1);
                float ty=sy+(y-sy)*d;
                m.cylinder(.02f*(1-d)+x*d,ty,z*d,tx,ty+.22f,tz,.010f,.003f,7,WOOD,b);
                m.ellipsoidBetween(.02f*(1-d)+x*d,ty+.018f,z*d,tx,ty+.23f,tz,.018f,.028f,7,4,SNOW,b);
            }
        }
        m.cylinder(.04f,1.32f,0,-.035f,1.90f,.025f,.025f,.003f,8,WOOD,b);
    }
    private static void crystals(MeshBuilder3D m,int b){
        leaf(m,b,0,.12f,0,.36f,.12f,.35f,BLUE);
        for(int i=0;i<9;i++){
            float a=i*TAU/9,x=(float)Math.cos(a)*.24f,z=(float)Math.sin(a)*.24f,h=.8f+(i%3)*.24f;
            float[]c=i%2==0?CYAN:new float[]{.32f,.30f,.43f,.10f,.23f,.10f};
            m.cylinder(x,.10f,z,x*1.45f,h,z*1.45f,.10f,.075f,6,c,b);
            m.cylinder(x*1.45f,h,z*1.45f,x*1.55f,h+.28f,z*1.55f,.075f,0,6,c,b);
        }
    }
    private static void pine(MeshBuilder3D m,int b){
        root(m,b,1.70f,.065f,BARK);
        for(int i=0;i<5;i++){
            float y=.40f+i*.27f,r=.53f-i*.083f;
            for(int j=0;j<7;j++){
                float a=j*TAU/7+i*.35f,x=(float)Math.cos(a)*r,z=(float)Math.sin(a)*r;
                m.cylinder(0,y+.13f,0,x,y-.04f,z,.015f,.003f,7,WOOD,b);
                m.ellipsoidBetween(x*.12f,y+.18f,z*.12f,x,y-.035f,z,.068f,.067f,8,5,j%3==0?TEAL:BLUE,b);
            }
        }
        m.cylinder(0,1.49f,0,0,1.97f,0,.115f,0,9,BLUE,b);
    }
    private static void fungus(MeshBuilder3D m,int b){
        for(int i=0;i<5;i++){
            float a=i*TAU/5,x=i==0?0:(float)Math.cos(a)*.32f,z=i==0?0:(float)Math.sin(a)*.32f,h=i==0?1.30f:.60f+(i%3)*.18f,r=i==0?.37f:.23f;
            m.cylinder(x,.02f,z,x,h,z,.05f,.035f,8,colour(.46f,.27f,.12f,0),b);
            leaf(m,b,x,h,z,r,.05f,r,CYAN);
            leaf(m,b,x,h+.10f,z,r*1.02f,.14f,r,TEAL);
            for(int j=0;j<5;j++){
                float f=j*TAU/5;
                leaf(m,b,x+(float)Math.cos(f)*r*.6f,h+.20f,z+(float)Math.sin(f)*r*.6f,.025f,.02f,.025f,CYAN);
            }
        }
    }
    private static void spiral(MeshBuilder3D m,int b){
        root(m,b,.75f,.08f,colour(.18f,.13f,.25f,0));
        for(int side=0;side<2;side++){
            float lastX=0,lastY=.42f,lastZ=0;
            for(int i=1;i<=16;i++){
                float a=i*.48f+side*(float)Math.PI,r=.10f+i*.014f;
                float x=(float)Math.cos(a)*r,z=(float)Math.sin(a)*r,y=.42f+i*.073f;
                m.cylinder(lastX,lastY,lastZ,x,y,z,.035f,.030f,6,PURPLE,b);
                if(i%3==0)leaf(m,b,x,y,z,.10f,.07f,.09f,colour(.39f,.25f,.43f,.04f));
                lastX=x;lastY=y;lastZ=z;
            }
            leaf(m,b,lastX,lastY,lastZ,.10f,.10f,.10f,CYAN);
        }
    }
    private static void cone(MeshBuilder3D m,int b){
        root(m,b,.48f,.11f,BARK);
        leaf(m,b,0,.91f,0,.35f,.72f,.35f,colour(.14f,.35f,.29f,0));
        for(int row=0;row<5;row++){
            float y=.42f+row*.24f,r=.33f*(float)Math.sin((row+1)*Math.PI/6);
            for(int j=0;j<7;j++){
                float a=j*TAU/7+row*.31f,x=(float)Math.cos(a)*r,z=(float)Math.sin(a)*r;
                leaf(m,b,x,y,z,.11f,.17f,.10f,j%3==0?GOLD:TEAL);
            }
        }
    }
}
