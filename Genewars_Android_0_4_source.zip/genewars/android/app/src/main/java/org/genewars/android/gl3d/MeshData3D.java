package org.genewars.android.gl3d;

/** Immutable indexed geometry and its articulated rig; independent of Android. */
public final class MeshData3D {
    public static final int STRIDE_FLOATS=13, MAX_BONES=24;
    public static final int IDLE=0,WALK=1,ATTACK=2,WORK=3,DEAD=4;
    public final String name;
    /** stride13: position3, normal3, sRGB3/emission1, roughness1/metallic1, bone1. */
    public final float[] vertices;
    public final int[] indices;
    public final Bone3D[] bones;
    public final int boneCount;
    /** Radius is measured in XZ; height is maxY-minY of the bind geometry. */
    public final float radius,height;
    private static final class Scratch {
        final float[] world=new float[384], t=new float[72],q=new float[96],s=new float[72],local=new float[16];
    }
    private static final ThreadLocal<Scratch> SCRATCH=new ThreadLocal<Scratch>() {
        @Override protected Scratch initialValue(){return new Scratch();}
    };
    MeshData3D(String name,float[]vertices,int[]indices,Bone3D[]bones) {
        this.name=name;this.vertices=vertices;this.indices=indices;this.bones=bones;this.boneCount=bones.length;
        float r=0,minY=Float.POSITIVE_INFINITY,maxY=Float.NEGATIVE_INFINITY;
        for(int i=0;i<vertices.length;i+=STRIDE_FLOATS){
            r=Math.max(r,(float)Math.sqrt(vertices[i]*vertices[i]+vertices[i+2]*vertices[i+2]));
            minY=Math.min(minY,vertices[i+1]);maxY=Math.max(maxY,vertices[i+1]);
        }
        radius=r;height=maxY-minY;
    }

    /**
     * Exact local TRS used by the native rig. Also exported to glTF animation.
     * Translation/scale arrays need 24*3 entries; quaternion array needs 24*4.
     */
    public void sampleLocalTRS(float time,int action,float speed,float[]translation,float[]rotation,float[]scale){
        if(translation.length<72||rotation.length<96||scale.length<72)throw new IllegalArgumentException("TRS output too small");
        float gait=time*(5.0f+Math.min(3,Math.abs(speed))*2.2f);
        for(int i=0;i<MAX_BONES;i++){
            int t=i*3,q=i*4;translation[t]=translation[t+1]=translation[t+2]=0;
            rotation[q]=rotation[q+1]=rotation[q+2]=0;rotation[q+3]=1;
            scale[t]=scale[t+1]=scale[t+2]=1;
            if(i>=boneCount)continue;
            Bone3D b=bones[i];Bone3D p=b.parent<0?null:bones[b.parent];
            translation[t]=b.x-(p==null?0:p.x);translation[t+1]=b.y-(p==null?0:p.y);translation[t+2]=b.z-(p==null?0:p.z);
            float a=0,ax=0,ay=0,az=0,amp=b.amplitude;
            switch(b.animation){
                case Bone3D.ROOT:
                    translation[t+1]+=.008f*(float)Math.sin(time*1.8f+b.phase);
                    scale[t+1]=1+.012f*(float)Math.sin(time*1.8f+b.phase);
                    if(action==WALK){float step=(float)Math.sin(gait);translation[t+1]+=.019f*step*step;}
                    break;
                case Bone3D.SWING_X:
                    ax=1;a=(action==WALK?amp*(float)Math.sin(gait+b.phase):.025f*(float)Math.sin(time*1.5f+b.phase));break;
                case Bone3D.KNEE_X:
                    ax=1;
                    if(action==WALK){float bend=Math.max(0,(float)Math.sin(gait+b.phase));a=amp*bend*bend;}
                    else a=.015f*(float)Math.sin(time+b.phase);
                    break;
                case Bone3D.SWING_Z:
                    az=1;a=(action==WALK?amp:.07f*amp)*(float)Math.sin((action==WALK?gait:time)+b.phase);break;
                case Bone3D.TAIL_Y:
                    ay=1;a=amp*(float)Math.sin(time*(action==WALK?4.2f:1.7f)+b.phase);break;
                case Bone3D.WING_Z:
                    az=1;a=amp*(action==WALK?.9f:.18f)*(float)Math.sin(time*(action==WALK?7f:1.8f)+b.phase);break;
                case Bone3D.WORK_ARM_X:
                    ax=1;
                    if(action==ATTACK)a=-.75f+amp*.55f*(float)Math.sin(time*10+b.phase);
                    else if(action==WORK)a=-.65f+amp*.35f*(float)Math.sin(time*5+b.phase);
                    else if(action==WALK)a=amp*.45f*(float)Math.sin(gait+b.phase);
                    else a=.04f*(float)Math.sin(time*1.6f+b.phase);
                    break;
                case Bone3D.ROTOR_Y:ay=1;a=time*amp+b.phase;break;
                case Bone3D.ROTOR_Z:az=1;a=time*amp+b.phase;break;
                case Bone3D.PULSE:
                    float pulse=1+.028f*(float)Math.sin(time*2.6f+b.phase);
                    scale[t]=scale[t+1]=scale[t+2]=pulse;break;
                case Bone3D.PLANT_SWAY_Z:
                    az=1;a=amp*(float)Math.sin(time*.8f+b.phase)+amp*.25f*(float)Math.sin(time*1.7f+b.phase);break;
                case Bone3D.JAW_X:ax=1;a=action==ATTACK?amp*(.5f+.5f*(float)Math.sin(time*9)):.015f*(float)Math.sin(time+b.phase);break;
                case Bone3D.HEAD_Y:ay=1;a=amp*(float)Math.sin(time*(action==ATTACK?5f:1.1f)+b.phase);break;
                default:break;
            }
            if(i==0&&action==DEAD){az=1;a=1.12f;translation[t+1]=.08f;}
            float sn=(float)Math.sin(a*.5f);rotation[q]=ax*sn;rotation[q+1]=ay*sn;rotation[q+2]=az*sn;rotation[q+3]=(float)Math.cos(a*.5f);
        }
    }

    /** 24 column-major skin matrices, relative to the bind mesh coordinates. */
    public void pose(float time,int action,float speed,float[]out384){
        if(out384.length<384)throw new IllegalArgumentException("Pose output too small");
        Scratch w=SCRATCH.get();sampleLocalTRS(time,action,speed,w.t,w.q,w.s);
        for(int i=0;i<MAX_BONES;i++){
            int o=i*16;
            if(i>=boneCount){identity(out384,o);continue;}
            trs(w.local,w.t,i*3,w.q,i*4,w.s,i*3);
            Bone3D b=bones[i];
            if(b.parent<0)System.arraycopy(w.local,0,w.world,o,16);
            else multiply(w.world,b.parent*16,w.local,0,w.world,o);
            System.arraycopy(w.world,o,out384,o,16);
            out384[o+12]=w.world[o+12]-w.world[o]*b.x-w.world[o+4]*b.y-w.world[o+8]*b.z;
            out384[o+13]=w.world[o+13]-w.world[o+1]*b.x-w.world[o+5]*b.y-w.world[o+9]*b.z;
            out384[o+14]=w.world[o+14]-w.world[o+2]*b.x-w.world[o+6]*b.y-w.world[o+10]*b.z;
        }
    }
    public static void identity(float[]m,int o){for(int j=0;j<16;j++)m[o+j]=j%5==0?1:0;}
    private static void trs(float[]m,float[]t,int ti,float[]q,int qi,float[]s,int si){
        float x=q[qi],y=q[qi+1],z=q[qi+2],w=q[qi+3];
        float xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;
        m[0]=(1-2*(yy+zz))*s[si];m[1]=2*(xy+wz)*s[si];m[2]=2*(xz-wy)*s[si];m[3]=0;
        m[4]=2*(xy-wz)*s[si+1];m[5]=(1-2*(xx+zz))*s[si+1];m[6]=2*(yz+wx)*s[si+1];m[7]=0;
        m[8]=2*(xz+wy)*s[si+2];m[9]=2*(yz-wx)*s[si+2];m[10]=(1-2*(xx+yy))*s[si+2];m[11]=0;
        m[12]=t[ti];m[13]=t[ti+1];m[14]=t[ti+2];m[15]=1;
    }
    private static void multiply(float[]a,int ai,float[]b,int bi,float[]out,int oi){
        // Output is a different bone slot from both inputs.
        for(int c=0;c<4;c++)for(int r=0;r<4;r++)out[oi+c*4+r]=a[ai+r]*b[bi+c*4]+a[ai+4+r]*b[bi+c*4+1]+a[ai+8+r]*b[bi+c*4+2]+a[ai+12+r]*b[bi+c*4+3];
    }
}
