package org.genewars.android.gl3d;

/** Rigid skeletal joint. The bind pivot is expressed in model coordinates. */
public final class Bone3D {
    public static final int NONE=0, ROOT=1, SWING_X=2, SWING_Z=3, TAIL_Y=4,
            WING_Z=5, WORK_ARM_X=6, ROTOR_Y=7, ROTOR_Z=8, PULSE=9,
            PLANT_SWAY_Z=10, JAW_X=11, HEAD_Y=12, KNEE_X=13;
    public final String name;
    public final int parent, animation;
    public final float x,y,z,phase,amplitude;
    Bone3D(String name,int parent,float x,float y,float z,int animation,float phase,float amplitude) {
        this.name=name;this.parent=parent;this.x=x;this.y=y;this.z=z;
        this.animation=animation;this.phase=phase;this.amplitude=amplitude;
    }
}
