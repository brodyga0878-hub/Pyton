package org.genewars.android;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.widget.Button;

/** Small native drawing primitives for the HD interface; no web UI or image IO. */
final class ModernUiSkin {
    static final int INK = Color.rgb(8, 18, 27);
    static final int PANEL = Color.rgb(16, 36, 47);
    static final int WHITE = Color.rgb(232, 245, 244);
    static final int SECONDARY = Color.rgb(150, 180, 187);
    static final int AQUA = Color.rgb(92, 232, 202);
    static final int GOLD = Color.rgb(238, 189, 105);
    private ModernUiSkin() {}

    static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable panel(Context context, int top, int bottom, float radius) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{top, bottom});
        drawable.setCornerRadius(dp(context, radius));
        drawable.setStroke(dp(context, 1), Color.argb(65, 136, 202, 202));
        return drawable;
    }

    static void styleButton(Button button, boolean primary) {
        Context context = button.getContext();
        int top = primary ? Color.rgb(92, 232, 202) : Color.rgb(30, 59, 70);
        int bottom = primary ? Color.rgb(44, 172, 155) : Color.rgb(15, 36, 48);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{-android.R.attr.state_enabled},
                panel(context, Color.rgb(25, 38, 44), Color.rgb(17, 28, 34), 13));
        states.addState(new int[]{}, panel(context, top, bottom, 13));
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(70, 216, 255, 244)), states, null));
        button.setStateListAnimator(null);
        button.setElevation(dp(context, primary ? 5 : 2));
        button.setTextColor(new ColorStateList(new int[][]{
                new int[]{-android.R.attr.state_enabled},new int[]{}},
                new int[]{Color.rgb(80, 103, 113), primary ? Color.rgb(8, 37, 39) : WHITE}));
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setLetterSpacing(.015f);
        button.setAllCaps(false);
        button.setPadding(dp(context, 14), dp(context, 4), dp(context, 14), dp(context, 4));
    }

    static Drawable icon(Context context, String name) {
        return new CommandIcon(dp(context, 20), name);
    }

    static View menuBackdrop(Context context, AssetRepository repository) {
        return new Backdrop(context, repository);
    }

    private static final class Backdrop extends View {
        private final AssetRepository repository;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final RectF destination = new RectF();
        private int polls;
        private final Runnable refresh = new Runnable() {
            @Override public void run() {
                if (!isAttachedToWindow()) return;
                invalidate();
                if (repository.image("ui/keyart") == null && polls++ < 80) postDelayed(this, 250);
            }
        };
        Backdrop(Context context, AssetRepository repository) { super(context); this.repository = repository; }
        @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(refresh); }
        @Override protected void onDetachedFromWindow() { removeCallbacks(refresh); super.onDetachedFromWindow(); }
        @Override protected void onDraw(Canvas canvas) {
            int width = getWidth(), height = getHeight();
            paint.setShader(new LinearGradient(0, 0, width, height,
                    new int[]{Color.rgb(5, 15, 25), Color.rgb(16, 43, 52), Color.rgb(7, 19, 31)}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, width, height, paint); paint.setShader(null);
            Bitmap art = repository.image("ui/keyart");
            if (art != null) {
                float scale = Math.max(width / (float)art.getWidth(), height / (float)art.getHeight());
                float w = art.getWidth() * scale, h = art.getHeight() * scale;
                destination.set((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2);
                paint.setAlpha(230); canvas.drawBitmap(art, null, destination, paint); paint.setAlpha(255);
            } else {
                float x = width * .76f, y = height * .47f, radius = height * .44f;
                paint.setShader(new RadialGradient(x - radius * .3f, y - radius * .4f, radius * 1.3f,
                        new int[]{Color.rgb(74, 118, 103), Color.rgb(22, 72, 76), Color.rgb(4, 22, 35)}, null, Shader.TileMode.CLAMP));
                canvas.drawCircle(x, y, radius, paint); paint.setShader(null);
                paint.setColor(Color.argb(75, 121, 243, 211)); paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dp(getContext(), 1)); canvas.drawCircle(x, y, radius * 1.04f, paint);
                paint.setStyle(Paint.Style.FILL);
                for (int i = 0; i < 42; i++) {
                    float px = (i * 173.3f + 61) % width, py = (i * 79.7f + 23) % height;
                    paint.setColor(Color.argb(80 + i % 120, 192, 225, 227));
                    canvas.drawCircle(px, py, dp(getContext(), i % 5 == 0 ? 1.4f : .65f), paint);
                }
            }
            paint.setShader(new LinearGradient(0, 0, width, 0,
                    new int[]{Color.argb(250, 7, 18, 28), Color.argb(235, 7, 18, 28), Color.argb(70, 7, 18, 28)},
                    new float[]{0, .35f, 1}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, width, height, paint);
            paint.setShader(new LinearGradient(0, height * .7f, 0, height,
                    Color.TRANSPARENT, Color.argb(230, 7, 18, 28), Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, width, height, paint); paint.setShader(null);
        }
    }

    private static final class CommandIcon extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final String name;
        private final int size;
        CommandIcon(int size, String name) { this.size = size; this.name = name; }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds(); canvas.save(); canvas.translate(b.left, b.top); canvas.scale(b.width() / 24f, b.height() / 24f);
            paint.setColor(AQUA); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.65f);
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
            if (name.equals("Строить")) {
                canvas.drawRect(4, 10, 20, 20, paint); canvas.drawLine(3, 10, 12, 3, paint); canvas.drawLine(12, 3, 21, 10, paint);
                canvas.drawLine(9, 20, 9, 14, paint); canvas.drawLine(15, 20, 15, 14, paint);
            } else if (name.equals("Существа") || name.equals("Скрестить")) {
                path.reset(); path.moveTo(7, 3); path.cubicTo(7, 10, 17, 14, 17, 21); canvas.drawPath(path, paint);
                path.reset(); path.moveTo(17, 3); path.cubicTo(17, 10, 7, 14, 7, 21); canvas.drawPath(path, paint);
                canvas.drawLine(8, 6, 16, 6, paint); canvas.drawLine(10, 11, 14, 11, paint); canvas.drawLine(8, 18, 16, 18, paint);
            } else if (name.equals("Меню")) {
                for (int y = 6; y <= 18; y += 6) canvas.drawLine(4, y, 20, y, paint);
            } else if (name.equals("К отряду")) {
                canvas.drawCircle(12, 12, 7, paint); canvas.drawCircle(12, 12, 2, paint);
                canvas.drawLine(12, 2, 12, 6, paint); canvas.drawLine(12, 18, 12, 22, paint);
                canvas.drawLine(2, 12, 6, 12, paint); canvas.drawLine(18, 12, 22, 12, paint);
            } else if (name.equals("Поворот")) {
                canvas.drawArc(3, 4, 21, 20, 28, 294, false, paint);
                path.reset(); path.moveTo(18, 3); path.lineTo(20, 8); path.lineTo(15, 8); canvas.drawPath(path, paint);
                canvas.drawCircle(12, 12, 2.5f, paint);
            } else if (name.equals("Звук")) {
                path.reset(); path.moveTo(4, 9); path.lineTo(8, 9); path.lineTo(13, 5); path.lineTo(13, 19); path.lineTo(8, 15); path.lineTo(4, 15); path.close(); canvas.drawPath(path, paint);
                canvas.drawArc(11, 5, 22, 19, -65, 130, false, paint);
            } else if (name.equals("Пиксели") || name.equals("Детали")) {
                canvas.drawRoundRect(4, 4, 20, 20, 3, 3, paint); canvas.drawLine(4, 12, 20, 12, paint); canvas.drawLine(12, 4, 12, 20, paint);
            } else if (name.equals("×1")) {
                path.reset(); path.moveTo(5, 5); path.lineTo(12, 12); path.lineTo(5, 19); canvas.drawPath(path, paint);
                path.reset(); path.moveTo(13, 5); path.lineTo(20, 12); path.lineTo(13, 19); canvas.drawPath(path, paint);
            } else if (name.equals("Пауза")) {
                canvas.drawLine(8, 5, 8, 19, paint); canvas.drawLine(16, 5, 16, 19, paint);
            } else {
                canvas.drawCircle(12, 12, 7, paint); canvas.drawLine(12, 8, 12, 16, paint); canvas.drawLine(8, 12, 16, 12, paint);
            }
            canvas.restore();
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
