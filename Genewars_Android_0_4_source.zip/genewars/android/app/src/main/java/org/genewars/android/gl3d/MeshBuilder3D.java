package org.genewars.android.gl3d;

import java.util.ArrayList;
import java.util.Arrays;

/** Procedural solid primitives merged into one indexed, skinned vertex buffer. */
public final class MeshBuilder3D {
    private final String name;
    private float[] data=new float[8192];private int size;
    private int[] triangles=new int[4096];private int count;
    private final ArrayList<Bone3D>bones=new ArrayList<Bone3D>();
    public MeshBuilder3D(String name){this.name=name;bones.add(new Bone3D("root",-1,0,0,0,Bone3D.NONE,0,0));}
    public int bone(String name,int parent,float x,float y,float z,int animation,float phase,float amplitude){
        if(bones.size()>=24||parent<0||parent>=bones.size())throw new IllegalArgumentException("Invalid rig parent/count");
        bones.add(new Bone3D(name,parent,x,y,z,animation,phase,amplitude));return bones.size()-1;
    }
    public int boneCount(){return bones.size();}
    private int vertex(float x,float y,float z,float nx,float ny,float nz,float[]c,float u,float v,int bone){
        if(size+13>data.length)data=Arrays.copyOf(data,data.length*2);
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);if(len<1e-7f){nx=0;ny=1;nz=0;len=1;}
        int index=size/13;data[size++]=x;data[size++]=y;data[size++]=z;
        data[size++]=nx/len;data[size++]=ny/len;data[size++]=nz/len;
        for(int i=0;i<4;i++)data[size++]=Math.max(0,Math.min(1,c[i]));
        // Actor meshes have no image atlas: retain stride13 and use the former
        // UV pair for exact per-region PBR roughness and metallic values.
        data[size++]=c.length>4?Math.max(.12f,Math.min(1,c[4])):.72f;
        data[size++]=c.length>5?Math.max(0,Math.min(1,c[5])):0;
        data[size++]=bone;return index;
    }
    private void tri(int a,int b,int c){
        int ai=a*13,bi=b*13,ci=c*13;
        float ux=data[bi]-data[ai],uy=data[bi+1]-data[ai+1],uz=data[bi+2]-data[ai+2];
        float vx=data[ci]-data[ai],vy=data[ci+1]-data[ai+1],vz=data[ci+2]-data[ai+2];
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        if(nx*nx+ny*ny+nz*nz<1e-13f)return;
        if(count+3>triangles.length)triangles=Arrays.copyOf(triangles,triangles.length*2);
        float dot=nx*(data[ai+3]+data[bi+3]+data[ci+3])+ny*(data[ai+4]+data[bi+4]+data[ci+4])+nz*(data[ai+5]+data[bi+5]+data[ci+5]);
        triangles[count++]=a;triangles[count++]=dot<0?c:b;triangles[count++]=dot<0?b:c;
    }
    public void ellipsoid(float x,float y,float z,float rx,float ry,float rz,int segments,int rings,float[]c,int bone){
        if(rx<=0||ry<=0||rz<=0||segments<3||rings<3)throw new IllegalArgumentException("Invalid ellipsoid");
        int top=vertex(x,y+ry,z,0,1,0,c,.5f,0,bone),start=size/13;
        for(int r=1;r<rings;r++){
            double theta=Math.PI*r/rings;float sy=(float)Math.cos(theta),sr=(float)Math.sin(theta);
            for(int j=0;j<=segments;j++){
                double phi=2*Math.PI*j/segments;float sx=sr*(float)Math.cos(phi),sz=sr*(float)Math.sin(phi);
                vertex(x+sx*rx,y+sy*ry,z+sz*rz,sx/rx,sy/ry,sz/rz,c,(float)j/segments,(float)r/rings,bone);
            }
        }
        int bottom=vertex(x,y-ry,z,0,-1,0,c,.5f,1,bone);
        for(int j=0;j<segments;j++)tri(top,start+j+1,start+j);
        for(int r=0;r<rings-2;r++)for(int j=0;j<segments;j++){
            int a=start+r*(segments+1)+j,b=a+1,cc=a+segments+1,d=cc+1;tri(a,b,cc);tri(b,d,cc);
        }
        int last=start+(rings-2)*(segments+1);for(int j=0;j<segments;j++)tri(bottom,last+j,last+j+1);
    }
    public void cylinder(float ax,float ay,float az,float bx,float by,float bz,float ra,float rb,int segments,float[]c,int bone){
        float dx=bx-ax,dy=by-ay,dz=bz-az,len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len<1e-6f||segments<3||ra<0||rb<0||ra+rb<=0)throw new IllegalArgumentException("Invalid cylinder");
        float wx=dx/len,wy=dy/len,wz=dz/len;
        float ux,uy,uz;if(Math.abs(wy)<.9f){ux=wz;uy=0;uz=-wx;}else{ux=0;uy=-wz;uz=wy;}
        float ul=(float)Math.sqrt(ux*ux+uy*uy+uz*uz);ux/=ul;uy/=ul;uz/=ul;
        float vx=wy*uz-wz*uy,vy=wz*ux-wx*uz,vz=wx*uy-wy*ux;
        int start=size/13;
        for(int j=0;j<=segments;j++){
            double phi=2*Math.PI*j/segments;float co=(float)Math.cos(phi),si=(float)Math.sin(phi);
            float rx=ux*co+vx*si,ry=uy*co+vy*si,rz=uz*co+vz*si;
            float nx=rx*len+wx*(ra-rb),ny=ry*len+wy*(ra-rb),nz=rz*len+wz*(ra-rb);
            vertex(ax+rx*ra,ay+ry*ra,az+rz*ra,nx,ny,nz,c,(float)j/segments,0,bone);
            vertex(bx+rx*rb,by+ry*rb,bz+rz*rb,nx,ny,nz,c,(float)j/segments,1,bone);
        }
        for(int j=0;j<segments;j++){int a=start+j*2;tri(a,a+2,a+1);tri(a+1,a+2,a+3);}
        cap(ax,ay,az,-wx,-wy,-wz,ux,uy,uz,vx,vy,vz,ra,segments,c,bone);
        cap(bx,by,bz,wx,wy,wz,ux,uy,uz,vx,vy,vz,rb,segments,c,bone);
    }
    /** Smooth volume along any axis, used for muscles, branches and leaves. */
    public void ellipsoidBetween(float ax,float ay,float az,float bx,float by,float bz,float width,float depth,int segments,int rings,float[]c,int bone){
        float dx=bx-ax,dy=by-ay,dz=bz-az,len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len<1e-5f||width<=0||depth<=0)throw new IllegalArgumentException("Invalid oriented ellipsoid");
        float wx=dx/len,wy=dy/len,wz=dz/len;
        float ux,uy,uz;if(Math.abs(wy)<.9f){ux=wz;uy=0;uz=-wx;}else{ux=0;uy=-wz;uz=wy;}
        float ul=(float)Math.sqrt(ux*ux+uy*uy+uz*uz);ux/=ul;uy/=ul;uz/=ul;
        float vx=wy*uz-wz*uy,vy=wz*ux-wx*uz,vz=wx*uy-wy*ux;
        float cx=(ax+bx)*.5f,cy=(ay+by)*.5f,cz=(az+bz)*.5f,half=len*.5f;
        int top=vertex(bx,by,bz,wx,wy,wz,c,.5f,0,bone),start=size/13;
        for(int r=1;r<rings;r++){
            double theta=Math.PI*r/rings;float sy=(float)Math.cos(theta),sr=(float)Math.sin(theta);
            for(int j=0;j<=segments;j++){
                double phi=2*Math.PI*j/segments;float sx=sr*(float)Math.cos(phi),sz=sr*(float)Math.sin(phi);
                vertex(cx+ux*sx*width+wx*sy*half+vx*sz*depth,cy+uy*sx*width+wy*sy*half+vy*sz*depth,cz+uz*sx*width+wz*sy*half+vz*sz*depth,
                    ux*sx/width+wx*sy/half+vx*sz/depth,uy*sx/width+wy*sy/half+vy*sz/depth,uz*sx/width+wz*sy/half+vz*sz/depth,c,(float)j/segments,(float)r/rings,bone);
            }
        }
        int bottom=vertex(ax,ay,az,-wx,-wy,-wz,c,.5f,1,bone);
        for(int j=0;j<segments;j++)tri(top,start+j+1,start+j);
        for(int r=0;r<rings-2;r++)for(int j=0;j<segments;j++){int a=start+r*(segments+1)+j,b=a+1,cc=a+segments+1;tri(a,b,cc);tri(b,cc,cc+1);}
        int last=start+(rings-2)*(segments+1);for(int j=0;j<segments;j++)tri(bottom,last+j,last+j+1);
    }
    private void cap(float x,float y,float z,float nx,float ny,float nz,float ux,float uy,float uz,float vx,float vy,float vz,float radius,int segments,float[]c,int bone){
        if(radius<1e-6f)return;int center=vertex(x,y,z,nx,ny,nz,c,.5f,.5f,bone),start=size/13;
        for(int j=0;j<=segments;j++){double p=2*Math.PI*j/segments;float co=(float)Math.cos(p),si=(float)Math.sin(p);
            vertex(x+radius*(ux*co+vx*si),y+radius*(uy*co+vy*si),z+radius*(uz*co+vz*si),nx,ny,nz,c,.5f+.5f*co,.5f+.5f*si,bone);}
        for(int j=0;j<segments;j++)tri(center,start+j,start+j+1);
    }
    public void quad(float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz,float[]color,int bone){
        float ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az;
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        int a=vertex(ax,ay,az,nx,ny,nz,color,0,0,bone),b=vertex(bx,by,bz,nx,ny,nz,color,1,0,bone),c=vertex(cx,cy,cz,nx,ny,nz,color,1,1,bone),d=vertex(dx,dy,dz,nx,ny,nz,color,0,1,bone);
        tri(a,b,c);tri(a,c,d);
    }
    public void box(float x,float y,float z,float sx,float sy,float sz,float[]c,int bone){
        float l=x-sx/2,r=x+sx/2,b=y-sy/2,t=y+sy/2,n=z-sz/2,f=z+sz/2;
        quad(l,b,n,l,t,n,r,t,n,r,b,n,c,bone);quad(r,b,f,r,t,f,l,t,f,l,b,f,c,bone);
        quad(l,b,f,l,t,f,l,t,n,l,b,n,c,bone);quad(r,b,n,r,t,n,r,t,f,r,b,f,c,bone);
        quad(l,t,n,l,t,f,r,t,f,r,t,n,c,bone);quad(l,b,f,l,b,n,r,b,n,r,b,f,c,bone);
    }
    public MeshData3D finish(){
        if(size==0||count==0||size/13>=65536)throw new IllegalStateException("Empty/oversized mesh");
        return new MeshData3D(name,Arrays.copyOf(data,size),Arrays.copyOf(triangles,count),bones.toArray(new Bone3D[bones.size()]));
    }
}
