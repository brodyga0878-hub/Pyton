// SPDX-License-Identifier: GPL-2.0-or-later
package org.genewars.android.gl3d;

/**
 * Native, fully volumetric building meshes. Every family has a distinct silhouette
 * and functioning mechanical rig; no sprite, camera-facing quad or imported DOS
 * executable is used. Materials encode sRGB, emission, roughness and metallic.
 */
public final class BuildingModels3D {
    private static final float PI = (float) Math.PI;
    private static final float[] IVORY = {.58f, .61f, .59f, 0, .42f, .35f};
    private static final float[] WHITE = {.73f, .75f, .72f, 0, .58f, .20f};
    private static final float[] DARK = {.085f, .10f, .11f, 0, .30f, .82f};
    private static final float[] METAL = {.27f, .30f, .31f, 0, .24f, .90f};
    private static final float[] COPPER = {.47f, .27f, .13f, 0, .25f, .90f};
    private static final float[] CYAN = {.07f, .39f, .48f, .24f, .22f, .05f};
    private static final float[] BLUE = {.055f, .095f, .13f, .025f, .19f, .15f};
    private static final float[] GREEN = {.12f, .22f, .15f, .015f, .28f, .15f};
    private static final float[] LIME = {.25f, .44f, .16f, .08f, .30f, .05f};
    private static final float[] AMBER = {.65f, .40f, .10f, .18f, .22f, .05f};
    private static final float[] WOOD = {.24f, .17f, .10f, 0, .88f, 0};
    private static final float[] WOOD_END = {.46f, .37f, .24f, 0, .92f, 0};
    private static final float[] CONCRETE = {.37f, .38f, .35f, 0, .85f, 0};
    private static final float[] RUBBER = {.045f, .052f, .047f, 0, .82f, 0};
    private static final float[] CERAMIC = {.66f, .65f, .59f, 0, .26f, .03f};
    private static final float[] YELLOW = {.57f, .43f, .12f, 0, .52f, .25f};

    private BuildingModels3D() {}

    /** Ordinals are the native Building.Kind order, not the old retail type ID. */
    public static MeshData3D build(int ordinal) {
        if (ordinal < 0 || ordinal >= 14) throw new IllegalArgumentException("Building ordinal");
        MeshBuilder3D b = new MeshBuilder3D("building_" + ordinal);
        switch (ordinal) {
            case 0: extractor(b); break;
            case 1: distributor(b); break;
            case 2: solar(b); break;
            case 3: geneLab(b); break;
            case 4: recycler(b); break;
            case 5: turret(b); break;
            case 6: pulper(b); break;
            case 7: landingPad(b); break;
            case 8: detector(b); break;
            case 9: wind(b); break;
            case 10: fusion(b); break;
            case 11: technicalCenter(b); break;
            case 12: shield(b); break;
            default: vat(b);
        }
        industrialDetails(b, ordinal);
        return b.finish();
    }

    private static void foundation(MeshBuilder3D b, float radius) {
        b.cylinder(0, .09f, 0, 0, .24f, 0, radius, radius * .96f, 12, CONCRETE, 0);
        b.cylinder(0, .24f, 0, 0, .29f, 0, radius * .84f, radius * .84f, 12, DARK, 0);
        for (int i = 0; i < 4; i++) {
            float a = PI * .25f + i * PI * .5f;
            float x = cos(a) * radius, z = sin(a) * radius;
            b.box(x, .075f, z, .27f, .15f, .28f, CONCRETE, 0);
            b.box(x, .159f, z, .23f, .018f, .24f, METAL, 0);
            b.cylinder(x * .66f, .25f, z * .66f, x, .18f, z, .054f, .054f, 7, METAL, 0);
            boltY(b, x-.067f, .175f, z-.069f, 0);
            boltY(b, x+.067f, .175f, z+.069f, 0);
            b.box(x * .84f, .275f, z * .84f, .042f, .019f, .045f, YELLOW, 0);
        }
        ringY(b, 0, .255f, 0, radius * .84f, .018f, 12, METAL, 0);
    }

    private static void extractor(MeshBuilder3D b) {
        foundation(b, .73f);
        int drill = b.bone("auger", 0, 0, .65f, .05f, Bone3D.ROTOR_Y, 0, 1.65f);
        for (int side = -1; side <= 1; side += 2) {
            b.cylinder(side * .45f, .28f, -.10f, side * .40f, 1.65f, -.06f,
                    .12f, .085f, 8, IVORY, 0);
            b.cylinder(side * .47f, .4f, .03f, side * .42f, 1.5f, .03f,
                    .034f, .034f, 6, COPPER, 0);
        }
        b.cylinder(-.44f, 1.64f, -.06f, .44f, 1.64f, -.06f, .15f, .15f, 8, METAL, 0);
        b.ellipsoid(0, 1.48f, .02f, .28f, .28f, .25f, 12, 7, IVORY, 0);
        b.cylinder(0, .28f, .05f, 0, 1.35f, .05f, .10f, .10f, 10, DARK, drill);
        for (int i = 0; i < 7; i++) {
            float y = .34f + i * .13f;
            b.cylinder(0, y, .05f, 0, y + .09f, .05f, .23f, .13f, 10, COPPER, drill);
        }
        b.cylinder(0, .17f, .05f, 0, .37f, .05f, .025f, .20f, 10, METAL, drill);
        b.box(.49f, .37f, .46f, .40f, .22f, .37f, DARK, 0);
        for (int i = 0; i < 5; i++)
            b.ellipsoid(.35f + .065f * i, .54f + .025f * (i % 2), .44f,
                    .09f, .075f, .08f, 6, 3, COPPER, 0);
        b.cylinder(-.48f, .32f, -.37f, -.48f, 1.91f, -.37f, .09f, .075f, 8, DARK, 0);
        ringY(b, -.48f, 1.80f, -.37f, .095f, .028f, 8, AMBER, 0);
        frontGauge(b, .27f, .78f, .29f, 0);
    }

    private static void distributor(MeshBuilder3D b) {
        foundation(b, .77f);
        int pulse = b.bone("plasma_node", 0, 0, 1.35f, 0, Bone3D.PULSE, 0, .045f);
        b.cylinder(0, .30f, 0, 0, 1.28f, 0, .31f, .18f, 12, IVORY, 0);
        b.ellipsoid(0, 1.42f, 0, .24f, .30f, .24f, 12, 8, CYAN, pulse);
        b.cylinder(0, 1.65f, 0, 0, 2.28f, 0, .07f, .025f, 8, DARK, 0);
        b.ellipsoid(0, 2.28f, 0, .06f, .065f, .06f, 8, 4, CYAN, pulse);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3 + PI / 2;
            float x = cos(a) * .53f, z = sin(a) * .53f;
            b.cylinder(x, .27f, z, x, 1.72f, z, .15f, .10f, 10, DARK, 0);
            for (int j = 0; j < 6; j++) ringY(b, x, .58f + j * .15f, z, .14f, .033f, 9, COPPER, 0);
            b.ellipsoid(x, 1.78f, z, .13f, .10f, .13f, 10, 5, IVORY, 0);
            b.cylinder(x, .42f, z, x * .35f, .58f, z * .35f, .065f, .065f, 7, METAL, 0);
        }
        frontGauge(b, 0, .8f, .27f, 0);
    }

    private static void solar(MeshBuilder3D b) {
        foundation(b, .66f);
        b.cylinder(0, .3f, 0, 0, 1.12f, 0, .18f, .11f, 10, IVORY, 0);
        int core = b.bone("collector_core", 0, 0, 1.17f, 0, Bone3D.PULSE, 0, .035f);
        int tracking = b.bone("solar_tracking", 0, 0, 1.12f, 0, Bone3D.ROTOR_Y, 0, .035f);
        b.ellipsoid(0, 1.15f, 0, .20f, .24f, .20f, 12, 6, CYAN, core);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3 + .15f;
            float ux = cos(a), uz = sin(a), vx = -uz, vz = ux;
            float x0 = ux * .12f, z0 = uz * .12f;
            float x1 = ux * .95f, z1 = uz * .95f;
            panel(b, x0, 1.12f, z0, x1, 1.70f, z1, vx * .28f, vz * .28f, BLUE, tracking);
            b.cylinder(x0, 1.1f, z0, x1, 1.72f, z1, .025f, .025f, 5, IVORY, tracking);
            for (int j = 1; j <= 4; j++) {
                float t = j / 5f, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
                float y = 1.12f + .58f * t + .027f;
                b.cylinder(x - vx * .26f, y, z - vz * .26f, x + vx * .26f, y, z + vz * .26f,
                        .005f, .005f, 4, METAL, tracking);
            }
            b.cylinder(ux * .2f, .43f, uz * .2f, ux * .68f, 1.48f, uz * .68f,
                    .04f, .03f, 6, COPPER, tracking);
        }
    }

    private static void geneLab(MeshBuilder3D b) {
        foundation(b, .79f);
        int pulse = b.bone("nutrient_vessel", 0, 0, 1.05f, 0, Bone3D.PULSE, .3f, .025f);
        b.ellipsoid(0, 1.04f, 0, .48f, .75f, .48f, 14, 9, GREEN, pulse);
        b.cylinder(0, .30f, 0, 0, .47f, 0, .56f, .52f, 12, IVORY, 0);
        b.cylinder(0, 1.68f, 0, 0, 1.84f, 0, .46f, .29f, 12, IVORY, 0);
        b.ellipsoid(0, 1.92f, 0, .21f, .25f, .21f, 10, 6, WHITE, 0);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2 + PI / 4;
            float x = cos(a), z = sin(a);
            b.cylinder(x * .56f, .37f, z * .56f, x * .44f, 1.62f, z * .44f, .055f, .045f, 7, IVORY, 0);
            b.cylinder(x * .62f, .35f, z * .62f, x * .60f, 1.18f, z * .60f, .035f, .035f, 6, COPPER, 0);
        }
        // An embossed double helix sits in front of the opaque nutrient surface.
        for (int i = 0; i < 12; i++) {
            float a = i * .62f, aa = (i + 1) * .62f;
            float y = .58f + i * .077f, yy = y + .077f;
            for (int strand = 0; strand < 2; strand++) {
                float phase = strand * PI;
                b.cylinder(sin(a + phase) * .20f, y, .46f, sin(aa + phase) * .20f, yy, .46f,
                        .018f, .018f, 5, strand == 0 ? CYAN : AMBER, pulse);
            }
            if ((i & 1) == 0) b.cylinder(-.16f, y, .463f, .16f, y, .463f, .009f, .009f, 4, IVORY, pulse);
        }
        sideVial(b, -.65f, .8f, .17f, .12f, AMBER);
        sideVial(b, .65f, .8f, .17f, .12f, LIME);
    }

    private static void recycler(MeshBuilder3D b) {
        foundation(b, .80f);
        int pulse = b.bone("digestor", 0, -.22f, .98f, -.12f, Bone3D.PULSE, 1.2f, .02f);
        b.ellipsoid(-.22f, .95f, -.12f, .43f, .65f, .43f, 12, 8, GREEN, pulse);
        ringY(b, -.22f, .49f, -.12f, .44f, .04f, 12, IVORY, 0);
        ringY(b, -.22f, 1.39f, -.12f, .37f, .05f, 12, IVORY, 0);
        b.ellipsoid(-.22f, 1.58f, -.12f, .24f, .14f, .24f, 10, 5, IVORY, 0);
        for (int i = 0; i < 3; i++) sideVial(b, .47f, .64f, -.4f + i * .35f, .15f, LIME);
        b.cylinder(-.25f, .39f, .28f, -.25f, .70f, .44f, .12f, .12f, 8, METAL, 0);
        panel(b, -.25f, .40f, .85f, -.25f, .66f, .27f, .30f, 0, DARK, 0);
        for (int i = 0; i < 5; i++) {
            float z = .35f + i * .12f, y = .64f - i * .05f;
            b.cylinder(-.53f, y, z, .03f, y, z, .027f, .027f, 6, METAL, 0);
        }
        b.cylinder(.35f, .44f, -.48f, .35f, 1.62f, -.48f, .065f, .065f, 8, METAL, 0);
        b.cylinder(.35f, 1.62f, -.48f, -.17f, 1.62f, -.48f, .065f, .065f, 8, COPPER, 0);
        frontGauge(b, .44f, .92f, .3f, 0);
    }

    private static void turret(MeshBuilder3D b) {
        foundation(b, .70f);
        b.cylinder(0, .3f, 0, 0, 1.09f, 0, .30f, .22f, 12, IVORY, 0);
        int head = b.bone("turret_tracking", 0, 0, 1.12f, 0, Bone3D.TAIL_Y, .2f, .35f);
        int recoil = b.bone("weapon_pitch", head, 0, 1.28f, .04f, Bone3D.WORK_ARM_X, 0, .08f);
        b.ellipsoid(0, 1.26f, .07f, .43f, .25f, .37f, 12, 7, IVORY, head);
        b.ellipsoid(0, 1.20f, -.27f, .29f, .15f, .18f, 10, 5, DARK, head);
        for (int side = -1; side <= 1; side += 2) {
            float x = side * .17f;
            b.cylinder(x, 1.27f, .15f, x, 1.27f, .95f, .105f, .075f, 10, DARK, recoil);
            b.cylinder(x, 1.27f, .83f, x, 1.27f, 1.0f, .13f, .12f, 10, IVORY, recoil);
            ringZ(b, x, 1.27f, .95f, .12f, .021f, 10, CYAN, recoil);
            b.cylinder(x, 1.27f, .988f, x, 1.27f, 1.01f, .070f, .070f, 8, RUBBER, recoil);
        }
        b.ellipsoid(-.29f, 1.42f, .25f, .075f, .075f, .07f, 8, 5, CYAN, head);
        b.cylinder(.30f, 1.37f, -.12f, .30f, 1.80f, -.12f, .023f, .015f, 6, DARK, head);
        b.ellipsoid(.30f, 1.81f, -.12f, .04f, .04f, .04f, 6, 3, AMBER, head);
    }

    private static void pulper(MeshBuilder3D b) {
        foundation(b, .80f);
        b.box(0, .62f, -.15f, 1.04f, .70f, .72f, IVORY, 0);
        b.box(0, .69f, .23f, .76f, .45f, .10f, DARK, 0);
        int wheel = b.bone("sawwheel", 0, 0, .91f, .30f, Bone3D.ROTOR_Z, 0, 2.8f);
        b.cylinder(0, .91f, .29f, 0, .91f, .38f, .43f, .43f, 16, METAL, wheel);
        b.cylinder(0, .91f, .38f, 0, .91f, .41f, .12f, .12f, 10, COPPER, wheel);
        for (int i = 0; i < 18; i++) {
            float a = i * PI * 2 / 18;
            float[] tooth={cos(a-.075f)*.40f,.91f+sin(a-.075f)*.40f,.40f,
                           cos(a-.017f)*.51f,.91f+sin(a-.017f)*.51f,.40f,
                           cos(a+.017f)*.51f,.91f+sin(a+.017f)*.51f,.40f,
                           cos(a+.075f)*.40f,.91f+sin(a+.075f)*.40f,.40f};
            prismZ(b,tooth,.065f,METAL,wheel);
        }
        for (int i = 0; i < 4; i++) {
            float y = .34f + (i % 2) * .18f, z = .52f + (i / 2) * .19f;
            b.cylinder(-.72f, y, z, .21f, y, z, .095f, .085f, 8, WOOD, 0);
            b.cylinder(.20f, y, z, .23f, y, z, .07f, .07f, 8, WOOD_END, 0);
        }
        b.cylinder(-.39f, .95f, -.30f, -.39f, 1.85f, -.30f, .075f, .07f, 8, DARK, 0);
        for (int i = 0; i < 3; i++) ringY(b, -.39f, 1.34f + .16f * i, -.30f, .079f, .025f, 8, COPPER, 0);
        frontGauge(b, .43f, .78f, .27f, 0);
    }

    private static void landingPad(MeshBuilder3D b) {
        b.cylinder(0, .05f, 0, 0, .18f, 0, .97f, .97f, 12, DARK, 0);
        b.cylinder(0, .18f, 0, 0, .23f, 0, .83f, .83f, 12, METAL, 0);
        ringY(b, 0, .245f, 0, .76f, .025f, 18, AMBER, 0);
        int pulse = b.bone("landing_beacon", 0, 0, .3f, 0, Bone3D.PULSE, 1, .04f);
        for (int i = 0; i < 8; i++) {
            float a = i * PI / 4;
            b.ellipsoid(cos(a) * .87f, .24f, sin(a) * .87f, .045f, .045f, .045f, 6, 4, CYAN, pulse);
        }
        b.cylinder(0, .36f, 0, 0, 1.50f, 0, .18f, .18f, 12, IVORY, 0);
        b.cylinder(0, 1.5f, 0, 0, 2.11f, 0, .18f, .018f, 12, WHITE, 0);
        b.cylinder(0, .28f, 0, 0, .53f, 0, .17f, .11f, 10, DARK, 0);
        b.ellipsoid(0, .30f, 0, .105f, .08f, .105f, 8, 4, CYAN, pulse);
        ringY(b, 0, .65f, 0, .185f, .022f, 12, COPPER, 0);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2, x = cos(a), z = sin(a);
            b.cylinder(x * .09f, .56f, z * .09f, x * .40f, .25f, z * .40f, .055f, .07f, 6, IVORY, 0);
            blade(b, x * .16f, .52f, z * .16f, x * .42f, .26f, z * .42f, .12f, DARK, 0);
        }
        frontGauge(b, 0, 1.2f, .182f, 0);
    }

    private static void detector(MeshBuilder3D b) {
        foundation(b, .73f);
        b.cylinder(0, .3f, 0, 0, 1.38f, 0, .28f, .14f, 12, IVORY, 0);
        int dish = b.bone("observatory_scan", 0, 0, 1.38f, 0, Bone3D.ROTOR_Y, 0, .18f);
        dish(b, 0, 1.43f, 0, .65f, .39f, IVORY, dish);
        ringY(b, 0, 1.82f, 0, .65f, .035f, 16, COPPER, dish);
        b.cylinder(-.49f, 1.71f, -.13f, .04f, 2.13f, .04f, .035f, .025f, 7, DARK, dish);
        b.ellipsoid(.04f, 2.14f, .04f, .10f, .08f, .10f, 10, 5, CYAN, dish);
        b.cylinder(.53f, .3f, -.33f, .53f, 1.67f, -.33f, .10f, .07f, 8, METAL, 0);
        b.cylinder(.53f, 1.67f, -.33f, .53f, 2.28f, -.33f, .025f, .013f, 6, COPPER, 0);
        b.ellipsoid(.53f, 2.29f, -.33f, .05f, .055f, .05f, 6, 4, AMBER, 0);
        frontGauge(b, 0, .8f, .24f, 0);
    }

    private static void wind(MeshBuilder3D b) {
        foundation(b, .60f);
        b.cylinder(0, .3f, 0, 0, 1.66f, 0, .13f, .095f, 10, IVORY, 0);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3;
            b.cylinder(cos(a) * .45f, .24f, sin(a) * .45f, 0, 1.28f, 0,
                    .055f, .035f, 6, COPPER, 0);
        }
        int rotor = b.bone("wind_rotor", 0, 0, 1.65f, .18f, Bone3D.ROTOR_Z, 0, 1.6f);
        b.cylinder(0, 1.65f, .05f, 0, 1.65f, .32f, .13f, .13f, 10, METAL, rotor);
        b.ellipsoid(0, 1.65f, .34f, .14f, .14f, .12f, 10, 6, CYAN, rotor);
        for (int i = 0; i < 3; i++) {
            float a = i * PI * 2 / 3;
            float ux = cos(a), uy = sin(a), vx = -uy, vy = ux;
            // A thick closed aerodynamic blade in the XY rotor plane.
            float[] p = {ux*.12f + vx*.10f,1.65f+uy*.12f+vy*.10f,.22f,
                         ux*.76f + vx*.055f,1.65f+uy*.76f+vy*.055f,.27f,
                         ux*.76f - vx*.055f,1.65f+uy*.76f-vy*.055f,.27f,
                         ux*.12f - vx*.10f,1.65f+uy*.12f-vy*.10f,.22f};
            prismZ(b, p, .055f, IVORY, rotor);
            b.cylinder(ux*.17f,1.65f+uy*.17f,.283f, ux*.70f,1.65f+uy*.70f,.316f,
                    .009f,.006f,5,METAL,rotor);
        }
    }

    private static void fusion(MeshBuilder3D b) {
        foundation(b, .82f);
        int pulse = b.bone("fusion_plasma", 0, 0, 1.02f, 0, Bone3D.PULSE, 0, .08f);
        int ring = b.bone("containment_ring", 0, 0, 1.04f, 0, Bone3D.ROTOR_Y, 0, .55f);
        b.ellipsoid(0, 1.02f, 0, .46f, .55f, .46f, 16, 10, CYAN, pulse);
        ringY(b, 0, .68f, 0, .53f, .075f, 16, COPPER, 0);
        ringY(b, 0, 1.37f, 0, .53f, .075f, 16, COPPER, 0);
        ringY(b, 0, 1.03f, 0, .65f, .045f, 18, METAL, ring);
        for (int i = 0; i < 4; i++) {
            float a = i * PI / 2 + PI / 4, x = cos(a), z = sin(a);
            b.cylinder(x*.67f,.31f,z*.67f,x*.62f,1.34f,z*.62f,.11f,.08f,8,IVORY,0);
            b.cylinder(x*.62f,1.34f,z*.62f,x*.33f,1.66f,z*.33f,.08f,.07f,8,IVORY,0);
            b.ellipsoid(x*.66f,1.03f,z*.66f,.09f,.13f,.09f,8,5,AMBER,ring);
        }
        b.cylinder(0,1.56f,0,0,1.74f,0,.28f,.20f,12,DARK,0);
        b.cylinder(0,1.74f,0,0,2.03f,0,.09f,.07f,10,IVORY,0);
        ringY(b,0,1.88f,0,.11f,.024f,10,CYAN,0);
    }

    private static void technicalCenter(MeshBuilder3D b) {
        foundation(b, .86f);
        taperedTower(b, .52f, .43f, .33f, .32f, .29f, 1.76f, IVORY, 0);
        b.cylinder(0,1.76f,0,0,1.90f,0,.38f,.32f,12,DARK,0);
        for(int row=0;row<3;row++) {
            float y=.66f+row*.31f, z=.43f-(y-.29f)/1.47f*.11f+.012f;
            for(int col=-1;col<=1;col++) {
                float x=col*.22f;
                b.quad(x-.075f,y-.06f,z,x+.075f,y-.06f,z,
                        x+.075f,y+.06f,z-.01f,x-.075f,y+.06f,z-.01f,BLUE,0);
            }
        }
        for(int side=-1;side<=1;side+=2) {
            b.ellipsoid(side*.62f,.60f,-.13f,.22f,.35f,.30f,10,6,METAL,0);
            b.cylinder(side*.63f,.45f,.15f,side*.63f,1.16f,.15f,.035f,.03f,6,COPPER,0);
        }
        b.cylinder(-.16f,1.84f,0,-.16f,2.36f,0,.025f,.012f,6,DARK,0);
        b.ellipsoid(-.16f,2.37f,0,.05f,.045f,.05f,6,4,CYAN,0);
        b.cylinder(.18f,1.84f,0,.18f,2.15f,0,.03f,.02f,6,COPPER,0);
        int pulse=b.bone("operations_beacon",0,.18f,2.15f,0,Bone3D.PULSE,2,.05f);
        b.ellipsoid(.18f,2.18f,0,.075f,.07f,.075f,8,4,AMBER,pulse);
    }

    private static void shield(MeshBuilder3D b) {
        foundation(b, .79f);
        int pulse=b.bone("shield_focus",0,0,1.45f,0,Bone3D.PULSE,0,.065f);
        b.ellipsoid(0,1.45f,0,.25f,.35f,.25f,12,8,CYAN,pulse);
        b.cylinder(0,.29f,0,0,.75f,0,.26f,.17f,10,DARK,0);
        ringY(b,0,.65f,0,.29f,.055f,12,COPPER,0);
        for(int i=0;i<4;i++) {
            float a=i*PI/2,ux=cos(a),uz=sin(a);
            float px=ux*.63f,py=.31f,pz=uz*.63f;
            for(int j=1;j<=5;j++) {
                float t=j/5f, r=.63f*(1-t*.72f),y=.31f+1.75f*t;
                float x=ux*r,z=uz*r;
                b.cylinder(px,py,pz,x,y,z,.085f,.065f,7,IVORY,0);
                if(j==3) b.ellipsoid(x,y,z,.085f,.10f,.085f,7,4,CYAN,pulse);
                px=x;py=y;pz=z;
            }
        }
        ringY(b,0,2.07f,0,.19f,.045f,12,COPPER,0);
        b.ellipsoid(0,2.12f,0,.15f,.13f,.15f,10,6,CYAN,pulse);
    }

    private static void vat(MeshBuilder3D b) {
        foundation(b,.80f);
        int pulse=b.bone("storage_biogel",0,0,.99f,0,Bone3D.PULSE,1,.018f);
        b.cylinder(0,.34f,0,0,1.44f,0,.58f,.58f,16,GREEN,pulse);
        b.cylinder(0,.31f,0,0,.43f,0,.65f,.63f,16,IVORY,0);
        b.cylinder(0,1.38f,0,0,1.52f,0,.63f,.60f,16,IVORY,0);
        b.ellipsoid(0,1.53f,0,.59f,.23f,.59f,14,7,IVORY,0);
        for(int i=0;i<6;i++) {
            float a=i*PI/3,x=cos(a)*.60f,z=sin(a)*.60f;
            b.cylinder(x,.40f,z,x,1.43f,z,.035f,.035f,6,COPPER,0);
        }
        for(int i=0;i<4;i++) {
            float y=.55f+i*.20f;
            b.ellipsoid(.14f*sin(i*1.6f),y,.575f,.075f,.055f,.025f,8,4,LIME,pulse);
        }
        b.cylinder(0,1.70f,0,0,1.90f,0,.065f,.065f,8,METAL,0);
        int valve=b.bone("pressure_valve",0,0,1.91f,0,Bone3D.ROTOR_Y,0,.27f);
        ringY(b,0,1.91f,0,.19f,.027f,12,COPPER,valve);
        for(int i=0;i<3;i++) {
            float a=i*PI*2/3;
            b.cylinder(0,1.91f,0,cos(a)*.18f,1.91f,sin(a)*.18f,.02f,.02f,5,IVORY,valve);
        }
        b.cylinder(.57f,.57f,-.12f,.81f,.57f,-.12f,.07f,.07f,8,DARK,0);
        b.cylinder(.81f,.57f,-.12f,.81f,1.20f,-.12f,.07f,.07f,8,COPPER,0);
        b.cylinder(.81f,1.20f,-.12f,.57f,1.20f,-.12f,.07f,.07f,8,DARK,0);
        b.ellipsoid(.81f,.57f,-.12f,.078f,.078f,.078f,8,5,METAL,0);
        b.ellipsoid(.81f,1.20f,-.12f,.078f,.078f,.078f,8,5,METAL,0);
    }

    /** Construction and service details share the family's existing rigid joints. */
    private static void industrialDetails(MeshBuilder3D b,int kind) {
        switch(kind) {
            case 0:
                for(int side=-1;side<=1;side+=2) {
                    b.cylinder(side*.42f,.40f,-.22f,-side*.39f,1.51f,-.22f,.026f,.026f,6,METAL,0);
                    boltZ(b,side*.40f,1.63f,.095f,0);
                    b.cylinder(side*.44f,.38f,-.13f,side*.41f,1.06f,-.13f,.067f,.067f,8,METAL,0);
                    b.cylinder(side*.41f,1.02f,-.13f,side*.40f,1.49f,-.13f,.028f,.028f,8,WHITE,0);
                }
                for(int i=0;i<5;i++) b.cylinder(-.65f,.49f+i*.23f,-.09f,-.51f,.49f+i*.23f,-.09f,.014f,.014f,6,METAL,0);
                b.cylinder(-.65f,.40f,-.09f,-.65f,1.48f,-.09f,.018f,.018f,6,METAL,0);
                b.cylinder(-.51f,.40f,-.09f,-.51f,1.48f,-.09f,.018f,.018f,6,METAL,0);
                b.box(0,1.48f,-.24f,.43f,.25f,.20f,DARK,0);
                vents(b,0,1.48f,-.129f,.32f,.14f,5,0);
                b.cylinder(.49f,.49f,.27f,.49f,.49f,.67f,.018f,.018f,6,METAL,0);
                b.cylinder(.30f,.49f,.64f,.69f,.49f,.64f,.018f,.018f,6,METAL,0);
                b.cylinder(.0f,.38f,-.30f,.28f,.63f,-.30f,.023f,.023f,6,RUBBER,0);
                b.cylinder(.28f,.63f,-.30f,.28f,1.31f,-.30f,.023f,.023f,6,RUBBER,0);
                break;
            case 1:
                flangeY(b,0,.35f,0,.33f,0);
                for(int i=0;i<3;i++) {
                    float a=i*PI*2/3+PI/2,aa=(i+1)*PI*2/3+PI/2;
                    float x=cos(a)*.53f,z=sin(a)*.53f;
                    b.cylinder(x,1.55f,z,x,1.67f,z,.13f,.13f,10,CERAMIC,0);
                    b.cylinder(x,1.72f,z,cos(aa)*.53f,1.72f,sin(aa)*.53f,.018f,.018f,6,COPPER,0);
                    b.cylinder(x,.39f,z,x*.65f,.39f,z*.65f,.022f,.022f,6,RUBBER,0);
                }
                for(int i=0;i<4;i++) {
                    float a=i*PI/2;
                    b.cylinder(cos(a)*.27f,1.18f,sin(a)*.27f,cos(a)*.27f,1.66f,sin(a)*.27f,.015f,.015f,6,METAL,0);
                }
                ringY(b,0,1.17f,0,.27f,.017f,10,METAL,0);
                ringY(b,0,1.67f,0,.27f,.017f,10,METAL,0);
                break;
            case 2:
                flangeY(b,0,.37f,0,.25f,0);
                b.cylinder(0,1.04f,0,0,1.13f,0,.235f,.235f,12,DARK,0);
                for(int i=0;i<3;i++) {
                    float a=i*PI*2/3+.15f,ux=cos(a),uz=sin(a),vx=-uz,vz=ux;
                    for(int side=-1;side<=1;side+=2) {
                        b.cylinder(ux*.12f+side*vx*.28f,1.12f,uz*.12f+side*vz*.28f,
                                ux*.95f+side*vx*.28f,1.70f,uz*.95f+side*vz*.28f,.014f,.014f,6,METAL,2);
                    }
                    for(int line=-1;line<=1;line++) b.cylinder(ux*.14f+vx*line*.13f,1.145f,uz*.14f+vz*line*.13f,
                            ux*.93f+vx*line*.13f,1.701f,uz*.93f+vz*line*.13f,.0035f,.0035f,4,WHITE,2);
                    b.cylinder(ux*.15f,1.05f,uz*.15f,ux*.85f,1.57f,uz*.85f,.024f,.024f,6,METAL,2);
                }
                break;
            case 3:
                ringY(b,0,.65f,0,.423f,.024f,12,METAL,0);
                ringY(b,0,1.40f,0,.425f,.024f,12,METAL,0);
                flangeY(b,0,.47f,0,.52f,0);
                for(int side=-1;side<=1;side+=2) {
                    ringZ(b,side*.34f,.98f,.375f,.075f,.012f,8,METAL,0);
                    b.cylinder(side*.34f,.98f,.369f,side*.34f,.98f,.384f,.064f,.064f,10,BLUE,0);
                    b.cylinder(side*.65f,.47f,.17f,side*.44f,.47f,.17f,.035f,.035f,7,METAL,0);
                    b.cylinder(side*.44f,.47f,.17f,side*.44f,.75f,.17f,.035f,.035f,7,METAL,0);
                }
                frontGauge(b,0,.40f,.53f,0);
                break;
            case 4:
                for(int side=0;side<2;side++) {
                    float x=side==0?-.56f:.055f;
                    b.cylinder(x,.43f,.86f,x,.70f,.27f,.025f,.025f,6,METAL,0);
                    b.cylinder(x,.39f,.80f,x,.28f,.80f,.025f,.025f,6,METAL,0);
                }
                b.box(.19f,.57f,.57f,.27f,.24f,.26f,IVORY,0);
                vents(b,.19f,.57f,.711f,.19f,.15f,4,0);
                flangeY(b,-.22f,.38f,-.12f,.44f,0);
                flangeY(b,.35f,.55f,-.48f,.10f,0);
                b.cylinder(-.44f,.68f,-.12f,-.66f,.68f,-.12f,.04f,.04f,7,METAL,0);
                ringZ(b,-.66f,.68f,-.095f,.09f,.015f,8,COPPER,0);
                break;
            case 5:
                flangeY(b,0,.37f,0,.34f,0);
                for(int side=-1;side<=1;side+=2) {
                    b.box(side*.405f,1.24f,.03f,.055f,.24f,.42f,METAL,1);
                    boltZ(b,side*.405f,1.27f,.25f,1);
                    for(int i=0;i<2;i++) ringZ(b,side*.17f,1.27f,.44f+i*.19f,.108f,.012f,8,METAL,2);
                    b.cylinder(side*.25f,1.39f,.11f,side*.25f,1.39f,.63f,.022f,.022f,6,WHITE,2);
                }
                for(int i=0;i<5;i++) b.box(-.17f+i*.085f,1.27f,-.37f,.032f,.16f,.10f,METAL,1);
                break;
            case 6:
                vents(b,-.29f,.70f,.219f,.28f,.25f,6,0);
                for(int side=-1;side<=1;side+=2) {
                    b.cylinder(side*.47f,.31f,.32f,side*.47f,.31f,.85f,.025f,.025f,6,METAL,0);
                    boltZ(b,side*.44f,.88f,.223f,0);
                    boltZ(b,side*.44f,.40f,.223f,0);
                }
                b.box(.43f,.66f,-.09f,.24f,.39f,.52f,DARK,0);
                for(int i=0;i<4;i++) b.box(.55f,.55f+i*.075f,-.09f,.035f,.018f,.43f,METAL,0);
                b.cylinder(-.46f,1.32f,.30f,.46f,1.32f,.30f,.033f,.033f,7,YELLOW,0);
                for(int i=0;i<4;i++) {
                    float y=.34f+(i%2)*.18f,z=.52f+(i/2)*.19f;
                    b.cylinder(-.69f,y+.077f,z-.025f,.16f,y+.077f,z-.025f,.006f,.006f,4,DARK,0);
                }
                break;
            case 7:
                b.cylinder(0,.015f,0,0,.055f,0,.995f,.995f,12,CONCRETE,0);
                ringY(b,0,1.48f,0,.184f,.012f,12,METAL,0);
                for(int i=0;i<4;i++) {
                    float a=i*PI/2,ux=cos(a),uz=sin(a);
                    blade(b,ux*.57f,.236f,uz*.57f,ux*.78f,.236f,uz*.78f,.035f,WHITE,0);
                    b.cylinder(ux*.67f,.23f,uz*.67f,ux*.67f,.55f,uz*.67f,.018f,.018f,6,METAL,0);
                    for(int j=0;j<2;j++) {
                        float y=.78f+j*.32f;
                        b.cylinder(ux*.18f,y,uz*.18f,ux*.187f,y,uz*.187f,.012f,.012f,6,METAL,0);
                    }
                }
                b.cylinder(-.67f,.55f,0,0,.55f,-.67f,.015f,.015f,6,METAL,0);
                break;
            case 8:
                flangeY(b,0,.39f,0,.31f,0);
                for(int i=0;i<4;i++) {
                    float a=i*PI/2;
                    b.cylinder(cos(a)*.12f,1.34f,sin(a)*.12f,cos(a)*.58f,1.71f,sin(a)*.58f,.020f,.020f,6,METAL,1);
                }
                b.cylinder(.49f,1.71f,-.13f,.04f,2.13f,.04f,.026f,.020f,7,METAL,1);
                b.box(0,.61f,-.25f,.29f,.37f,.16f,DARK,0);
                for(int i=0;i<5;i++) b.cylinder(.37f,.52f+i*.19f,-.32f,.51f,.52f+i*.19f,-.32f,.012f,.012f,6,METAL,0);
                b.cylinder(.37f,.43f,-.32f,.37f,1.36f,-.32f,.015f,.015f,6,METAL,0);
                break;
            case 9:
                b.ellipsoid(0,1.65f,-.10f,.145f,.14f,.30f,12,6,DARK,0);
                b.cylinder(0,1.65f,-.02f,0,1.65f,.13f,.16f,.16f,12,METAL,0);
                b.box(0,.56f,.126f,.13f,.26f,.018f,DARK,0);
                boltZ(b,-.045f,.65f,.144f,0);boltZ(b,.045f,.47f,.144f,0);
                for(int i=0;i<5;i++) b.cylinder(-.10f,.46f+i*.19f,-.13f,.10f,.46f+i*.19f,-.13f,.011f,.011f,6,METAL,0);
                for(int i=0;i<4;i++) b.box(0,1.70f,-.20f+i*.065f,.21f,.055f,.018f,METAL,0);
                break;
            case 10:
                flangeY(b,0,.40f,0,.34f,0);
                for(int i=0;i<4;i++) {
                    float a=i*PI/2+PI/4,x=cos(a),z=sin(a);
                    b.cylinder(x*.35f,.40f,z*.35f,x*.52f,.75f,z*.52f,.028f,.028f,7,COPPER,0);
                    b.cylinder(x*.52f,.75f,z*.52f,x*.52f,1.28f,z*.52f,.025f,.025f,7,METAL,0);
                    boltY(b,x*.62f,1.38f,z*.62f,0);
                }
                for(int i=0;i<5;i++) b.box(-.18f+i*.09f,1.71f,-.01f,.024f,.17f,.35f,METAL,0);
                frontGauge(b,0,.47f,.49f,0);
                break;
            case 11:
                for(int row=0;row<3;row++) {
                    float y=.52f+row*.44f,z=.43f-(y-.29f)/1.47f*.11f+.014f;
                    float r=.52f-(y-.29f)/1.47f*.19f;
                    b.cylinder(-r,y,z,r,y,z,.008f,.008f,5,DARK,0);
                }
                b.box(0,.50f,.429f,.22f,.35f,.018f,DARK,0);
                b.box(.068f,.50f,.443f,.014f,.07f,.015f,METAL,0);
                b.box(0,.30f,.50f,.32f,.06f,.19f,CONCRETE,0);
                for(int side=-1;side<=1;side+=2) {
                    vents(b,side*.62f,.64f,.178f,.22f,.25f,5,0);
                    boltZ(b,side*.62f,.44f,.171f,0);
                    b.cylinder(side*.59f,.37f,-.22f,side*.59f,.37f,-.43f,.032f,.032f,6,RUBBER,0);
                }
                break;
            case 12:
                for(int i=0;i<4;i++) {
                    float a=i*PI/2,ux=cos(a),uz=sin(a);
                    b.box(ux*.62f,.32f,uz*.62f,.19f,.08f,.19f,METAL,0);
                    boltY(b,ux*.62f+.052f,.37f,uz*.62f+.052f,0);
                    b.cylinder(ux*.49f,.35f,uz*.49f,ux*.18f,1.31f,uz*.18f,.022f,.022f,7,RUBBER,0);
                    for(int j=1;j<=3;j++) {
                        float t=j/4f,r=.63f*(1-t*.72f),y=.31f+1.75f*t;
                        b.cylinder(ux*r,y,uz*r,ux*(r+.09f),y,uz*(r+.09f),.035f,.035f,6,METAL,0);
                    }
                }
                break;
            default:
                flangeY(b,0,1.52f,0,.59f,0);
                for(int side=-1;side<=1;side+=2) b.cylinder(side*.105f,.39f,-.64f,side*.105f,1.54f,-.64f,.018f,.018f,6,METAL,0);
                for(int i=0;i<6;i++) b.cylinder(-.105f,.47f+i*.17f,-.64f,.105f,.47f+i*.17f,-.64f,.014f,.014f,6,METAL,0);
                flangeY(b,.81f,.70f,-.12f,.10f,0);
                b.cylinder(.56f,1.17f,.19f,.72f,1.17f,.19f,.022f,.022f,6,METAL,0);
                b.cylinder(.73f,1.17f,.18f,.73f,1.17f,.21f,.068f,.068f,10,WHITE,0);
                b.cylinder(.73f,1.17f,.21f,.73f,1.17f,.219f,.056f,.056f,10,BLUE,0);
                b.cylinder(.73f,1.17f,.221f,.757f,1.194f,.221f,.005f,.005f,4,WHITE,0);
                break;
        }
    }

    private static void boltY(MeshBuilder3D b,float x,float y,float z,int bone) {
        b.cylinder(x,y-.005f,z,x,y+.010f,z,.020f,.020f,6,METAL,bone);
    }
    private static void boltZ(MeshBuilder3D b,float x,float y,float z,int bone) {
        b.cylinder(x,y,z-.004f,x,y,z+.012f,.020f,.020f,6,METAL,bone);
    }
    private static void flangeY(MeshBuilder3D b,float x,float y,float z,float r,int bone) {
        b.cylinder(x,y-.018f,z,x,y+.018f,z,r,r,12,METAL,bone);
        for(int i=0;i<6;i++) {
            float a=i*PI/3;
            boltY(b,x+cos(a)*r*.82f,y+.026f,z+sin(a)*r*.82f,bone);
        }
    }
    private static void vents(MeshBuilder3D b,float x,float y,float z,float width,float height,int rows,int bone) {
        b.box(x,y,z,width,height,.024f,RUBBER,bone);
        for(int i=0;i<rows;i++) b.box(x,y-height*.42f+height*.84f*i/(rows-1),z+.020f,
                width*.94f,.014f,.030f,METAL,bone);
    }

    private static void sideVial(MeshBuilder3D b,float x,float y,float z,float r,float[] colour) {
        b.cylinder(x,y-.34f,z,x,y+.25f,z,r,r,9,colour,0);
        b.cylinder(x,y-.39f,z,x,y-.30f,z,r*1.16f,r*1.16f,9,METAL,0);
        b.cylinder(x,y+.24f,z,x,y+.32f,z,r*1.16f,r*.8f,9,IVORY,0);
        b.ellipsoid(x,y+.34f,z,r*.52f,.05f,r*.52f,8,4,CYAN,0);
    }

    private static void frontGauge(MeshBuilder3D b,float x,float y,float z,int bone) {
        b.box(x,y,z,.20f,.16f,.045f,DARK,bone);
        b.box(x,y,z+.027f,.14f,.095f,.015f,BLUE,bone);
        b.box(x-.045f,y-.06f,z+.032f,.035f,.018f,.014f,AMBER,bone);
        b.box(x+.045f,y-.06f,z+.032f,.035f,.018f,.014f,CYAN,bone);
    }

    private static void ringY(MeshBuilder3D b,float cx,float cy,float cz,float r,float tube,int segments,float[] c,int bone) {
        for(int i=0;i<segments;i++) {
            float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
            b.cylinder(cx+cos(a)*r,cy,cz+sin(a)*r,cx+cos(aa)*r,cy,cz+sin(aa)*r,tube,tube,5,c,bone);
        }
    }

    private static void ringZ(MeshBuilder3D b,float cx,float cy,float cz,float r,float tube,int segments,float[] c,int bone) {
        for(int i=0;i<segments;i++) {
            float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
            b.cylinder(cx+cos(a)*r,cy+sin(a)*r,cz,cx+cos(aa)*r,cy+sin(aa)*r,cz,tube,tube,5,c,bone);
        }
    }

    /** A closed thin panel with eight independent 3D corners. */
    private static void panel(MeshBuilder3D b,float ax,float ay,float az,float bx,float by,float bz,
                              float wx,float wz,float[] colour,int bone) {
        float[] p={ax-wx,ay,az-wz,bx-wx,by,bz-wz,bx+wx,by,bz+wz,ax+wx,ay,az+wz};
        prismY(b,p,.035f,colour,bone);
    }

    private static void blade(MeshBuilder3D b,float ax,float ay,float az,float bx,float by,float bz,
                              float width,float[] colour,int bone) {
        float dx=bx-ax,dz=bz-az,length=(float)Math.sqrt(dx*dx+dz*dz);
        float wx=length>0?-dz/length*width:width,wz=length>0?dx/length*width:0;
        panel(b,ax,ay,az,bx,by,bz,wx,wz,colour,bone);
    }

    private static void prismY(MeshBuilder3D b,float[] p,float thickness,float[] colour,int bone) {
        float[] q=p.clone();for(int i=1;i<q.length;i+=3)q[i]-=thickness;
        closedPrism(b,p,q,colour,bone);
    }
    private static void prismZ(MeshBuilder3D b,float[] p,float thickness,float[] colour,int bone) {
        float[] q=p.clone();for(int i=2;i<q.length;i+=3)q[i]-=thickness;
        closedPrism(b,p,q,colour,bone);
    }
    private static void closedPrism(MeshBuilder3D b,float[] p,float[] q,float[] colour,int bone) {
        closedPrism(b,p,q,colour,COPPER,bone);
    }
    private static void closedPrism(MeshBuilder3D b,float[] p,float[] q,float[] colour,float[] sideColour,int bone) {
        float cx=0,cy=0,cz=0;
        for(int i=0;i<12;i+=3) {
            cx+=(p[i]+q[i])/8;cy+=(p[i+1]+q[i+1])/8;cz+=(p[i+2]+q[i+2])/8;
        }
        outwardFace(b,p,cx,cy,cz,colour,bone);outwardFace(b,q,cx,cy,cz,METAL,bone);
        for(int i=0;i<4;i++) {
            int j=(i+1)%4;
            float[] side={p[i*3],p[i*3+1],p[i*3+2],q[i*3],q[i*3+1],q[i*3+2],
                          q[j*3],q[j*3+1],q[j*3+2],p[j*3],p[j*3+1],p[j*3+2]};
            outwardFace(b,side,cx,cy,cz,sideColour,bone);
        }
    }
    /** Winding is outward for any convex four-sided prism orientation. */
    private static void outwardFace(MeshBuilder3D b,float[] p,float cx,float cy,float cz,float[] colour,int bone) {
        float ux=p[3]-p[0],uy=p[4]-p[1],uz=p[5]-p[2];
        float vx=p[6]-p[0],vy=p[7]-p[1],vz=p[8]-p[2];
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        float fx=(p[0]+p[3]+p[6]+p[9])/4-cx,fy=(p[1]+p[4]+p[7]+p[10])/4-cy;
        float fz=(p[2]+p[5]+p[8]+p[11])/4-cz;
        if(nx*fx+ny*fy+nz*fz>=0)face(b,p,0,1,2,3,colour,bone);
        else face(b,p,3,2,1,0,colour,bone);
    }
    private static void face(MeshBuilder3D b,float[] p,int a,int c,int d,int e,float[] colour,int bone) {
        b.quad(p[a*3],p[a*3+1],p[a*3+2],p[c*3],p[c*3+1],p[c*3+2],
                p[d*3],p[d*3+1],p[d*3+2],p[e*3],p[e*3+1],p[e*3+2],colour,bone);
    }

    private static void taperedTower(MeshBuilder3D b,float rx0,float rz0,float rx1,float rz1,float y0,float y1,float[] colour,int bone) {
        float[] low={-rx0,y0,-rz0,rx0,y0,-rz0,rx0,y0,rz0,-rx0,y0,rz0};
        float[] high={-rx1,y1,-rz1,rx1,y1,-rz1,rx1,y1,rz1,-rx1,y1,rz1};
        closedPrism(b,high,low,colour,colour,bone);
    }

    private static void dish(MeshBuilder3D b,float cx,float cy,float cz,float radius,float depth,float[] colour,int bone) {
        final int rings=4,segments=16;
        b.ellipsoid(cx,cy+.015f,cz,.10f,.035f,.10f,8,4,METAL,bone);
        for(int row=0;row<rings;row++) {
            float r0=.075f+(radius-.075f)*row/rings,r1=.075f+(radius-.075f)*(row+1)/rings;
            float y0=cy+depth*(r0/radius)*(r0/radius),y1=cy+depth*(r1/radius)*(r1/radius);
            for(int i=0;i<segments;i++) {
                float a=2*PI*i/segments,aa=2*PI*(i+1)/segments;
                float[] p={cx+cos(a)*r0,y0,cz+sin(a)*r0,cx+cos(a)*r1,y1,cz+sin(a)*r1,
                           cx+cos(aa)*r1,y1,cz+sin(aa)*r1,cx+cos(aa)*r0,y0,cz+sin(aa)*r0};
                face(b,p,3,2,1,0,colour,bone);
                // Back face is also physical, with a small normal-direction separation.
                float[] front=p.clone();
                for(int j=1;j<p.length;j+=3)p[j]-=.018f;
                face(b,p,0,1,2,3,METAL,bone);
                if(row==rings-1) b.quad(front[3],front[4],front[5],p[3],p[4],p[5],
                        p[6],p[7],p[8],front[6],front[7],front[8],COPPER,bone);
                if(row==0) b.quad(front[9],front[10],front[11],p[9],p[10],p[11],
                        p[0],p[1],p[2],front[0],front[1],front[2],METAL,bone);
            }
        }
    }

    private static float cos(float value) { return (float)Math.cos(value); }
    private static float sin(float value) { return (float)Math.sin(value); }
}
