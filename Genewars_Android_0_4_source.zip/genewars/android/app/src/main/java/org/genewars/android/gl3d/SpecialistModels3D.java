package org.genewars.android.gl3d;

/** Equipped anatomical field specialists, with separate PBR material regions. */
final class SpecialistModels3D {
    private static final float[] IVORY={.58f,.61f,.57f,0,.43f,.24f},DARK={.105f,.125f,.132f,0,.81f,.02f},
        SKIN={.58f,.40f,.31f,0,.58f,0},LIGHT={.64f,.46f,.36f,0,.56f,0},STEEL={.42f,.46f,.48f,0,.28f,.84f},
        COPPER={.43f,.29f,.17f,0,.29f,.78f},GLOW={.13f,.56f,.58f,.32f,.22f,.05f},GLASS={.095f,.16f,.18f,0,.16f,.18f},
        RUBBER={.055f,.061f,.064f,0,.92f,0},EYE={.78f,.75f,.66f,0,.22f,0},PUPIL={.08f,.10f,.09f,0,.16f,0};
    private static final float[][] JOB={{.47f,.28f,.13f,0,.82f,0},{.23f,.31f,.22f,0,.86f,0},{.51f,.48f,.38f,0,.78f,0},{.16f,.22f,.26f,0,.84f,0}};
    static MeshData3D build(int kind){
        if(kind<0||kind>3)throw new IllegalArgumentException("Specialist kind");
        MeshBuilder3D b=new MeshBuilder3D("specialist_"+kind);float[]suit=JOB[kind];
        int body=b.bone("torso",0,0,.85f,0,Bone3D.ROOT,.3f*kind,.012f);
        // Seven-head proportions: pelvis, chest and abdomen, fitted clothing.
        b.ellipsoid(0,.76f,0,.13f,.13f,.10f,14,8,suit,body);
        b.ellipsoid(0,.96f,0,.165f,.205f,.105f,16,10,suit,body);
        b.ellipsoid(0,.87f,.012f,.125f,.12f,.099f,12,7,DARK,body);
        for(int side=-1;side<=1;side+=2){
            b.ellipsoid(side*.074f,1.015f,.078f,.073f,.105f,.045f,10,7,kind==3?DARK:IVORY,body);
            b.cylinder(side*.07f,1.11f,.075f,side*.115f,.83f,.087f,.011f,.012f,7,DARK,body);
        }
        b.cylinder(0,1.135f,0,0,1.255f,.012f,.048f,.046f,12,SKIN,body);
        b.cylinder(0,1.15f,0,0,1.185f,0,.063f,.061f,12,DARK,body);
        int h=b.bone("head",body,0,1.235f,.005f,Bone3D.HEAD_Y,kind*.6f,.055f);
        head(b,h,kind);
        int[]hands=new int[2];
        for(int side=-1;side<=1;side+=2){
            float phase=side<0?0:(float)Math.PI;
            int thigh=b.bone("leg_hip_"+side,body,side*.073f,.75f,0,Bone3D.SWING_X,phase,.40f);
            int shin=b.bone("leg_knee_"+side,thigh,side*.085f,.405f,.012f,Bone3D.KNEE_X,phase+1.1f,.61f);
            b.ellipsoidBetween(side*.073f,.745f,0,side*.085f,.40f,.012f,.071f,.069f,12,7,suit,thigh);
            b.cylinder(side*.073f,.69f,.003f,side*.085f,.445f,.012f,.052f,.047f,10,suit,thigh);
            b.box(side*.106f,.57f,.061f,.056f,.11f,.022f,DARK,thigh);
            b.box(side*.106f,.61f,.074f,.049f,.016f,.009f,IVORY,thigh);
            b.ellipsoid(side*.085f,.405f,.027f,.054f,.061f,.060f,10,6,DARK,shin);
            b.ellipsoid(side*.085f,.405f,.073f,.043f,.049f,.017f,10,5,IVORY,shin);
            b.ellipsoidBetween(side*.085f,.39f,.012f,side*.088f,.13f,.005f,.045f,.049f,12,7,suit,shin);
            b.cylinder(side*.088f,.11f,0,side*.088f,.23f,0,.046f,.052f,10,DARK,shin);
            boot(b,shin,side*.088f);
            int arm=b.bone("arm_shoulder_"+side,body,side*.176f,1.095f,0,Bone3D.WORK_ARM_X,phase+(float)Math.PI,.58f);
            int fore=b.bone("arm_elbow_"+side,arm,side*.221f,.875f,.004f,Bone3D.SWING_X,phase+.4f,.13f);
            b.ellipsoid(side*.175f,1.085f,0,.065f,.08f,.064f,12,7,suit,arm);
            b.ellipsoidBetween(side*.185f,1.075f,0,side*.221f,.875f,.004f,.047f,.045f,12,7,suit,arm);
            b.ellipsoid(side*.205f,1.085f,.026f,.052f,.055f,.045f,10,5,kind==3?DARK:IVORY,arm);
            b.ellipsoid(side*.221f,.875f,.004f,.039f,.042f,.038f,9,5,DARK,fore);
            b.ellipsoidBetween(side*.221f,.875f,.004f,side*.231f,.68f,.043f,.041f,.038f,12,6,suit,fore);
            b.cylinder(side*.231f,.685f,.043f,side*.23f,.735f,.033f,.039f,.043f,10,DARK,fore);
            b.box(side*.235f,.76f,.069f,.058f,.08f,.018f,IVORY,fore);
            glove(b,fore,side);hands[side<0?0:1]=fore;
        }
        b.cylinder(0,.746f,0,0,.775f,0,.137f,.136f,14,DARK,body);
        b.box(0,.76f,.139f,.05f,.035f,.015f,STEEL,body);
        for(int side=-1;side<=1;side+=2){
            b.box(side*.095f,.746f,.12f,.062f,.065f,.045f,suit,body);
            b.box(side*.095f,.771f,.145f,.05f,.014f,.011f,DARK,body);
        }
        b.box(0,.975f,-.125f,.205f,.30f,.085f,DARK,body);
        b.box(0,.987f,-.177f,.17f,.24f,.035f,suit,body);
        for(int side=-1;side<=1;side+=2){
            b.cylinder(side*.105f,.83f,-.15f,side*.105f,1.125f,-.15f,.011f,.011f,7,STEEL,body);
            b.cylinder(side*.095f,.89f,-.184f,side*.095f,1.075f,-.184f,.027f,.027f,10,kind==1?suit:STEEL,body);
        }
        for(int i=0;i<4;i++)b.box(0,.91f+i*.035f,-.2f,.11f,.009f,.007f,RUBBER,body);
        b.box(.105f,1.093f,-.002f,.025f,.027f,.021f,GLOW,body);
        tool(b,kind,body,hands,suit);return b.finish();
    }
    private static void head(MeshBuilder3D b,int h,int kind){
        b.ellipsoid(0,1.329f,.010f,.077f,.107f,.081f,18,12,SKIN,h);
        b.ellipsoid(0,1.278f,.031f,.061f,.050f,.062f,14,8,SKIN,h);
        b.ellipsoid(0,1.265f,.056f,.043f,.025f,.032f,12,6,LIGHT,h);
        for(int side=-1;side<=1;side+=2){
            b.ellipsoid(side*.075f,1.325f,.004f,.012f,.027f,.020f,9,6,SKIN,h);
            b.ellipsoid(side*.036f,1.318f,.074f,.026f,.022f,.015f,10,6,LIGHT,h);
            b.ellipsoid(side*.030f,1.350f,.079f,.020f,.009f,.007f,10,5,EYE,h);
            b.ellipsoid(side*.030f,1.350f,.085f,.007f,.008f,.003f,9,5,PUPIL,h);
            b.cylinder(side*.011f,1.365f,.081f,side*.051f,1.362f,.078f,.005f,.004f,7,DARK,h);
        }
        b.ellipsoid(0,1.333f,.085f,.012f,.028f,.014f,10,7,LIGHT,h);
        b.ellipsoid(0,1.317f,.096f,.018f,.012f,.018f,10,6,SKIN,h);
        b.cylinder(-.022f,1.288f,.084f,.022f,1.288f,.084f,.0032f,.0032f,7,new float[]{.29f,.17f,.14f,0,.65f,0},h);
        b.ellipsoid(0,1.397f,.001f,.085f,.061f,.085f,18,8,kind==0?IVORY:DARK,h);
        b.cylinder(-.083f,1.389f,.061f,.083f,1.389f,.061f,.012f,.012f,10,kind==3?DARK:IVORY,h);
        for(int side=-1;side<=1;side+=2){
            b.box(side*.037f,1.351f,.089f,.059f,.027f,.009f,GLASS,h);
            b.box(side*.037f,1.365f,.091f,.066f,.005f,.008f,STEEL,h);
            b.ellipsoid(side*.084f,1.352f,.005f,.015f,.027f,.024f,9,6,DARK,h);
        }
        b.box(0,1.352f,.094f,.017f,.006f,.008f,STEEL,h);
        if(kind==0){b.box(0,1.421f,.068f,.032f,.024f,.020f,DARK,h);b.box(0,1.421f,.080f,.023f,.015f,.005f,new float[]{.72f,.65f,.43f,.35f,.2f,.05f},h);}
        if(kind==2)b.cylinder(.086f,1.34f,0,.074f,1.295f,.084f,.005f,.005f,7,STEEL,h);
    }
    private static void boot(MeshBuilder3D b,int bone,float x){
        b.ellipsoid(x,.081f,.025f,.054f,.075f,.097f,12,7,DARK,bone);
        b.ellipsoid(x,.045f,.066f,.056f,.035f,.084f,12,5,RUBBER,bone);
        b.box(x,.023f,.035f,.108f,.024f,.182f,RUBBER,bone);
        for(int j=0;j<3;j++)b.cylinder(x-.034f,.106f-j*.013f,.061f+j*.009f,x+.034f,.106f-j*.013f,.061f+j*.009f,.003f,.003f,6,IVORY,bone);
        b.box(x,.062f,.129f,.083f,.025f,.013f,STEEL,bone);
    }
    private static void glove(MeshBuilder3D b,int bone,int side){
        b.ellipsoid(side*.232f,.655f,.047f,.034f,.044f,.029f,10,6,DARK,bone);
        b.ellipsoid(side*.234f,.662f,.068f,.027f,.023f,.012f,9,5,IVORY,bone);
        for(int f=0;f<3;f++)b.ellipsoid(side*(.215f+f*.016f),.625f,.053f,.008f,.021f,.012f,7,4,RUBBER,bone);
        b.ellipsoid(side*.202f,.65f,.070f,.012f,.025f,.014f,8,4,DARK,bone);
    }
    private static void tool(MeshBuilder3D b,int kind,int body,int[]hands,float[]suit){
        if(kind==0){
            b.box(.143f,.905f,-.178f,.14f,.026f,.068f,DARK,body);
            for(int i=0;i<3;i++)b.cylinder(.105f+i*.035f,.90f,-.177f,.105f+i*.035f,1.06f,-.177f,.008f,.008f,7,STEEL,body);
            b.box(.232f,.659f,.11f,.057f,.055f,.12f,DARK,hands[1]);
            b.cylinder(.232f,.67f,.11f,.232f,.67f,.27f,.030f,.019f,12,STEEL,hands[1]);
            b.cylinder(.232f,.67f,.25f,.232f,.67f,.30f,.020f,.012f,9,COPPER,hands[1]);
            b.ellipsoid(.232f,.67f,.30f,.011f,.011f,.008f,8,4,new float[]{.72f,.40f,.13f,.3f,.2f,0},hands[1]);
        }else if(kind==1){
            for(int side=-1;side<=1;side+=2){int arm=hands[side<0?0:1];
                b.cylinder(side*.232f,.62f,.09f,side*.232f,.73f,.09f,.025f,.025f,12,STEEL,arm);
                b.cylinder(side*.232f,.639f,.09f,side*.232f,.711f,.09f,.026f,.026f,12,new float[]{.24f,.38f,.24f,0,.32f,.05f},arm);
                b.cylinder(side*.232f,.72f,.09f,side*.232f,.735f,.09f,.028f,.028f,10,DARK,arm);
            }
        }else if(kind==2){
            b.box(-.232f,.666f,.108f,.12f,.095f,.018f,DARK,hands[0]);
            b.box(-.232f,.667f,.12f,.10f,.073f,.005f,new float[]{.21f,.39f,.41f,.18f,.17f,.02f},hands[0]);
            b.cylinder(.232f,.66f,.09f,.232f,.66f,.20f,.022f,.016f,10,STEEL,hands[1]);
            b.cylinder(.232f,.66f,.19f,.232f,.66f,.22f,.017f,.017f,10,GLOW,hands[1]);
        }else{
            b.box(.232f,.685f,.13f,.055f,.065f,.19f,DARK,hands[1]);
            b.cylinder(.232f,.695f,.16f,.232f,.695f,.43f,.018f,.015f,12,STEEL,hands[1]);
            b.box(.232f,.739f,.17f,.028f,.025f,.09f,GLASS,hands[1]);
            b.cylinder(-.09f,1.07f,-.11f,-.09f,1.32f,-.11f,.005f,.003f,7,DARK,body);
        }
    }
}
