package org.genewars.android.gl3d;

/** Small column-major matrix helper, usable by JVM camera tests. */
final class Matrix3D {
    private Matrix3D() {}
    static float[] identity() { float[] m = new float[16]; m[0]=m[5]=m[10]=m[15]=1; return m; }
    static void identity(float[] m) { for(int i=0;i<16;i++)m[i]=0; m[0]=m[5]=m[10]=m[15]=1; }
    static float[] multiply(float[] a,float[] b) {
        float[] r=new float[16];
        for(int col=0;col<4;col++)for(int row=0;row<4;row++)
            for(int k=0;k<4;k++)r[col*4+row]+=a[k*4+row]*b[col*4+k];
        return r;
    }
    static float[] perspective(float fov,float aspect,float near,float far) {
        float[] m=new float[16];float t=(float)(1/Math.tan(Math.toRadians(fov)*.5));
        m[0]=t/aspect;m[5]=t;m[10]=(far+near)/(near-far);m[11]=-1;m[14]=2*far*near/(near-far);return m;
    }
    static float[] ortho(float left,float right,float bottom,float top,float near,float far) {
        float[] m=identity();m[0]=2/(right-left);m[5]=2/(top-bottom);m[10]=-2/(far-near);
        m[12]=-(right+left)/(right-left);m[13]=-(top+bottom)/(top-bottom);m[14]=-(far+near)/(far-near);return m;
    }
    static float[] lookAt(float ex,float ey,float ez,float tx,float ty,float tz) {
        float fx=tx-ex,fy=ty-ey,fz=tz-ez,l=(float)Math.sqrt(fx*fx+fy*fy+fz*fz);fx/=l;fy/=l;fz/=l;
        float sx=-fz,sy=0,sz=fx;l=(float)Math.sqrt(sx*sx+sz*sz);sx/=l;sz/=l;
        float ux=sy*fz-sz*fy,uy=sz*fx-sx*fz,uz=sx*fy-sy*fx;
        float[] m=identity();m[0]=sx;m[4]=sy;m[8]=sz;m[1]=ux;m[5]=uy;m[9]=uz;m[2]=-fx;m[6]=-fy;m[10]=-fz;
        m[12]=-(sx*ex+sy*ey+sz*ez);m[13]=-(ux*ex+uy*ey+uz*ez);m[14]=fx*ex+fy*ey+fz*ez;return m;
    }
    static float[] transform(float[] m,float x,float y,float z,float w) {
        return new float[]{m[0]*x+m[4]*y+m[8]*z+m[12]*w,m[1]*x+m[5]*y+m[9]*z+m[13]*w,
                m[2]*x+m[6]*y+m[10]*z+m[14]*w,m[3]*x+m[7]*y+m[11]*z+m[15]*w};
    }
    static float[] inverse(float[] m) {
        double[][] a=new double[4][8];
        for(int row=0;row<4;row++){for(int col=0;col<4;col++)a[row][col]=m[col*4+row];a[row][4+row]=1;}
        for(int col=0;col<4;col++){
            int pivot=col;for(int row=col+1;row<4;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
            if(Math.abs(a[pivot][col])<1e-12)throw new IllegalArgumentException("Singular camera matrix");
            double[] swap=a[col];a[col]=a[pivot];a[pivot]=swap;double scale=a[col][col];
            for(int j=0;j<8;j++)a[col][j]/=scale;
            for(int row=0;row<4;row++)if(row!=col){double k=a[row][col];for(int j=0;j<8;j++)a[row][j]-=k*a[col][j];}
        }
        float[] result=new float[16];for(int row=0;row<4;row++)for(int col=0;col<4;col++)result[col*4+row]=(float)a[row][col+4];return result;
    }
    static void model(float[] out,float x,float y,float z,float yaw,float sx,float sy,float sz) {
        identity(out);float c=(float)Math.cos(yaw),s=(float)Math.sin(yaw);
        out[0]=c*sx;out[2]=-s*sx;out[5]=sy;out[8]=s*sz;out[10]=c*sz;out[12]=x;out[13]=y;out[14]=z;
    }
}
