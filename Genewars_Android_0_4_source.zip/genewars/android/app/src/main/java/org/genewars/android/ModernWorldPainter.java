package org.genewars.android;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Log;
import org.genewars.core.WorldMap;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Native, cached 2.5D terrain renderer. It does not change the simulation or map.
 * Texture IO happens once on a worker; ordinary frames never decode images.
 */
final class ModernWorldPainter {
    interface Projection {
        float x(double worldX, double worldY);
        float y(double worldX, double worldY);
        float halfWidth();
        float halfHeight();
        int width();
        int height();
        float density();
    }

    private static final String[] MATERIALS = {"water", "shore", "sand", "grass", "rock", "alien", "snow", "moss"};
    private static final int[] BASE = {
        Color.rgb(24, 72, 91), Color.rgb(66, 133, 132), Color.rgb(175, 157, 103),
        Color.rgb(83, 123, 75), Color.rgb(116, 122, 116), Color.rgb(101, 113, 135),
        Color.rgb(197, 211, 209), Color.rgb(76, 124, 95)
    };
    private static final int MAX_GLINTS = 48, MAX_FOAM = 32, MAX_MOTES = 8;

    private final AssetManager assets;
    private final Runnable onTexturesReady;
    private final AtomicBoolean requested = new AtomicBoolean();
    private final ExecutorService textureWorker = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "modern-terrain-textures");
            thread.setDaemon(true); return thread;
        }
    });
    private volatile boolean closed;
    private volatile TextureSet textures;
    private volatile Effects effects = new Effects(new float[0], new float[0]);
    private final Paint ground = new Paint();
    private final Paint texturePaint = new Paint();
    private final Paint detail = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint atmospherePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path quad = new Path(), triangle = new Path(), wave = new Path();
    private final RectF rectangle = new RectF();
    private final Matrix textureMatrix = new Matrix();
    private final float[] textureTransform = new float[9];
    private final ColorMatrixColorFilter[] lightFilters = new ColorMatrixColorFilter[16];
    private final RadialGradient shadowGradient = new RadialGradient(0, 0, 1,
            new int[]{0x82071718, 0x43071718, 0x00071718}, new float[]{0, .42f, 1}, Shader.TileMode.CLAMP);
    private final RadialGradient cloudGradient = new RadialGradient(0, 0, 1,
            new int[]{0x12041118, 0x08041118, 0x00041118}, new float[]{0, .45f, 1}, Shader.TileMode.CLAMP);

    ModernWorldPainter(AssetManager assets, Runnable onTexturesReady) {
        this.assets = assets; this.onTexturesReady = onTexturesReady;
        ground.setAntiAlias(false); texturePaint.setAntiAlias(false);
        for (int i = 0; i < lightFilters.length; i++) {
            float gain = .64f + i * .04f;
            lightFilters[i] = new ColorMatrixColorFilter(new float[]{
                    gain, 0, 0, 0, 2, 0, gain, 0, 0, 2, 0, 0, gain, 0, 1, 0, 0, 0, 1, 0});
        }
        shadowPaint.setShader(shadowGradient);
    }

    /** Safe on the UI thread: the method schedules at most one background task. */
    void requestTextures() {
        if (closed || !requested.compareAndSet(false, true)) return;
        try {
            textureWorker.execute(new Runnable() {
                @Override public void run() {
                    try {
                        TextureSet loaded = loadTextures();
                        if (closed) return;
                        textures = loaded;
                        Log.i("GeneWars", "Modern terrain textures ready; HD materials=" + loaded.hdCount);
                        if (onTexturesReady != null) onTexturesReady.run();
                    } catch (IOException exception) {
                        Log.w("GeneWars", "Using built-in terrain palette", exception);
                    }
                }
            });
        } catch (RejectedExecutionException ignored) { }
    }

    void close() { closed = true; textureWorker.shutdownNow(); }

    /** Called only when the owner's viewport cache is rebuilt. */
    void drawTerrain(Canvas canvas, WorldMap map, Projection projection, boolean smooth) {
        canvas.drawColor(Color.rgb(15, 31, 40));
        final float halfW = projection.halfWidth(), halfH = projection.halfHeight();
        if (halfW <= 0 || halfH <= 0) return;
        final int width = projection.width(), height = projection.height();
        final float density = Math.max(.5f, projection.density());
        final float originX = projection.x(0, 0), originY = projection.y(0, 0);
        final TextureSet material = textures;
        if (material != null) {
            for (int i = 0; i < material.shaders.length; i++) {
                if (material.shaders[i] == null) continue;
                float texelsPerTile = material.bitmaps[i].getWidth() / 3.5f;
                textureTransform[0] = halfW / texelsPerTile;
                textureTransform[1] = -halfW / texelsPerTile;
                textureTransform[2] = originX;
                textureTransform[3] = halfH / texelsPerTile;
                textureTransform[4] = halfH / texelsPerTile;
                textureTransform[5] = originY;
                textureTransform[6] = 0; textureTransform[7] = 0; textureTransform[8] = 1;
                textureMatrix.setValues(textureTransform);
                material.shaders[i].setLocalMatrix(textureMatrix);
            }
        }
        texturePaint.setFilterBitmap(smooth);
        ArrayList<Float> glints = new ArrayList<Float>(), foam = new ArrayList<Float>();
        int waterSeen = 0, foamSeen = 0;
        for (int sum = 0; sum < map.width + map.height - 1; sum++) {
            int from = Math.max(0, sum - map.height + 1), to = Math.min(map.width - 1, sum);
            for (int x = from; x <= to; x++) {
                int y = sum - x;
                float cx = projection.x(x + .5, y + .5), cy = projection.y(x + .5, y + .5);
                if (cx < -halfW * 3 || cx > width + halfW * 3 || cy < -halfH * 6 || cy > height + halfH * 6) continue;
                float x0 = projection.x(x, y), y0 = projection.y(x, y);
                float x1 = projection.x(x + 1, y), y1 = projection.y(x + 1, y);
                float x2 = projection.x(x + 1, y + 1), y2 = projection.y(x + 1, y + 1);
                float x3 = projection.x(x, y + 1), y3 = projection.y(x, y + 1);
                int at = y * map.width + x, kind = map.terrain[at] & 7;
                int h = map.elevation[at];
                int hx = map.elevation[y * map.width + Math.min(map.width - 1, x + 1)];
                int hy = map.elevation[Math.min(map.height - 1, y + 1) * map.width + x];
                float dx = (hx - h) / 256f, dy = (hy - h) / 256f;
                float normal = (float) Math.sqrt(1 + .08f * dx * dx + .08f * dy * dy);
                float sunlight = (.85f - dx * .10f - dy * .16f) / normal;
                float shade = clamp(.82f + sunlight * .22f, .64f, 1.20f);
                int noise = ((x * 37 + y * 61 + x * y * 3) & 15) - 7;
                int base = BASE[kind];
                ground.setColor(tint(base, shade, noise * .45f));
                quad.reset(); quad.moveTo(x0, y0); quad.lineTo(x1, y1);
                quad.lineTo(x2, y2); quad.lineTo(x3, y3); quad.close();
                canvas.drawPath(quad, ground);
                if (material != null && material.shaders[kind] != null) {
                    texturePaint.setShader(material.shaders[kind]);
                    texturePaint.setColorFilter(lightFilters[Math.min(15, Math.max(0, Math.round((shade - .64f) / .04f)))]);
                    texturePaint.setAlpha(material.hd[kind] ? 226 : 27);
                    canvas.drawPath(quad, texturePaint);
                }
                // Separate triangular lighting reveals the underlying 3D slope,
                // while all four boundary vertices are shared with neighbours.
                if (Math.abs(dx - dy) > .16f && kind >= 2) {
                    triangle.reset(); triangle.moveTo(x0, y0); triangle.lineTo(x1, y1); triangle.lineTo(x2, y2); triangle.close();
                    detail.setColor(dx > dy ? Color.argb(13, 4, 25, 24) : Color.argb(10, 243, 244, 211));
                    detail.setStyle(Paint.Style.FILL); canvas.drawPath(triangle, detail);
                }
                if (kind >= 2) {
                    drawGroundDetails(canvas, projection, kind, x, y, cx, cy, halfW, halfH);
                    // Small, soft creases are ambient occlusion at actual height
                    // transitions, not a black outline around every tile.
                    float crevice = Math.abs(dx) + Math.abs(dy);
                    if (crevice > 1.8f) {
                        detail.setStyle(Paint.Style.STROKE); detail.setStrokeWidth(Math.max(.7f, density * .6f));
                        detail.setColor(Color.argb((int) Math.min(26, 6 + crevice * 2), 9, 30, 29));
                        canvas.drawLine(x0, y0, dx > dy ? x1 : x3, dx > dy ? y1 : y3, detail);
                        detail.setStyle(Paint.Style.FILL);
                    }
                } else {
                    int hash = hash(x, y);
                    if ((hash & 15) < 3) {
                        waterSeen++;
                        addReservoir(glints, MAX_GLINTS, waterSeen, hash,
                                cx, cy, halfW * (.25f + (hash & 7) * .035f), (hash & 255) / 31f);
                    }
                    if (x > 0 && (map.terrain[at - 1] & 7) >= 2) { foamSeen++; shoreline(canvas, foam, foamSeen, hash, x0, y0, x3, y3, density); }
                    if (x + 1 < map.width && (map.terrain[at + 1] & 7) >= 2) { foamSeen++; shoreline(canvas, foam, foamSeen, hash + 1, x1, y1, x2, y2, density); }
                    if (y > 0 && (map.terrain[at - map.width] & 7) >= 2) { foamSeen++; shoreline(canvas, foam, foamSeen, hash + 2, x0, y0, x1, y1, density); }
                    if (y + 1 < map.height && (map.terrain[at + map.width] & 7) >= 2) { foamSeen++; shoreline(canvas, foam, foamSeen, hash + 3, x3, y3, x2, y2, density); }
                }
            }
        }
        texturePaint.setShader(null); texturePaint.setColorFilter(null); texturePaint.setAlpha(255);
        // Soft grade is cached together with terrain; it costs no per-frame
        // image filtering or offscreen layer allocation.
        atmospherePaint.setAlpha(255);
        atmospherePaint.setShader(new LinearGradient(0, 0, width * .4f, height,
                new int[]{0x08D9EFE0, 0x00000000, 0x1905101C}, new float[]{0, .45f, 1}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, width, height, atmospherePaint);
        atmospherePaint.setShader(null);
        effects = new Effects(toArray(glints), toArray(foam));
    }

    private void drawGroundDetails(Canvas canvas, Projection p, int kind, int x, int y,
                                   float cx, float cy, float halfW, float halfH) {
        int hash = hash(x, y);
        if ((hash & 7) != 0 || halfW < 6) return;
        float ux = ((hash >>> 4) & 15) / 20f - .35f;
        float uy = ((hash >>> 8) & 15) / 20f - .35f;
        float px = p.x(x + .5 + ux, y + .5 + uy), py = p.y(x + .5 + ux, y + .5 + uy);
        detail.setStyle(Paint.Style.FILL);
        if (kind == 3 || kind == 5 || kind == 7) {
            detail.setStrokeWidth(Math.max(.7f, p.density() * .55f));
            detail.setColor(kind == 5 ? 0x3639C8B4 : 0x34234D29);
            float blade = Math.min(halfH * .34f, p.density() * 3.6f);
            canvas.drawLine(px, py, px - blade * .35f, py - blade, detail);
            canvas.drawLine(px + blade * .4f, py + .4f, px + blade * .7f, py - blade * .7f, detail);
        } else if (kind == 4 || kind == 2) {
            float size = Math.min(halfH * .18f, p.density() * 1.4f);
            detail.setColor(kind == 4 ? 0x40525D5B : 0x2C7E784E);
            rectangle.set(px - size * 1.5f, py - size * .6f, px + size * 1.5f, py + size * .6f);
            canvas.drawOval(rectangle, detail);
        }
    }

    private void shoreline(Canvas canvas, ArrayList<Float> points, int seen, int hash,
                           float x0, float y0, float x1, float y1, float density) {
        detail.setStyle(Paint.Style.STROKE); detail.setStrokeCap(Paint.Cap.ROUND);
        detail.setStrokeWidth(Math.max(1, density * 2.2f)); detail.setColor(0x2ACEE6D3);
        canvas.drawLine(x0, y0, x1, y1, detail);
        detail.setStrokeWidth(Math.max(.6f, density * .6f)); detail.setColor(0x64E4F0D7);
        canvas.drawLine(x0, y0, x1, y1, detail); detail.setStyle(Paint.Style.FILL);
        addReservoir(points, MAX_FOAM, seen, hash, x0, y0, x1, y1);
    }

    /** Only bounded highlights/atmosphere; never loops over all terrain cells. */
    void drawDynamic(Canvas canvas, WorldMap map, Projection projection, float elapsedSeconds) {
        if (!Float.isFinite(elapsedSeconds)) return;
        Effects visible = effects;
        float density = Math.max(.5f, projection.density());
        waterPaint.setStyle(Paint.Style.STROKE); waterPaint.setStrokeCap(Paint.Cap.ROUND);
        waterPaint.setStrokeWidth(Math.max(.7f, density * .65f));
        for (int i = 0; i + 3 < visible.glints.length; i += 4) {
            float phase = elapsedSeconds * .72f + visible.glints[i + 3];
            float amplitude = .5f + .5f * (float) Math.sin(phase);
            float x = visible.glints[i] + (float) Math.sin(phase * .44f) * density * 2;
            float y = visible.glints[i + 1], width = visible.glints[i + 2] * (.7f + amplitude * .3f);
            waterPaint.setColor(Color.argb((int) (10 + amplitude * 28), 192, 229, 224));
            wave.reset(); wave.moveTo(x - width, y);
            wave.quadTo(x, y - Math.max(.5f, width * .04f), x + width, y);
            canvas.drawPath(wave, waterPaint);
        }
        for (int i = 0; i + 3 < visible.foam.length; i += 4) {
            float phase = elapsedSeconds * .6f + i * .31f;
            float amount = .35f + .25f * (float) Math.sin(phase);
            float x0 = visible.foam[i], y0 = visible.foam[i + 1];
            float dx = visible.foam[i + 2] - x0, dy = visible.foam[i + 3] - y0;
            waterPaint.setColor(Color.argb((int) (16 + amount * 46), 221, 241, 219));
            canvas.drawLine(x0 + dx * amount * .3f, y0 + dy * amount * .3f,
                    x0 + dx * (.65f + amount * .35f), y0 + dy * (.65f + amount * .35f), waterPaint);
        }
        waterPaint.setStyle(Paint.Style.FILL);
        // Broad drifting cloud shadows, rendered with one reused radial shader.
        atmospherePaint.setAlpha(255);
        atmospherePaint.setShader(cloudGradient);
        for (int i = 0; i < 2; i++) {
            float width = projection.width(), height = projection.height();
            float x = ((elapsedSeconds * 5 * density + i * width * .61f) % (width * 1.8f)) - width * .4f;
            float y = height * (.22f + i * .47f);
            int saved = canvas.save(); canvas.translate(x, y); canvas.scale(width * .31f, Math.max(1, height * .19f));
            canvas.drawCircle(0, 0, 1, atmospherePaint); canvas.restoreToCount(saved);
        }
        atmospherePaint.setShader(null);
        for (int i = 0; i < MAX_MOTES; i++) {
            float phase = elapsedSeconds * (.03f + i * .003f) + i * .413f;
            float x = fractional(phase * .37f + i * .17f) * projection.width();
            float y = fractional(phase * .18f + i * .37f) * projection.height();
            atmospherePaint.setColor(Color.argb(10 + (i % 3) * 5, 235, 233, 184));
            canvas.drawCircle(x, y, density * (.55f + i % 2 * .3f), atmospherePaint);
        }
    }

    void drawContactShadow(Canvas canvas, float x, float y, float width, float height, float opacity) {
        if (width <= 0 || height <= 0 || opacity <= 0) return;
        shadowPaint.setAlpha((int) (clamp(opacity, 0, 1) * 255));
        int saved = canvas.save(); canvas.translate(x + width * .11f, y + height * .12f);
        canvas.scale(width * .5f, height * .5f); canvas.drawCircle(0, 0, 1, shadowPaint);
        canvas.restoreToCount(saved); shadowPaint.setAlpha(255);
    }

    private TextureSet loadTextures() throws IOException {
        Bitmap[] images = new Bitmap[8]; boolean[] hd = new boolean[8];
        Map<String, Bitmap> decoded = new HashMap<String, Bitmap>();
        JSONObject entries = null;
        try {
            JSONObject manifest = new JSONObject(readText("native/hd/manifest.json", 512 * 1024));
            entries = manifest.optJSONObject("textures");
        } catch (Exception ignored) { }
        int hdCount = 0;
        for (int i = 0; i < images.length && !closed; i++) {
            JSONObject entry = entries == null ? null : entries.optJSONObject(MATERIALS[i]);
            if (entry == null && entries != null && i == 1) entry = entries.optJSONObject("sand");
            if (entry == null && entries != null && i == 5) entry = entries.optJSONObject("grass");
            if (entry == null && entries != null && i == 7) entry = entries.optJSONObject("grass");
            if (entry != null) {
                try {
                    String file = safePath(entry.getString("file"));
                    Bitmap source = decoded.get(file);
                    if (source == null) { source = decode(file); decoded.put(file, source); }
                    JSONArray region = entry.optJSONArray("rect");
                    if (region == null) images[i] = source;
                    else {
                        if (region.length() != 4) throw new IOException("Invalid texture region");
                        int x = region.getInt(0), y = region.getInt(1), width = region.getInt(2), height = region.getInt(3);
                        if (x < 0 || y < 0 || width < 1 || height < 1 || x > source.getWidth() - width || y > source.getHeight() - height)
                            throw new IOException("Texture region outside atlas");
                        images[i] = Bitmap.createBitmap(source, x, y, width, height);
                    }
                    images[i].setDensity(Bitmap.DENSITY_NONE); hd[i] = true; hdCount++;
                } catch (Exception exception) { Log.w("GeneWars", "HD terrain material unavailable: " + MATERIALS[i], exception); }
            }
        }
        // Original atlas is used only as low-opacity grain if generated HD art
        // is unavailable. It is not described as a new HD texture.
        Bitmap fallback = null;
        for (int i = 0; i < images.length && !closed; i++) if (images[i] == null) {
            if (fallback == null) {
                try { fallback = decode("native/terrain/B32A.png"); }
                catch (IOException ignored) { break; }
            }
            int index = 80 + (i * 7) % 64;
            images[i] = Bitmap.createBitmap(fallback, (index % 16) * 32, (index / 16) * 32, 32, 32);
            images[i].setDensity(Bitmap.DENSITY_NONE);
        }
        return new TextureSet(images, hd, hdCount);
    }

    private Bitmap decode(String path) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inJustDecodeBounds = true;
        try (InputStream in = assets.open(path)) { BitmapFactory.decodeStream(in, null, options); }
        if (options.outWidth < 1 || options.outHeight < 1 || options.outWidth > 4096 || options.outHeight > 4096)
            throw new IOException("Invalid terrain texture dimensions");
        options.inJustDecodeBounds = false; options.inScaled = false; options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap;
        try (InputStream in = assets.open(path)) { bitmap = BitmapFactory.decodeStream(in, null, options); }
        if (bitmap == null) throw new IOException("Terrain texture decoding failed");
        bitmap.setDensity(Bitmap.DENSITY_NONE); return bitmap;
    }

    private String readText(String path, int maxBytes) throws IOException {
        try (InputStream in = assets.open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) {
                if (out.size() > maxBytes - count) throw new IOException("Terrain manifest too large");
                out.write(buffer, 0, count);
            }
            return out.toString("UTF-8");
        }
    }

    private static String safePath(String path) throws IOException {
        if (!path.startsWith("native/") || path.contains("..") || path.indexOf('\\') >= 0)
            throw new IOException("Unsafe terrain path");
        return path;
    }
    private static float fractional(float value) { return value - (float) Math.floor(value); }
    private static float clamp(float value, float low, float high) { return Math.max(low, Math.min(high, value)); }
    private static int tint(int color, float gain, float offset) {
        return Color.rgb((int) clamp(Color.red(color) * gain + offset, 0, 255),
                (int) clamp(Color.green(color) * gain + offset, 0, 255),
                (int) clamp(Color.blue(color) * gain + offset, 0, 255));
    }
    private static int hash(int x, int y) {
        int value = x * 73856093 ^ y * 19349663; value ^= value >>> 13; return value & 0x7fffffff;
    }
    private static void addReservoir(ArrayList<Float> points, int maximum, int seen, int hash,
                                     float a, float b, float c, float d) {
        int target;
        if (seen <= maximum) { target = points.size(); for (int i = 0; i < 4; i++) points.add(0f); }
        else { int sample = (hash & 0x7fffffff) % seen; if (sample >= maximum) return; target = sample * 4; }
        points.set(target, a); points.set(target + 1, b); points.set(target + 2, c); points.set(target + 3, d);
    }
    private static float[] toArray(ArrayList<Float> values) {
        float[] result = new float[values.size()]; for (int i = 0; i < result.length; i++) result[i] = values.get(i); return result;
    }
    private static final class TextureSet {
        final Bitmap[] bitmaps; final BitmapShader[] shaders = new BitmapShader[8]; final boolean[] hd; final int hdCount;
        TextureSet(Bitmap[] bitmaps, boolean[] hd, int hdCount) {
            this.bitmaps = bitmaps; this.hd = hd; this.hdCount = hdCount;
            for (int i = 0; i < bitmaps.length; i++) if (bitmaps[i] != null)
                shaders[i] = new BitmapShader(bitmaps[i], Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        }
    }
    private static final class Effects {
        final float[] glints, foam;
        Effects(float[] glints, float[] foam) { this.glints = glints; this.foam = foam; }
    }
}
