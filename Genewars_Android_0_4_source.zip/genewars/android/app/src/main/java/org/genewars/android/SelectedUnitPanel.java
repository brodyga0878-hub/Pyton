package org.genewars.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.genewars.core.Unit;

/** Native selection UI. Its transparent portrait window reveals the real GL model. */
final class SelectedUnitPanel extends FrameLayout {
    interface Actions { void command(String action); void geometryChanged(); }
    static final String MOVE="move", STOP="stop", BUILD="build", HARVEST="harvest", PLANT="plant",
            RESEARCH="research", ATTACK="attack", CONTEXT="context", CENTER="center", NEXT="next";
    private final Actions actions;
    private final LinearLayout body, details, commands;
    private final FrameLayout portrait;
    private final TextView title, category, health, task;
    private final HealthBar bar;
    private final Button collapse;
    private final Button[] buttons=new Button[4];
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box=new RectF(), hole=new RectF();
    private final Path panelPath=new Path();
    private LinearGradient panelGradient;
    private int gradientHeight, boundId=-1;
    private Unit.Kind boundKind;
    private boolean collapsed;
    private String activeMode="";

    SelectedUnitPanel(Context context,Actions listener) {
        super(context); actions=listener; setWillNotDraw(false); setClickable(true);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription("Карточка выбранного члена отряда");
        LinearLayout content=new LinearLayout(context);content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8),dp(7),dp(8),dp(8));addView(content,new FrameLayout.LayoutParams(-1,-2));
        body=new LinearLayout(context);body.setGravity(Gravity.CENTER_VERTICAL);content.addView(body,new LinearLayout.LayoutParams(-1,-2));
        portrait=new FrameLayout(context);portrait.setClickable(true);portrait.setFocusable(true);
        portrait.setOnClickListener(new OnClickListener(){@Override public void onClick(View view){actions.command(NEXT);}});
        body.addView(portrait,new LinearLayout.LayoutParams(dp(76),dp(100)));
        TextView next=label("›",22,ModernUiSkin.AQUA);next.setGravity(Gravity.BOTTOM|Gravity.RIGHT);
        next.setPadding(0,0,dp(5),0);next.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        portrait.addView(next,new FrameLayout.LayoutParams(-1,-1));
        details=new LinearLayout(context);details.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(0,-2,1);detailParams.leftMargin=dp(9);body.addView(details,detailParams);
        LinearLayout heading=new LinearLayout(context);heading.setGravity(Gravity.CENTER_VERTICAL);details.addView(heading,new LinearLayout.LayoutParams(-1,dp(48)));
        title=label("",14,ModernUiSkin.WHITE);title.setTypeface(Typeface.create("sans-serif-medium",0));title.setMaxLines(2);
        heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        collapse=new Button(context);collapse.setText("⌄");collapse.setTextSize(20);collapse.setAllCaps(false);
        collapse.setMinWidth(0);collapse.setMinimumWidth(0);collapse.setMinHeight(dp(48));collapse.setMinimumHeight(dp(48));
        ModernUiSkin.styleButton(collapse,false);collapse.setPadding(0,0,0,0);
        collapse.setContentDescription("Свернуть карточку");heading.addView(collapse,new LinearLayout.LayoutParams(dp(48),dp(48)));
        collapse.setOnClickListener(new OnClickListener(){@Override public void onClick(View view){setCollapsed(!collapsed);}});
        category=label("",10,ModernUiSkin.SECONDARY);category.setSingleLine(true);details.addView(category);
        health=label("",10,ModernUiSkin.AQUA);details.addView(health);
        bar=new HealthBar(context);LinearLayout.LayoutParams barParams=new LinearLayout.LayoutParams(-1,dp(5));barParams.topMargin=dp(3);barParams.bottomMargin=dp(4);details.addView(bar,barParams);
        task=label("",11,ModernUiSkin.WHITE);task.setMaxLines(2);details.addView(task);
        commands=new LinearLayout(context);LinearLayout.LayoutParams commandParams=new LinearLayout.LayoutParams(-1,dp(48));commandParams.topMargin=dp(7);content.addView(commands,commandParams);
        for(int i=0;i<buttons.length;i++){
            Button button=new Button(context);button.setTextSize(11);button.setAllCaps(false);button.setMaxLines(2);
            button.setMinWidth(0);button.setMinimumWidth(0);button.setMinHeight(dp(48));button.setMinimumHeight(dp(48));
            ModernUiSkin.styleButton(button,false);button.setPadding(dp(2),dp(2),dp(2),dp(2));
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,dp(48),1);if(i>0)params.leftMargin=dp(4);commands.addView(button,params);buttons[i]=button;
        }
        addOnLayoutChangeListener(new OnLayoutChangeListener(){@Override public void onLayoutChange(View view,int l,int t,int r,int b,int ol,int ot,int or,int ob){actions.geometryChanged();}});
    }

    void bind(Unit unit,boolean ready,boolean canCommand,String mode) {
        if(unit==null||!unit.alive()||!ready){if(getVisibility()!=GONE){setVisibility(GONE);actions.geometryChanged();}return;}
        if(getVisibility()!=VISIBLE)setVisibility(VISIBLE);
        setText(title,unit.title());title.setContentDescription("Выбран: "+unit.title());
        setText(category,(unit.kind==Unit.Kind.CREATURE?"Существо":"Специалист")+" · Союзник");
        setText(health,"ОЗ: "+(int)unit.hp+" / "+(int)unit.maxHp);
        health.setContentDescription("Здоровье выбранного: "+(int)unit.hp+" из "+(int)unit.maxHp);
        setText(task,"Задача: "+(unit.task==null?"Ожидание":unit.task));
        bar.value((float)(unit.hp/unit.maxHp));
        portrait.setContentDescription("3D-портрет выбранного: "+unit.title()+". Следующий член отряда");
        if(boundId!=unit.id||boundKind!=unit.kind){
            boundId=unit.id;boundKind=unit.kind;
            assign(0,"Идти",MOVE);assign(2,"Стоп",STOP);
            switch(unit.kind){
                case ENGINEER:assign(1,"Строить",BUILD);assign(3,"К нему",CENTER);break;
                case BOTANIST:assign(1,"Собирать",HARVEST);assign(3,"Посадить",PLANT);break;
                case GENETICIST:assign(1,"Изучать",RESEARCH);assign(3,"Приказ",CONTEXT);break;
                case RANGER:assign(1,"Атака",ATTACK);assign(3,"К нему",CENTER);break;
                default:assign(1,"Атака",ATTACK);assign(3,"Собирать",HARVEST);break;
            }
        }
        for(Button button:buttons)if(button.isEnabled()!=canCommand)button.setEnabled(canCommand);
        String nextMode=mode==null?"":mode;
        if(!activeMode.equals(nextMode)){
            activeMode=nextMode;
            for(Button button:buttons){boolean selected=activeMode.equals(button.getTag());ModernUiSkin.styleButton(button,selected);button.setPadding(dp(2),dp(2),dp(2),dp(2));button.setSelected(selected);}
        }
    }

    private void assign(int index,String label,final String command){
        Button button=buttons[index];setText(button,label);button.setTag(command);button.setContentDescription("Приказ выбранному: "+label);
        button.setOnClickListener(new OnClickListener(){@Override public void onClick(View view){actions.command(command);}});
    }
    private void setCollapsed(boolean value){
        collapsed=value;portrait.setVisibility(value?GONE:VISIBLE);category.setVisibility(value?GONE:VISIBLE);health.setVisibility(value?GONE:VISIBLE);
        bar.setVisibility(value?GONE:VISIBLE);task.setVisibility(value?GONE:VISIBLE);commands.setVisibility(value?GONE:VISIBLE);
        collapse.setText(value?"⌃":"⌄");collapse.setContentDescription(value?"Развернуть карточку":"Свернуть карточку");
        requestLayout();invalidate();actions.geometryChanged();
    }
    boolean portraitBounds(ViewGroup ancestor,Rect result){
        if(collapsed||getVisibility()!=VISIBLE||portrait.getWidth()<=0||portrait.getHeight()<=0)return false;
        result.set(0,0,portrait.getWidth(),portrait.getHeight());ancestor.offsetDescendantRectToMyCoords(portrait,result);return true;
    }
    private TextView label(String text,int size,int color){TextView view=new TextView(getContext());view.setText(text);view.setTextSize(size);view.setTextColor(color);view.setEllipsize(TextUtils.TruncateAt.END);view.setIncludeFontPadding(false);return view;}
    private static void setText(TextView view,String value){if(!TextUtils.equals(view.getText(),value))view.setText(value);}
    private int dp(float value){return ModernUiSkin.dp(getContext(),value);}

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);if(gradientHeight!=getHeight()){gradientHeight=getHeight();panelGradient=new LinearGradient(0,0,0,getHeight(),0xF31C3441,0xF307141E,Shader.TileMode.CLAMP);}
        box.set(dp(.5f),dp(.5f),getWidth()-dp(.5f),getHeight()-dp(.5f));panelPath.reset();panelPath.setFillType(Path.FillType.EVEN_ODD);panelPath.addRoundRect(box,dp(15),dp(15),Path.Direction.CW);
        if(!collapsed&&portrait.getVisibility()==VISIBLE){Rect rectangle=new Rect();portrait.getDrawingRect(rectangle);offsetDescendantRectToMyCoords(portrait,rectangle);hole.set(rectangle);panelPath.addRect(hole,Path.Direction.CW);}
        paint.setStyle(Paint.Style.FILL);paint.setShader(panelGradient);canvas.drawPath(panelPath,paint);paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(Color.argb(130,96,204,199));canvas.drawRoundRect(box,dp(15),dp(15),paint);
        if(!collapsed){paint.setColor(Color.argb(180,111,216,209));canvas.drawRect(hole,paint);}paint.setStyle(Paint.Style.FILL);
    }
    private static final class HealthBar extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final RectF rect=new RectF();private float value=-1;
        HealthBar(Context context){super(context);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        void value(float next){if(value!=next){value=Math.max(0,Math.min(1,next));invalidate();}}
        @Override protected void onDraw(Canvas canvas){rect.set(0,0,getWidth(),getHeight());paint.setColor(0xFF18323A);canvas.drawRoundRect(rect,3,3,paint);rect.right*=value;paint.setColor(value<.3f?0xFFF3A172:ModernUiSkin.AQUA);canvas.drawRoundRect(rect,3,3,paint);}
    }
}
