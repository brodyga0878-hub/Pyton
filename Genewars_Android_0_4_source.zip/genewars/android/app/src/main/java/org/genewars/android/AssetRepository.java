package org.genewars.android;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Rect;
import org.genewars.core.WorldMap;
import org.genewars.core.GameState;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;

/** Loads only resources bundled with this app. It never opens DOS executables. */
final class AssetRepository {
    /** An immutable HD picture or atlas region. Coordinates are source pixels. */
    private static final class Visual {
        final String file;
        final Rect region;
        final float scale, anchorX, anchorY;
        final String cacheKey;
        Visual(String file, Rect region, float scale, float anchorX, float anchorY) {
            this.file = file; this.region = region;
            this.scale = scale; this.anchorX = anchorX; this.anchorY = anchorY;
            cacheKey = file + (region == null ? "" : "#" + region.left + ":" + region.top + ":" + region.width() + ":" + region.height());
        }
    }
    static final class MapEntry {
        final String file;
        final String name;
        final String title;
        final int index;
        final double dropX;
        final double dropY;
        final JSONObject scenario;
        final boolean hasHostiles;
        MapEntry(String file, String name, String title, int index, double dropX, double dropY, JSONObject scenario) {
            this.file = file; this.name = name; this.title = title; this.index = index;
            this.dropX = dropX; this.dropY = dropY;
            this.scenario = scenario;
            boolean hostiles = scenario.optBoolean("hasHostiles", false);
            for (String key : new String[]{"creatures", "buildings"}) {
                JSONArray records = scenario.optJSONArray(key);
                if (records == null) continue;
                for (int i = 0; i < records.length(); i++) {
                    JSONObject record = records.optJSONObject(i);
                    int owner = record == null ? 0 : record.optInt("owner", 0);
                    if (owner >= 1 && owner <= 3) hostiles = true;
                }
            }
            hasHostiles = hostiles;
        }
        String displayTitle() {
            return title.length() > 0 ? title : "Карта " + (index + 1);
        }
    }

    final AssetManager assets;
    final List<MapEntry> maps = new ArrayList<MapEntry>();
    private final Map<String, String> spritePaths = new HashMap<String, String>();
    private final Map<String, Visual> hdSprites = new HashMap<String, Visual>();
    private final Map<String, Visual> hdImages = new HashMap<String, Visual>();
    private final Map<String, Bitmap> imagesByPath = new ConcurrentHashMap<String, Bitmap>();
    private final Set<String> pendingImages = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final Set<String> failedImages = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final ExecutorService graphicsWorker = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "native-graphics"); thread.setDaemon(true); return thread;
        }
    });
    private volatile boolean closed;
    final Map<String, String> sounds = new HashMap<String, String>();
    final List<String> music = new ArrayList<String>();

    AssetRepository(Context context) throws Exception {
        long started = android.os.SystemClock.elapsedRealtime();
        assets = context.getAssets();
        JSONObject manifest = new JSONObject(readText("native/manifest.json", 4 * 1024 * 1024));
        JSONArray entries = manifest.getJSONArray("maps");
        if (entries.length() < 1 || entries.length() > 100) throw new IOException("Некорректный список карт");
        for (int i = 0; i < entries.length(); i++) {
            JSONObject item = entries.getJSONObject(i);
            String title = item.optString("title_ru", "");
            String name = item.optString("name", "");
            if (title.length() == 0) {
                title = name.startsWith("CUST") ? "Своя карта " + (i + 1) : "Планета " + (i + 1);
            }
            JSONArray dropSites = item.optJSONArray("dropSites");
            JSONObject drop = dropSites != null && dropSites.length() > 0 ? dropSites.optJSONObject(0) : null;
            maps.add(new MapEntry(safe(item.getString("file")), name, title, i,
                    drop == null ? Double.NaN : drop.optDouble("x", Double.NaN),
                    drop == null ? Double.NaN : drop.optDouble("y", Double.NaN), item));
        }
        JSONObject imageEntries = manifest.optJSONObject("sprites");
        if (imageEntries != null) {
            for (Iterator<String> iterator = imageEntries.keys(); iterator.hasNext();) {
                String key = iterator.next();
                Object value = imageEntries.get(key);
                String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
                spritePaths.put(key, safe(path));
            }
        }
        JSONObject sources = manifest.optJSONObject("spriteSources");
        if (sources != null) for (Iterator<String> iterator = sources.keys(); iterator.hasNext();) {
            String key = iterator.next();
            JSONObject info = sources.optJSONObject(key);
            String path = spritePaths.get(key);
            if (info == null || path == null) continue;
            String source = info.optString("source", "");
            int slash = source.lastIndexOf('/');
            String name = source.substring(slash + 1).replace(".ANB", "");
            if (source.contains("/CREATURE/")) spritePaths.put("creatures/" + name, path);
            else if (source.contains("/BUILDING/")) spritePaths.put("buildings/" + name, path);
            else if (source.contains("/SPEC/")) spritePaths.put("specialists/" + name, path);
        }
        JSONObject audioEntries = manifest.optJSONObject("sounds");
        if (audioEntries != null) {
            for (Iterator<String> iterator = audioEntries.keys(); iterator.hasNext();) {
                String key = iterator.next();
                Object value = audioEntries.get(key);
                String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
                sounds.put(key, safe(path));
            }
        }
        JSONArray musicEntries = manifest.optJSONArray("music");
        if (musicEntries != null) for (int i = 0; i < musicEntries.length(); i++) {
            Object value = musicEntries.get(i);
            String path = value instanceof JSONObject ? ((JSONObject) value).getString("file") : value.toString();
            music.add(safe(path));
        }
        readHdIndex();
        android.util.Log.i("GeneWars", "Resource index ready: " + maps.size() + " maps in "
                + (android.os.SystemClock.elapsedRealtime() - started) + " ms; graphics deferred");
    }

    WorldMap loadMap(MapEntry entry) throws IOException {
        try (InputStream in = assets.open(entry.file)) { return WorldMap.read(in); }
    }

    GameState startGame(MapEntry entry, int mission, long seed) throws Exception {
        JSONObject scenario = entry.scenario;
        if (scenario.has("scenarioFile")) {
            scenario = new JSONObject(readText(safe(scenario.getString("scenarioFile")), 1024 * 1024));
        }
        WorldMap map = loadMap(entry);
        GameState game = Double.isNaN(entry.dropX) || Double.isNaN(entry.dropY)
                ? GameState.newImportedGame(map, mission, seed)
                : GameState.newImportedGame(map, mission, seed, entry.dropX, entry.dropY);
        // Initial ecology and buildings come from the supplied map, not a
        // decorative or randomly invented layout. New simulation rules remain
        // explicitly separate from the decoded original records.
        game.clearScenarioEntities();
        JSONArray trees = scenario.getJSONArray("trees");
        for (int i = 0; i < trees.length(); i++) {
            JSONObject tree = trees.getJSONObject(i);
            int biomass = tree.optInt("wood", 0);
            if (biomass <= 0) biomass = tree.getInt("health");
            game.importPlant(tree.getInt("species"), tree.getDouble("x"), tree.getDouble("y"), biomass);
        }
        JSONArray creatures = scenario.getJSONArray("creatures");
        for (int i = 0; i < creatures.length(); i++) {
            JSONObject creature = creatures.getJSONObject(i);
            int owner = creature.getInt("owner");
            int team = owner == 0 ? 0 : owner == 4 ? 2 : 1;
            game.importCreature(creature.getInt("species"), creature.getDouble("x"), creature.getDouble("y"),
                    team, creature.getDouble("health"), creature.getDouble("energy"),
                    creature.getDouble("maxHealth"), creature.getDouble("maxEnergy"), creature.getDouble("lifespan"));
        }
        JSONArray buildings = scenario.getJSONArray("buildings");
        for (int i = 0; i < buildings.length(); i++) {
            JSONObject building = buildings.getJSONObject(i);
            int team = building.getInt("owner") == 0 ? 0 : 1;
            if (!game.importBuilding(building.getInt("type"), building.getInt("stage"),
                    building.getDouble("x"), building.getDouble("y"), team,
                    building.getInt("build"), building.getInt("flags"))) {
                android.util.Log.w("GeneWars", "Unsupported source building in " + entry.name);
            }
        }
        game.finishScenarioImport(scenario.getInt("payment"));
        return game;
    }

    /** Called on the game-loading worker, before the new world is published. */
    void prepareGraphics(GameState state) throws IOException {
        Set<String> keys = new HashSet<String>();
        for (org.genewars.core.Unit unit : state.units) keys.add(unit.spriteKey());
        for (org.genewars.core.Building building : state.buildings) keys.add(building.spriteKey());
        for (org.genewars.core.Plant plant : state.plants) keys.add("plant_" + plant.species);
        for (String key : keys) {
            if (closed || Thread.currentThread().isInterrupted()) throw new IOException("Загрузка прервана");
            Visual hd = hdSprites.get(key);
            if (hd != null) {
                try { cachedDecode(hd); continue; }
                catch (IOException exception) {
                    failedImages.add(hd.cacheKey);
                    android.util.Log.w("GeneWars", "HD sprite unavailable, using original: " + key, exception);
                }
            }
            String path = spritePaths.get(key);
            if (path != null) cachedDecode(path);
        }
    }

    /** No disk IO on the drawing thread: unseen sprites are decoded once asynchronously. */
    Bitmap sprite(String key) {
        Visual hd = hdSprites.get(key);
        if (hd != null) {
            Bitmap image = request(hd);
            if (image != null) return image;
        }
        final String path = spritePaths.get(key);
        if (path == null) return null;
        return request(new Visual(path, null, 1, .5f, 1));
    }

    /** HD menu art/illustration; never performs IO on the caller's thread. */
    Bitmap image(String key) {
        Visual visual = hdImages.get(key);
        return visual == null ? null : request(visual);
    }

    float spriteScale(String key) { Visual visual = readyStyle(key); return visual == null ? 1 : visual.scale; }
    float spriteAnchorX(String key) { Visual visual = readyStyle(key); return visual == null ? .5f : visual.anchorX; }
    float spriteAnchorY(String key) { Visual visual = readyStyle(key); return visual == null ? 1 : visual.anchorY; }
    boolean hasHdSprite(String key) { return hdSprites.containsKey(key); }
    boolean hasHdGraphics() { return !hdSprites.isEmpty() || !hdImages.isEmpty(); }

    private Visual readyStyle(String key) {
        Visual visual = hdSprites.get(key);
        return visual != null && imagesByPath.containsKey(visual.cacheKey) ? visual : null;
    }

    private Bitmap request(final Visual visual) {
        final String key = visual.cacheKey;
        Bitmap image = imagesByPath.get(key);
        if (image == null && !closed && !failedImages.contains(key) && pendingImages.add(key)) {
            try {
                graphicsWorker.execute(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!closed) cachedDecode(visual);
                        } catch (IOException exception) {
                            failedImages.add(key);
                            android.util.Log.w("GeneWars", "Picture could not be decoded: " + visual.file, exception);
                        } finally { pendingImages.remove(key); }
                    }
                });
            } catch (RejectedExecutionException exception) { pendingImages.remove(key); }
        }
        return image;
    }

    void close() { closed = true; graphicsWorker.shutdownNow(); }

    private Bitmap cachedDecode(String path) throws IOException {
        return cachedDecode(new Visual(path, null, 1, .5f, 1));
    }

    private Bitmap cachedDecode(Visual visual) throws IOException {
        synchronized (imagesByPath) {
            if (closed) throw new IOException("Загрузка прервана");
            Bitmap image = imagesByPath.get(visual.cacheKey);
            if (image != null) return image;
            image = loadBitmap(visual);
            if (closed) throw new IOException("Загрузка прервана");
            imagesByPath.put(visual.cacheKey, image);
            return image;
        }
    }

    private Bitmap loadBitmap(Visual visual) throws IOException {
        String path = visual.file;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try (InputStream in = assets.open(path)) { BitmapFactory.decodeStream(in, null, options); }
        if (options.outWidth <= 0 || options.outHeight <= 0 || options.outWidth > 4096 || options.outHeight > 4096)
            throw new IOException("Некорректный размер спрайта: " + path);
        options.inJustDecodeBounds = false;
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap image;
        if (visual.region == null) {
            if (options.outWidth > 2048 || options.outHeight > 2048)
                throw new IOException("Слишком большое изображение: " + path);
            try (InputStream in = assets.open(path)) { image = BitmapFactory.decodeStream(in, null, options); }
        } else {
            Rect region = visual.region;
            if (region.left < 0 || region.top < 0 || region.right > options.outWidth || region.bottom > options.outHeight
                    || region.width() <= 0 || region.height() <= 0 || region.width() > 2048 || region.height() > 2048)
                throw new IOException("Некорректная область атласа: " + path);
            try (InputStream in = assets.open(path)) {
                BitmapRegionDecoder decoder = BitmapRegionDecoder.newInstance(in, false);
                if (decoder == null) throw new IOException("Не удалось прочитать атлас: " + path);
                try { image = decoder.decodeRegion(region, options); }
                finally { decoder.recycle(); }
            }
        }
        if (image == null) throw new IOException("Не удалось прочитать спрайт: " + path);
        image.setDensity(Bitmap.DENSITY_NONE);
        return image;
    }

    private void readHdIndex() {
        try {
            JSONObject manifest = new JSONObject(readText("native/hd/manifest.json", 512 * 1024));
            if (manifest.optInt("format", 1) != 1) throw new IOException("Неизвестный формат HD-ресурсов");
            readVisuals(manifest.optJSONObject("sprites"), hdSprites);
            readVisuals(manifest.optJSONObject("images"), hdImages);
            // HD overrides must also reach core-origin aliases used by preload.
            Map<String, Visual> aliases = new HashMap<String, Visual>();
            for (Map.Entry<String, Visual> entry : hdSprites.entrySet()) {
                String original = spritePaths.get(entry.getKey());
                if (original == null) continue;
                for (Map.Entry<String, String> candidate : spritePaths.entrySet())
                    if (original.equals(candidate.getValue()) && !hdSprites.containsKey(candidate.getKey()))
                        aliases.put(candidate.getKey(), entry.getValue());
            }
            hdSprites.putAll(aliases);
            for (int i = 0; i < GameState.SPECIES_SPRITES.length; i++) {
                Visual visual = hdSprites.get("creature_" + i);
                if (visual != null) hdSprites.put("creatures/" + GameState.SPECIES_SPRITES[i], visual);
            }
            for (org.genewars.core.Building.Kind kind : org.genewars.core.Building.Kind.values()) {
                Visual visual = hdSprites.get("building_" + kind.name());
                if (visual != null) hdSprites.put("buildings/" + kind.sprite, visual);
            }
            android.util.Log.i("GeneWars", "HD resource index ready: " + hdSprites.size() + " sprite keys");
        } catch (java.io.FileNotFoundException missing) {
            // HD is optional; original art remains available in a base build.
        } catch (Exception exception) {
            hdSprites.clear(); hdImages.clear();
            android.util.Log.w("GeneWars", "HD index rejected; using original art", exception);
        }
    }

    private void readVisuals(JSONObject values, Map<String, Visual> output) throws Exception {
        if (values == null) return;
        if (values.length() > 512) throw new IOException("Слишком много HD-изображений");
        for (Iterator<String> iterator = values.keys(); iterator.hasNext();) {
            String key = iterator.next();
            Object raw = values.get(key);
            JSONObject object = raw instanceof JSONObject ? (JSONObject) raw : null;
            String file = safe(object == null ? raw.toString() : object.getString("file"));
            if (!file.startsWith("native/hd/")) throw new IOException("HD-путь вне каталога ресурсов");
            Rect region = null;
            JSONArray rectangle = object == null ? null : object.optJSONArray("rect");
            if (rectangle != null) {
                if (rectangle.length() != 4) throw new IOException("Некорректная область HD-атласа");
                int x = rectangle.getInt(0), y = rectangle.getInt(1), width = rectangle.getInt(2), height = rectangle.getInt(3);
                if (x < 0 || y < 0 || width <= 0 || height <= 0 || width > 2048 || height > 2048
                        || x > 4096 - width || y > 4096 - height)
                    throw new IOException("HD-область выходит за границы");
                region = new Rect(x, y, x + width, y + height);
            }
            double scale = object == null ? 1 : object.optDouble("scale", 1);
            double anchorX = .5, anchorY = 1;
            JSONArray anchor = object == null ? null : object.optJSONArray("anchor");
            if (anchor != null) {
                if (anchor.length() != 2) throw new IOException("Некорректная точка привязки");
                anchorX = anchor.getDouble(0); anchorY = anchor.getDouble(1);
            }
            if (Double.isNaN(scale) || Double.isInfinite(scale) || scale < .25 || scale > 4
                    || Double.isNaN(anchorX) || Double.isNaN(anchorY) || anchorX < 0 || anchorX > 1 || anchorY < 0 || anchorY > 1)
                throw new IOException("Некорректная геометрия HD-спрайта");
            output.put(key, new Visual(file, region, (float) scale, (float) anchorX, (float) anchorY));
        }
    }

    private String readText(String path, int limit) throws IOException {
        try (InputStream in = assets.open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) {
                if (out.size() + n > limit) throw new IOException("Слишком большой манифест ресурсов");
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), "UTF-8");
        }
    }

    private static String safe(String path) throws IOException {
        if (!path.startsWith("native/") || path.contains("..") || path.indexOf('\\') >= 0)
            throw new IOException("Некорректный путь ресурса");
        return path;
    }
}
