package org.genewars.android.gl3d;

import org.genewars.core.WorldMap;

/** Thread-safe perspective orbit camera. XZ is terrain, +Y is up. */
public final class Camera3D {
    public static final float HEIGHT_FACTOR=.14f;
    private final WorldMap map;
    private int width=1,height=1;
    private float targetX,targetZ,distance=22,yaw=45,pitch=55;
    private Snapshot cachedSnapshot;
    public Camera3D(WorldMap source) {
        if(source==null)throw new IllegalArgumentException("Map required");
        // Keep camera ray tests independent from any mutable simulation arrays.
        map=new WorldMap(source.width,source.height,source.terrain,source.elevation,source.blocked,source.sourceName);
        targetX=map.width*.5f;targetZ=map.height*.5f;
    }
    public synchronized void setViewport(int w,int h){int nw=Math.max(1,w),nh=Math.max(1,h);if(nw!=width||nh!=height){width=nw;height=nh;cachedSnapshot=null;}}
    public synchronized void centerOn(float x,float z){if(finite(x)&&finite(z)){float nx=clamp(x,0,map.width-1),nz=clamp(z,0,map.height-1);if(nx!=targetX||nz!=targetZ){targetX=nx;targetZ=nz;cachedSnapshot=null;}}}
    public synchronized void orbit(float yawDeltaDegrees,float pitchDeltaDegrees){
        if(!finite(yawDeltaDegrees)||!finite(pitchDeltaDegrees))return;
        float nextYaw=(yaw+yawDeltaDegrees)%360,nextPitch=clamp(pitch+pitchDeltaDegrees,28,78);
        if(nextYaw!=yaw||nextPitch!=pitch){yaw=nextYaw;pitch=nextPitch;cachedSnapshot=null;}
    }
    public synchronized void zoom(float factor){if(finite(factor)&&factor>0){float next=clamp(distance/factor,7,75);if(next!=distance){distance=next;cachedSnapshot=null;}}}
    /** Accept GestureDetector scroll distances, not raw finger deltas. */
    public synchronized void panScreen(float dx,float dy){
        if(!finite(dx)||!finite(dy))return;
        double a=Math.toRadians(yaw),b=Math.toRadians(pitch);float scale=(float)(2*distance*Math.tan(Math.toRadians(42)*.5)/height);
        float up=dy/(float)Math.sin(b);
        centerOn(targetX+(float)(Math.cos(a)*dx+Math.sin(a)*up)*scale,
                targetZ+(float)(-Math.sin(a)*dx+Math.cos(a)*up)*scale);
    }
    public synchronized float zoomLevel(){return 22/distance;}
    public synchronized float yawDegrees(){return yaw;}
    public synchronized float[] projectGround(float x,float z){return project(x,heightAt(map,x,z),z);}
    public synchronized float[] project(float x,float y,float z){
        Snapshot s=snapshot();float[] clip=Matrix3D.transform(s.viewProjection,x,y,z,1);
        if(clip[3]<=.0001f)return null;
        return new float[]{(clip[0]/clip[3]*.5f+.5f)*width,(.5f-clip[1]/clip[3]*.5f)*height,clip[2]/clip[3]};
    }
    public synchronized float[] pickGround(float screenX,float screenY){
        if(!finite(screenX)||!finite(screenY))return null;
        Snapshot s=snapshot();float nx=screenX/width*2-1,ny=1-screenY/height*2;
        float[] near=Matrix3D.transform(s.inverseViewProjection,nx,ny,-1,1),far=Matrix3D.transform(s.inverseViewProjection,nx,ny,1,1);
        for(int i=0;i<3;i++){near[i]/=near[3];far[i]/=far[3];}
        float dx=far[0]-near[0],dy=far[1]-near[1],dz=far[2]-near[2],length=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        dx/=length;dy/=length;dz/=length;
        float start=0,end=Math.min(length,300);
        float[] bx=slab(near[0],dx,0,map.width-.0001f),bz=slab(near[2],dz,0,map.height-.0001f);
        if(bx==null||bz==null)return null;start=Math.max(start,Math.max(bx[0],bz[0]));end=Math.min(end,Math.min(bx[1],bz[1]));
        if(start>end)return null;
        float previous=start,previousF=near[1]+dy*start-heightAt(map,near[0]+dx*start,near[2]+dz*start);
        for(float t=Math.min(end,start+.25f);t<=end+.001f;t=Math.min(end,t+.25f)){
            float value=near[1]+dy*t-heightAt(map,near[0]+dx*t,near[2]+dz*t);
            if(previousF>=0&&value<=0){
                float lo=previous,hi=t;for(int i=0;i<18;i++){float mid=(lo+hi)*.5f;float f=near[1]+dy*mid-heightAt(map,near[0]+dx*mid,near[2]+dz*mid);if(f>0)lo=mid;else hi=mid;}
                float hit=(lo+hi)*.5f;return new float[]{clamp(near[0]+dx*hit,0,map.width-.0001f),clamp(near[2]+dz*hit,0,map.height-.0001f)};
            }
            if(t>=end)break;previous=t;previousF=value;
        }
        return null;
    }
    public synchronized Snapshot snapshot(){
        if(cachedSnapshot!=null)return cachedSnapshot;
        float ty=heightAt(map,targetX,targetZ),a=(float)Math.toRadians(yaw),b=(float)Math.toRadians(pitch);
        float ex=targetX+distance*(float)Math.cos(b)*(float)Math.sin(a),ey=ty+distance*(float)Math.sin(b),ez=targetZ+distance*(float)Math.cos(b)*(float)Math.cos(a);
        float[] view=Matrix3D.lookAt(ex,ey,ez,targetX,ty,targetZ),projection=Matrix3D.perspective(42,width/(float)height,.15f,260);
        float[] vp=Matrix3D.multiply(projection,view);
        cachedSnapshot=new Snapshot(width,height,ex,ey,ez,targetX,ty,targetZ,distance,yaw,pitch,view,projection,vp,Matrix3D.inverse(vp));
        return cachedSnapshot;
    }
    public static float heightAt(WorldMap map,double x,double z){
        return heightAt(map.width,map.height,map.elevation,x,z);
    }
    static float heightAt(int width,int height,short[] values,double x,double z){
        float wx=clamp((float)x,0,width-1),wz=clamp((float)z,0,height-1);int ix=(int)wx,iz=(int)wz;
        int nx=Math.min(width-1,ix+1),nz=Math.min(height-1,iz+1);float u=wx-ix,v=wz-iz;
        float h00=values[iz*width+ix],h10=values[iz*width+nx],h11=values[nz*width+nx],h01=values[nz*width+ix];
        float h=v<=u?h00+(h10-h00)*u+(h11-h10)*v:h00+(h11-h01)*u+(h01-h00)*v;
        return h/256f*HEIGHT_FACTOR;
    }
    private static float[] slab(float origin,float direction,float low,float high){
        if(Math.abs(direction)<.000001f)return origin>=low&&origin<=high?new float[]{-10000,10000}:null;
        float a=(low-origin)/direction,b=(high-origin)/direction;return new float[]{Math.min(a,b),Math.max(a,b)};
    }
    private static boolean finite(float v){return !Float.isNaN(v)&&!Float.isInfinite(v);}
    private static float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    public static final class Snapshot {
        public final int width,height;
        public final float eyeX,eyeY,eyeZ,targetX,targetY,targetZ,distance,yaw,pitch;
        final float[] view,projection,viewProjection,inverseViewProjection;
        Snapshot(int w,int h,float ex,float ey,float ez,float tx,float ty,float tz,float d,float yaw,float pitch,float[] v,float[] p,float[] vp,float[] ivp){
            width=w;height=h;eyeX=ex;eyeY=ey;eyeZ=ez;targetX=tx;targetY=ty;targetZ=tz;distance=d;this.yaw=yaw;this.pitch=pitch;view=v;projection=p;viewProjection=vp;inverseViewProjection=ivp;
        }
    }
}
