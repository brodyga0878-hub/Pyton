package org.genewars.qa;

import org.genewars.android.gl3d.MeshData3D;
import org.genewars.android.gl3d.ModelLibrary3D;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Independent CPU geometry/rig invariants; no Android, OpenGL or game state. */
public final class Model3DAcceptance {
    private static int models, triangles, animatedModels;
    private static final StringBuilder records = new StringBuilder();

    public static void main(String[] ignored) {
        Set<Long> creatureShapes = new HashSet<Long>();
        for (int i = 0; i < 25; i++) {
            MeshData3D model = ModelLibrary3D.getCreature(i);
            require(model == ModelLibrary3D.getCreature(i), "Creature model is not cached: " + i);
            creatureShapes.add(check("creature_" + i, model, true));
        }
        for (int i = 0; i < 4; i++) {
            MeshData3D model = ModelLibrary3D.getSpecialist(i);
            require(model == ModelLibrary3D.getSpecialist(i), "Specialist model is not cached: " + i);
            check("specialist_" + i, model, true);
        }
        for (int i = 0; i < 14; i++) {
            MeshData3D model = ModelLibrary3D.getBuilding(i);
            require(model == ModelLibrary3D.getBuilding(i), "Building model is not cached: " + i);
            check("building_" + i, model, false);
        }
        for (int i = 0; i < 12; i++) {
            MeshData3D model = ModelLibrary3D.getPlant(i);
            require(model == ModelLibrary3D.getPlant(i), "Plant model is not cached: " + i);
            check("plant_" + i, model, false);
        }
        require(creatureShapes.size() >= 5, "Creature families do not have distinct geometry");
        require(triangles <= 276380, "Model library exceeds 2x version0.3 triangle budget: " + triangles);
        System.out.println("{\"passed\":true,\"models\":" + models + ",\"triangles\":" + triangles
                + ",\"animated_models\":" + animatedModels + ",\"distinct_creature_shapes\":"
                + creatureShapes.size() + ",\"records\":[" + records + "]}");
    }

    private static long check(String key, MeshData3D mesh, boolean requireWalk) {
        require(mesh != null, key + ": missing model");
        float[] vertices = mesh.vertices;
        int[] indices = mesh.indices;
        require(vertices != null && vertices.length > 0 && vertices.length % 13 == 0, key + ": bad stride");
        int count = vertices.length / 13;
        require(count <= 65535, key + ": exceeds model-library vertex budget");
        require(indices != null && indices.length >= 12 && indices.length % 3 == 0, key + ": bad triangles");
        require(mesh.boneCount >= 1 && mesh.boneCount <= 24, key + ": bad palette size");
        require(mesh.bones.length == mesh.boneCount, key + ": palette/bone array mismatch");
        for (int bone = 0; bone < mesh.boneCount; bone++) {
            org.genewars.android.gl3d.Bone3D joint = mesh.bones[bone];
            require(joint != null && (bone == 0 ? joint.parent == -1 : joint.parent >= 0 && joint.parent < bone),
                    key + ": invalid or cyclic joint hierarchy");
            require(Float.isFinite(joint.x) && Float.isFinite(joint.y) && Float.isFinite(joint.z)
                    && Float.isFinite(joint.phase) && Float.isFinite(joint.amplitude), key + ": nonfinite joint parameters");
        }
        require(Float.isFinite(mesh.radius) && mesh.radius > 0, key + ": bad radius");
        require(Float.isFinite(mesh.height) && mesh.height > 0, key + ": bad height");
        float[] min = {Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY};
        float[] max = {Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY};
        Set<Integer> usedBones = new HashSet<Integer>();
        Set<Long> materials = new HashSet<Long>();
        long signature = 0xcbf29ce484222325L;
        for (int i = 0; i < vertices.length; i += 13) {
            for (int j = 0; j < 13; j++) require(Float.isFinite(vertices[i + j]), key + ": nonfinite vertex");
            for (int j = 0; j < 3; j++) {
                min[j] = Math.min(min[j], vertices[i + j]); max[j] = Math.max(max[j], vertices[i + j]);
                signature = (signature ^ Float.floatToIntBits(vertices[i + j])) * 0x100000001b3L;
            }
            float normal2 = vertices[i + 3] * vertices[i + 3] + vertices[i + 4] * vertices[i + 4]
                    + vertices[i + 5] * vertices[i + 5];
            require(Math.abs(normal2 - 1) < .03f, key + ": non-unit normal");
            for (int j = 6; j < 10; j++) require(vertices[i + j] >= 0 && vertices[i + j] <= 1, key + ": invalid color");
            float roughness = vertices[i + 10], metallic = vertices[i + 11];
            require(roughness >= .12f && roughness <= 1 && metallic >= 0 && metallic <= 1,
                    key + ": invalid roughness/metallic material");
            materials.add(((long)Float.floatToIntBits(roughness) << 32) | (Float.floatToIntBits(metallic) & 0xffffffffL));
            int bone = Math.round(vertices[i + 12]);
            require(Math.abs(vertices[i + 12] - bone) < 1e-5 && bone >= 0 && bone < mesh.boneCount,
                    key + ": invalid bone attribute");
            usedBones.add(bone);
        }
        float sx = max[0] - min[0], sy = max[1] - min[1], sz = max[2] - min[2];
        if (key.startsWith("specialist_") || key.startsWith("building_"))
            require(materials.size() >= 2, key + ": all regions use the same material response");
        require(Math.min(sx, Math.min(sy, sz)) > .01f, key + ": geometry is flat");
        int degenerates = 0;
        double volume6 = 0;
        for (int i = 0; i < indices.length; i += 3) {
            for (int j = 0; j < 3; j++) require(indices[i + j] >= 0 && indices[i + j] < count,
                    key + ": index outside VBO");
            int a = indices[i] * 13, b = indices[i + 1] * 13, c = indices[i + 2] * 13;
            double abx = vertices[b] - vertices[a], aby = vertices[b + 1] - vertices[a + 1], abz = vertices[b + 2] - vertices[a + 2];
            double acx = vertices[c] - vertices[a], acy = vertices[c + 1] - vertices[a + 1], acz = vertices[c + 2] - vertices[a + 2];
            double nx = aby * acz - abz * acy, ny = abz * acx - abx * acz, nz = abx * acy - aby * acx;
            if (nx * nx + ny * ny + nz * nz < 1e-16) degenerates++;
            volume6 += vertices[a] * (vertices[b + 1] * vertices[c + 2] - vertices[b + 2] * vertices[c + 1])
                    + vertices[a + 1] * (vertices[b + 2] * vertices[c] - vertices[b] * vertices[c + 2])
                    + vertices[a + 2] * (vertices[b] * vertices[c + 1] - vertices[b + 1] * vertices[c]);
        }
        require(degenerates * 20 <= indices.length / 3, key + ": excessive collapsed triangles");
        require(Math.abs(volume6 / 6) > 1e-6, key + ": zero signed volume, inspect mesh winding/flatness");
        float maxMovement = 0;
        boolean separateBones = false;
        for (int action = 0; action <= 4; action++) {
            float[] first = pose(mesh, .07f, action, key), second = pose(mesh, .43f, action, key);
            for (int i = 0; i < count; i++) {
                int offset = i * 13, bone = Math.round(vertices[offset + 12]) * 16;
                for (int axis = 0; axis < 3; axis++) {
                    float a = transform(first, bone, vertices, offset, axis), b = transform(second, bone, vertices, offset, axis);
                    maxMovement = Math.max(maxMovement, Math.abs(a - b));
                }
            }
            for (int bone : usedBones) for (int n = 0; n < 16; n++)
                if (Math.abs(second[bone * 16 + n] - second[n]) > 1e-4) separateBones = true;
        }
        if (requireWalk) {
            require(usedBones.size() >= 3, key + ": too few influenced bones for a segmented rig");
            require(maxMovement > .002f, key + ": rig does not animate influenced geometry");
            require(separateBones, key + ": whole mesh only moves as one rigid body");
        }
        if (maxMovement > .00001f) animatedModels++;
        if (records.length() > 0) records.append(',');
        records.append(String.format(Locale.ROOT,
                "{\"key\":\"%s\",\"vertices\":%d,\"triangles\":%d,\"bones\":%d,\"used_bones\":%d,"
                + "\"materials\":%d,\"bounds\":[%.5f,%.5f,%.5f],\"signed_volume\":%.8f,\"degenerate_triangles\":%d,\"max_pose_motion\":%.6f}",
                key, count, indices.length / 3, mesh.boneCount, usedBones.size(), materials.size(), sx, sy, sz, volume6 / 6, degenerates, maxMovement));
        models++; triangles += indices.length / 3;
        return signature;
    }

    private static float[] pose(MeshData3D mesh, float time, int action, String key) {
        float[] out = new float[384];
        java.util.Arrays.fill(out, Float.NaN);
        mesh.pose(time, action, 1, out);
        for (int bone = 0; bone < mesh.boneCount; bone++) {
            int at = bone * 16;
            for (int i = 0; i < 16; i++) require(Float.isFinite(out[at + i]), key + ": nonfinite pose");
            require(Math.abs(out[at + 3]) < 1e-5 && Math.abs(out[at + 7]) < 1e-5
                    && Math.abs(out[at + 11]) < 1e-5 && Math.abs(out[at + 15] - 1) < 1e-5,
                    key + ": nonaffine bone pose");
            double determinant = out[at] * (out[at + 5] * out[at + 10] - out[at + 6] * out[at + 9])
                    - out[at + 4] * (out[at + 1] * out[at + 10] - out[at + 2] * out[at + 9])
                    + out[at + 8] * (out[at + 1] * out[at + 6] - out[at + 2] * out[at + 5]);
            require(Math.abs(determinant) > 1e-4, key + ": singular bone transform");
        }
        return out;
    }

    private static float transform(float[] matrix, int m, float[] vertex, int v, int axis) {
        return matrix[m + axis] * vertex[v] + matrix[m + 4 + axis] * vertex[v + 1]
                + matrix[m + 8 + axis] * vertex[v + 2] + matrix[m + 12 + axis];
    }

    private static void require(boolean condition, String detail) {
        if (!condition) throw new AssertionError(detail);
    }
}
