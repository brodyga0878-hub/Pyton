package org.genewars.android.gl3d;

import org.genewars.core.GameState;
import org.genewars.core.Unit;
import org.genewars.core.WorldMap;

/** Independent camera/picking and immutable-snapshot checks, without Android. */
public final class Scene3DAcceptance {
    private static long terrainAttributesCompared, terrainIndicesCompared;
    private static int terrainFixtures;
    public static void main(String[] ignored) {
        int width = 32, height = 32;
        byte[] types = new byte[width * height];
        short[] elevations = new short[types.length];
        boolean[] blocked = new boolean[types.length];
        for (int z = 0; z < height; z++) for (int x = 0; x < width; x++) {
            types[z * width + x] = 3;
            elevations[z * width + x] = (short)(x * 30 + z * 16 + (x * z % 7) * 24);
        }
        WorldMap map = new WorldMap(width, height, types, elevations, blocked, "QA slope");
        Camera3D camera = new Camera3D(map);
        camera.setViewport(1440, 900); camera.centerOn(16, 16);
        int roundtrips = 0;
        float maxError = 0;
        for (int view = 0; view < 12; view++) {
            camera.orbit(view == 0 ? 0 : 30, view % 3 == 0 ? -12 : 6);
            camera.zoom(view % 2 == 0 ? 1.15f : 1 / 1.15f);
            float[] center = camera.projectGround(16, 16);
            require(center != null && Math.abs(center[0] - 720) < .01f && Math.abs(center[1] - 450) < .01f,
                    "Orbit camera target is not the viewport center");
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                float x = 16 + dx * 1.25f, z = 16 + dz * 1.25f;
                float[] projected = camera.projectGround(x, z);
                require(projected != null, "Visible ground point projected behind camera");
                float[] hit = camera.pickGround(projected[0], projected[1]);
                require(hit != null, "Projected ground point could not be picked");
                float error = (float)Math.hypot(hit[0] - x, hit[1] - z);
                require(error < .01f, "Render/pick mismatch: " + error + " at view " + view);
                maxError = Math.max(maxError, error); roundtrips++;
            }
        }
        float[] before = camera.projectGround(18, 16);
        camera.orbit(90, 0);
        float[] after = camera.projectGround(18, 16);
        require(Math.hypot(after[0] - before[0], after[1] - before[1]) > 10,
                "Orbit does not change world projection");
        require(camera.pickGround(Float.NaN, 0) == null, "Nonfinite screen input accepted");
        camera.orbit(Float.NaN, 0); camera.zoom(Float.POSITIVE_INFINITY);
        require(Float.isFinite(camera.snapshot().eyeX), "Bad gesture corrupted camera");

        GameState state = GameState.newImportedGame(map, 0, 123, 16, 16);
        Unit unit = state.units.get(0);
        unit.task = "Движение";
        Scene3DFrame frame = Scene3DFrame.capture(state, 1, true);
        Scene3DFrame.Actor actor = null;
        for (Scene3DFrame.Actor candidate : frame.actors) if (candidate.id == unit.id) actor = candidate;
        require(actor != null && actor.action == 1, "Movement state was not captured");
        float oldX = actor.x, oldHp = actor.hp, oldHeight = frame.terrain.height(16, 16);
        int oldCount = frame.actors.size();
        unit.x += 3; unit.hp -= 5; state.units.clear();
        float[] cameraBeforeMutation = camera.projectGround(16, 16);
        map.elevation[16 * width + 16] += 1024;
        require(actor.x == oldX && actor.hp == oldHp && frame.actors.size() == oldCount,
                "Snapshot retained live mutable actors");
        require(frame.terrain.height(16, 16) == oldHeight, "Snapshot retained mutable terrain arrays");
        float[] cameraAfterMutation = camera.projectGround(16, 16);
        require(cameraBeforeMutation[0] == cameraAfterMutation[0] && cameraBeforeMutation[1] == cameraAfterMutation[1],
                "Camera retained mutable source map arrays");
        boolean immutable = false;
        try { frame.actors.clear(); } catch (UnsupportedOperationException expected) { immutable = true; }
        require(immutable, "Snapshot actor list is mutable");
        require(Scene3DFrame.capture(state, Float.NaN, false).seconds == 0, "Nonfinite animation time accepted");
        checkTerrainMesh(8, 8, 0);
        checkTerrainMesh(8, 8, 1);
        checkTerrainMesh(17, 11, 2);
        checkTerrainMesh(128, 128, 0);
        checkTerrainMesh(128, 128, 1);
        checkTerrainMesh(128, 128, 2);
        checkNativeWorkActions();
        System.out.println("{\"passed\":true,\"projection_pick_roundtrips\":" + roundtrips
                + ",\"max_world_error\":" + maxError + ",\"immutable_actor_and_terrain_snapshot\":true,\"camera_map_copy\":true"
                + ",\"terrain_equivalence_fixtures\":" + terrainFixtures + ",\"terrain_float_attributes_bitwise_equal\":"
                + terrainAttributesCompared + ",\"terrain_indices_equal\":" + terrainIndicesCompared
                + ",\"native_research_work_capture\":true,\"native_healing_work_capture\":true}");
    }

    /** Commands must actually perform work; no fixture assigns display task strings. */
    private static void checkNativeWorkActions() {
        byte[] types = new byte[32 * 32]; java.util.Arrays.fill(types, (byte)3);
        WorldMap map = new WorldMap(32, 32, types, new short[types.length], new boolean[types.length], "QA work");
        GameState research = GameState.newImportedGame(map, 0, 123, 16, 16);
        Unit scientist = null;
        for (Unit unit : research.units) if (unit.kind == Unit.Kind.GENETICIST) scientist = unit;
        require(scientist != null, "No geneticist in imported crew");
        research.importCreature(0, scientist.x - 1.3, scientist.y, 0, 100, 100);
        research.select(scientist.id);
        require(research.researchSelected(), "Native research command rejected");
        research.update(.1);
        require(research.researchLevels[0] > 0 && scientist.task.startsWith("Изучение "),
                "Native research did not perform actual work");
        requireCapturedWork(research, scientist.id, "native research");

        GameState healing = GameState.newImportedGame(map, 0, 456, 16, 16);
        Unit healer = null, patient = null;
        for (Unit unit : healing.units) {
            if (unit.kind == Unit.Kind.GENETICIST) healer = unit;
            if (unit.kind == Unit.Kind.ENGINEER) patient = unit;
        }
        require(healer != null && patient != null, "Missing healer/patient crew");
        patient.hp = 40;
        healing.select(healer.id);
        require(healing.commandSelected(patient.x, patient.y), "Native contextual heal command rejected");
        healing.update(.1);
        require(patient.hp > 40 && patient.hp < patient.maxHp && healer.task.equals("Лечение"),
                "Native heal command did not heal the selected target");
        requireCapturedWork(healing, healer.id, "native healing");
    }

    private static void requireCapturedWork(GameState state, int id, String label) {
        Scene3DFrame frame = Scene3DFrame.capture(state, (float)state.elapsed, true);
        for (Scene3DFrame.Actor actor : frame.actors) if (actor.id == id) {
            require(actor.action == 3, label + " did not reach the renderer's work pose"); return;
        }
        throw new AssertionError(label + " actor missing from snapshot");
    }

    /** Re-evaluate each corner using the original slow renderer algorithm. */
    private static void checkTerrainMesh(int width, int height, int pattern) {
        byte[] types = new byte[width * height];
        short[] elevations = new short[types.length];
        for (int z = 0; z < height; z++) for (int x = 0; x < width; x++) {
            types[z * width + x] = (byte)((x * 13 + z * 7) & 255);
            elevations[z * width + x] = pattern == 0 ? (short)513 : pattern == 1
                    ? (short)(x * 119 - z * 73 - 1000)
                    : (short)((x * 1103515245 + z * 1234567 + x * z * 77) >>> 9);
        }
        // Exercise both signed-short extremes and discontinuities at map edges.
        if (pattern == 2) {
            elevations[0] = Short.MIN_VALUE;
            elevations[width - 1] = Short.MAX_VALUE;
            elevations[(height - 1) * width] = Short.MAX_VALUE;
            elevations[elevations.length - 1] = Short.MIN_VALUE;
        }
        WorldMap map = new WorldMap(width, height, types, elevations, new boolean[types.length], "QA terrain");
        Scene3DFrame.Terrain terrain = new Scene3DFrame.Terrain(map);
        TerrainMesh3D actual = TerrainMesh3D.build(terrain);
        float[] expected = new float[width * height * 4 * 13];
        int[] expectedIndices = new int[width * height * 6];
        int[] ox = {0, 1, 1, 0}, oz = {0, 0, 1, 1};
        int v = 0, k = 0;
        for (int z = 0; z < height; z++) for (int x = 0; x < width; x++) {
            int base = v / 13;
            for (int corner = 0; corner < 4; corner++) {
                float wx = x + ox[corner], wz = z + oz[corner];
                float nx = terrain.height(wx - 1, wz) - terrain.height(wx + 1, wz);
                float nz = terrain.height(wx, wz - 1) - terrain.height(wx, wz + 1), ny = 2;
                float length = (float)Math.sqrt(nx * nx + ny * ny + nz * nz);
                expected[v++] = wx; expected[v++] = terrain.height(wx, wz); expected[v++] = wz;
                expected[v++] = nx / length; expected[v++] = ny / length; expected[v++] = nz / length;
                expected[v++] = 1; expected[v++] = 1; expected[v++] = 1; expected[v++] = 0;
                expected[v++] = wx / 3.5f; expected[v++] = wz / 3.5f; expected[v++] = terrain.type(x, z);
            }
            expectedIndices[k++] = base; expectedIndices[k++] = base + 2; expectedIndices[k++] = base + 1;
            expectedIndices[k++] = base; expectedIndices[k++] = base + 3; expectedIndices[k++] = base + 2;
        }
        require(actual.vertices.length == expected.length && actual.indices.length == expectedIndices.length,
                "Terrain mesh size changed: " + width + "x" + height);
        for (int i = 0; i < expected.length; i++)
            require(Float.floatToIntBits(actual.vertices[i]) == Float.floatToIntBits(expected[i]),
                    "Terrain attribute differs at " + i + " for " + width + "x" + height + "/" + pattern
                    + ": " + actual.vertices[i] + " vs " + expected[i]);
        for (int i = 0; i < expectedIndices.length; i++)
            require(actual.indices[i] == expectedIndices[i], "Terrain index differs at " + i);
        terrainFixtures++;
        terrainAttributesCompared += expected.length; terrainIndicesCompared += expectedIndices.length;
    }

    private static void require(boolean condition, String detail) {
        if (!condition) throw new AssertionError(detail);
    }
}
